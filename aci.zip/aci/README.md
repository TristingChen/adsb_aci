# ACI
这是一套基于PHP端后台管理程序，兼容BOOSTRAP<br/> V3.0，集成了用户管理，用户组管理，模块管理，菜单管理，权限管理，非常友好的支持二次开发及代码一站式自定义模块导入，最最关键的一点的基于Codeigniter 。<br/>
侧重点在于：做后台管理，企业级应用，APP管理程序，APP移动应用API接口，做毕业设计更是小菜一碟。<br/>
<br/>
演示版本 http://demo.autocodeigniter.com <br/>
视频教程： http://www.youku.com/playlist_show/id_26135511.html<br/>
更多信息请访问http://www.autocodeigniter.com 。<br/>
QQ群：138471995<br/>
<hr/>
区别于其他权限系统特色<br/>
1. 权限可以控制在按钮上面，如果这个页面中的按钮是编辑连接按钮，而当前用户没有权限是不会显示出来的。<br/>
2. 增加了模块管理环节，没有注册的模块无法正常使用<br/>
