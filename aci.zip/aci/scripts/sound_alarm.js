/**
 * Created with JetBrains PhpStorm.
 * User: cjl
 * Date: 17-2-21
 * To change this template use File | Settings | File Templates.
 */

//
function sound_alarm(id,val,kind) {
        if(val == 1){
            var alarm_text = '您已确认告警信息并进行告警铃声开启吗';
        }else{
            var alarm_text = '您已确认告警信息并进行告警铃声关闭吗';
        }


          if(confirm(alarm_text)){
               $.ajax({
                  type: "POST",
                  url: SITE_URL+folder_name+"/appMonitor/sound_alarm_switch_off/"+id+"/"+val+"/"+kind,
                  async: false,
                  success:function(response){
                    response = JSON.parse(response);
                           
                    /*if(response.status){
                      if(val == 1){
                          $('.sound_alarm_switch').html('告警铃声关闭');
                          $('.sound_alarm_switch').attr('onclick','sound_alarm('+id+',0,'+kind+')');

                      }else{
                          $('.sound_alarm_switch').html('告警铃声开启');
                          $('.sound_alarm_switch').attr('onclick','sound_alarm('+id+',1,'+kind+')');
                      }
                    }*/
                     alert(response.tips);
                  },
                  error: function (request, status, error) {
                      //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                     console.log('error');
                  }
              });
          }
}
function cat_switch(id,val,kind) {
        if(kind == 1){
            var text = 'cat023';
        }else{
            var text = 'cat247';

        }
        if(val == 1){
            var alarm_text = '确认将'+text+'监控开启吗';
        }else{
            var alarm_text = '确认将'+text+'监控关闭吗';
        }
        if(confirm(alarm_text)){
             $.ajax({
                type: "POST",
                url: SITE_URL+folder_name+"/station/cat_switch/"+id+"/"+val+"/"+kind,
                async: false,
                success:function(response){
                  response = JSON.parse(response);
                  
                   alert(response.tips);
                },
                error: function (request, status, error) {
                    //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                   console.log('error');
                }
            });
        }
}
