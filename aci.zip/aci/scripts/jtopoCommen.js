/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-21
 * Time: 下午4:12
 * To change this template use File | Settings | File Templates.
 */

//获取节点信息
function GetNodeAxis(obj) {
    var str = "";
    if (obj.length == undefined) {
        obj.x = parseInt(obj.x);
        obj.y = parseInt(obj.y);
        str += obj.toJson();
    } else {
        for (var i = 0; i < obj.length; i++) {
            obj[i].x = parseInt(obj[i].x);
            obj[i].y = parseInt(obj[i].y);
            str += obj[i].toJson() + ',';
        }
        str = str.substring(0, str.length - 1);
    }
    return JSON.parse(str);
}

//保存坐标
function SaveAxis(obj,server_id,kind) {
    var data = GetNodeAxis(obj);
    //进行子节点的移动
    var url = SITE_URL+folder_name+"/AppMonitor/save_axis/"+server_id+'/'+kind;
    $.ajax({
        type: "POST",
        url:url,
        data: {json:data,node_name:obj.text}
    });
}

function old_bindNodeEvent(nodeObj) {
    nodeObj.mouseover(function (evt) {

    });

    nodeObj.mousemove(function (evt) {

    });
    nodeObj.mouseout(function (evt) {

    });

    //双击查看子级
    nodeObj.dbclick(function () {

    });

    nodeObj.click(function (evt) {

    });

    nodeObj.mouseup(function (evt) {
        SaveAxis(nodeObj);
    });
    nodeObj.mousedown(function (evt) {

    });
}
function bindNodeEvent(node,server_id,container,kind,is_station){

    /*  if(kind == 2){
     console.log(node)
     }*/
    node.dbclick(function(event){
        if(kind == 0){


            window.location.href="/adminpanel/appMonitor/one_hardware_detail/"+server_id;

        }else if(kind == 1){
            if(is_station == 0){
                window.location.href="/adminpanel/station/one_station_detail/"+server_id;
            }else{
                // window.location.href="/adminpanel/station/one_station_num_detail/"+server_id;
                window.location.href="/adminpanel/station/one_station_detail/"+server_id;
            }
        }else if(kind == 2){
            console.log(node)
            window.location.href="/adminpanel/station/one_rader_detail/"+server_id;
        }else if(kind == 3){
            window.location.href="/adminpanel/appMonitor/one_ntp_detail/"+server_id;
        }
    })
    //进行左键拖拉改变坐标
    node.mouseup(function (evt) {
        // console.log(evt.button)
        if(evt.button == 2){  //右键进行坐标的改变
            SaveAxis(node,server_id,kind);
        }

    });

    if(container){
        node.mousedrag(function(evt){
            var data = GetNodeAxis(node);
            //进行子节点的移动
            var new_x = data.x;
            var new_y = data.y;
            var container_child = container.childs;
            if(kind == 1){

                container_child[1].setLocation(new_x-14,new_y+40);
                container_child[2].setLocation(new_x+14,new_y+40);
            }else if(kind == 2){
                container_child[1].setLocation(new_x-20,new_y+45);
                container_child[2].setLocation(new_x+20,new_y+45);
            }else{
                for(var i=1;i<container_child.length;i++){
                    container_child[i].setLocation(new_x+i*8,new_y);
                }
            }


        })
    }

    node.mousedown(function (evt) {
        // console.log(evt)
        // console.log(evt)
        if(evt.button == 0){
            node.dragable = false;
        }else{
            node.dragable = true;
        }

    });


}
function bindAppEvent(obj){
    obj.mouseup(function (evt) {
        // console.log(evt.button)
        if(evt.button == 2){  //右键进行坐标的改变
            // SaveAxis(node,server_id);
            console.log(obj)

        }

    });

}

function link_moving(){
    CanvasRenderingContext2D.prototype.JtopoDrawPointPath=function(a,b,c,d,e,f){
        var animespeed=(new Date())/10;
        var xs=c- a,
            xy=d- b,
            l = Math.floor(Math.sqrt(xs * xs + xy * xy)),
            colorlength=50,
            j=l;
        xl=xs/ l,
            yl=xy/l;
        var colorpoint=animespeed%(l+colorlength)-colorlength;
        for(var i=0;i<j;i++){
            if(((i)>colorpoint)&&((i)<(colorpoint+colorlength))){
                this.beginPath();
                this.strokeStyle=e;
                this.moveTo(a+(i-1)*xl,b+(i-1)*yl);
                this.lineTo(a+i*xl,b+i*yl);
                this.stroke();
            }else{
                this.beginPath();
                this.strokeStyle=f;
                this.moveTo(a+(i-1)*xl,b+(i-1)*yl);
                this.lineTo(a+i*xl,b+i*yl)
                this.stroke();
            }
        }
    };
    return JtopoDrawPointPath;

}
