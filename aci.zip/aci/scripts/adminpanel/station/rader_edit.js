define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');


    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: '雷达名称不能为空'
                    }
                }
            }
        }    
    };
    var version = $('#version');
    
    $('#rader_kind').change(function(){
         var version_str = $('#rader_kind option:checked').attr('tmp_version');
         var version_arr = version_str.split(',');
         var option_html = '';
         $.each(version_arr,function(i,obj){
               option_html +='<option value="'+obj+'">'+obj+'</option>';
         })

         version.html(option_html);
    })
    if(!edit){
             var version_str = $('#rader_kind option:checked').attr('tmp_version');
            var option_html = '';
            var version_arr = version_str.split(',');
             $.each(version_arr,function(i,obj){
                   option_html +='<option value="'+obj+'">'+obj+'</option>';
             })

             version.html(option_html);
    }
   
   $('#add_dots').click(function(){
        var old_dot_num = $('#route_a .form-group:last').attr('dot_num');
        if(!old_dot_num){
            old_dot_num = 0;
        }
        var new_dot_num = Number(old_dot_num)+1;
        /*var dots_add = '<div class="form-group has-feedback" dot_num = '+new_dot_num+'>
        <label for="longtitude"  class="col-sm-2 control-label dots" >多边形点'+new_dot_num+':</label><div class="controls controls-row"><input name="longtitude[]"  class="span1" type="number" step="0.01" placeholder="经度"  value=""/><input name="latitude[]"  class="span1" type="number" step="0.01"    placeholder="纬度"  value=""/><span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span></div></div>';*/
        var dots_add = '<div class="form-group" dot_num = "'+new_dot_num+'">';
            dots_add += '<label for="longtitude"  class="col-sm-2 control-label dots" >转发地址'+new_dot_num+':</label>';
            dots_add += '<div class="controls controls-row col-xs-2">';
            dots_add += '<input name="resend_ip[]"  class="form-control validate[required]" type="text" placeholder="转发地址ip"  value=""/></div>';
            dots_add += '<div class="controls controls-row col-xs-2">';
            dots_add += '<input name="resend_port[]"  class="form-control validate[required]" type="number"   placeholder="转发地址端口"  value=""/></div>';
            dots_add += '<div class="controls controls-row col-xs-2">';
            dots_add += '<select id="cast_type" class="form-control" name="cast_type[]" onchange="show_next(this,\'\',0)"><option value="1">单播</option><option value="2">组播</option><option value="3">广播</option></select></div>';
            dots_add += '<div class="controls controls-row col-xs-2">';
            dots_add += '<span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span></div>';
            dots_add +=  '</div>';
        $('#route_a').append(dots_add);
    })
    $('#add_dots_b').click(function(){
        var old_dot_num = $('#route_b .form-group:last').attr('dot_num');
        if(!old_dot_num){
            old_dot_num = 0;
        }
        var new_dot_num = Number(old_dot_num)+1;
        /*var dots_add = '<div class="form-group has-feedback" dot_num = '+new_dot_num+'>
         <label for="longtitude"  class="col-sm-2 control-label dots" >多边形点'+new_dot_num+':</label><div class="controls controls-row"><input name="longtitude[]"  class="span1" type="number" step="0.01" placeholder="经度"  value=""/><input name="latitude[]"  class="span1" type="number" step="0.01"    placeholder="纬度"  value=""/><span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span></div></div>';*/
        var dots_add = '<div class="form-group" dot_num = "'+new_dot_num+'">';
        dots_add += '<label for="longtitude"  class="col-sm-2 control-label dots" >转发地址'+new_dot_num+':</label>';
        dots_add += '<div class="controls controls-row col-xs-2">';
        dots_add += '<input name="resend_ip_b[]"  class="form-control validate[required]" type="text" placeholder="转发地址ip"  value=""/></div>';
        dots_add += '<div class="controls controls-row col-xs-2">';
        dots_add += '<input name="resend_port_b[]"  class="form-control validate[required]" type="number"   placeholder="转发地址端口"  value=""/></div>';
        dots_add += '<div class="controls controls-row col-xs-2">';
        dots_add += '<select  class="form-control" name="cast_type_b[]" onchange="show_next(this,\'\',1)"><option value="1">单播</option><option value="2">组播</option><option value="3">广播</option></select></div>';
        dots_add += '<div class="controls controls-row col-xs-2">';
        dots_add += '<span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span></div>';
        dots_add +=  '</div>';
        $('#route_b').append(dots_add);
    })

    //通道a数据输出方式
    $('input[name=data_cast_type]').click(function(){
        if($(this).val() == 2){
            $('.cast_type_ip_group').show();
            
        }else{
            $('.cast_type_ip_group').hide();
        }
        if($(this).val() == 3){
            $('.broad_ip_a_group').show();
            $('.receive_ip_group').hide();
        }else{
             $('.broad_ip_a_group').hide();
            $('.receive_ip_group').show();
        }
    })

    //通道b数据输出方式
    $('input[name=data_cast_type_b]').click(function(){
        if($(this).val() == 2){
            $('.cast_type_ip_b_group').show();
            
        }else{
            $('.cast_type_ip_b_group').hide();
        }
        if($(this).val() == 3){
            $('.broad_ip_b_group').show();
            $('.receive_ip_b_group').hide();
        }else{
             $('.broad_ip_b_group').hide();
            $('.receive_ip_b_group').show();
        }
    })
   /* //转发地址的方式改变
    $('.cast_type_select').change(function(){
        console.log($(this).val());
        console.log($('.resend_group_ip_a_input'))
        $('.resend_group_ip_a_input').show();
    })
    $('.cast_type_b_select').change(function(){
        
    })*/

    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
        e.preventDefault();
        $("#dosubmit").attr("disabled","disabled");
        $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);		
        $.ajax({
            type: "POST",
            url: edit?SITE_URL+folder_name+"/station/rader_edit/"+id:SITE_URL+folder_name+"/station/rader_add/",
            data:  $("#validateform").serialize(),
            success:function(response){
                var dataObj=jQuery.parseJSON(response);
                if(dataObj.status)
                {
                    $.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
                    aci.GoUrl(SITE_URL+folder_name+'/station/rader_lists/',1);
                }else
                {
                    $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                    $("#dosubmit").removeAttr("disabled");
                }
            },
            error: function (request, status, error) {
                $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                $("#dosubmit").removeAttr("disabled");
            }
        });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);});

});
function remove_self(_this){
    var father_group = _this.parents('.form-group');
    father_group.remove();
}

function show_next(_this,resend_group_ip_a,kind = 0){
  if(kind == 0){
      var re_name = "resend_group_ip_a[]";
  }else{
      var re_name = "resend_group_ip_b[]";

  }
  if($(_this).val() == 2){
      var resend_str = '<div class="controls controls-row col-xs-2 resend_group_ip_a_input"><input name="'+re_name+'"  class="form-control validate[required]" type="text"  placeholder="转发组播地址"  value="'+resend_group_ip_a+'"/></div>';
      $(_this).parent().after(resend_str);
  }else{
      $(_this).parent().next().remove();
  }
}