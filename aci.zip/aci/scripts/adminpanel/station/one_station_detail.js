/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-9
 * Time: 下午3:10
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('message');

    var interval = setInterval(function(){
          $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/station/timing_one_station_detail/"+station_id,
            dataType:'json',
            async: false,
            success:function(response){
                // var station_body = $('.table3');
                if(response.status == false){
                    alert(response.tips);
                    clearInterval(interval);
                    $.scojs_message(response.tips, $.scojs_message.TYPE_ERROR);
                    aci.GoUrl(SITE_URL+folder_name+'/appMonitor/topo/',1);
                    return false;
                }
                var response_a = response[0];
                var response_b = response[1];
                var tbody_0 = $('.tbody_0');
                var tbody_1 = $('.tbody_1');
                if(response_a.alarm_status >0){
                     $('#sound_switch').show();
                      if(response_a['sound_switch'] == 1){
                        var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+station_id+',0,1)"><span class="glyphicon glyphicon-volume-down"></span>关闭告警铃声</p>';
                      }else{
                        var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+station_id+',1,1)"><span class="glyphicon glyphicon-volume-up"></span>开启告警铃声</p>';
                      }
                       
                      $('#sound_switch').html(p_obj);
                }else{

                     $('#sound_switch').hide();
                }
                if(response_a['cat023_switch'] == 1){
                  var cat023_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="cat_switch('+station_id+',0,1)"><span class="glyphicon glyphicon-pause"></span>关闭cat023监控</p>';
                }else{
                  var cat023_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="cat_switch('+station_id+',1,1)"><span class="glyphicon glyphicon-play"></span>开启cat023监控</p>';

                }
                if(response_a['cat247_switch'] == 1){
                  var cat247_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="cat_switch('+station_id+',0,2)"><span class="glyphicon glyphicon-pause"></span>关闭cat247监控</p>';
                }else{
                  var cat247_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="cat_switch('+station_id+',1,2)"><span class="glyphicon glyphicon-play"></span>开启cat247监控</p>';
                }
                /*if(response_a['current_work_pass'] == 'A'){
                  var cchange_curent_path_obj = '<p class="btn  btn-sm pull-right " onclick="change_current_path(\'A\',0)"><span class="glyphicon glyphicon-info-sign""></span>切换B通道为主用</p>';
                }else{
                  var cchange_curent_path_obj = '<p class="btn  btn-sm pull-right " onclick="change_current_path(\'B\',0)"><span class="glyphicon glyphicon-info-sign""></span>切换A通道为主用</p>';
                }*/

                $('#cat023').html(cat023_obj);
                $('#cat247').html(cat247_obj);
                // $('#change_curent_path').html(cchange_curent_path_obj);
                station_html(response_a,tbody_0,0);
                station_html(response_b,tbody_1,1);

                
                
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
               console.log(1212342)
            }
        });
    },1000);

/*    $('.cat_0').click(function(){
        $('.cat_0_info').toggle();
    })

    $('.cat_1').click(function(){
        $('.cat_1_info').toggle();
    })*/
});



function station_html(obj,tbody,kind){
  if(kind == 0){
      var path_box = $('path_box_0');
      var box = 'A';
  }else{
      var path_box = $('path_box_1');
      var box = 'B';

  }

  tbody.html('');
  var pit_str = '<tr>';
      pit_str += '<th>通道状态</th>';
      if(kind == 0){
        if(obj['current_work_pass'] == 'A'){
          var tmp_str = '主用';
        }else{
          var tmp_str = '备用';
        }
      }else{
        if(obj['current_work_pass'] == 'B'){
          var tmp_str = '主用';
        }else{
          var tmp_str = '备用';
        }
      }
      pit_str += '<th><button type="button" class="btn btn-default" title="点击进行改变状态操作" onclick="change_current_path(\''+obj.current_work_pass+'\',0,\''+box+'\')">'+tmp_str+'</button></th>';

      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>通道开启状态</th>';
      pit_str += '<th><button type="button" class="btn btn-default" title="点击进行改变状态操作" onclick="change_current_path(\''+obj.enable+'\',1,\''+box+'\')">'+obj.enable+'</button></th>';
      pit_str += '</tr>';

      pit_str += '<tr>';
      pit_str += '<th>通道发送ip</th>';
      pit_str += '<th>'+obj['send_ip']+'</th>';
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>通道发送端口</th>';
      pit_str += '<th>'+obj['send_port']+'</th>';
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>最小航迹数</th>';
      pit_str += '<th>'+obj['data_upper_limit']+'</th>';
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>当前航迹量</th>';

      if(obj['enable'].indexOf('开启') >= 0){
          if(Number(obj['channel_data']) >0 &&Number(obj['channel_data']) > Number(obj['data_upper_limit'])){
               pit_str += '<th>'+obj['channel_data']+'</th>';

          }else{
               pit_str += '<th class="red_status">'+obj['channel_data']+'</th>';
          }
      }else{
               pit_str += '<th>通道关闭未监控</th>';
      }
      
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>当前流量(Byte)</th>';
      pit_str += '<th>'+obj['channel_bite']+'</th>';
      pit_str += '</tr>';                                               

      pit_str += '<tr>';
      pit_str += '<th>实时版本</th>';
      pit_str += '<th>'+obj['channel_version']+'</th>';
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>版本匹配状态</th>';
      if(obj['enable'].indexOf('开启') >= 0){
          if(obj['cat247_switch'] == 1){
              if(obj['version_alarm'] == 0){
                pit_str += '<th>匹配</th>';
              }else{
                  if(obj['version_alarm'] == -1){
                        pit_str += '<th><dd class="red_status">数据流失</dd>  </th>';
                  }else{
                        pit_str += '<th><dd class="red_status">不匹配</dd>  </th>';
                  }
              }
          }else{
              pit_str += '<th>cat247监控关闭</th>';
          }

      }else{
                   pit_str += '<th>通道关闭未监控</th>';
      }
     
      
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>通道告警状态</th>';
      if(obj['enable'].indexOf('开启') >= 0){
          if(obj['channel_status'] == 1){
               pit_str += '<th>正常</th>';

          }else{
               pit_str += '<th><dd class="red_status">不正常</dd></th>';
          }
      }else{
               pit_str += '<th>通道关闭未监控</th>';
      }
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>状态报告时间</th>';
      pit_str += '<th>'+obj['channel_time']+'</th>';
      pit_str += '</tr>';
      pit_str += '<tr>';
      pit_str += '<th>cat023详情</th>';
      if(obj['enable'].indexOf('开启') >= 0){
          if(obj['cat023_switch'] == 1){
                if(obj['cat023_status'] == 1){
                    if(kind == 0){
                          pit_str += '<th><button type="button" class="btn btn-primary cat_0" onclick="show_html(0)">正常</button></th>';

                      }else{
                          pit_str += '<th><button type="button" class="btn btn-primary cat_1" onclick="show_html(1)">正常</button></th>';
                      }
              }else{
                  if(kind == 0){
                    pit_str += '<th><button type="button" class="btn btn-danger cat_0" onclick="show_html(0)">不正常</button></th>';

                  }else{
                    pit_str += '<th><button type="button" class="btn btn-danger cat_1" onclick="show_html(1)">不正常</button></th>';
                  }
              }
          }else{
                    if(kind == 0){
                          pit_str += '<th><button type="button" class="btn btn-default disabled cat_0" onclick="show_html(0)">cat023未监控</button></th>';

                      }else{
                          pit_str += '<th><button type="button" class="btn btn-default disabled cat_1" onclick="show_html(1)">cat023未监控</button></th>';
                      }

          }
      }else{
         if(kind == 0){
              pit_str += '<th><button type="button" class="btn btn-default disabled cat_0" onclick="show_html(0)">通道关闭</button></th>';

          }else{
              pit_str += '<th><button type="button" class="btn btn-default disabled cat_1" onclick="show_html(1)">通道关闭</button></th>';
          }
      }
          pit_str += '</tr>';
      tbody.append(pit_str);
      if(kind == 0){
          $('.a_data_file').html(obj['a_data_file']);
      }else{
          $('.b_data_file').html(obj['a_data_file']);
      }

}
function show_html(kind){
  if(kind==0){
    $('.cat_0_info').toggle();
  }else{
    $('.cat_1_info').toggle();
  }
}


function change_current_path(value,kind,key_name = 'A'){
            if(kind == 0){
                if(value == 'A'){
                  if(key_name == 'A'){
                      var text_a = '将该通道切换为备用';
                  }else{
                      var text_a = '将该通道切换为主用';

                  }
                }else{
                  if(key_name == 'A'){
                      var text_a = '将该通道切换为主用';
                  }else{
                      var text_a = '将该通道切换为备用';

                  }

                }
            }else{
                if(value.indexOf('开启') >= 0){
                    if(key_name == 'A'){
                        var text_a = '确定将A通道关闭吗';
                    }else{
                        var text_a = '确定将B通道关闭吗';
                    }
                }else{
                    if(key_name == 'A'){
                        var text_a = '确定将A通道开启吗';
                    }else{
                        var text_a = '确定将B通道开启吗';
                    }
                }
            }
            if(confirm(text_a)){
                     $.ajax({
                        type: "POST",
                        url: SITE_URL+folder_name+"/station/change_current_path/"+station_id,
                        dataType:'text',
                        data:{'value':value,'kind':kind,'key_name':key_name},
                        async: false,
                        success:function(response){
                          var obj = jQuery.parseJSON(response);
                          alert(obj.tips);
                        },
                        error: function (request, status, error) {
                            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                           console.log(1212342)

                        }
                    
                    });
            }else{
                
                // window.location.reload();
            }


}