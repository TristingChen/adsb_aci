define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

    $("#reverseBtn").click(function(){
        aci.ReverseChecked('pid[]');
    });
});