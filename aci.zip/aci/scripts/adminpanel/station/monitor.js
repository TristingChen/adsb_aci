﻿/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-9
 * Time: 下午3:10
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
	require('topo');

    var canvas = document.getElementById('canvas');
    var stage = new JTopo.Stage(canvas);
    //显示工具栏
    showJTopoToobar(stage);

    var scene = new JTopo.Scene();
    scene.background = img_path+'pstn/bg.jpg';

    var content_width = $('#content').width();
    var navbar_height = $("#navbar").height();
    var breadcrumb_height = $("#breadcrumb").height();
    var JTopoToobar_heigth = $('.jtopo_toolbar').height();
    var body_height =  $(document.body).height();
    $("#canvas").attr("width",content_width);
    $("#canvas").attr("height",body_height - navbar_height - breadcrumb_height - JTopoToobar_heigth - 50);
    var canvas_width = content_width;
    var canvas_height = body_height - navbar_height - breadcrumb_height - JTopoToobar_heigth - 50;
    
    function station_node(img, name,server_id,alarm_status,is_station){
        var node = new JTopo.Node(name);
        // node.setLocation(x, y);
        if(!img){
            img = 'Group1.png';
        }
        node.textPosition = "Bottom_Center";
        node.setImage(img_path+'pstn/' + img, true);
        if(alarm_status !=0){
            node.alarm = "报警";
        }else{
            node.alarm = null;
        }
        bindNodeEvent(node,server_id,1,is_station);
        scene.add(node);
        //appServer1(node);
        return node;
    }

    function rader_node(name,server_id,alarm_status){
        var node = new JTopo.Node(name);
        // node.setLocation(x, y);
        node.textPosition = "Bottom_Center";
        node.setImage(img_path+'pstn/satellite_antenna.png', true);
        if(alarm_status !=0){
            node.alarm = "报警";
        }else{
            node.alarm = null;
        }
        bindNodeEvent(node,server_id,2);
        scene.add(node);
        //appServer1(node);
        return node;
    }

   var flowLayout1 = JTopo.layout.FlowLayout(10, 40);

    function appServer1(){

        var container = new JTopo.Container('基站监控');
        container.textPosition="Top_Center";
        container.fontColor = '255,255,255';
        container.font="18px Consolas";
        container.layout = flowLayout1;
        // container.fillColor = img_path+'pstn/bg.jpg';
        container.setBound(10, 30, canvas_width*0.7, canvas_height); 
        // container.childDragble = true;
        container.alpha = 0.2;
        scene.add(container);
        return container;
    }
   var flowLayout2 = JTopo.layout.FlowLayout(40, 40);

    function appServer2(notes){
        var container = new JTopo.Container('雷达监控');
        container.setLocation(100,100);
        container.textPosition="Top_Center";
        container.fontColor = '255,255,255';
        container.font="18px Consolas";
        container.layout = flowLayout2;
        // container.fillColor = img_path+'pstn/bg.jpg';
        container.setBound(canvas_width*0.7, 30, canvas_width*0.3, canvas_height*0.5); 
        // container.childDragble = true;
        container.alpha = 0.2;
        // container.setBound(20,20,300,300);
        scene.add(container);
        return container;
    }
    function appServer3(notes){
        var container = new JTopo.Container('数据基站监控');
        container.setLocation(100,100);
        container.textPosition="Top_Center";
        container.fontColor = '255,255,255';
        container.font="18px Consolas";
        container.layout = flowLayout2;
        // container.fillColor = img_path+'pstn/bg.jpg';
        container.setBound(canvas_width*0.71, canvas_height*0.55, canvas_width*0.3, canvas_height*0.5); 
        // container.childDragble = true;
        container.alpha = 0.2;
        // container.setBound(20,20,300,300);
        scene.add(container);
        return container;
    }

    //初始时间的进行画图和状态判断
    var station_arr = data_list.station;
    var rader_arr = data_list.rader;
    console.log(rader_arr);
    var container1 = appServer1(); //基站容器
    var container2 = appServer2(); //雷达容器
    var container3 = appServer3(); //雷达容器
    var station_node_arr = new Array();
    var rader_node_arr = new Array();
     $.each(station_arr,function(i,obj){ 
	 console.log(obj);
                 var node1 = station_node(obj.station_img,obj.station_name,obj.station_id,obj.alarm_status,obj.is_station);
                 // var  station_obj = {station:node1};
                 station_node_arr[obj.station_id] = node1;
                 if(obj.is_station == 1){
                     container3.add(node1);
                 }else{
                     container1.add(node1);
                 }
    });
     $.each(rader_arr,function(i,obj){ 
                 node2 = rader_node(obj.name,obj.id,obj.rader_alarm);
                 rader_node_arr[obj.id] = node2;
                 container2.add(node2);

    });
     console.log(rader_node_arr);
    setInterval(function(){
        $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/station/stations_status",
            // data:data_list,
            dataType:'json',
            async: true,
            success:function(response){
                // json_data = jQuery.parseJSON(response);1行12个  10 -- 1400的距离  x=10+110i  y=10+80i
                //基站添加与报警
                // console.log(response);

                // response = jQuery.parseJSON(response);
                var new_station_arr = response.station;
                var new_rader_arr = response.rader;

                $.each(new_station_arr,function(i,obj){ 
                     if(jQuery.inArray(obj.station_id,station_arr)){
                            station_node_arr[obj.station_id].setImage(img_path+'pstn/' + obj.station_img, true); //时刻进行背景图的更换
                            if(obj.alarm_status != 0){
                                    if(station_node_arr[obj.station_id].alarm != '报警'){
                                        station_node_arr[obj.station_id].alarm = '报警';
                                    }else{
                                        station_node_arr[obj.station_id].alarm = null;
                                    }

                            }else{
                                    station_node_arr[obj.station_id].alarm = null;

                            }
                     }else{
                         var node1 = station_node(obj.station_img,obj.station_name,obj.station_id,obj.alarm_status,obj.is_station);
                         station_node_arr[obj.station_id] = node1;
                         station_arr[obj.station_id] = obj;
                         container1.add(node1);
                     }
                });

                $.each(new_rader_arr,function(i,obj){ 
                     if(obj.rader_alarm == 1){
                            if(rader_node_arr[obj.id].alarm == '报警'){
                                 rader_node_arr[obj.id].alarm = null;
                            }else{
                                 rader_node_arr[obj.id].alarm = '报警';
                            }
                     }else{
                            rader_node_arr[obj.id].alarm = null;

                     }
                });


            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
            }
        });
    },3000);

    stage.add(scene);
});








//根据节点名获取容器中的子元素
function get_container_child(container,text){
    var child_node;
    $.each(container.childs,function(i,obj){
        if(obj.text.toLowerCase() == text.toLowerCase()){
            child_node = obj;
        }
    });
    return child_node;
}

//添加连线
function addLink(fromNode, toNode, text, line_color,f=false) {
    if(f){
        var link = new JTopo.Link(fromNode, toNode, text);
    }else{
        var link = new JTopo.FoldLink(fromNode, toNode, text);
    }
   
    link.shadow = false;
    link.lineWidth = 2;
    link.bundleOffset = 60; // 折线拐角处的长度
    link.bundleGap = 20; // 线条之间的间隔
    link.textOffsetY = 3; // 文本偏移量（向下3个像素）
    link.strokeColor = line_color;
    link.direction = 'vertical';
   
    link.id = toNode.id;
    bindLinkEvent(link);
    return link;
}

var currentLink = null;
//绑定连线事件
function bindLinkEvent(link) {
    link.mousedown(function (evt) {
        currentLink = link;
        if (evt.button == 0) {
            //console.log(event);
            //左键 可拖动
            currentLink.dragable = true;
        } else if (evt.button == 2) {
            scene.dragable = false;
            stage.dragable = false;
            var content = document.getElementById('content');
            var menu = document.getElementById('linkmenu');
            /*获取当前鼠标右键按下后的位置，据此定义菜单显示的位置*/
            var rightedge = content.clientWidth - evt.clientX;
            var bottomedge = content.clientHeight - evt.clientY;
            /*如果从鼠标位置到容器右边的空间小于菜单的宽度，就定位菜单的左坐标（Left）为当前鼠标位置向左一个菜单宽度*/
            if (rightedge < menu.offsetWidth)
                menu.style.left = content.scrollLeft + evt.clientX - menu.offsetWidth + "px";
            else
            /*否则，就定位菜单的左坐标为当前鼠标位置*/
                menu.style.left = content.scrollLeft + evt.clientX + "px";

            /*如果从鼠标位置到容器下边的空间小于菜单的高度，就定位菜单的上坐标（Top）为当前鼠标位置向上一个菜单高度*/
            if (bottomedge < menu.offsetHeight)
                menu.style.top = content.scrollTop + evt.clientY - menu.offsetHeight + "px";
            else
            /*否则，就定位菜单的上坐标为当前鼠标位置*/
                menu.style.top = content.scrollTop + evt.clientY + "px";

            /*设置菜单可见*/
            $("#menuMask").css("display", "block");
            menu.style.display = "block";
        }
    });
}
//kind=1为基站 kind=2为雷达
function bindNodeEvent(node,server_id,kind=1,is_station=0){ 
    // console.log(node)
    node.click(function(event){
        // window.location.href="/adminpanel/appMonitor/one_hardware_detail/"+server_id;
        if(kind == 1){
            if(is_station == 0){
                window.location.href="/adminpanel/station/one_station_detail/"+server_id;
            }else{
                window.location.href="/adminpanel/station/one_station_num_detail/"+server_id;
            }
        }else{
            window.location.href="/adminpanel/station/one_rader_detail/"+server_id;
        }
    })
    // alert(node.elementType);
}


