/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-21
 * Time: 下午4:12
 * To change this template use File | Settings | File Templates.
 */

//获取节点信息
function GetNodeAxis(obj) {
    var str = "";
    if (obj.length == undefined) {
        obj.x = parseInt(obj.x);
        obj.y = parseInt(obj.y);
        str += obj.toJson();
    } else {
        for (var i = 0; i < obj.length; i++) {
            obj[i].x = parseInt(obj[i].x);
            obj[i].y = parseInt(obj[i].y);
            str += obj[i].toJson() + ',';
        }
        str = str.substring(0, str.length - 1);
    }
    return JSON.parse(str);
}

//保存坐标
function SaveAxis(obj) {
    var data = GetNodeAxis(obj);
    var url = SITE_URL+folder_name+"/"+controller_name+"/save_axis";
    $.ajax({
        type: "POST",
        url:url,
        data: {json:data,node_name:obj.text}
    });
}

function bindNodeEvent(nodeObj) {
    nodeObj.mouseover(function (evt) {

    });

    nodeObj.mousemove(function (evt) {

    });
    nodeObj.mouseout(function (evt) {

    });

    //双击查看子级
    nodeObj.dbclick(function () {

    });

    nodeObj.click(function (evt) {

    });

    nodeObj.mouseup(function (evt) {
        SaveAxis(nodeObj);
    });
    nodeObj.mousedown(function (evt) {

    });
}

