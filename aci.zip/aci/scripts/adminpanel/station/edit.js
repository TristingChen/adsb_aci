define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

    $(".uploadThumb_a").click(function(){
        $.extDialogFrame(SITE_URL+folder_name+"/user/upload/thumb/thumb/1",{model:true,width:600,height:250,title:'请上传...',buttons:null});
    });
    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            station_name: {
                validators: {
                    notEmpty: {
                        message: '基站名称不能为空'
                    }
                }
            },
            data_version: {
                validators: {
                    notEmpty: {
                        message: '基站输出数据版本不能为空'
                    },
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: '数据版本只能全为数字'
                    }
                }
            },
            sac_code: {
                validators: {
                    notEmpty: {
                        message: 'SAC码不能为空'
                    },
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: 'SAC码只能全为数字'
                    }
                }
            },
            sic_code: {
                validators: {
                    notEmpty: {
                        message: 'SIC码不能为空'
                    },
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: 'SIC码只能全为数字'
                    }
                }
            },
            station_height:{
                validators: {
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: '基站高度只能全为数字'
                    }
                }
            },
            station_status: {
                validators: {
                    notEmpty: {
                        message: '请选择基站状态'
                    }
                }
            },
            in_work_option: {
                validators: {
                    notEmpty: {
                        message: '请选择基站通道'
                    }
                }
            },
            longtitude:{
                validators: {
                    notEmpty: {
                        message: '基站经度（度）不能为空'
                    },
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: '基站经度（度）只能全为数字'
                    }
                }
            },
            latitude:{
                validators: {
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: '基站纬度只能全为数字'
                    }
                }
            },
            /*station_ip:{
                validators:{
                    notEmpty:{
                        message:'请输入基站IP'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },*/
            cast_type_A:{
                validators:{
                    notEmpty:{
                        message:'请选择A路数据传输方式'
                    }
                }
            },
            send_ip_A:{
                validators:{
                    notEmpty:{
                        message:'请输入A路数据发送IP'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },
            channel_ip_A:{
                validators:{
                    notEmpty:{
                        message:'请输入A路通道IP'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },
            send_port_A:{
                validators:{
                    notEmpty:{
                        message:'请输入A路数据发送端口'
                    },
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: '数据发送端口只能全为数字'
                    }
                }
            },
            exchange_eth_id_A:{
                validators:{
                    notEmpty:{
                        message:'请选择交换服务器A路数据接收网口'
                    }
                }
            },
            channel_status_A:{
                validators:{
                    notEmpty:{
                        message:'请选择A路数据通道状态'
                    }
                }
            },
            cast_type_B:{
                validators:{
                    notEmpty:{
                        message:'请选择B路数据传输方式'
                    }
                }
            },
            send_ip_B:{
                validators:{
                    notEmpty:{
                        message:'请输入B路数据发送IP'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },
            channel_ip_B:{
                validators:{
                    notEmpty:{
                        message:'请输入B路通道IP'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },
            send_port_B:{
                validators:{
                    notEmpty:{
                        message:'请输入B路数据发送端口'
                    },
                    regexp: {
                        regexp: /^[0-9\.]+$/,
                        message: '数据发送端口只能全为数字'
                    }
                }
            },
            exchange_eth_id_B:{
                validators:{
                    notEmpty:{
                        message:'请选择交换服务器B路数据接收网口'
                    }
                }
            },
            channel_status_B:{
                validators:{
                    notEmpty:{
                        message:'请选择B路数据通道状态'
                    }
                }
            }
        }
    };
    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
        e.preventDefault();
        $("#dosubmit").attr("disabled","disabled");
        $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);
        $.ajax({
            type: "POST",
            url: edit?SITE_URL+folder_name+"/station/edit/"+id:SITE_URL+folder_name+"/station/add/",
            data:  $("#validateform").serialize(),
            success:function(response){
                var dataObj=jQuery.parseJSON(response);
                if(dataObj.status)
                {
                    $.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
                    aci.GoUrl(SITE_URL+folder_name+'/station/lists/',1);
                }else
                {
                    $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                    $("#dosubmit").removeAttr("disabled");
                }
            },
            error: function (request, status, error) {
                $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                $("#dosubmit").removeAttr("disabled");
            }
        });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);});

});
