﻿/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-9
 * Time: 下午3:10
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
    setInterval(function(){
          $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/station/timing_one_rader_detail/"+rader_id,
            dataType:'json',
            async: true,
            success:function(response){
                // var station_body = $('.dataTable tbody');
                if(response){
                      var rader_bag = $('.rader_bag').html(response.rader_bag);
                      var r_td = '<td>'+response.name+'</td>';
                      if(response.path_switch_a == 1){
                         r_td += '<td>开启</td>';
                      } else {
                         r_td += '<td>关闭</td>';
                      }
                        r_td += '<td>'+response.rader_a_bag+'</td>';
                        if(response.path_switch_a == 0){
                          r_td += '<td>A通道未监控</td>';
                        }else{
                          if(response.path_a_alarm == 1){
                              r_td += '<td class="red_status">不正常:A通道数据量为0</td>';
                          }else{
                              r_td += '<td>正常</td>';
                          }

                        }
                      if(response.path_switch_b == 1){
                         r_td += '<td>开启</td>';
                      } else {
                         r_td += '<td>关闭</td>';
                      }
                        r_td += '<td>'+response.rader_b_bag+'</td>';
                        if(response.path_switch_b == 0){
                          r_td += '<td>B通道未监控</td>';
                        }else{
                          if(response.path_b_alarm == 1){
                              r_td += '<td class="red_status">>不正常:B通道数据量为0</td>';
                          }else{
                              r_td += '<td>正常</td>';
                          }

                        }
                      if(response.report_time == '1970-01-01 00:00:00'){
                         r_td += '<td>数据未能成功推送</td>';
                      } else {
                         r_td += '<td>'+response.report_time+'</td>';
                      }
                      if(response.rader_alarm == 1){
                         r_td += '<td class="red_status">不正常</td>';

                      }else{
                         r_td += '<td>正常</td>';

                      }
                      $('#rader_body').html('');
                      $('#rader_body').html(r_td);

                      // $('.rader_time').html(response.dateline);
                      if(response.rader_alarm == 0){
                        $('.rader_alarm').html('正常');
                           $('#sound_switch').hide();

                      }else{
                        $('.rader_alarm').html('不正常');
                        $('#sound_switch').show();
                            if(response['sound_switch'] == 1){
                              var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+rader_id+',0,2)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声关闭</p>'
                            }else{
                              var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+rader_id+',1,2)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声开启</p>'
                            }
                            $('#sound_switch').html(p_obj);
                      }


                }else{
                    $('#rader_body').html('');
                    $('#rader_body').html('<td>数据未能成功推送</td><td>数据未能成功推送</td><td>数据未能成功推送</td><td>数据未能成功推送</td><td>数据未能成功推送</td><td>数据未能成功推送</td><td>数据未能成功推送</td><td>数据未能成功推送</td><td>数据未能成功推送</td>');
                }
                
                
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
               console.log(1212342)
            }
        });
    },1000);

    
});
