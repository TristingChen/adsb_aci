define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

    $("#reverseBtn").click(function(){
        aci.ReverseChecked('pid[]');
    });
     $("#pro_file").click(function(){
         $.ajax({
	        type: "POST",
	        url: SITE_URL+folder_name+"/station/produce_xml",
	        dataType:'text',
	        async: false,
	        success:function(response){
	          if(response){
                alert('配置文件生成成功');
              } else{
                alert('配置文件生成失败');
              }
       		 },
	        error: function (request, status, error) {
	            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
	        }
    	});
    });

     var sta_id,old_current_path,old_path_switch,old_enable_a,old_enable_b;
     $('.shift-main').click(function() {
          old_current_path = $(this).attr('old_current_path');
          sta_id = $(this).attr('sta_id');
          $('#myModalLabel').attr('attd',sta_id);
         // var current_td = $(this).parents('tr').find('.current_td');
         old_path_switch = $(this).attr('path_switch');
         old_enable_a = $(this).attr('enable_a');
         old_enable_b = $(this).attr('enable_b');

         var station_name = $(this).attr('station_name');
         var current_work_pass2 = $('#current_work_pass2');
         var current_work_pass3 = $('#current_work_pass3');
         var station_name_again = $('#station_name_again');
         var path_switch2 = $('#path_switch2');
         var path_switch3 = $('#path_switch3'); 
         var enable_a2 = $('#enable_a2');
         var enable_a3 = $('#enable_a3');
         var enable_b2 = $('#enable_b2');
         var enable_b3 = $('#enable_b3');

         if(old_current_path ==1){
            current_work_pass2.prop('checked',true);
            current_work_pass3.removeAttr('checked');

         }else{
            current_work_pass2.removeAttr('checked');
            current_work_pass3.prop('checked',true);
         }

         station_name_again.html(station_name+'总开关:');
         if(path_switch2.val() == old_path_switch){
            path_switch2.prop('checked',true);
         }else{
            path_switch2.removeAttr('checked');

         }
         if(path_switch3.val() == old_path_switch){
            path_switch3.prop('checked',true);
         }else{
            path_switch3.removeAttr('checked');

         }
         if(old_path_switch == 0){
            $('.path_detail').hide();
         }else{
            if(enable_a2.val() == old_enable_a){
                enable_a2.prop('checked',true);
             }else{
                enable_a2.removeAttr('checked');

             }
             if(enable_a3.val() == old_enable_a){
                enable_a3.prop('checked',true);
             }else{
                enable_a3.removeAttr('checked');

             }

             if(enable_b2.val() == old_enable_b){
                enable_b2.prop('checked',true);
             }else{
                enable_b2.removeAttr('checked');

             }
             if(enable_b3.val() == old_enable_b){
                enable_b3.prop('checked',true);
             }else{
                enable_b3.removeAttr('checked');

             }
         }
         
     });


   /* $(".change_current_path").on('click',function(){
        // var cur_data = $('#modal_current_path').children('option:selected').val();

            var current_work_pass = $("input[name='current_work_pass']:checked").val();
            var path_switch = $("input[name='path_switch']:checked").val();
            var enable_a = $("input[name='enable_a']:checked").val();
            var enable_b = $("input[name='enable_b']:checked").val();
            var hardware_id_dom = $("input[name ='hardware_id[]']:checked");
            // var hardware_id_arr = {};
            // var hardware_id_arr[0] = hardware_id_dom;
            if(hardware_id_dom.length == 0){
                alert('通知服务器必选');
                return false;
            }

           

            var hardware_id_arr = [];
            $(hardware_id_dom).each(function(i,obj){
                 hardware_id_arr.push($(this).val());
            });

            var data_obj = {
                'hardware_id_arr':hardware_id_arr,
                'current_work_pass':current_work_pass,
                'path_switch':path_switch,
                'enable_a':enable_a,
                'enable_b':enable_b
            };
            console.log($(this));
            return false;
            if(confirm('确定切换吗')){
                console.log(data_obj)
                
                 data_obj[$(this).attr('name')] = $(this).val();
                     $.ajax({
                        type: "POST",
                        url: SITE_URL+folder_name+"/station/change_current_path/"+sta_id,
                        data:data_obj,
                        dataType:'text',
                        async: false,
                        success:function(response){
                            if(response == 1){
                                alert('信息修改成功');
                                window.location.reload();
                            }else{
                                 alert('信息修改失败');
                            }
                            
                        },
                        error: function (request, status, error) {
                            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                           console.log(1212342)

                        }
                    
                    });
            }

          
        $('#myModal').hide();
        
    })*/


});

/*function choose_this(_this){
    _this.attr('checked','checked');
}*/



/*function remove_disable(_this){
    $('.btn-radio').remove("disabled"); 
}*/

function change_current_path(_this){
            var event = window.event;
            var sta_id = $('#myModalLabel').attr('attd');
            var current_work_pass = $("input[name='current_work_pass']:checked").val();
            var path_switch = $("input[name='path_switch']:checked").val();
            var enable_a = $("input[name='enable_a']:checked").val();
            var enable_b = $("input[name='enable_b']:checked").val();
            var hardware_id_dom = $("input[name ='hardware_id[]']:checked");
            // var hardware_id_arr = {};
            // var hardware_id_arr[0] = hardware_id_dom;
            if(hardware_id_dom.length == 0){
                alert('通知服务器必选');
                $('#myModal').hide();
                return false;
            }

            var hardware_id_arr = [];
            $(hardware_id_dom).each(function(i,obj){
                 hardware_id_arr.push($(this).val());
            });
            var che_name = _this.attr('name');
            var val = _this.val();
            
            var data_obj = {
                'hardware_id_arr':hardware_id_arr,
                'name':che_name,
                'value':val
            };

           /* event.preventDefault();
                console.log(event)
                return false;*/
            if(confirm('确定切换吗')){
                     $.ajax({
                        type: "POST",
                        url: SITE_URL+folder_name+"/station/change_current_path/"+sta_id,
                        data:data_obj,
                        dataType:'text',
                        async: false,
                        success:function(response){
                            if(response == 1){
                                alert('信息修改成功');
                                window.location.reload();
                            }else{
                                 alert('信息修改失败');
                            }
                            
                        },
                        error: function (request, status, error) {
                            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                           console.log(1212342)

                        }
                    
                    });
            }else{
                
                window.location.reload();
            }

          
        



}