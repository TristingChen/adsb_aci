﻿/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-9
 * Time: 下午3:10
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
    setInterval(function(){
          window.location.reload();
    },10000);

    
});

