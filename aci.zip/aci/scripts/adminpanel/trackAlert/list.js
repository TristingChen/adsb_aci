/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-13
 * Time: 下午3:35
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
});