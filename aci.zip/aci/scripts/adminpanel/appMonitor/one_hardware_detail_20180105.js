/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-23
 * Time: 下午2:33
 * To change this template use File | Settings | File Templates.
 */
define(function(require){
    // var $ = require('jquery');
    require('bootstrap');
    require('highcharts');
    // require('exporting');
    // require('series-label');
    require('message');

    var first_load = 0;



var cpu_used_percent_arr = JSON.parse(cpu_used_arr);
var storage_used_percent_arr = JSON.parse(storage_used_arr);
create_charts('#container_1','cpu占用百分比动态图',cpu_used_percent_arr,1);
if(server_kind != 3){
   create_charts('#container_2','内存占用百分比动态图',storage_used_percent_arr,2);
}



  $('#shift_main').click(function(){
        is_main_limit = JSON.parse(is_main_limit);
        console.log(is_main_limit);
        if(is_main_limit['is_main'] == 1){
          var new_main = 0;
          var new_main_str = '备用服务器';
        }else{
          var new_main = 1;
          var new_main_str = '主用服务器';

        }
        if(confirm('确定要切换至'+new_main_str)){ 

              $.ajax({
              type: "POST",
              url: SITE_URL+folder_name+"/appMonitor/shift_main/"+hardware_id+'/'+new_main,
              async: false,
              success:function(response){
                  if(response ==1){
                      alert('切换成功')
                  }else{
                      alert('切换失败');
                  }

                  //进行table表格的替换
                 
              },
              error: function (request, status, error) {
                  //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
              }
               
          });
      }

  });

  $('.use_server').click(function(){
      var server_id = $(this).attr('server_id');
      var change_info='';
      console.log(server_id)
      if(server_id == 1){
           change_info = '关机';
      }else if(server_id == 0){
           change_info = '重启';
      }
      if(confirm('确定要'+change_info)){ 

              $.ajax({
              type: "POST",
              url: SITE_URL+folder_name+"/appMonitor/use_server/"+hardware_id+'/'+server_id,
              // data:'server_id ='+server_id,
              async: false,
              success:function(response){
                  json_res = JSON.parse(response);
                  alert(json_res.tips);
                  //进行table表格的替换
              },
              error: function (request, status, error) {
                  //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
              }
               
          });
      }


function create_charts(obj,name,n_data,kind){
   var json_res 
   var chart = { 
      type: 'spline',
      animation: Highcharts.svg, // don't animate in IE < IE 10.
      marginRight: 10,
      events: {
         load: function () {
            // set up the updating of the chart each second
            var series = this.series[0];
           
              setInterval(function () {
              
               json_res = get_data();

               if(kind == 1){
                  var x = (new Date()).getTime();
                  var y = json_res.cpu_used['cpu_used_percent'];
               }else{
                  var x = (new Date()).getTime();
                  var y = json_res.storage_name[1]['all_block_used_percent'];
               }

               series.addPoint([x,y],true,true);

            }, 5000);
            
         }
      }
   };
   var title = {
      text: name   
   };   
   var xAxis = {
      type: 'datetime',
      tickPixelInterval: 150
   };
   var yAxis = {
      title: {
         text: '100%'
      },
      max:100,
      min:0,
      tickInterval:10,
      tickPosition:[0,20,50,100],
      plotLines: [{
         value: 0,
         width: 1,
         color: '#808080'
      }]
   };
   var tooltip = {
      formatter: function () {
      return '<b>' + this.series.name + '</b><br/>' +
         Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', this.x) + '<br/>' +
         Highcharts.numberFormat(this.y, 2);
      }
   };
   var plotOptions = {
      area: {
         pointStart: 1940,
         marker: {
            enabled: false,
            symbol: 'circle',
            radius: 2,
            states: {
               hover: {
                 enabled: true
               }
            }
         }
      }
   };
   var legend = {
      enabled: false
   };
   var exporting = {
      enabled: false
   };
   var series= [{
      name: 'data',
      data: (function () {
         var data = [];time = (new Date()).getTime(),i;
         for (var i = 0; i <= 4; i++) {
           
                 data.push({
                   x:time + (i-4)*5000,
                   y:n_data[i]['y']
                 })
          };             
         return data;
      }()) 
   }];     

   var credits= {
        enabled:false
   };
   var json = {};   
   json.chart = chart; 
   json.title = title;     
   json.tooltip = tooltip;
   json.xAxis = xAxis;
   json.yAxis = yAxis; 
   json.legend = legend;  
   json.exporting = exporting;   
   json.series = series;
   json.plotOptions = plotOptions;
   json.credits = credits;
   
   Highcharts.setOptions({
      global: {
         useUTC: false
      }
   });
   $(obj).highcharts(json);
}

  

  })




});
function get_data(){
      var json_res='';
      $.ajax({
        type: "POST",
        url: SITE_URL+folder_name+"/appMonitor/timing_hardware_detail/"+hardware_id,
        async: false,
        success:function(response){
            json_res = JSON.parse(response);
               var tbody1 = $('.table1');
               var tbody2 = $('.table2');
               var tbody3 = $('.table3');
               var main_info = $('#main_info');
               if(main_info == 1){
                  main_info.html('(主用)');
               }else{
                  main_info.html('(备用)');
               }
               net_html(json_res['net_name'],tbody2);
               if(server_kind != 3){
                        pit_html(json_res['storage_name'],tbody1)
                        process_html(json_res['process_name'],tbody3)               
               }
           
        },
        error: function (request, status, error) {
            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
        }
         
    });
      return json_res;
    
}


function pit_html(obj,tbody){
   var pit_res = '';
      var objlen = 0;
      for(var i in obj){
         objlen++;
      }
      tbody.html('');
      for (var i = 2; i <= objlen; i++) {
               var pit_str = '<tr>'
                pit_str +=  '<td>'+obj[i].storage_name+'</td>';
                pit_str +=   '<td>'+obj[i].all_block_size+'</td>';
                pit_str +=   '<td>'+obj[i].all_blocked_size+'</td>';
                pit_str +=   '<td>'+obj[i].all_block_used_percent+'</td>';
                if(obj[i].status){
                  pit_str +=   '<td>正常</td>';
                }else{
                  pit_str +=   '<td>不正常</td>';

                }
                
                pit_str += '</tr>'
                tbody.append(pit_str);
      };
}

function net_html(obj,tbody){
    var pit_res = '';
      var objlen = 0;
      for(var i in obj){
         objlen++;
      }
      tbody.html('');
      for (var i = 1; i <= objlen; i++) {
            var pit_str = '<tr>'
             pit_str +=  '<td>'+obj[i].net_name+'</td>';
             pit_str +=   '<td>'+obj[i].ins_num+'</td>';
             pit_str +=   '<td>'+obj[i].lost_ins_num+'</td>';
             pit_str +=   '<td>'+obj[i].wrong_ins_num+'</td>';
             pit_str +=   '<td>'+obj[i].out_num+'</td>';
             pit_str +=   '<td>'+obj[i].lost_out_num+'</td>';
             pit_str +=   '<td>'+obj[i].wrong_out_num+'</td>';
             if(obj[i].status){
               pit_str +=   '<td>正常</td>';
             }else{
               pit_str +=   '<td>不正常</td>';

             }
             pit_str += '</tr>'
             tbody.append(pit_str);
      };

}

function  process_html(obj,tbody){
    var pit_res = '';
      var objlen = 0;
      for(var i in obj){
         objlen++;
      }
      tbody.html('');
      for (var i = 1; i <= objlen; i++) {
             var pit_str = '<tr>'
             pit_str +=  '<td>'+obj[i].process_name+'</td>';
             pit_str +=   '<td>'+obj[i].process_path_name+'</td>';
             pit_str +=   '<td>'+obj[i].process_cpu_used_add_status+'</td>';
             pit_str +=   '<td>'+obj[i].process_storage_used+'</td>';
             
             if(obj[i].status){
               pit_str +=   '<td>正常</td>';
             }else{
               pit_str +=   '<td>不正常</td>';

             }
             pit_str += '</tr>'
             tbody.append(pit_str);
      };

}