/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-23
 * Time: 下午2:33
 * To change this template use File | Settings | File Templates.
 */
define(function(require){
    var $ = require('jquery');
    require('bootstrap');
    require('highstock');
    require('exporting');
    require('message');

    Highcharts.setOptions({
        global : {
        useUTC : false
    }
    });

    function getAppData(){
        var json_data = "";
        $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/"+controller_name+"/data_charts/"+app_id+"/"+app_name,
            async: false,
            success:function(response){
                json_data =jQuery.parseJSON(response);
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
            }
        });
        return json_data;
    }

    var data_list = getAppData();

    function create_charts(cont_id){
        $('#container_'+cont_id).highcharts('StockChart',{
            chart : {
                events : {
                    load:function(){
                        var series = this.series[0];
                        setInterval(function(){
                            data_list = getAppData();
                            var x = (new Date()).getTime(),
                                y = Number(data_list[cont_id]['count']);
                            series.addPoint([x,y],true,true);
                        },10000);
                    }
                }
            },
            rangeSelector:{
                buttons:[{
                    count:1,
                    type:'minute',
                    text:'1M'
                },{
                    count:5,
                    type:'minute',
                    text:'5M'
                },{
                    type:'all',
                    text:'ALL'
                }],
                inputEnabled:false,
                selected:0
            },
            title : {
                text : data_list[cont_id]['data_source']
            },
            exporting:{
                enable:false
            },
            series:[{
                name : data_list[cont_id]['data_source'],
                data:(function(){
                    var data = [],time = (new Date()).getTime(),j;
                    for(j = -99;j<=0;j+=1){
                        data.push([
                            time + j*1000,
                            0
                        ]);
                    }
                    return data;
                }())
            }]
        });
    }

    for(var i=0;i<charts_count;i++){
        create_charts(i);
    }
});
