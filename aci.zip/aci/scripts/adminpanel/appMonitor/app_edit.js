/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-14
 * Time: 下午2:25
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },

          

        fields: {
            
            program_name:{
                validators: {
                    notEmpty: {
                        message: '请输入程序名'
                    }
                }
            },
            hardware_id:{
                validators: {
                    notEmpty: {
                        message: '请选择服务器'
                    }
                }
            },
            program_start_dir:{
                validators: {
                    notEmpty: {
                        message: '请输入程序启动目录'
                    }
                }
            },

            program_log_dir:{
                validators: {
                    notEmpty: {
                        message: '请输入日志目录'
                    }
                }
            },
            program_log_degree:{
                validators: {
                    notEmpty: {
                        message: '请输入日志级别'
                    }
                }
            },
            time_out:{
                validators: {
                    notEmpty: {
                        message: '请输入心跳包超时周期'
                    }
                }
            },
            app_description:{
                validators: {
                    notEmpty: {
                        message: '请输入应用说明'
                    }
                }
            },
            hardware_id:{
                validators: {
                    notEmpty: {
                        message: '请输入所在服务器'
                    }
                }
            },
            receive_watch_ip:{
                validators: {
                    notEmpty: {
                        message: '请输入接收监控消息ip'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },
            receive_watch_port:{
                validators: {
                    notEmpty: {
                        message: '请输入接收监控消息端口'
                    }
                }
            },
            receive_ip:{
                validators: {
                    notEmpty: {
                        message: '接收接口ip'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },

            send_watch_ip:{
                validators: {
                    notEmpty: {
                        message: '请输入发送监控消息ip'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },
            send_watch_port:{
                validators: {
                    notEmpty: {
                        message: '请输入发送监控消息端口'
                    }
                }
            },
            send_ip:{
                validators: {
                    notEmpty: {
                        message: '发送接口ip'
                    },
                    regexp: {
                        regexp: /^((25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)\.){3}(25[0-5]|2[0-4]\d|(1\d|[1-9])?\d)$/,
                        message: '请输入正确的IP地址'
                    }
                }
            },
            send_cycle:{
                validators: {
                    notEmpty: {
                        message: '发送周期'
                    }
                }
            },
        }
    };
    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
        e.preventDefault();
        $("#dosubmit").attr("disabled","disabled");
        $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);
        $.ajax({
            type: "POST",
            url: edit?SITE_URL+folder_name+"/appMonitor/app_edit/"+id:SITE_URL+folder_name+"/appMonitor/app_add/",
            data:  $("#validateform").serialize(),
            success:function(response){
                var dataObj=jQuery.parseJSON(response);
                if(dataObj.status)
                {
                    $.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
                    aci.GoUrl(SITE_URL+folder_name+'/appMonitor/app_lists/',1);
                }else
                {
                    $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                    $("#dosubmit").removeAttr("disabled");
                }
            },
            error: function (request, status, error) {
                $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                $("#dosubmit").removeAttr("disabled");
            }
        });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);$("#dosubmit").removeAttr("disabled");});

});
