/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-23
 * Time: 下午2:33
 * To change this template use File | Settings | File Templates.
 */
define(function(require){
    var $ = require('jquery');
    require('bootstrap');
    require('highstock');
    require('exporting');
    require('message');

    Highcharts.setOptions({
        global : {
        useUTC : false
    }
    });

    function getAppData(){
        var json_data = "";
        $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/"+controller_name+"/timing_hardware_detail/"+hardware_id,
            async: false,
            success:function(response){
                json_data =jQuery.parseJSON(response);
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
            }
        });
        return json_data;
    }
    // var data_list = getAppData();
  /*  var this_data = JSON.parse(this_data_list);
    var cpu_used_percent = this_data.cpu_used.cpu_used_percent;
    var storage_data = this_data.storage_name[1];
    var this_time = this_data.send_time;
    // var storage_data = this_data_list.storage_data[1];
    var cpu_data = [];
     cpu_data.push([
        this_time,
        cpu_used_percent
    ]);
     console.log(cpu_data)*/
    function cpu_create_charts(){
        $('#container_1').highcharts('StockChart',{
            chart : {
                events : {
                    load:function(){
                        var series = this.series[0];
                        setInterval(function(){
                            data_list = getAppData();
                            var x = (new Date()).getTime(),
                                y =Math.round(Math.random()*100);
                            series.addPoint([x,y],true,true);
                        },10000);
                    }
                }
            },
             rangeSelector:{
                buttons:[{
                    count:5,
                    type:'second',
                    text:'5s'
                },{
                    count:1,
                    type:'minute',
                    text:'1M'
                },{
                    type:'all',
                    text:'ALL'
                }],
                inputEnabled:false,
                selected:0
            },
            title : {
                text : 'cpu实时动态'
            },
            exporting:{
                enable:false
            },
            series:[{
                name : 'cpu百分比',
                data:(function(){
                    var data = [],i;
                    for (i =-999; i <= 0; i++) {
                        data.push([155678638,1])
                    };


                    return data;
                }())
            }]
        });
    }
    cpu_create_charts();
   function storage_create_charts(){
        $('#container_2').highcharts('StockChart',{
            chart : {
                events : {
                    load:function(){
                        var series = this.series[0];
                        setInterval(function(){
                            data_list = getAppData();
                            var x = (new Date()).getTime(),
                                y = 100;
                            series.addPoint([x,y],true,true);
                        },10000);
                    }
                }
            },
            title : {
                text : data_list[cont_id]['data_source']
            },
            exporting:{
                enable:false
            },
            series:[{
                name : data_list[cont_id]['data_source'],
                data:(function(){
                    var data = [],time = (new Date()).getTime(),j;
                    for(j = -99;j<=0;j+=1){
                        data.push([
                            time + j*1000,
                            0
                        ]);
                    }
                    return data;
                }())
            }]
        });
    }
});
