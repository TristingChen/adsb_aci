/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-23
 * Time: 下午2:33
 * To change this template use File | Settings | File Templates.
 */

define(function(require){
    var $ = require('jquery');
    require('bootstrap');
    require('datepicker');

/*  require('highcharts');
  require('highcharts_more');
    require('highcharts_solid');*/
    // require('exporting');
    // require('series-label');
    // require('message');

    var first_load = 0;

    $('#sum_button').click(function(){
        if($("#station_name").val() == ''){
            alert('请填写基站名');
        }
        if($('#start_time').val() == ''){
            alert('请选择开始时间');
        }
        if($('#end_time').val() == ''){
            alert('请选择结束时间');
        }
        if($("#station_name").val() != '' && $('#start_time').val() != '' && $('#end_time').val() != ''){
            var check_start = Date.parse(new Date($('#start_time').val().replace('-','/').replace('-','/')))/1000;
            var check_end = Date.parse(new Date($('#end_time').val().replace('-','/').replace('-','/')))/1000;
            var sub = check_end - check_start;
            if(sub <= 0){
                alert('结束时间需大于开始时间');
            }else{
                //最多可选一个小时内的数据  
                
                    $('#search_form').submit();
                
            }
        }

    })

    $('#clear_input').click(function(){
        $("#station_name").val('');
        $('#start_time').val('');
        $('#end_time').val('');
    })
    $('#print_table').click(function(){
        bdhtml=window.document.body.innerHTML;   
        sprnstr="<!--startprint-->";   
        eprnstr="<!--endprint-->";   
        prnhtml=bdhtml.substr(bdhtml.indexOf(sprnstr)+17);   
        prnhtml=prnhtml.substring(0,prnhtml.indexOf(eprnstr));   
        window.document.body.innerHTML=prnhtml;  
        window.print();   
    })


/*var cpu_used_percent_arr = JSON.parse(cpu_used_arr);
var storage_used_percent_arr = JSON.parse(storage_used_arr);
create_charts('#container_1','cpu占用百分比动态图',cpu_used_percent_arr,1);
if(server_kind != 3){
   create_charts('#container_2','内存占用百分比动态图',storage_used_percent_arr,2);
}
*/
// console.log(data_list)

var server_type = data_list.server_type;
// 公共配置
/*Highcharts.setOptions({
    chart: {
        type: 'solidgauge'
    },
    title: null,
    pane: {
        center: ['50%', '85%'],
        size: '140%',
        startAngle: -90,
        endAngle: 90,
        background: {
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || '#EEE',
            innerRadius: '60%',
            outerRadius: '100%',
            shape: 'arc'
        }
    },
    tooltip: {
        enabled: false
    },
    yAxis: {
        stops: [
            [0.1, '#55BF3B'], // green
            [0.5, '#DDDF0D'], // yellow
            [0.9, '#DF5353'] // red
        ],
        lineWidth: 0,
        minorTickInterval: null,
        tickPixelInterval: 400,
        tickWidth: 0,
        title: {
            y: -70
        },
        labels: {
            y: 16
        }
    },
    plotOptions: {
        solidgauge: {
            dataLabels: {
                y: 5,
                borderWidth: 0,
                useHTML: true
            }
        }
    }
});
var server_type = data_list.server_type;
var cpu_data =data_list.snmp.cpu;
var chart1 = Highcharts.chart('container_cpu', {
    yAxis: {
        min: 0,
        max: 100,
        title: {
            text: 'cpu实时动态'
        }
    },
    credits: {
        enabled: false
    },
    series: [{
        name: 'cpu',
        data: [cpu_data],
        dataLabels: {
            format: '<div style="text-align:center"><span style="font-size:25px;color:' +
            ((Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black') + '">{y}</span><br/>' +
            '<span style="font-size:12px;color:silver">%</span></div>'
        },
        tooltip: {
            valueSuffix: '%'
        }
    }]
});
// 转速仪表
if(server_type == 2){
    var snmp_data =data_list.snmp;
    var mem_data = snmp_data.diskArray[0];
    var mem_percent = Math.round(mem_data.use/mem_data.total*100);
    console.log(mem_percent)
    var chart2 = Highcharts.chart('container_memory', {
      yAxis: {
          min: 0,
          max: 100,
          title: {
              text: '内存实时动态'
          }
      },
      credits: {
          enabled: false
      },
      series: [{
          name: '内存',
          data: [mem_percent],
          dataLabels: {
              format: '<div style="text-align:center"><span style="font-size:25px;color:' +
              ((Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black') + '">{y}</span><br/>' +
              '<span style="font-size:12px;color:silver">%</span></div>'
          },
          tooltip: {
              valueSuffix: '%'
          }
      }]
  });  
}*/





  $('#shift_main').click(function(){
       /* is_main_limit = JSON.parse(is_main_limit);
        console.log(is_main_limit);
        return;*/
        if(is_main_limit['is_main'] == 1){
          var new_main = 0;
          var new_main_str = '备用服务器';
        }else{
          var new_main = 1;
          var new_main_str = '主用服务器';

        }
        if(confirm('确定要切换至'+new_main_str)){ 

              $.ajax({
              type: "POST",
              url: SITE_URL+folder_name+"/appMonitor/shift_main/"+hardware_id+'/'+new_main,
              async: false,
              success:function(response){
                console.log(response)
                  if(response ==1){
                      if(new_main == 0){
                          is_main_limit['is_main'] = 0;
                      }else{
                          is_main_limit['is_main'] = 1;
                      }
                      alert('操作成功')
                  }else{
                      alert('操作失败');
                  }

                  //进行table表格的替换
                 
              },
              error: function (request, status, error) {
                  //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
              }
               
          });
      }

  });

  $('.use_server').click(function(){
      var server_id = $(this).attr('server_id');
      var change_info='';
      if(server_id == 1){
           change_info = '关机';
      }else if(server_id == 0){
           change_info = '重启';
      }
      if(confirm('确定要'+change_info)){ 

              $.ajax({
              type: "POST",
              url: SITE_URL+folder_name+"/appMonitor/use_server/"+hardware_id+'/'+server_id,
              // data:'server_id ='+server_id,
              async: false,
              success:function(response){
                  json_res = JSON.parse(response);
                  alert(json_res.tips);
                  //进行table表格的替换
              },
              error: function (request, status, error) {
                  //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
              }
          });
      }
   });

 /*  $('.sound_alarm_switch').click(function(){

      
   });*/



    var alert_warning = $('.alert-warning');
    setInterval(function(){
      var timing_data = ajax_data(hardware_id); 
          var point;
      if(timing_data){
          var tbody1 = $('.table1');
           var tbody2 = $('.table2');
           var well_bom = $('.well_progress');
           var clock_time = $('.clock_time');
          var  container_cpu = $('#container_cpu');
          var container_memory =  $('#container_memory');

           net_html(timing_data['snmp']['agentArray'],tbody2);
           //cpu
           var cpu = Number(timing_data['snmp']['cpu']);
           if(timing_data['error_degree'] ==2){
              $('.alert-warning').html(timing_data.error_info);
              $('.alert-warning').show();
              // $('.alert-warning').attr('style','display:block');

           }else{
              $('.alert-warning').hide();
           }
               /*if (chart1) {
                  point = chart1.series[0].points[0];
                  point.update(cpu);
              }*/
              if(cpu >90 || cpu < 0){
                  $('#container_cpu').addClass('red_span');
                  $('#container_cpu').removeClass('normal_span');

              }else{
                  $('#container_cpu').addClass('normal_span');
                  $('#container_cpu').removeClass('red_span');
              }
              $('#container_cpu').html(cpu+'%');
           /* if(timing_data['error_degree'] >=2 && timing_data['fork_die'] == false){
                $('.alert_warning').show();
            }else{
                $('.alert_warning').hide();
            }*/
            if(timing_data['error_degree'] >0){
                $('#sound_switch').show();
                if(timing_data['sound_switch'] == 1){
                  var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+hardware_id+',0,0)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声关闭</p>'
                }else{
                  var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+hardware_id+',1,0)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声开启</p>'
                }
                $('#sound_switch').html(p_obj);

            }else{
                $('#sound_switch').hide();

            }
           if(server_type == 2){
                pit_html(timing_data['snmp']['diskArray'],tbody1); //磁盘
                progress_html(timing_data['snmp']['forkArray'],well_bom);
                ntp_html(timing_data,$('#ntp_server_subtime'));

                //内存
                  var snmping_data = timing_data['snmp']
                   var mem_num = snmping_data.diskArray[0];
                  /*  var mem_percent = Math.round(mem_num.use/mem_data.total*100);*/
                    /*if (chart2) {
                      point = chart2.series[0].points[0];
                        point.update(mem_percent);
                    }*/
                    if((mem_num.use/mem_num.total) >0.9 || mem_num.total <0 || mem_num.use < 0){
                        $('#container_memory').addClass('red_span');
                        $('#container_memory').removeClass('normal_span');

                    }else{
                        $('#container_memory').addClass('normal_span');
                        $('#container_memory').removeClass('red_span');
                    }
                    $('#container_memory').html((((mem_num.use).toFixed(2))/(mem_num.total).toFixed(2)).toFixed(3)+'%');

           }
           clock_time.html(fmtDate(timing_data.snmp_file_time));
           //主备状态的显示
           // console.log(timing_data.is_main)
           if(timing_data.is_main != undefined){
              var main_html = $('#main_info');
              if(server_type == 2 && timing_data.is_middel_server == 0){
                  if(timing_data.is_main == 1){
                    main_html.html(' (主用)');
                  }else{
                    
                    main_html.html(' (备用)');
                  }
              }
           }
      }

    }, 1000);

    $('.confirm_msg').on('click',function(){
      var msg_kind = $(this).attr('msg_kind');
      //var app_id = $(this).parents().find('.well').attr('att_appid');
        var app_id = $(this).attr("att_appid");
      if(confirm('确定发送消息吗')){
         $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/appMonitor/change_msg_confirm",
            data:{'msg_kind':msg_kind,'app_id':app_id,'hardware_id':hardware_id},
            async: false,
            success:function(response){
              response = JSON.parse(response);
                      alert(response.tips);
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
               console.log('error');
            }
        });
      }

    });
/*    $('.data-hide').click(function(){

        var data_hide = $(this).attr('data-hide');
        console.log(123)
        $('#model_content').html(data_hide);
    })*/


});

function ajax_data(hardware_id){
  var json_res='';
    $.ajax({
              type: "POST",
              url: SITE_URL+folder_name+"/appMonitor/timing_hardware_detail/"+hardware_id,
              // data:'server_id ='+server_id,
              async: false,
              success:function(response){
                  json_res = JSON.parse(response);
              },
              error: function (request, status, error) {
                  //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
              }
               
    });
    return json_res;
}

function pit_html(obj,tbody){
   var pit_res = '';
     /* var objlen = 0;
      for(var i in obj){
         objlen++;
      }*/
      tbody.html('');
      $.each(obj,function(i,s_obj){
            if(i != 0){
                var pit_str = '<tr>'
                pit_str +=  '<td>'+s_obj.name+'</td>';
                pit_str +=   '<td>'+(s_obj.total/1024).toFixed(3)+'</td>';
                pit_str +=   '<td>'+(s_obj.use/1024).toFixed(3)+'</td>';
                pit_str +=   '<td>'+(s_obj.use/s_obj.total*100).toFixed(3)+'</td>';
               
               if(s_obj.use/s_obj.total > 0.9  || s_obj.fx == 0 || s_obj.use <0 || s_obj.total <0){
                  pit_str +=   '<td class="res_span">不正常</td>';
                }else{
                  pit_str +=   '<td>正常</td>';
                }
                pit_str += '</tr>'
                tbody.append(pit_str);
            }
               
      });
}

//时间戳转日期
function fmtDate(timeStamp){
       var date = new Date();  
    date.setTime(timeStamp * 1000);  
    var y = date.getFullYear();      
    var m = date.getMonth() + 1;      
    m = m < 10 ? ('0' + m) : m;      
    var d = date.getDate();      
    d = d < 10 ? ('0' + d) : d;      
    var h = date.getHours();    
    h = h < 10 ? ('0' + h) : h;    
    var minute = date.getMinutes();    
    var second = date.getSeconds();    
    minute = minute < 10 ? ('0' + minute) : minute;      
    second = second < 10 ? ('0' + second) : second;     
    return y + '-' + m + '-' + d+' '+h+':'+minute+':'+second;     
}
function net_html(obj,tbody){
    var pit_res = '';
      var objlen = 0;
     /* for(var i in obj){
         objlen++;
      }*/
      tbody.html('');
      $.each(obj,function(i,s_obj){
        var pit_str = '<tr>'
             pit_str +=  '<td>'+s_obj.name+'</td>';
             pit_str +=  '<td>'+s_obj.ip+'</td>';
             pit_str +=   '<td>'+s_obj.inNum+'</td>';
             pit_str +=   '<td>'+s_obj.outNum+'</td>';
             if(s_obj.fx != 0 && s_obj.switch == 1){
               pit_str +=   '<td>正常</td>';
             }else{
               pit_str +=   '<td class="res_span">不正常</td>';
             }
             pit_str += '</tr>'
             tbody.append(pit_str);
      })
/*
      for (var i = 0; i <= obj.length; i++) {
            var pit_str = '<tr>'
             pit_str +=  '<td>'+obj[i].name+'</td>';
             pit_str +=   '<td>'+obj[i].inNum.toFixed(2)+'MB</td>';
             pit_str +=   '<td>'+obj[i].outNum.toFixed(2)+'MB</td>';
             if(obj[i].fx != 0){
               pit_str +=   '<td>正常</td>';
             }else{
               pit_str +=   '<td>不正常</td>';
             }
             pit_str += '</tr>'
             tbody.append(pit_str);
      };*/

}

function progress_html(obj,well_dom){
    var pit_res = '';
      var objlen = 0;
      for(var i in obj){
         objlen++;
      }
      well_dom.each(function(i,dom_obj){
        var dom_this = $(this);
         var tbody = $(this).find('.table3');
         tbody.html('');
            // console.log(dom_this.find('.table3'));
            // console.log(obj[i].name);

            if(obj[i]){
              var pit_str = '<caption><b>'+obj[i].name +'</b></caption>';
                pit_str += '<threa>';
                pit_str += '<tr>';
                pit_str += '<th>cpu占比(%)</th>';
                pit_str += '<th>'+obj[i].cpu.toFixed(3)+'</th>';
                pit_str += '</tr>';

                pit_str += '<tr>';
                pit_str += '<th>内存占用(%)</th>';
                pit_str += '<th>'+(obj[i].mem).toFixed(3)+'</th>';
                pit_str += '</tr>';

                pit_str += '<tr>';
                pit_str += '<th>报告状态</th>';
                if(obj[i]['count'] <=1 && obj[i]['fx'] != 0 && obj[i]['application']['appStatus'] =='OK' && obj[i]['application']['hearbeatTimeOut'] == true){
                    pit_str += '<th>正常</th>';
                    dom_this.removeClass('red_span');
                    dom_this.removeClass('yellow_span');

                }else{
                    if(obj[i]['count'] >1  || obj[i]['application']['hearbeatTimeOut'] == false){
                           pit_str += '<th class="res_span">进程挂断,以上信息不准确</th>';
                           dom_this.removeClass('yellow_span');
                           dom_this.addClass('red_span');
                    }else{
                          if(obj[i]['application']['appAlertContent'].length <20){
                              pit_str += '<th ><div class="data-hide" >不正常:'+obj[i]['application']['appAlertContent']+'</div></th>';
                          }else{
                             pit_str += '<th ><div class="data-hide" onclick="data_hide(this)" data-hide="不正常:'+obj[i]['application']['appAlertContent']+'" data-toggle="modal" data-target="#myModal" >不正常:'+obj[i]['application']['appAlertContent'].substring(0,20)+'...</div></th>';
                          }
                              
                           dom_this.removeClass('red_span');
                           dom_this.addClass('yellow_span');

                    }
                   
                }
                pit_str += '</tr>';
                pit_str += '<tr>';
                pit_str += '<th>报告时间</th>';
                pit_str += '<th>'+obj[i]['application']['appReportTime']+'</th>';
               pit_str += '</tr>';
               pit_str += '</threa>'
               tbody.append(pit_str);
            }
        



      })
}
function ntp_html(obj,ntp_server_subtime){
      if(obj.ntp_warning){
          if(!ntp_server_subtime.hasClass('red_span')){
              ntp_server_subtime.addClass('red_span');
          }
      }else{
           if(ntp_server_subtime.hasClass('red_span')){
              ntp_server_subtime.removeClass('red_span');
          }
      }
      ntp_server_subtime.html('');
      var ntp_str = '<table class="table table">';
          ntp_str += '<caption>时钟校验</caption>';
         ntp_str += '<threa>';
                ntp_str += '<tr>';
                ntp_str += '<th>ntp时间</th>';
                ntp_str += '<th>'+fmtDate(obj.ntp_time)+'</th>';
                ntp_str += '</tr>';

                ntp_str += '<tr>';
                ntp_str += '<th>该服务器时间</th>';
                ntp_str += '<th>'+fmtDate(obj.snmp.time)+'</th>';
                ntp_str += '</tr>';

                ntp_str += '<tr>';
                ntp_str += '<th>相差时间</th>';
                ntp_str += '<th>'+obj.ntp_server_subtime+'</th>';
                ntp_str += '</tr>';

                ntp_str += '<tr>';
                ntp_str += '<th>状态</th>';
                if(obj.ntp_warning){
                  ntp_str += '<th>不正常</th>';
                }else{
                  ntp_str += '<th>正常</th>';
                }
                ntp_str += '</tr>';
         ntp_str += '</threa>';
         ntp_str += '</table>';
         ntp_server_subtime.html(ntp_str);

}
function auto_alarm_switch(hardware_id){
    $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/appMonitor/auto_alarm_switch/"+hardware_id,
            async: false,
            success:function(response){
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
               console.log('error');
            }
        });
} 
function data_hide(_this){
  console.log(_this)
  $('#model_content').html($(_this).attr('data-hide'));
}