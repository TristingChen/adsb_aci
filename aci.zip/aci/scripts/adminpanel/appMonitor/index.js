/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-23
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
    	var well_class = $('.well');

    	//进行定时请求
        setInterval(function(){
		      $.ajax({
		        type: "POST",
		        url: SITE_URL+folder_name+"/appMonitor/timing_app_status",
		        async: false,
		        success:function(response){
		        	json_da = JSON.parse(response);
		        	$.each(json_da,function(i,obj){
		        		obj_check(well_class,obj.app_id,obj.app_status,obj.app_report_time,obj.aler_content);
		        	})		            
		        },
		        error: function (request, status, error) {
		            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
		           console.log('error')
		        }
		    });
    },1000);

    $('.confirm_msg').on('click',function(){
    	var msg_kind = $(this).attr('msg_kind');
    	//var app_id = $(this).parents().find('.well').attr('att_appid');
        var app_id = $(this).attr("att_appid");
    	if(confirm('确定发送消息吗')){
    		 $.ajax({
		        type: "POST",
		        url: SITE_URL+folder_name+"/appMonitor/change_msg_confirm",
		        data:{'msg_kind':msg_kind,'app_id':app_id},
		        async: false,
		        success:function(response){
		        	response = JSON.parse(response);
	                    alert(response.tips);
		        },
		        error: function (request, status, error) {
		            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
		           console.log('error');
		        }
		    });
    	}

    })




});


function obj_check(well_class,app_id,app_status,app_report_time,aler_content){
	well_class.each(function(i,obj){
		if($(this).attr('att_appid') == app_id){
            $(this).children().find('.report_time').html(app_report_time);
			$(this).children().find('.timing_status').html('');
			if(app_status == 'OK'){
				var span_obj = '<span class="green_status">正常</span>';
				$(this).children().find('.timing_status').append(span_obj);
			}else{
                var span_obj = "";
                if(aler_content != "" && aler_content!=null)
                {
                    span_obj = '<span class="red_status">不正常'+ ',' + aler_content+'</span>';
                }
                else
                {                    
                    span_obj = '<span class="red_status">不正常,无告警内容</span>';
                }
				$(this).children().find('.timing_status').append(span_obj);
			}
		}
		
	});
	
}