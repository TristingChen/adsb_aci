﻿/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-9
 * Time: 下午3:10
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
    require('topo');

    var canvas = document.getElementById('canvas');
    var stage = new JTopo.Stage(canvas);
    //显示工具栏
    showJTopoToobar(stage);

    var scene = new JTopo.Scene();
    scene.background = img_path+'pstn/bg.png';

    var content_width = $('#content').width();
    var navbar_height = $("#navbar").height();
    var breadcrumb_height = $("#breadcrumb").height();
    var JTopoToobar_heigth = $('.jtopo_toolbar').height();
    var body_height =  $(document.body).height();
    $("#canvas").attr("width",content_width);
    $("#canvas").attr("height",body_height - navbar_height - breadcrumb_height - JTopoToobar_heigth - 50);

    /*$(document).ready(function(){
     pop_init("哈哈","<ul><li>ADS-B数据收集解析服务器A</li><li>ADS-B数据收集解析服务器B</li></ul>");
     $('#pop_div').fadeIn(400)
     })*/
    function node(x, y, img, name,is_accetive,server_id,alarm_status,is_monitor){
        var node = new JTopo.Node(name);

        node.setLocation(x, y);
        if(is_accetive){
            node.textPosition = "Bottom_Center";

        }else if(is_accetive ==0){
            node.textPosition = "Middle_Left";
        }
        if(is_monitor == 1){
            if(alarm_status == 1){
                node.alarm = '告警';
            }else{
                node.alarm = null;
            }
        }

        node.setImage(img_path+'pstn/' + img, true);
        // console.log(node)
        bindNodeEvent(node,server_id,null,0);
        scene.add(node);
        return node;
    }


    function linkNode(nodeA, nodeZ){
        var link = new JTopo.FoldLink(nodeA, nodeZ);
        link.lineWidth = 3;
        link.strokeColor = '255,255,0';
        scene.add(link);
        return link;
    }

    function ethernets(x,y,eth_num,container,server_id){
        var j = 1;
        var eth = new Array();
        for(var i=0;i<eth_num;i++){
            eth[i] = new JTopo.Node(server_id+'_'+i);
            eth[i].width = 1;
            eth[i].height = 1;
            eth[i].fillColor = '255,255,0';
            eth[i].setLocation(x+7+i*8,y);
            eth[i].dragable = false;
            container.add( eth[i]);
        }
        scene.add(eth);
    }
    function ntp_ethernets(x,y,eth_num,container,server_id){
        var j = 1;
        var eth = new Array();
        for(var i=0;i<eth_num;i++){
            eth[i] = new JTopo.Node(server_id+'_'+i);
            eth[i].width = 1;
            eth[i].height = 1;
            eth[i].fillColor = '255,255,0';
            eth[i].setLocation(x+20+i*8,y+12);
            eth[i].dragable = false;
            container.add( eth[i]);
        }
        scene.add(eth);
    }

    var flowLayout1 = JTopo.layout.FlowLayout(0,10);
    function appServer(x,y,kind,server_img,to_notes,server_name,server_id,server_type,is_monitor,alarm_status,s_width,s_height,is_station,channel_status_A,channel_status_B,current_work_pass,enable_A,enable_B){
        var container = new JTopo.Container();
        // container.fillColor = '0,255,255';
        // container.zIndex = 10;
        x= Number(x);
        y= Number(y);
        container.childDragble = false;
        container.alpha = 0;
        container.setLocation(x, y);
        // container.layout = flowLayout1;
        scene.add(container);
        var original_dot = new JTopo.Node(server_name);
        if(kind == 1){
            original_dot.textPosition = "Middle_Right";
        }else if(kind == 2){
            original_dot.textPosition = "Middle_Right";
        }else{
            original_dot.textPosition = "Bottom_Center";
        }
        /* if(is_main == 0 && server_type == 2){
         original_dot.setImage(img_path+'pstn/server_b.png');
         }else{
         original_dot.setImage(img_path+'pstn/' + server_img);
         }*/
        original_dot.setImage(img_path+'pstn/' + server_img);

        if(is_monitor == 1){
            if(alarm_status == 1){
                original_dot.alarm = '告警';
            }else{
                original_dot.alarm = null;
            }
        }

        if(s_width && s_height){
            original_dot.setSize(s_width,s_height);
        }
        original_dot.setLocation(x, y);
        container.add(original_dot);
        scene.add(original_dot);
        var to_notes_arr = to_notes.split(',');
        var to_notes_len = to_notes_arr.length;
        if(kind == 1){
            station_route(x,y,container,server_id,channel_status_A,channel_status_B,current_work_pass,is_monitor,enable_A,enable_B);
        }else if(kind == 2){
            rader_route(x,y,container,server_id,channel_status_A,channel_status_B,current_work_pass,is_monitor,enable_A,enable_B);
        }else if(kind == 0){
            ethernets(x,y,to_notes_len,container,server_id);
        }else if(kind == 3){
            ntp_ethernets(x,y,to_notes_len,container,server_id);
        }
        bindNodeEvent(original_dot,server_id,container,kind,is_station);
        // bindAppEvent(container);
        return container;
    }
    //基站通道的填写
    function station_route(x,y,container,server_id,channel_status_A,channel_status_B,current_work_pass,is_monitor,enable_A,enable_B){
        var station_a = new JTopo.Node();

        station_a.setLocation(x-14,y+40);
        // station_a.setSize(38,19);
        station_a.setSize(28,12);

        if(is_monitor == 1){
            if(enable_A == 1 || enable_A == 3){
                if(channel_status_A == 1){
                    if(current_work_pass == 1){
                        station_a.setImage(img_path+'pstn/route_a.png');
                    }else{
                        station_a.setImage(img_path+'pstn/route_a1.png');
                    }
                }else{
                    station_a.setImage(img_path+'pstn/route_a2.png');
                }
            }else{
                station_a.setImage(img_path+'pstn/route_a3.png');
            }
        }else{
            station_a.setImage(img_path+'pstn/route_a3.png');
        }
        scene.add(station_a);
        container.add(station_a);
        var station_b =  new JTopo.Node();

        station_b.setLocation(x+14,y+40);
        // station_b.setSize(38,19);
        station_b.setSize(28,12);
        if(is_monitor == 1){
            if(enable_B == 1 || enable_B == 3){
                if(channel_status_B == 1){
                    if(current_work_pass == 2){
                        station_b.setImage(img_path+'pstn/route_b.png');
                    }else{
                        station_b.setImage(img_path+'pstn/route_b1.png');
                    }
                }else{
                    station_b.setImage(img_path+'pstn/route_b2.png');
                }
            }else{
                station_b.setImage(img_path+'pstn/route_b3.png');
            }
        }else{
            station_b.setImage(img_path+'pstn/route_b3.png');
        }
        scene.add(station_b);
        container.add(station_b);
    }

    //雷达通道的填写
    function rader_route(x,y,container,server_id,channel_status_A,channel_status_B,current_work_pass,is_monitor,enable_A,enable_B){
        var station_a = new JTopo.Node();

        station_a.setLocation(x-20,y+45);
        station_a.setSize(38,19);
        if(is_monitor == 1){
            if(enable_A == 1){
                if(channel_status_A == 0){
                    if(current_work_pass == 1 || current_work_pass == 3){
                        station_a.setImage(img_path+'pstn/route_a.png');
                    }else{
                        station_a.setImage(img_path+'pstn/route_a1.png');
                    }
                }else{
                    station_a.setImage(img_path+'pstn/route_a2.png');
                }
            }else{
                station_a.setImage(img_path+'pstn/route_a3.png');
            }
        }else{
            station_a.setImage(img_path+'pstn/route_a3.png');
        }
        scene.add(station_a);
        container.add(station_a);
        var station_b =  new JTopo.Node();

        station_b.setLocation(x+20,y+45);
        station_b.setSize(38,19);
        if(is_monitor == 1){
            if(enable_B == 1){
                if(channel_status_B == 0){
                    if(current_work_pass == 2){
                        station_b.setImage(img_path+'pstn/route_b.png');
                    }else{
                        station_b.setImage(img_path+'pstn/route_b1.png');
                    }
                }else{
                    station_b.setImage(img_path+'pstn/route_b2.png');
                }
            }else{
                station_b.setImage(img_path+'pstn/route_b3.png');
            }
        }else{
            station_b.setImage(img_path+'pstn/route_b3.png');
        }
        scene.add(station_b);
        container.add(station_b);
    }

    var node_arr = new Array();
    $.each(data_list['hardware_datas'],function(i,obj){
        var server_id = obj['hardware_id'];
        var server_name = obj['hardware_name'];
        var server_type = obj["hardware_type_id"];
        var server_img = obj["img_dir"];
        var x = parseInt(obj["canvas_x"]);
        var y = parseInt(obj["canvas_y"]);
        var is_accetive = obj['is_accetive'];
        var to_notes = obj['to_notes'];
        var is_middel_server = obj['is_middel_server'];
        var is_main = obj['is_main'];
        var alarm_status = obj['alarm_status'];
        var is_monitor = obj.is_monitor;
        if(server_type == 2 ){
            //容器 将附带的点加进去

            if(is_monitor){
                if(is_middel_server ==1){
                    server_img = 'bypass.png';
                }else if(is_middel_server == 0){
                    if(obj.is_main == 0){
                        server_img = 'server_b.png';
                    }else{
                        server_img = 'server_m.png';
                    }

                }else{
                    if(obj.is_main == 0){
                        server_img = 'ntp_server2.png';
                    }else{
                        server_img = 'ntp_server1.png';
                    }
                }

            }else{
                if(is_middel_server ==1){
                    server_img = 'bypass2.png';
                }else if(is_middel_server == 0){
                    if(obj.is_main == 0){
                        server_img = 'server_b2.png';
                    }else{
                        server_img = 'server_m2.png';
                    }
                }else{
                    
                     server_img = 'ntp_server1.png';
                    
                }
            }
            if(is_middel_server == 2){
                node_arr[obj['hardware_id']] = appServer(x,y,3,server_img,to_notes,server_name,server_id,server_type,is_monitor,alarm_status,40,33);

            }else{
                node_arr[obj['hardware_id']] = appServer(x,y,0,server_img,to_notes,server_name,server_id,server_type,is_monitor,alarm_status,28,39);

            }
        }else{
            //直接造节点
            if(server_type == 6){
                if(obj.is_monitor == 0){
                    node_arr[obj['hardware_id']] = appServer(x,y,0,'terminal2.png',to_notes,server_name,server_id,server_type,is_monitor,alarm_status);
                }else{
                    node_arr[obj['hardware_id']] = appServer(x,y,0,server_img,to_notes,server_name,server_id,server_type,is_monitor,alarm_status);
                }
            }else if(server_type == 8){

                if(obj.is_monitor == 0){
                    node_arr[obj['hardware_id']] = appServer(x,y,0,'xieyi2.png',to_notes,server_name,server_id,server_type,is_monitor,alarm_status,38,20);
                }else{
                    node_arr[obj['hardware_id']] = appServer(x,y,0,server_img,to_notes,server_name,server_id,server_type,is_monitor,alarm_status,38,20);
                }
            }else{
                if(obj.is_monitor == 0){
                    server_img = 'router2.png';
                }
                if(server_type == 1 && is_accetive == 0){
                    node_arr[obj['hardware_id']] = node(x,y,server_img,server_name,0,server_id,alarm_status,is_monitor);
                }else{
                    node_arr[obj['hardware_id']] = node(x,y,server_img,server_name,1,server_id,alarm_status,is_monitor);
                }
            }

        }

    });
    //连线
    var station_arr = data_list.station;
    var rader_arr = data_list.rader;

    var station_node_arr = new Array();
    var rader_node_arr = new Array();
    $.each(station_arr,function(i,obj){
        if(obj.is_monitor == 0){
            obj.station_img = 'station2.png';
        }
        var node1 = appServer(obj.canvas_x,obj.canvas_y,1,obj.station_img,'1,2',obj.station_name,obj.station_id,0,obj.is_monitor,obj.alarm_status,27,40,obj.is_station,obj.channel_status_A,obj.channel_status_B,obj.current_work_pass,obj.enable_A,obj.enable_B);
        station_node_arr[obj.station_id] = node1;
    });
    $.each(rader_arr,function(i,obj){
        if(obj.is_monitor == 0){
            obj.rader_img = 'satellite_antenna2.png';
        }
        node2 = appServer(obj.canvas_x,obj.canvas_y,2,obj.rader_img,'1,2',obj.name,obj.id,0,obj.is_monitor,obj.rader_alarm,45,45,0,obj.path_a_alarm,obj.path_b_alarm,obj.in_work_option,obj.path_switch_a,obj.path_switch_b);
        rader_node_arr[obj.id] = node2;

    });
    //连线
    //
    var station_link_arr = new Array();
    var rader_link_arr = new Array();
    var server_link_arr = new Array();
    $.each(station_node_arr,function(i,obj){
        if(obj){
            // var j = 0
            var link1 = addLink(obj.childs[1],node_arr[17],'','0,255,144');
            scene.add(link1)
            station_link_arr.push(link1);

            var link2 = addLink(obj.childs[2],node_arr[18],'','0,255,144');
            scene.add(link2)
            station_link_arr.push(link2);
        }
    });
    //雷达与协调
    $.each(rader_node_arr,function(i,obj){
        var tmp_link_arr = new Array();
        if(obj){
            if(i == 1){
                var link1 = addLink(obj.childs[1],node_arr[17],'','0,255,144');
                scene.add(link1)
                rader_link_arr.push(link1);
                var link2 = addLink(obj.childs[2],node_arr[18],'','0,255,144');
                scene.add(link2)
                rader_link_arr.push(link2);

            }else{
                var link1 = addLink(obj.childs[1],node_arr[38].childs[0],'','0,255,144');
                scene.add(link1)
                rader_link_arr.push(link1);

                var link2 = addLink(obj.childs[2],node_arr[39].childs[0],'','0,255,144');
                scene.add(link2)
                rader_link_arr.push(link2);
                /* var link2 = addLink(obj.childs[2],node_arr[38].childs[0],'','0,255,144');
                 scene.add(link2)*/
            }
        }
    });

    //旁路与输出
    var link1 = addLink(node_arr[33].childs[1],node_arr[19],'33_19','0,255,144');
    scene.add(link1)
    server_link_arr.push(link1);


    var link2 = addLink(node_arr[33].childs[2],node_arr[20],'33_20','0,255,144');
    scene.add(link2)
    server_link_arr.push(link2);

    function hide_node(x, y, name){
        var node = new JTopo.Node(name);
        node.setLocation(x, y);
        node.width = 1;
        node.height = 1;
        node.visible = false;
        scene.add(node);
        return node;
    }
    //协议与输入

    //// 构造新的节点
    //飞行与输入
    var tmp_node1 = hide_node(node_arr[5].childs[1].x,node_arr[17].y+8,'5_17_1');
    var tmp_node2 = hide_node(node_arr[5].childs[2].x,node_arr[18].y+8,'5_18_2');
    var tmp_node3 = hide_node(node_arr[6].childs[1].x,node_arr[17].y+8,'6_17_1');
    var tmp_node4 = hide_node(node_arr[6].childs[2].x,node_arr[18].y+8,'6_18_2');
    var link1 = addLink(tmp_node1,node_arr[5].childs[1],'5_17','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(tmp_node2,node_arr[5].childs[2],'5_18','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);
    var link1 = addLink(tmp_node3,node_arr[6].childs[1],'6_17','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(tmp_node4,node_arr[6].childs[2],'6_18','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);

    //雷达与输入
    var tmp_node1 = hide_node(node_arr[3].childs[1].x,node_arr[17].y+8,'3_17_1');
    var tmp_node2 = hide_node(node_arr[3].childs[2].x,node_arr[18].y+8,'3_18_2');
    var tmp_node3 = hide_node(node_arr[4].childs[1].x,node_arr[17].y+8,'4_17_1');
    var tmp_node4 = hide_node(node_arr[4].childs[2].x,node_arr[18].y+8,'4_18_2');
    var link1 = addLink(tmp_node1,node_arr[3].childs[1],'3_17','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(tmp_node2,node_arr[3].childs[2],'3_18','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);
    var link1 = addLink(tmp_node3,node_arr[4].childs[1],'4_17','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(tmp_node4,node_arr[4].childs[2],'4_18','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);


    //数据搜集与输入
    var tmp_node1 = hide_node(node_arr[1].childs[1].x,node_arr[17].y+8,'1_17_1');
    var tmp_node2 = hide_node(node_arr[1].childs[2].x,node_arr[18].y+8,'1_18_2');
    var tmp_node3 = hide_node(node_arr[2].childs[1].x,node_arr[17].y+8,'2_17_1');
    var tmp_node4 = hide_node(node_arr[2].childs[2].x,node_arr[18].y+8,'2_18_2');
    var link1 = addLink(tmp_node1,node_arr[1].childs[1],'1_17','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(tmp_node2,node_arr[1].childs[2],'1_18','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);
    var link1 = addLink(tmp_node3,node_arr[2].childs[1],'2_17','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(tmp_node4,node_arr[2].childs[2],'2_18','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);

    //分发与输出
    var tmp_node1 = hide_node(node_arr[25].childs[1].x,node_arr[19].y+8,'3_17_1');
    var tmp_node2 = hide_node(node_arr[25].childs[2].x,node_arr[20].y+8,'3_18_2');
    var tmp_node3 = hide_node(node_arr[26].childs[1].x,node_arr[19].y+8,'4_17_1');
    var tmp_node4 = hide_node(node_arr[26].childs[2].x,node_arr[20].y+8,'4_18_2');
    var link1 = addLink(node_arr[25].childs[1],tmp_node1,'25_19','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(node_arr[25].childs[2],tmp_node2,'25_20','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);
    var link1 = addLink(node_arr[26].childs[1],tmp_node3,'26_19','0,255,144',1);
    scene.add(link1);
    server_link_arr.push(link1);
    var link2 = addLink(node_arr[26].childs[2],tmp_node4,'26_20','0,255,144',1);
    scene.add(link2);
    server_link_arr.push(link2);
    //大部分服务器的连线
    $.each(data_list['hardware_datas'],function(i,obj){
        //ads是被动连接 不做主动的连线
        var to_end_notes_str = obj.to_notes;
        var to_end_notes_arr = to_end_notes_str.split(',');
        var to_end_notes_len = to_end_notes_arr.length;
        var start_notes = node_arr[obj.hardware_id];
        if(obj.hardware_type_id == 2 || obj.hardware_type_id == 8){
            //多点链接在ads网上的服务器  容器
            // if(obj.hardware_id !=39){
                //容器中 两个节点只有两个节点
                $.each(to_end_notes_arr,function(j,s_obj){

                    var h_node = hide_node(start_notes.childs[j+1].x,node_arr[s_obj].y+8,obj.hardware_id+'_'+s_obj+'_'+(j+1));
                    if(obj.hardware_id == 25 || obj.hardware_id == 26){
                        var link = addLink(h_node,node_arr[s_obj],obj.hardware_id+'_'+s_obj,'0,255,144',null);
                        scene.add(link);
                    }
                    if(obj.hardware_id == 33){
                        var link = addLink(h_node,node_arr[s_obj],obj.hardware_id+'_'+s_obj,'0,255,144',null);
                        scene.add(link);
                    }
                    if(obj.hardware_id ==3 ||obj.hardware_id ==4 ||obj.hardware_id ==5 ||obj.hardware_id ==6 || obj.hardware_id ==1 || obj.hardware_id == 2 || obj.hardware_id == 38 || obj.hardware_id == 39){
                        if(obj.hardware_id ==5 ||obj.hardware_id ==6){
                            var link = addLink(start_notes.childs[j+1],h_node,obj.hardware_id+'_'+s_obj,'0,255,144');
                        }else{
                            var link = addLink(start_notes.childs[j+1],h_node,obj.hardware_id+'_'+s_obj,'0,255,144');

                        }
                    }else{
                        var link = addLink(h_node,start_notes.childs[j+1],obj.hardware_id+'_'+s_obj,'0,255,144');
                    }
                    scene.add(link);
                    server_link_arr.push(link);
                    //进行数据的读取
                })
            // }
        }else if(obj.hardware_type_id == 6){
            //中端 没了
            $.each(to_end_notes_arr,function(j,s_obj){

                var h_node = hide_node(start_notes.childs[j+1].x,node_arr[s_obj].y+8,obj.hardware_id+'_'+s_obj+'_'+(j+1));
                // console.log(h_node)
                var link = addLink(h_node,start_notes.childs[j+1],obj.hardware_id+'_'+s_obj,'0,255,144');
                scene.add(link);
                server_link_arr.push(link);
            })
        }
    });

    stage.add(scene);
    //eventsource
    if(typeof(EventSource) != 'undefined'){
        var source = new EventSource(SITE_URL+'adminpanel/appMonitor/hardware_status');
        source.addEventListener('message',function(e){
            // document.getElementById('geleral_time').innerHTML = e.data;
            response = e.data;
            if(!response){
                console.log(123);
            }else{
                json_data = jQuery.parseJSON(response);
                // console.log(json_data);
                var hardware_info = json_data['hardware_info'];
                var station_info = json_data['station'];
                var rader_info = json_data['rader'];
                var hardware_wrong = [];
                if(hardware_info){
                    // console.log(hardware_info)
                    $.each(hardware_info,function(j,obj){
                        var hardware_node = node_arr[j];
                        var snmp = obj.snmp;
                        var is_main = obj.is_main;
                        if(obj.server_type != 2){
                            var alarm_node = hardware_node;
                        }else{
                            var alarm_node = hardware_node.childs[0];
                        }
                        var hardware_wrong_str = obj.error_info;
                        
                        if(!snmp || obj.is_monitor == 0){
                            if(is_main != undefined){
                                //主备切换
                                if(obj.server_type == 2){
                                    // var one_obj_childs = hardware_node.childs[0];
                                    if(obj.is_middel_server == 1){
                                        alarm_node.setImage(img_path+'pstn/bypass2.png',true);
                                    }else if(obj.is_middel_server == 0){
                                        if(is_main == 0){
                                            alarm_node.setImage(img_path+'pstn/server_b2.png',true);
                                        }else{
                                            alarm_node.setImage(img_path+'pstn/server_m2.png',true);

                                        }
                                    }else{
                                            alarm_node.setImage(img_path+'pstn/ntp_server4.png',true);
                                    }
                                    // alarm_node.setSize(28,39);
                                }else if(obj.server_type == 1){
                                    alarm_node.setImage(img_path+'pstn/router2.png',true);
                                }
                                alarm_node.alarm = null;
                            }

                        }else{
                            var is_main = obj.is_main;
                            var agent_arr  = snmp.agentArray;
                            var cpu = snmp.cpu;
                            var diskArr = snmp.diskArray;
                            var forkArr = snmp.forkArray;
                            

                            //进行snmp解析 并进行不同颜色的警告
                            if(obj.is_middel_server != 2){
                                $.each(agent_arr,function(i,a_obj){
                                    var switch_id = a_obj.switch_id;
                                    var  link_text = switch_id+'_'+j;
                                    var  link1_text = j+'_'+switch_id;

                                    if(a_obj.fx !=0 && a_obj.switch ==1 && a_obj.pingInvertal > 1){
                                        $.each(server_link_arr,function(s,s_obj){
                                             
                                            if(s_obj.text == link_text || s_obj.text == link1_text){
                                                s_obj.strokeColor = '0,255,144';
                                                // s_obj.PointPathColor="rgb(0,255,144)";
                                            }
                                        })
                                    }else{

                                        $.each(server_link_arr,function(s,s_obj){
                                            if(s_obj.text == link_text || s_obj.text == link1_text){
                                                s_obj.strokeColor = '255,0,0';
                                                // s_obj.PointPathColor="rgb(255,0,0)";
                                            }
                                        })
                                    }

                                })
                            }
                            
                            // console.log(hardware_wrong_str)
                            if(hardware_wrong_str != '' && obj.error_degree != 0){
                                hardware_wrong_str = obj.hardware_name+':'+hardware_wrong_str;
                                hardware_wrong.push(hardware_wrong_str);
                            }

                            if(obj.error_degree == 0){
                                alarm_node.alarm = null;
                                if(is_main != undefined){
                                    //主备切换
                                    if(obj.server_type == 2){
                                        if(obj.is_middel_server == 1){
                                            server_img = 'pstn/bypass.png';
                                        }else if(obj.is_middel_server == 0){
                                            if(is_main == 0){
                                                server_img = 'pstn/server_b.png';
                                            }else{
                                                server_img = 'pstn/server_m.png';
                                            }
                                        }else{
                                            if(obj.is_main == 0){
                                                server_img = 'pstn/ntp_server2.png';
                                            }else{
                                                server_img = 'pstn/ntp_server1.png';
                                            }

                                        }
                                        alarm_node.setImage(img_path+server_img,true);
                                        // alarm_node.setSize(28,39);
                                    }else if(obj.server_type == 1){
                                        alarm_node.setImage(img_path+'pstn/router.png',true);
                                    }
                                }
                            }else{
                                //进行告警信息的添加



                                if(is_main != undefined){
                                    //主备切换
                                    if(obj.server_type == 2){
                                        // var one_obj_childs = hardware_node.childs[0];
                                        if(obj.is_middel_server == 1){
                                            server_img = 'pstn/bypass1.png';
                                        }else if(obj.is_middel_server == 0){
                                            if(is_main == 0){
                                                server_img = 'pstn/server_b1.png';
                                            }else{
                                                server_img = 'pstn/server_m1.png';
                                            }
                                        }else{
                                                server_img = 'pstn/ntp_server3.png';
                                        }
                                        alarm_node.setImage(img_path+server_img,true);
                                        // alarm_node.setSize(28,39);
                                    }else if(obj.server_type == 1){
                                        alarm_node.setImage(img_path+'pstn/router1.png',true);
                                    }
                                }
                                if(obj.error_degree == 1){
                                    alarm_node.alarm = '告警';
                                    alarm_node.alarmColor = '255,255,0';
                                    if(obj.sound_switch == 1){
                                        $('#yellowAudio')[0].play();
                                    }
                                }else{
                                    alarm_node.alarm = '告警';
                                    alarm_node.alarmColor = '255,0,0';
                                    if(obj.sound_switch == 1){
                                        $('#redAudio')[0].play();
                                    }
                                }

                            }


                        }
                        if(obj.server_type == 2){
                            if(obj.is_middel_server ==2){
                                    alarm_node.setSize(40,32);

                            }else{
                                    alarm_node.setSize(28,39);
                            }
                        }

                    })
                }
                //基站
                var station_wrong = [];

                $.each(station_info,function(i,obj){
                    var station_wrong_str = '';
                    console.log(obj)
                    if(station_node_arr[obj.station_id]){
                        station_node_arr[obj.station_id].childs[0].setImage(img_path+'pstn/' + obj.station_img, true); //时刻进行背景图的更换
                        station_node_arr[obj.station_id].childs[0].setSize(27,40);
                        


                        if(obj.alarm_status != 0){
                            station_node_arr[obj.station_id].childs[0].alarm = '告警';
                            if( (obj.channel_status_A == 0 && obj.channel_status_B == 0) || ((obj.enable_A == 0 || obj.enable_A == 2)&&obj.channel_status_B ==0) || ((obj.enable_B == 0 || obj.enable_B == 2)&&obj.channel_status_A ==0)  ){
                                station_node_arr[obj.station_id].childs[0].alarmColor = '255,0,0';
                                if(obj.sound_switch == 1){
                                    $('#redAudio')[0].play();
                                }

                            }else{
                                station_node_arr[obj.station_id].childs[0].alarmColor = '255,255,0';
                                if(obj.sound_switch ==1){
                                    $('#yellowAudio')[0].play();
                                }

                            }
                            //进行错误信息的搜集
                            /*if(obj.is_monitor){
                                if(obj.enable_A == 1 || obj.enable_A == 3){
                                    if(!obj.channel_status_A == 0){
                                        if(Number(obj.channel_data_A) <= 0){
                                            station_wrong_str += 'A通道暂无航迹量,';
                                        }

                                        if(Number(obj.channel_data_A) < Number(obj.data_upper_limit_A)){
                                            station_wrong_str += 'A通道当前航迹量小于最小航迹数,';

                                        }else{
                                            // if(obj.cat247_switch == 0 && obj.cat023_switch ==1){
                                            //     station_wrong_str += 'A通道cat023数据异常,';
                                            // }else if(obj.cat247_switch == 1 && obj.cat023_switch ==1){
                                            //     if(obj.version_alarm_A == 0){
                                            //         station_wrong_str += 'A通道cat023数据异常,';
                                            //     }
                                            // }
                                        }
                                        if(obj.cat247_switch == 0 && obj.cat023_switch ==1){
                                                station_wrong_str += 'A通道cat023数据异常,';
                                        }else if(obj.cat247_switch == 1 && obj.cat023_switch ==1){
                                            if(obj.version_alarm_A == 0){
                                                station_wrong_str += 'A通道cat023数据异常,';
                                            }
                                        }
                                        if(obj.cat247_switch == 1){
                                            if(obj.version_alarm_A == -1){
                                                station_wrong_str += 'A通道版本匹配数据流失,';

                                            }else if(obj.version_alarm_A == 1){
                                                station_wrong_str += 'A通道版本匹配错误,';
                                            }
                                        }

                                    }
                                }
                                if(obj.enable_B == 1 || obj.enable_B == 3){
                                    if(obj.channel_status_B == 0){
                                         if(Number(obj.channel_data_B) <= 0){
                                            station_wrong_str += 'B通道暂无数据量,';
                                        }
                                        if(Number(obj.channel_data_B) < Number(obj.data_upper_limit_B)){
                                            station_wrong_str += 'B通道当前航迹量小于最小航迹数,';

                                        }else{
                                            if(obj.cat247_switch == 0 && obj.cat023_switch ==1){
                                                station_wrong_str += 'B通道cat023通道数据异常,';
                                            }else if(obj.cat247_switch == 1 && obj.cat023_switch ==1){
                                                if(obj.version_alarm_B == 0){
                                                    station_wrong_str += 'B通道cat023通道数据异常,';
                                                }
                                            }
                                        }
                                        if(obj.cat247_switch ==1){
                                            if(obj.version_alarm_B == -1){
                                                station_wrong_str += 'B通道版本匹配数据流失,';

                                            }else if(obj.version_alarm_B == 1){
                                                station_wrong_str += 'B通道版本匹配错误,';
                                            }
                                        }
                                    }
                                }

                            }*/
                            // $('#redAudio')[0].play();
                            // if(station_wrong_str != ''){
                            //     // station_wrong_str = obj.station_name+':'+station_wrong_str.substring(0,station_wrong_str.length-1);
                            //     // station_wrong.push(station_wrong_str);
                            //     station_wrong.push()
                            // }
                            if(obj.error_info != ''){
                                station_wrong.push(obj.error_info);
                            }

                        }else{
                            if(obj.enable_A == 0 && obj.enable_B == 0){
                                /*console.log(station_node_arr[obj.station_id].childs[0])
                                station_node_arr[obj.station_id].childs[0].alarm = '通道关闭';
                                station_node_arr[obj.station_id].childs[0].chromefillColor = "255,255,255";

                                station_node_arr[obj.station_id].childs[0].alarmColor = '255,255,255';*/

                            }else{
                                station_node_arr[obj.station_id].childs[0].alarm = null;

                            }

                        }
                // console.log(station_wrong_str)

                        if(obj.is_monitor == 1){
                            if(obj.enable_A == 1 || obj.enable_A == 3){
                                if(obj.channel_status_A == 1){
                                    if(obj.current_work_pass == 1){
                                        station_node_arr[obj.station_id].childs[1].setImage(img_path+'pstn/route_a.png');
                                    }else{
                                        station_node_arr[obj.station_id].childs[1].setImage(img_path+'pstn/route_a1.png');
                                    }
                                }else{
                                    station_node_arr[obj.station_id].childs[1].setImage(img_path+'pstn/route_a2.png');
                                }
                            }else{
                                station_node_arr[obj.station_id].childs[1].setImage(img_path+'pstn/route_a3.png');
                            }

                        }else{
                            station_node_arr[obj.station_id].childs[1].setImage(img_path+'pstn/route_a3.png');

                        }

                        if(obj.is_monitor == 1){
                            if(obj.enable_B == 1 || obj.enable_B == 3){

                                if(obj.channel_status_B == 1){
                                    if(obj.current_work_pass == 2){
                                        station_node_arr[obj.station_id].childs[2].setImage(img_path+'pstn/route_b.png');
                                    }else{
                                        station_node_arr[obj.station_id].childs[2].setImage(img_path+'pstn/route_b1.png');
                                    }
                                }else{
                                    station_node_arr[obj.station_id].childs[2].setImage(img_path+'pstn/route_b2.png');
                                }
                            }else{
                                station_node_arr[obj.station_id].childs[2].setImage(img_path+'pstn/route_b3.png');

                            }
                        }else{
                            station_node_arr[obj.station_id].childs[2].setImage(img_path+'pstn/route_b3.png');

                        }
                        station_node_arr[obj.station_id].childs[1].setSize(28,12);
                        station_node_arr[obj.station_id].childs[2].setSize(28,12);
                    }


                });
                var rader_wrong = [];
                $.each(rader_info,function(i,obj){
                    var rader_str = '';
                    if(rader_node_arr[obj.id]){
                        rader_node_arr[obj.id].childs[0].setImage(img_path+'pstn/' + obj.rader_img, true); //时刻进行背景图的更换
                        rader_node_arr[obj.id].childs[0].setSize(45,45);
                        if(obj.is_monitor == 1){
                            if(obj.path_switch_a == 1){
                                if(obj.path_a_alarm == 0){
                                    if(obj.in_work_option == 1 || obj.in_work_option == 3){
                                        rader_node_arr[obj.id].childs[1].setImage(img_path+'pstn/route_a.png');
                                    }else{
                                        rader_node_arr[obj.id].childs[1].setImage(img_path+'pstn/route_a1.png');
                                    }
                                }else{
                                    rader_node_arr[obj.id].childs[1].setImage(img_path+'pstn/route_a2.png');
                                    rader_str += obj.name+':A通道数据异常';
                                }
                            }else{
                                rader_node_arr[obj.id].childs[1].setImage(img_path+'pstn/route_a3.png');
                            }

                        }else{
                            rader_node_arr[obj.id].childs[1].setImage(img_path+'pstn/route_a3.png');

                        }

                        if(obj.is_monitor == 1){
                            if(obj.path_switch_b == 1){
                                if(obj.path_b_alarm == 0){
                                    if(obj.in_work_option == 2){
                                        rader_node_arr[obj.id].childs[2].setImage(img_path+'pstn/route_b.png');
                                    }else{
                                        rader_node_arr[obj.id].childs[2].setImage(img_path+'pstn/route_b1.png');
                                    }
                                }else{
                                    rader_node_arr[obj.id].childs[2].setImage(img_path+'pstn/route_b2.png');
                                    rader_str += obj.name+':B通道数据异常';

                                }
                            }else{
                                rader_node_arr[obj.id].childs[2].setImage(img_path+'pstn/route_b3.png');
                            }

                        }else{
                            rader_node_arr[obj.id].childs[2].setImage(img_path+'pstn/route_b3.png');

                        }

                        if(obj.rader_alarm == 1){
                            rader_node_arr[obj.id].childs[0].alarm = '告警';
                            if(obj.sound_switch == 1){
                                $('#redAudio')[0].play();
                            }
                        }else{
                            rader_node_arr[obj.id].childs[0].alarm = null;

                        }
                    }
                    if(rader_str != ''){
                        rader_wrong.push(rader_str);

                    }

                });

                //左侧消息的显示
                left_warnings(hardware_wrong,station_wrong,rader_wrong);
            }

        });

        /*source.onerror = function(e){
            console.log(e)
        }
        source.onopen = function(e){
            console.log(e)
        }*/
    }else{
        document.getElementById('geleral_time').innerHTML = 'sorry,please use chrome browser';
    }



  
/*     $.ajax({
         type: "POST",
         url: SITE_URL+folder_name+"/appMonitor/hardware_status",
         async: true,
         type:'json',
         success:function(response){
             if(!response){
                console.log(123);
             }else{
                 json_data = jQuery.parseJSON(response);
                 console.log(json_data);
            }
         },   
         error: function (request, status, error) {
         //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
            console.log('error')
         }
     });*/
    
// add_alarm_sounds();
});



//根据节点名获取容器中的子元素
function get_container_child(container,text){
    var child_node;
    $.each(container.childs,function(i,obj){
        if(obj.text.toLowerCase() == text.toLowerCase()){
            child_node = obj;
        }
    });
    return child_node;
}

//添加连线
function addLink(fromNode, toNode, text, line_color,f) {
    /* CanvasRenderingContext2D.prototype.JtopoDrawPointPath=function(a,b,c,d,e,f){
     var animespeed=(new Date())/10;
     var xs=c- a,
     xy=d- b,
     l = Math.floor(Math.sqrt(xs * xs + xy * xy)),
     colorlength=50,
     j=l;
     xl=xs/ l,
     yl=xy/l;
     var colorpoint=animespeed%(l+colorlength)-colorlength;
     for(var i=0;i<j;i++){
     if(((i)>colorpoint)&&((i)<(colorpoint+colorlength))){
     this.beginPath();
     this.strokeStyle=e;
     this.moveTo(a+(i-1)*xl,b+(i-1)*yl);
     this.lineTo(a+i*xl,b+i*yl);
     this.stroke();
     }else{
     this.beginPath();
     this.strokeStyle=f;
     this.moveTo(a+(i-1)*xl,b+(i-1)*yl);
     this.lineTo(a+i*xl,b+i*yl)
     this.stroke();
     }
     }
     };*/
    if(f ==1){
        var link = new JTopo.Link(fromNode, toNode, text);
    }else{
        var link = new JTopo.FoldLink(fromNode, toNode, text);


    }

    link.font = '0px Consolas' ;
    link.shadow = false;
    link.lineWidth = 2;
    link.bundleOffset = 60; // 折线拐角处的长度
    link.bundleGap = 20; // 线条之间的间隔
    // link.textOffsetY = 3; // 文本偏移量（向下3个像素）
    link.strokeColor = line_color;
    link.direction = 'vertical';
    // link.PointPathColor="rgb(0,255,144)";
    /*    link.paintPath = function(a, b) {
     if (this.nodeA === this.nodeZ) return void this.paintLoop(a);
     a.beginPath(),
     a.moveTo(b[0].x, b[0].y);
     for (var c = 1; c < b.length; c++) {

     null == this.dashedPattern ? (
     (null==this.PointPathColor?a.lineTo(b[c].x, b[c].y):a.JtopoDrawPointPath(b[c - 1].x, b[c - 1].y, b[c].x, b[c].y, a.strokeStyle,this.PointPathColor))
     ) : a.JTopoDashedLineTo(b[c - 1].x, b[c - 1].y, b[c].x, b[c].y, this.dashedPattern)
     };
     if (a.stroke(), a.closePath(), null != this.arrowsRadius) {
     var d = b[b.length - 2],
     e = b[b.length - 1];
     this.paintArrow(a, d, e)
     }
     } */


    // link.id = toNode.id;
    bindLinkEvent(link);
    return link;
}

var currentLink = null;
//绑定连线事件
function bindLinkEvent(link) {
    // console.log(link)
    link.mousedown(function (evt) {
        currentLink = link;
        if (evt.button == 0) {
            //console.log(event);
            //左键 可拖动
            currentLink.dragable = true;
        } else if (evt.button == 2) {
            scene.dragable = false;
            stage.dragable = false;
            var content = document.getElementById('content');
            var menu = document.getElementById('linkmenu');
            /*获取当前鼠标右键按下后的位置，据此定义菜单显示的位置*/
            var rightedge = content.clientWidth - evt.clientX;
            var bottomedge = content.clientHeight - evt.clientY;
            /*如果从鼠标位置到容器右边的空间小于菜单的宽度，就定位菜单的左坐标（Left）为当前鼠标位置向左一个菜单宽度*/
            if (rightedge < menu.offsetWidth)
                menu.style.left = content.scrollLeft + evt.clientX - menu.offsetWidth + "px";
            else
            /*否则，就定位菜单的左坐标为当前鼠标位置*/
                menu.style.left = content.scrollLeft + evt.clientX + "px";

            /*如果从鼠标位置到容器下边的空间小于菜单的高度，就定位菜单的上坐标（Top）为当前鼠标位置向上一个菜单高度*/
            if (bottomedge < menu.offsetHeight)
                menu.style.top = content.scrollTop + evt.clientY - menu.offsetHeight + "px";
            else
            /*否则，就定位菜单的上坐标为当前鼠标位置*/
                menu.style.top = content.scrollTop + evt.clientY + "px";

            /*设置菜单可见*/
            $("#menuMask").css("display", "block");
            menu.style.display = "block";
        }
    });
}

function add_alarm_sounds(){
    $('<audio id="redAudio"><source src="<?php echo AUDIO_PATH;?>red.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>red.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>red.wav" type="audio/ogg"></audio><audio id="yellowAudio"><source src="<?php echo AUDIO_PATH;?>yellow.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>yellow.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>yellow.wav" type="audio/ogg"></audio>').appendTo('body');

}

//左侧的告警显示
function left_warnings(hardware_wrong,station_wrong,rader_wrong){

    if(hardware_wrong.length > 0){
        var tmp_hardware = '';
        $.each(hardware_wrong,function(i,obj){
            tmp_hardware += '<li class="list-group-item">'+obj+'</li>';
        })
        $('.hardware_content').html(tmp_hardware);
    }else{
        $('.hardware_content').html('暂无');

    }
    if(station_wrong.length > 0){
        var tmp_station = '';
        $.each(station_wrong,function(i,obj){
            tmp_station += '<li class="list-group-item">'+obj+'</li>';
        })
        $('.station_content').html(tmp_station);

    }else{
        $('.station_content').html('暂无');

    }
    if(rader_wrong.length > 0){
        var tmp_rader = '';
        $.each(rader_wrong,function(i,obj){
            tmp_rader += '<li class="list-group-item">'+obj+'</li>';
        })
        $('.rader_content').html(tmp_rader);
    }else{
        $('.rader_content').html('暂无');
    }
    $('#pop_div').fadeIn(400);



}
