/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-23
 * Time: 下午2:33
 * To change this template use File | Settings | File Templates.
 */

define(function(require){
    var $ = require('jquery');
    require('bootstrap');
    require('datepicker');


var server_type = data_list.server_type;
    var alert_warning = $('.alert-warning');
    setInterval(function(){
      var timing_data = ajax_data(hardware_id); 
      if(timing_data){
           //cpu
           if(timing_data['error_degree'] ==2){
              $('.alert-warning').html(timing_data.error_info);
              $('.alert-warning').show();
           }else{
              $('.alert-warning').hide();
           }
              
            if(timing_data['error_degree'] >0){
                $('#sound_switch').show();
                if(timing_data['sound_switch'] == 1){
                  var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+hardware_id+',0,0)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声关闭</p>'
                }else{
                  var p_obj = '<p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm('+hardware_id+',1,0)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声开启</p>'
                }
                $('#sound_switch').html(p_obj);

            }else{
                $('#sound_switch').hide();

            }
            var ntp_time = timing_data['snmp']['time'];
            var timeDiff = new Date().valueOf()-ntp_time*1000;
            $('#time_box').html(server_Time(timeDiff));
            if(timing_data.is_main != undefined){
              var main_html = $('#main_info');
                  if(timing_data.is_main == 1){
                    main_html.html(' (主用)');
                  }else{
                    
                    main_html.html(' (备用)');
                  }
           }
      }

    }, 1000);

/*    $('.data-hide').click(function(){

        var data_hide = $(this).attr('data-hide');
        console.log(123)
        $('#model_content').html(data_hide);
    })*/


});

function ajax_data(hardware_id){
  var json_res='';
    $.ajax({
              type: "POST",
              url: SITE_URL+folder_name+"/appMonitor/timing_hardware_detail/"+hardware_id,
              // data:'server_id ='+server_id,
              async: false,
              success:function(response){
                  json_res = JSON.parse(response);
              },
              error: function (request, status, error) {
                  //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
              }
               
    });
    return json_res;
}


//时间戳转日期
function fmtDate(timeStamp){
       var date = new Date();  
    date.setTime(timeStamp * 1000);  
    var y = date.getFullYear();      
    var m = date.getMonth() + 1;      
    m = m < 10 ? ('0' + m) : m;      
    var d = date.getDate();      
    d = d < 10 ? ('0' + d) : d;      
    var h = date.getHours();    
    h = h < 10 ? ('0' + h) : h;    
    var minute = date.getMinutes();    
    var second = date.getSeconds();    
    minute = minute < 10 ? ('0' + minute) : minute;      
    second = second < 10 ? ('0' + second) : second;     
    return y + '-' + m + '-' + d+' '+h+':'+minute+':'+second;     
}


    
    function server_Time(timeDiff){
        this.date = new Date();
        date.setTime(new Date().valueOf()-timeDiff);
        this.Y = date.getUTCFullYear() + '-';
        this.M = (date.getUTCMonth()+1 < 10 ? '0'+(date.getUTCMonth()+1):date.getUTCMonth()+1)+'-';
        this.D = date.getUTCDate() <10 ? '0' + date.getUTCDate() + ' ' :date.getUTCDate() + ' ';
        this.h = date.getUTCHours() < 10 ? '0' + date.getUTCHours() + ':':date.getUTCHours() + ':';
        this.m = date.getUTCMinutes() <10 ? '0' + date.getUTCMinutes() + ':':date.getUTCMinutes() + ':';
        this.s = date.getUTCSeconds() <10 ? '0' + date.getUTCSeconds():date.getUTCSeconds();
        return Y + M + D + h + m + s;
        
    }

function auto_alarm_switch(hardware_id){
    $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/appMonitor/auto_alarm_switch/"+hardware_id,
            async: false,
            success:function(response){
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
               console.log('error');
            }
        });
} 
