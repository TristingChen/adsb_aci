/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-9
 * Time: 下午3:10
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');

    var canvas = document.getElementById('canvas');
    var stage = new JTopo.Stage(canvas);
    //显示工具栏
    showJTopoToobar(stage);

    var scene = new JTopo.Scene();
    scene.background = img_path+'pstn/bg.jpg';

    var content_width = $('#content').width();
    var navbar_height = $("#navbar").height();
    var breadcrumb_height = $("#breadcrumb").height();
    var JTopoToobar_heigth = $('.jtopo_toolbar').height();
    var body_height =  $(document.body).height();
    $("#canvas").attr("width",content_width);
    $("#canvas").attr("height",body_height - navbar_height - breadcrumb_height - JTopoToobar_heigth - 50);


    function node(x, y, img, name,position,size=false,c,d,z_index=false){
        var node = new JTopo.Node(name);
        node.setLocation(x, y);
        // console.log(size);
        if(size){
            node.setImage(img_path+'pstn/' + img);
            node.setSize(c,d);
        }else{
             node.setImage(img_path+'pstn/' + img, true);

        }
        if(z_index){
            node.zindex = 99;
        }
        node.textPosition = position;
        bindNodeEvent(node);
        scene.add(node);
        return node;
    }


    function linkNode(nodeA, nodeZ,f=false){
        var link;
        if(f){
            var link = new JTopo.FoldLink(nodeA, nodeZ);
            link.direction = 'vertical';
        }else{
            var link = new JTopo.Link(nodeA, nodeZ);
            link.bundleOffset = 90;
        }
       
        link.arrowsRadius =1;
        link.lineWidth = 3;
        link.strokeColor = JTopo.util.randomColor();
        link.bundleGap = 20;
        link.getStartPosition = function () {
            var a;
            return (a = (function (thisl) {
                var b = thisl.nodeA, c = thisl.nodeZ;
                var d = JTopo.util.lineF(b.cx, b.cy, c.cx+20, c.cy+20),
                    e = b.getBound(),
                    f = JTopo.util.intersectionLineBound(d, e);
                return f;
            })(this)),
                null == a && (a = {
                    x: this.nodeZ.cx,
                    y: this.nodeZ.cy
                }), a;
        };

        scene.add(link);
        return link;
    }


    function ethernets(x,y,eth_num,container){
        var j = 1;
        var eth = new Array();
        for(var i=0;i<eth_num;i++){
            eth[i] = new JTopo.Node("Eth"+i);
            eth[i].textPosition = "Middle_Center";
            eth[i].width = 50;
            eth[i].height = 25;
            eth[i].alpha = 0.5;
            eth[i].fontColor = '0,0,0';
            eth[i].fillColor = '255,255,240';
            j = (i%8!=0)?j:j+1;
            eth[i].setLocation(x+50*(i%8),25*j+y);
            eth[i].dragable = false;
            container.add(eth[i]);
            scene.add(eth[i]);
        }
    }
    //var container = new Array();
    function appServer(nodes,text){
        var container = new JTopo.Container('text');
        container.fillColor = '255.255.0';
      
        //container[num].zIndex = 10;
        container.childDragble = false;
        container.dragble = true;
        container.borderColor = '255.255.0';
        container.borderWidth = 2;
        container.alpha = 0;
        container.zindex = 100;
        // ethernets(x,y,eth_num,container);
        // bindNodeEvent(container);
        console.log(container)
        container.add(nodes);
        scene.add(container);
        return container;
    }


    var input_net1 = node(120,43,'modem.png','输入网','Middle_Left');
    var input_net2 = node(120,53,'modem.png','','Middle_Left');

    var output_net1 = node(1400,43,'modem.png','输出网','Middle_Right');
    var output_net2 = node(1400,53,'modem.png','','Middle_Right');


    var wall_server = node(700,43,'mainframe.png','路旁处理服务器','Top_Center');
   /* var a_net = node(20,400,'modem.png','A','Middle_Left',true,1600,6);
    var b_net = node(20,440,'modem.png','B','Middle_Left',true,1600,6);
    var c_net = node(20,480,'modem.png','C','Middle_Left',true,1600,6);*/

     var a_net_line = node(21,400,'a.png','A','Middle_Left',true,1600,6);
     var b_net_line = node(21,440,'b.png','B','Middle_Left',true,1600,6);
     var c_net_line = node(21,480,'c.png','C','Middle_Left',true,1600,6);
   
    // var ads_server_a = node(120,200,'router.png','A网交换服务器','Top_Left',false,'','',true);
    var a1 = node(120,200,'','','',true,1,1);
    var a2 = node(130,200,'','','',true,1,1);
    var a3 = node(140,200,'','','',true,1,1);

    var b1 =  node(1120,200,'','','',true,1,1);
    var b2 =  node(1140,200,'','','',true,1,1);
    var b3 =  node(1160,200,'','','',true,1,1);



    var ads_server_b = node(320,200,'router.png','B网交换服务器','Top_Left');

    var ads_server_c = node(120,520,'router.png','A网处理服务器','Top_Left');

    var ads_server_d = node(320,520,'router.png','A网处理服务器','Top_Left');

     var ads_server_e = node(920,200,'router.png','A网处理服务器','Top_Left');
     var ads_server_f = node(1120,200,'router.png','A网处理服务器','Top_Left');

     
     //连线
    linkNode(input_net1,wall_server);
    linkNode(input_net2,wall_server);
    linkNode(output_net1,wall_server);
    linkNode(output_net2,wall_server);

   /* linkNode(ads_server_a,input_net1);
    linkNode(ads_server_a,input_net2,true);*/
    //test
    linkNode(a1,a_net_line,true);
    linkNode(a2,b_net_line,true);
    linkNode(a3,c_net_line,true);
    linkNode(b1,a_net_line,true);
    linkNode(b2,b_net_line,true);
    linkNode(b3,c_net_line,true);

    appServer(a1);
    appServer(a2);
    appServer(a3);
    // appServer(ads_server_a);



    /*inkNode(ads_server_b,a_net_line,true);
    // linkNode(ads_server_a,b_net_line,true);
    linkNode(ads_server_b,b_net_line,true);
    // linkNode(ads_server_a,c_net_line,true);
    linkNode(ads_server_b,c_net_line,true);*/


    


    stage.add(scene);
    
});

//根据节点名获取容器中的子元素
function get_container_child(container,text){
    var child_node;
    $.each(container.childs,function(i,obj){
        if(obj.text.toLowerCase() == text.toLowerCase()){
            child_node = obj;
        }
    });
    return child_node;
}

//添加连线
function addLink(fromNode, toNode, text, line_color,line_type) {
    var link = new JTopo.Link(fromNode, toNode, text);
    link.shadow = false;
    link.lineWidth = 1;
    link.bundleOffset = 60; // 折线拐角处的长度
    link.bundleGap = 20; // 线条之间的间隔
    link.textOffsetY = 3; // 文本偏移量（向下3个像素）
    link.strokeColor = line_color;
    link.direction = 'horizontal';
    if(line_type == 2|| line_type ==4){
        link.dashedPattern = dashedPattern; //虚线
    }else if(line_type == 3||line_type == 4){
        link.arrowsRadius = 10; //箭头大小
    }
    link.id = toNode.id;
    link.getStartPosition = function () {
        var a;
        return (a = (function (thisl) {
            var b = thisl.nodeA, c = thisl.nodeZ;
            var d = JTopo.util.lineF(b.cx, b.cy, c.cx, c.cy),
                e = b.getBound(),
                f = JTopo.util.intersectionLineBound(d, e);
            return f;
        })(this)),
            null == a && (a = {
                x: this.nodeZ.cx,
                y: this.nodeZ.cy
            }), a;
    };
    link.getEndPosition = function () {
        var a;
        return (a = (function (thisl) {
            var b = thisl.nodeZ, c = thisl.nodeA;
            var d = JTopo.util.lineF(b.cx, b.cy, c.cx, c.cy),
                e = b.getBound(),
                f = JTopo.util.intersectionLineBound(d, e);
            return f;
        })(this)),
            null == a && (a = {
                x: this.nodeZ.cx,
                y: this.nodeZ.cy
            }), a;
    }
    bindLinkEvent(link);
    return link;
}

var currentLink = null;
//绑定连线事件
function bindLinkEvent(link) {
    link.mousedown(function (evt) {
        currentLink = link;
        if (evt.button == 0) {
            //console.log(event);
            //左键 可拖动
            currentLink.dragable = true;
        } else if (evt.button == 2) {
            scene.dragable = false;
            stage.dragable = false;
            var content = document.getElementById('content');
            var menu = document.getElementById('linkmenu');
            /*获取当前鼠标右键按下后的位置，据此定义菜单显示的位置*/
            var rightedge = content.clientWidth - evt.clientX;
            var bottomedge = content.clientHeight - evt.clientY;
            /*如果从鼠标位置到容器右边的空间小于菜单的宽度，就定位菜单的左坐标（Left）为当前鼠标位置向左一个菜单宽度*/
            if (rightedge < menu.offsetWidth)
                menu.style.left = content.scrollLeft + evt.clientX - menu.offsetWidth + "px";
            else
            /*否则，就定位菜单的左坐标为当前鼠标位置*/
                menu.style.left = content.scrollLeft + evt.clientX + "px";

            /*如果从鼠标位置到容器下边的空间小于菜单的高度，就定位菜单的上坐标（Top）为当前鼠标位置向上一个菜单高度*/
            if (bottomedge < menu.offsetHeight)
                menu.style.top = content.scrollTop + evt.clientY - menu.offsetHeight + "px";
            else
            /*否则，就定位菜单的上坐标为当前鼠标位置*/
                menu.style.top = content.scrollTop + evt.clientY + "px";

            /*设置菜单可见*/
            $("#menuMask").css("display", "block");
            menu.style.display = "block";
        }
    });
}

function bindNodeEvent(node){

    // console.log(node);
}
