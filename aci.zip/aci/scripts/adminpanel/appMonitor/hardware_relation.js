﻿/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-9
 * Time: 下午3:10
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
    require('topo');

    var canvas = document.getElementById('canvas');
    var stage = new JTopo.Stage(canvas);
    //显示工具栏
    showJTopoToobar(stage);

    var scene = new JTopo.Scene();
    scene.background = img_path+'pstn/bg.jpg';

    var content_width = $('#content').width();
    var navbar_height = $("#navbar").height();
    var breadcrumb_height = $("#breadcrumb").height();
    var JTopoToobar_heigth = $('.jtopo_toolbar').height();
    var body_height =  $(document.body).height();
    $("#canvas").attr("width",content_width);
    $("#canvas").attr("height",body_height - navbar_height - breadcrumb_height - JTopoToobar_heigth - 50);

    
    function node(x, y, img, name,server_id){

        var node = new JTopo.Node(name);
        
        node.setLocation(x, y);
        node.textPosition = "Bottom_Center";
        node.setImage(img_path+'pstn/' + img, true);
        node.setSize(60,60);
        // console.log(node)
        bindNodeEvent(node,server_id);
        scene.add(node);
        return node;
    }

    function appServer(x, y, img, name,server_id){
        var container = new JTopo.Container();
        // container.fillColor = '0,255,255';
        // container.zIndex = 10;
        x= Number(x);
        y= Number(y);
        container.childDragble = false;
        container.alpha = 0;
        container.setLocation(x, y);
        // container.layout = flowLayout1;
        scene.add(container);
        var original_dot = new JTopo.Node(name);
       
        original_dot.textPosition = "Bottom_Center";
       /* if(is_main == 0 && server_type == 2){
            original_dot.setImage(img_path+'pstn/server_b.png');
        }else{
            original_dot.setImage(img_path+'pstn/' + server_img);
        }*/
        original_dot.setImage(img_path+'pstn/' + img);
        
        original_dot.setSize(80,80);
        original_dot.setLocation(x, y);
        container.add(original_dot);
        scene.add(original_dot);
       /* var to_notes_arr = to_notes.split(',');
        var to_notes_len = to_notes_arr.length;
        if(kind == 1){
                station_route(x,y,container,server_id,channel_status_A,channel_status_B,current_work_pass,is_monitor);
        }else{
                ethernets(x,y,to_notes_len,container,server_id);
        }*/
        // bindNodeEvent(original_dot,server_id,container,kind,is_station);
        bindNodeEvent(original_dot,server_id);
        
        // bindAppEvent(container);
        return container;
    }

    function linkNode(nodeA, nodeZ){
        var link = new JTopo.FoldLink(nodeA, nodeZ);
        link.lineWidth = 3;
        link.strokeColor = '255,255,0';
        scene.add(link);
        return link;
    }

    function ethernets(x,y,eth_num,container){
        var j = 1;
        var eth = new Array();
        for(var i=0;i<eth_num;i++){
            eth[i] = new JTopo.Node();
            eth[i].width = 1;
            eth[i].height = 1;
            eth[i].fillColor = '255,255,0';
            eth[i].setLocation(x+20+i*10,y);
            eth[i].dragable = false;
             container.add( eth[i]);
        }
        scene.add(eth);
    }

    data_list = JSON.parse(data_list);
    var node_arr = new Array();
    $.each(data_list,function(i,obj){
        var server_name = obj['hardware_name'];
        var server_img = obj["relation_img"];
        var x = parseInt(obj["canvas_x"]);
        var y = parseInt(obj["canvas_y"]);
        var is_bypass = obj['is_bypass'];
        node_arr[obj['id']] = appServer(x,y,server_img,server_name,obj.main_hardware_id); 
        console.log( node_arr[obj['id']])

   });
    //连线
    // console.log(node_arr);
     $.each(data_list,function(i,obj){
        //ads是被动连接 不做主动的连线
           var to_end_notes_str = obj.to_nodes;
           var is_bypass = obj.is_bypass;
           if(to_end_notes_str){
                        var to_end_notes_arr = to_end_notes_str.split(',');
                       
                        var to_end_notes_len = to_end_notes_arr.length;
                        var start_notes = node_arr[obj.id];
                    if(to_end_notes_arr.length>0){
                        $.each(to_end_notes_arr,function(j,s_obj){
                           var link = addLink(start_notes,node_arr[s_obj],'','255,255,255');
                             scene.add(link);
                             var link = addLink(start_notes,node_arr[s_obj],'','255,255,255');
                             scene.add(link);

                             //进行数据的读取
                        })   
                    }
           }
          
        
    });


stage.add(scene);
    
});

//根据节点名获取容器中的子元素
function get_container_child(container,text){
    var child_node;
    $.each(container.childs,function(i,obj){
        if(obj.text.toLowerCase() == text.toLowerCase()){
            child_node = obj;
        }
    });
    return child_node;
}

//添加连线
function addLink(fromNode, toNode, text, line_color,f=false) {
    // console.log(f);
    if(f==0){
        var link = new JTopo.Link(fromNode, toNode, text);
    }else{
        var link = new JTopo.FoldLink(fromNode, toNode, text);
    }
    link.arrowsRadius = 15; //箭头大小
    link.shadow = false;
    link.lineWidth = 2;
    link.bundleOffset = 60; // 折线拐角处的长度
    link.bundleGap = 20; // 线条之间的间隔
    link.textOffsetY = 3; // 文本偏移量（向下3个像素）
    link.strokeColor = line_color;
    link.direction = 'vertical';
    link.getStartPosition = function () {
        var a;
        return (a = (function (thisl) {
            var b = thisl.nodeA, c = thisl.nodeZ;
            var d = JTopo.util.lineF(b.cx, b.cy, c.cx, c.cy),
                e = b.getBound(),
                f = JTopo.util.intersectionLineBound(d, e);
            return f;
        })(this)),
            null == a && (a = {
                x: this.nodeZ.cx,
                y: this.nodeZ.cy
            }), a;
    };
    link.getEndPosition = function () {
        var a;
        return (a = (function (thisl) {
            var b = thisl.nodeZ, c = thisl.nodeA;
            var d = JTopo.util.lineF(b.cx, b.cy, c.cx, c.cy),
                e = b.getBound(),
                f = JTopo.util.intersectionLineBound(d, e);
            return f;
        })(this)),
            null == a && (a = {
                x: this.nodeZ.cx,
                y: this.nodeZ.cy
            }), a;
    }
    // link.id = toNode.id;
    // bindLinkEvent(link);
    return link;
}

var currentLink = null;
//绑定连线事件
function bindLinkEvent(link) {
    link.mousedown(function (evt) {
        currentLink = link;
        if (evt.button == 0) {
            //console.log(event);
            //左键 可拖动
            currentLink.dragable = true;
        } else if (evt.button == 2) {
            scene.dragable = false;
            stage.dragable = false;
            var content = document.getElementById('content');
            var menu = document.getElementById('linkmenu');
            /*获取当前鼠标右键按下后的位置，据此定义菜单显示的位置*/
            var rightedge = content.clientWidth - evt.clientX;
            var bottomedge = content.clientHeight - evt.clientY;
            /*如果从鼠标位置到容器右边的空间小于菜单的宽度，就定位菜单的左坐标（Left）为当前鼠标位置向左一个菜单宽度*/
            if (rightedge < menu.offsetWidth)
                menu.style.left = content.scrollLeft + evt.clientX - menu.offsetWidth + "px";
            else
            /*否则，就定位菜单的左坐标为当前鼠标位置*/
                menu.style.left = content.scrollLeft + evt.clientX + "px";

            /*如果从鼠标位置到容器下边的空间小于菜单的高度，就定位菜单的上坐标（Top）为当前鼠标位置向上一个菜单高度*/
            if (bottomedge < menu.offsetHeight)
                menu.style.top = content.scrollTop + evt.clientY - menu.offsetHeight + "px";
            else
            /*否则，就定位菜单的上坐标为当前鼠标位置*/
                menu.style.top = content.scrollTop + evt.clientY + "px";

            /*设置菜单可见*/
            $("#menuMask").css("display", "block");
            menu.style.display = "block";
        }
    });
}

function bindNodeEvent(node,server_id){
    node.dbclick(function(event){
        // window.location.href="/adminpanel/appMonitor/one_hardware_detail/"+server_id;
        window.location.href="/adminpanel/appMonitor/one_hardware_detail/"+server_id;
    })
    // alert(node.elementType);
}

function newFoldLink(nodeA, nodeZ, text, direction, dashedPattern){
    var link = new JTopo.FoldLink(nodeA, nodeZ, text);
    link.direction = direction || 'horizontal';
    link.arrowsRadius = 15; //箭头大小
    link.lineWidth = 3; // 线宽
    link.bundleOffset = 60; // 折线拐角处的长度
    link.bundleGap = 20; // 线条之间的间隔
    link.textOffsetY = 3; // 文本偏移量（向下3个像素）
    link.strokeColor = JTopo.util.randomColor(); // 线条颜色随机
    link.dashedPattern = dashedPattern;




    // scene.add(link);
    return link;
}