define(function (require) {
	var $ = require('jquery');
	var aci = require('aci');
	require('bootstrap');

	$("#reverseBtn").click(function(){
		aci.ReverseChecked('pid[]');
	});

	$("#lockBtn").click(function(){
		var _arr = aci.GetCheckboxValue('pid[]');
		if(_arr.length==0)
		{
			alert("请先勾选明细");
			return false;
		}

		if(confirm("确定要反设置禁止登录？"))
		{
			$("#form_list").attr("action",SITE_URL+folder_name+"/user/lock/");
			$("#form_list").submit();
		}
	});

	$("#deleteBtn").click(function(){
		var _arr = aci.GetCheckboxValue('pid[]');
		if(_arr.length==0)
		{
			alert("请先勾选明细");
			return false;
		}

		if(confirm("确定要删除用户吗？"))
		{
			$("#form_list").attr("action",SITE_URL+folder_name+"/user/delete/");
			$("#form_list").submit();
		}
	});

	  $('.use_server').click(function(){
      var server_id = $(this).attr('server_id');
      var change_info='';
      if(server_id == 1){
           change_info = '关机';
      }else if(server_id == 0){
           change_info = '重启';
      }
      var pid = $('.hardware_id_check:checked');
      if(confirm('确定要'+change_info)){ 
      		if(pid.length == 0){
      			alert('请先进行设备的勾选');
      			return false;
      		}else{
      			var post_data = [];
      			pid.each(function(i,obj){
      				post_data.push($(this).val());
      			})

      		}
      		pid_obj = {};
      		  pid_obj['hardware_id_arr'] = post_data
              $.ajax({
              type: "POST",
              url: SITE_URL+folder_name+"/hardwareMonitor/use_server/"+server_id,
              data:pid_obj,
              // data:'server_id ='+server_id,
              async: false,
              success:function(response){
                  json_res = JSON.parse(response);
                  alert(json_res.tips);
                  //进行table表格的替换
              },
              error: function (request, status, error) {
                  //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
              }
               
          });
      }





  })



});