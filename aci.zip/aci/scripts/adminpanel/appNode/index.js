/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-28
 * Time: 上午10:08
 * To change this template use File | Settings | File Templates.
 */
define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('bootstrapValidator');
    require('message');
});

function make_table_html()
{
    var app_id = $("#app_id option:selected").val();
    $.ajax({
        type: "POST",
        url: SITE_URL+folder_name+"/appNode/index/"+app_id,
        async: false,
        success:function(response){
            var table_html = response;
            $("#tbody").html(table_html);
            var add_node_html = "<a href='"+ SITE_URL+folder_name+"/appNode/add/0/"+app_id+"' class='btn btn-sm pull-right'>";
            add_node_html += "<span class='glyphicon glyphicon-plus'></span> 添加节点</a>";
            $("#add_node").html(add_node_html);
        },
        error: function (request, status, error) {
            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
        }
    });
}
