define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

    $("#reverseBtn").click(function(){
        aci.ReverseChecked('pid[]');
    });
     $("#pro_file").click(function(){
         $.ajax({
	        type: "POST",
	        url: SITE_URL+folder_name+"/station/produce_xml",
	        dataType:'text',
	        async: false,
	        success:function(response){
	          if(response){
                alert('配置文件生成成功');
              } else{
                alert('配置文件生成失败');
              }
       		 },
	        error: function (request, status, error) {
	            //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
	        }
    	});
    });

     var sta_id,old_val,current_td
     $('.shift-main').click(function() {
       // body...
         old_val = $(this).attr('old_value');
         sta_id = $(this).attr('sta_id');
         current_td = $(this).parents('tr').find('.current_td');
     });




    $("#change_current_path").click(function(){
        var cur_data = $('#modal_current_path').children('option:selected').val();
          $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/station/change_current_path/"+sta_id+'/'+cur_data+'/'+old_val,
            dataType:'text',
            async: false,
            success:function(response){
                if(response != -1){
                     if(response == 2){
                        current_td.html('A');
                     }else if(response == 3){
                        current_td.html('B');
                     }
                    
                     alert('切换成功');
                }else{
                 
                   alert('切换失败');
                }
                   
                
            },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
               console.log(1212342)

            }
        });
        $('#myModal').hide();
        
    })


});