define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

    $(".uploadThumb_a").click(function(){
        $.extDialogFrame(SITE_URL+folder_name+"/user/upload/thumb/thumb/1",{model:true,width:600,height:250,title:'请上传...',buttons:null});
    });
    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        }
    };

    $('#add_dots').click(function(){
        var old_dot_num = $('.form-group:last').attr('dot_num');
        if(!old_dot_num){
            old_dot_num = 0;
        }
        var new_dot_num = Number(old_dot_num)+1;
        /*var dots_add = '<div class="form-group has-feedback" dot_num = '+new_dot_num+'>
        <label for="longtitude"  class="col-sm-2 control-label dots" >多边形点'+new_dot_num+':</label><div class="controls controls-row"><input name="longtitude[]"  class="span1" type="number" step="0.01" placeholder="经度"  value=""/><input name="latitude[]"  class="span1" type="number" step="0.01"    placeholder="纬度"  value=""/><span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span></div></div>';*/
        var dots_add = '<div class="form-group" dot_num = "'+new_dot_num+'">';
            dots_add += '<label for="longtitude"  class="col-sm-2 control-label dots" >多边形点'+new_dot_num+':</label>';
            dots_add += '<div class="controls controls-row col-xs-2">';
            dots_add += '<input name="longtitude[]"  class="form-control validate[required]" type="number" step="0.01" placeholder="经度"  value=""/></div>';
            dots_add += '<div class="controls controls-row col-xs-2">';
            dots_add += '<input name="latitude[]"  class="form-control validate[required]" type="number" step="0.01"   placeholder="纬度"  value=""/></div>';
            dots_add += '<div class="controls controls-row col-xs-2">';  
            dots_add += '<span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span></div>';
            dots_add +=  '</div>';
        $('fieldset').append(dots_add);
    })
/*    $('.dots_remove').on('click',function(){
        var father_group = $(this).parents('.form-group');
        father_group.remove();
    })
*/
    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
        e.preventDefault();
		var data = $("#validateform").serialize();
        $("#dosubmit").attr("disabled","disabled");
        $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);
        // console.log(edit);return;
        $.ajax({
            type: "POST",
            url: edit?SITE_URL+folder_name+"/polygonsManage/edit/"+id:SITE_URL+folder_name+"/polygonsManage/add/",
            data:  $("#validateform").serialize(),
            success:function(response){
                var dataObj=jQuery.parseJSON(response);
                if(dataObj.status)
                {
                    $.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
                    aci.GoUrl(SITE_URL+folder_name+'/polygonsManage/lists/',1);
                }else
                {
                    $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                    $("#dosubmit").removeAttr("disabled");
                }
            },
            error: function (request, status, error) {
                $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                //$("#dosubmit").removeAttr("disabled");
            }
        });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);});

});
function remove_self(_this){
    var father_group = _this.parents('.form-group');
    father_group.remove();
}