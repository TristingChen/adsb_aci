/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 0;
var station_id = channel_id=-1;
var ii = 0;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');
    require('datepicker');
    setInterval(get_buff_data, 10);
    $(function () {
        $("[data-toogle='tooltip']").tooltip();
    });
});

function send_buff()
{
	var keyword = $("#hidden_keyword").val();
    $.ajax({
        type: "POST",
        url: SITE_URL + folder_name + "/dataAnalyse/choose_source/"+station_id+"/"+channel_id+"/"+keyword,
        success: function (response) {
            var dataObj = jQuery.parseJSON(response);
            if (dataObj.status) {
                $.scojs_message('操作成功', $.scojs_message.TYPE_OK);
                //aci.GoUrl(SITE_URL + folder_name + '/dataAnalyse/index/' + station_name + "/" + channel_name + "/" + station_id + "/" + channel_id, 3);
            } else {
                $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
            }
        },
        error: function (request, status, error) {

        }
    });
}

function setDatasource() {
    station_id = $("#station_id").val();
    channel_id = $("#channel_id").val();
    var station_name = $("#station_id").find("option:selected").text();
    var channel_name = $("#channel_id").find("option:selected").text();
    if (station_id == "") {
        alert("请选择需要统计的数据源!");
    }
    $.ajax({
        type: "POST",
        url: SITE_URL + folder_name + "/dataAnalyse/choose_source/" + station_id + "/" + channel_id,
        success: function (response) {
            var dataObj = jQuery.parseJSON(response);
            if (dataObj.status) {
                $.scojs_message('操作成功', $.scojs_message.TYPE_OK);
				enable = 1;
                //aci.GoUrl(SITE_URL + folder_name + '/dataAnalyse/index/' + station_name + "/" + channel_name + "/" + station_id + "/" + channel_id, 3);
            } else {
                $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
            }
        },
        error: function (request, status, error) {

        }
    });
}

function set_keyword()
{
    $("#hidden_keyword").val($("#keyword").val());
	send_buff();
}

function get_buff_data() {
    //var keyword = $("#hidden_keyword").val();
    if (enable) {
		if(0 > station_id)return;
        $.ajax({
            type: "POST",
			async:false,
            url: SITE_URL + folder_name + "/dataAnalyse/read_buff_data/" + station_id + "/" + channel_id,
            success: function (response) {
                    if (response != "") {
						
                    //$("#buff_tbody").appendhtml(response);
					var tab = $("#buff_tbody");
					var tabnum = tab[0].childElementCount;
					if(tabnum >20)
					{
						tab[0].childNodes[0].remove();
					}
					//if(enable)
					//{
						tab.append(response);
					//}					
                }
            },
            error: function (request, status, error) {

            }
        });
    }
}

function get_statistics_data() {
    if (enable) {
        $.ajax({
            type: "POST",
            url: SITE_URL + folder_name + "/dataAnalyse/read_statistics_data/" + station_id + "/" + channel_id,
            success: function (response) {
                if (response != "") {
                    $("#statistics_tbody").html(response);
                }
            },
            error: function (request, status, error) {

            }
        });
    }
}

function suspend() {
    enable = 0;
    $("#suspend").hide();
    $("#resume").show();
}

function resume() {
    enable = 1;
    $("#resume").hide();
    $("#suspend").show();
}
