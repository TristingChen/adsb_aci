/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 1;
var json_val = null;


$(function () {
    setDatasource();
});

function show_all_charts() {
    show_charts('COUNT', '数据概况');
    show_charts('ERROR_TIMEMARK', '数据延时分布');
    show_charts('LOW_QUALITY', '数据质量分布');
    show_charts('GHOST_TARGET_CNT', '虚假目标统计');
}

Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "H+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S": this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

function setDatasource() {
    var station_id = $("#station_id").val();
    var channel_id = $("#channel_id").val();
    var start_time = $("#starttime").val();
    var end_time = $("#endtime").val();

    if (start_time == "" || end_time == "") {
        end_time = new Date().Format("yyyy-MM-dd HH:mm:ss");
        start_time = new Date(end_time).setHours(new Date(end_time).getHours() - 1);
        start_time = new Date(start_time).Format("yyyy-MM-dd HH:mm:ss");
    }

    if (0 > (new Date(end_time) - new Date(start_time))) {
        alert("结束时间必须大于开始时间，请重新选择统计时间范围！");
        return false;
    }


    var hh = SITE_URL + folder_name + "/dataAnalyse/echo_offline_data/" + station_id + "/" + channel_id + "/" + start_time + "/" + end_time;

    $.ajax({
        type: "POST",
        url: SITE_URL + folder_name + "/dataAnalyse/echo_offline_data/" + station_id + "/" + channel_id + "/" + start_time + "/" + end_time,
        success: function (response) {
            json_val = jQuery.parseJSON(response);
            show_all_charts();
        },
        error: function (request, status, error) {

        }
    });
}

function set_chart_data(chart_type) {
    var data_arr = Array();
	if(json_val['COUNT'] == 0) json_val["COUNT"] = 1;
    if (chart_type == "COUNT") {
		/*
        data_arr = [
            ['错误数据帧数', json_val["ERROR_CNT"],json_val["ERROR_CNT"]/json_val["COUNT"]],
            ['位置跳变数据帧数', json_val["POS_JUMP_CNT"],json_val["POS_JUMP_CNT"]/json_val["COUNT"]],
            ['高度跳变数据帧数', json_val["HEIGHT_JUMP_CNT"],json_val["HEIGHT_JUMP_CNT"]/json_val["COUNT"]]
        ]
		*/
		 data_arr = [{
			 name:'错误数据帧数',
			 y:json_val["ERROR_CNT"],
			 z:(json_val["ERROR_CNT"]/json_val["COUNT"])*100
		 },{
			 name:'位置跳变数据帧数',
			 y:json_val["POS_JUMP_CNT"],
			 z:(json_val["POS_JUMP_CNT"]/json_val["COUNT"])*100
		 },{
			 name:'高度跳变数据帧数',
			 y:json_val["HEIGHT_JUMP_CNT"],
			 z:(json_val["HEIGHT_JUMP_CNT"]/json_val["COUNT"])*100
		 }]
    }
    if (chart_type == "ERROR_TIMEMARK") {
		/*
        data_arr = [
            ['小于0.4s', json_val["ERROR_TIMEMARK"][0]],
            ['0.4s-0.8s', json_val["ERROR_TIMEMARK"][1]],
            ['0.8s-1.2s', json_val["ERROR_TIMEMARK"][2]],
            ['1.2s-1.8s', json_val["ERROR_TIMEMARK"][3]],
            ['1.8s-10s', json_val["ERROR_TIMEMARK"][4]],
            ['10s-1800s', json_val["ERROR_TIMEMARK"][5]],
            ['大于1800s', json_val["ERROR_TIMEMARK"][6]]
        ]
		*/
		data_arr = [{
			name:'小于0.4s',
			y:json_val['ERROR_TIMEMARK'][0],
			z:((json_val['ERROR_TIMEMARK'][0])/json_val['COUNT'])*100
		},{
			name:'0.4s-0.8s',
			y:json_val['ERROR_TIMEMARK'][1],
			z:((json_val['ERROR_TIMEMARK'][1])/json_val['COUNT'])*100
		},{
			name:'0.8s-1.2s',
			y:json_val['ERROR_TIMEMARK'][2],
			z:((json_val['ERROR_TIMEMARK'][2])/json_val['COUNT'])*100
		},{
			name:'1.2s-1.8s',
			y:json_val['ERROR_TIMEMARK'][3],
			z:((json_val['ERROR_TIMEMARK'][3])/json_val['COUNT'])*100
		},{
			name:'1.8s-10s',
			y:json_val['ERROR_TIMEMARK'][4],
			z:((json_val['ERROR_TIMEMARK'][4])/json_val['COUNT'])*100
		},{
			name:'10s-1800s',
			y:json_val['ERROR_TIMEMARK'][5],
			z:((json_val['ERROR_TIMEMARK'][5])/json_val['COUNT'])*100
		},{
			name:'大于1800s',
			y:json_val['ERROR_TIMEMARK'][6],
			z:((json_val['ERROR_TIMEMARK'][6])/json_val['COUNT'])*100
		}]
    }

    if (chart_type == "NUCp/NIC" || chart_type == "LOW_QUALITY") {
        for (var i = 0; i < 12; i++) {
            //data_arr[i] = ["" + i + "", json_val['NUC'][i]];
			data_arr[i] = {
				name:i,
				y:json_val['NUC'][i],
				z:(json_val['NUC'][i]/json_val['COUNT'])*100
			}
        }
    }

    if (chart_type == "NAC") {
        for (var i = 0; i < 12; i++) {
            //data_arr[i] = [""+i+"", json_val['NAC'][i]];
			data_arr[i] = {
				name:i,
				y:json_val['NAC'][i],
				z:(json_val['NAC'][i]/json_val['COUNT'])*100
			}
        }
    }

    if (chart_type == "SIL") {
        for (var i = 0; i < 4; i++) {
            //data_arr[i] = [""+i+"", json_val['SIL'][i]];
			data_arr[i] = {
				name:i,
				y:json_val['SIL'][i],
				z:(json_val['SIL'][i]/json_val['COUNT'])*100
			}
        }
    }

    if(chart_type == "GHOST_TARGET_CNT")
    {
		data_arr = [{
			name:'范围验证异常',
			y:json_val['GHOST_TARGET_CNT'][0],
			z:((json_val['GHOST_TARGET_CNT'][0])/json_val['COUNT'])*100
		},{
			name:'雷达验证异常',
			y:json_val['GHOST_TARGET_CNT'][1],
			z:((json_val['GHOST_TARGET_CNT'][1])/json_val['COUNT'])*100
		},{
			name:'TDOA验证异常',
			y:json_val['GHOST_TARGET_CNT'][2],
			z:((json_val['GHOST_TARGET_CNT'][2])/json_val['COUNT'])*100
		}]                   
    }
    return data_arr;
}

function show_charts(chart_type, title) {
    var data_arr = set_chart_data(chart_type);
    if (chart_type == "NAC" || chart_type == "SIL" || chart_type == "NUCp/NIC") {
        chart_type = "LOW_QUALITY";
    }
    $('#' + chart_type).highcharts({
        chart: {
            plotBackgrounColor: null,
            plotBoderwidth: null,
            plotShadow: false
        },
        title: {
            text: title
        },
        tooltip: {
            headerFormat: '{series.name}<br>',
            pointFormat: '{point.name}:<b>{point.y}</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '{point.name}:<b>{point.y}({point.z:.6f}%)</b>',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                },
                showInLegend: true
            }
        },
        series: [
            {
                type: 'pie',
                name: '数据质量概况【总数据帧数：' + json_val["COUNT"] + "】",
                data: data_arr
            }
        ],
        exporting: {
            buttons: {
                contextButton: {
                    enabled: true
                },
                SILButton: {
                    text: 'SIL',
                    onclick: function () {
                        show_charts('SIL', title);
                    },
                    enabled: (chart_type == "LOW_QUALITY")
                },
                NICButton: {
                    text: 'NAC',
                    onclick: function () {
                        show_charts('NAC', title);
                    },
                    enabled: (chart_type == "LOW_QUALITY")
                },
                NUCButton: {
                    text: 'NUC',
                    onclick: function () {
                        show_charts('NUCp/NIC', title);
                    },
                    enabled: (chart_type == "LOW_QUALITY")
                }
            }
        }
    });
}

function downloadExcel()
{
	var start_time = $("#starttime").val();
    var end_time = $("#endtime").val();

    if (start_time == "" || end_time == "") {
        end_time = new Date().Format("yyyy-MM-dd HH:mm:ss");
        start_time = new Date(end_time).setHours(new Date(end_time).getHours() - 1);
        start_time = new Date(start_time).Format("yyyy-MM-dd HH:mm:ss");
    }

    if (0 > (new Date(end_time) - new Date(start_time))) {
        alert("结束时间必须大于开始时间，请重新选择统计时间范围！");
        return false;
    }
	
	var url = SITE_URL + folder_name + "/dataAnalyse/exportExcel/"+ start_time + "/" + end_time;
	window.location.href = url;

}
 


