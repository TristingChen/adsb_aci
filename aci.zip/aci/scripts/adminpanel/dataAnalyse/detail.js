/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');

    get_buff_data();
});

function get_buff_data() {
    $.ajax({
        type: "POST",
        url: SITE_URL + folder_name + "/dataAnalyse/get_buff_detail/" + station_id+"/"+channel_id,
        success: function (response) {
            if (response != "") {
                $("#detail").html(response);
            }
        },
        error: function (request, status, error) {

        }
    });
}

