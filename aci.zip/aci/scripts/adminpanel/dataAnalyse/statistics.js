/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 1;
var json_val_A = null;
var json_val_B = null;
var json_val_R = null;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');
    require('datepicker');
    require('highstock');

    setInterval(statistics_data, 1000);

    show_charts('COUNT', '数据帧总数');
    show_charts('TARGET_CNT', '收到的目标总数');
    show_charts('DISPEAR_CNT', '丢失跟踪目标个数');
    show_charts('TEST_DISPEAR_CNT', '信标丢失次数');
    show_charts('ERROR_CNT', '错误数据帧数');
    show_charts('POS_JUMP_CNT', '位置跳变目标个数');
    show_charts('HEIGHT_JUMP_CNT', '高度跳变目标个数');
    show_charts('GHOST_TARGET_CNT', '可疑目标个数');
    show_charts('ERROR_TIMEMARK', '时标异常帧数');
    show_charts('LOW_QUALITY', '低质量数据帧数');

    $(function () {
        $("[data-toogle='tooltip']").tooltip();
    });
});

function reload_show_charts() {
    show_charts('COUNT', '数据帧总数');
    show_charts('TARGET_CNT', '收到的目标总数');
    show_charts('DISPEAR_CNT', '丢失跟踪目标个数');
    show_charts('TEST_DISPEAR_CNT', '信标丢失次数');
    show_charts('ERROR_CNT', '错误数据帧数');
    show_charts('POS_JUMP_CNT', '位置跳变目标个数');
    show_charts('HEIGHT_JUMP_CNT', '高度跳变目标个数');
    show_charts('GHOST_TARGET_CNT', '可疑目标个数');
    show_charts('ERROR_TIMEMARK', '时标异常帧数');
    show_charts('LOW_QUALITY', '低质量数据帧数');
}

function show_charts(chart_type, title) {
    $('#' + chart_type).highcharts('StockChart', {
        chart: {
            events: {
                load: function () {
                    // set up the updating of the chart each second
                    if ($("#station_id").val() != 0) {
                        var series_a = this.series[0];
                        var series_b = this.series[1];
                        setInterval(function () {
                            var x = (new Date()).getTime(); // current time
                            var y_a = 0;
                            var y_b = 0;
                            if (json_val_A != null) {
                                y_a = parseInt(json_val_A[chart_type]);
                            }
                            if (json_val_B != null) {
                                y_b = parseInt(json_val_B[chart_type]);
                            }
                            series_a.addPoint([x, y_a], true, true);
                            series_b.addPoint([x, y_b], true, true);
                        }, 5000);
                    } else {
                        var series = this.series[0];
                        setInterval(function () {
                            var x = (new Date()).getTime();
                            var y = 0;
                            if (json_val_R != null) {
                               y = parseInt(json_val_R[chart_type]);
                            }
                            series.addPoint([x, y], true, true);
                        }, 5000);
                    }

                }
            }
        },
        rangeSelector: {
            buttons: [
                {
                    count: 1,
                    type: 'minute',
                    text: '1M'
                },
                {
                    count: 5,
                    type: 'minute',
                    text: '5M'
                },
                {
                    type: 'all',
                    text: 'All'
                }
            ],
            inputEnabled: false,
            selected: 0
        },
        title: {
            text: title
        },
        tooltip: {
            split: false
        },
        exporting: {
            enabled: false
        },
        series: [
            {
                name: 'A网数据',
                data: (function () {
                    var data = [], time = (new Date()).getTime(), i;
                    for (i = -17279; i <= 0; i += 1) { //999，线形图最多能保存的点数
                        data.push([
                            time + i * 0,
                            0
                        ]);
                    }
                    return data;
                }())
            },
            {
                name: 'B网数据',
                data: (function () {
                    var data = [], time = (new Date()).getTime(), i;
                    for (i = -17279; i <= 0; i += 1) {
                        data.push([
                            time + i * 0,
                            0
                        ]);
                    }
                    return data;
                }())
            }
        ]
    });
}

function get_statistics_data(station_id , channel_id) {
    if (enable) {
		var tmp = SITE_URL + folder_name + "/dataAnalyse/read_statistics_data/" + station_id + "/" + channel_id;
        $.ajax({
            type: "POST",
            url: SITE_URL + folder_name + "/dataAnalyse/read_statistics_data/" + station_id + "/" + channel_id,
            success: function (response) {
                if (response != "null") {
                    //$("#statistics_tbody").html(response);
                    if (channel_id == 0) {
                        json_val_A = JSON.parse(response);
                    } else if (channel_id == 1) {
                        json_val_B = JSON.parse(response);
                    } else if (channel_id == 2) {
                        json_val_R = JSON.parse(response);
                    }

                }
            },
            error: function (request, status, error) {

            }
        });
    }
    return 0;
}

function statistics_data() {
    var station_id = $("#station_id").val();
    if (station_id == "") return 0;
    if (station_id == 0) {
        get_statistics_data(station_id, 2);
    }else{
        get_statistics_data(station_id, 0);
        get_statistics_data(station_id, 1);
    }

}


function suspend() {
    enable = 0;
    $("#suspend").hide();
    $("#resume").show();
}

function resume() {
    enable = 1;
    $("#resume").hide();
    $("#suspend").show();
}
