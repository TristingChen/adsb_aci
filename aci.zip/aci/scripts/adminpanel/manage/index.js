define(function (require) {
    var $ = require('jquery');
    require('bootstrap');
});