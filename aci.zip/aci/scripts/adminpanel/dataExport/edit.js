define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: '用户名不得为空'
                    }
                }
            }
        }
    };
    $("#reverseBtn").click(function(){
        aci.ReverseChecked('select_item_val[]');
    });
    
    $('#select_item_version').change(function(){
        var version_val = $(this).val();
        var cat_bom = $('#cat_version_data');
        var chosed_version_data = cat_version_data[version_val];
        if(chosed_version_data == undefined){
            alert('请开发人员先进行版本匹配');
            return false;
        }
        cat_bom.html(' ');
        $.each(chosed_version_data,function(i,n){
            var tmp = '<div  class="col-sm-6" ><label class="col-sm-6 control-label">'+n+'</label><input name="select_item_val[]" checked value="'+i+'"  type="checkbox"   cols="45" rows="5" class="checkbox" style="" /></div>';
            cat_bom.append(tmp);
        })

        /*$aa = <div  class="col-sm-6" >
                                <label class="col-sm-6 control-label"><?=$item?></label><input name="select_item_val[]" value="1"  type="checkbox"   cols="45" rows="5" class="checkbox" style="" />
                            </div>*/

    });
    /*$('input[name=delay_switch]').click(function(){
        if($(this).val() == 0){
            $('.delay_val_group').hide();
        }else{
            $('.delay_val_group').show();
        }
    })*/
    /*$('input[name=duration_switch]').click(function(){
        if($(this).val() == 0){
            $('.duration_val_group').hide();
        }else{
            $('.duration_val_group').show();
        }
    })*/
    $('input[name=cast_type]').click(function(){
        if($(this).val() == 2){
            $('.cast_type_ip_group').show();
            $('.send_a_ip_group').hide();
            $('.eth_num_group').show();
        }else{
            $('.cast_type_ip_group').hide();
            $('.send_a_ip_group').show();
            $('.eth_num_group').hide();
        }
    })


    var first_type = $('.data_type:checked').val();
/*
    var faker_range_val = $('#faker_range:checked').val();
    var faker_radar_val = $('#faker_radar:checked').val();
    var faker_tdoa_val = $('#faker_tdoa:checked').val();
    var faker_plan_val = $('#faker_plan:checked').val();
    var first_data = [];
    first_data.push($('#faker_range').attr('checked')?"checked":"");
    first_data.push($('#faker_radar').attr('checked')?"checked":"");
    first_data.push($('#faker_tdoa').attr('checked')?"checked":"");
    first_data.push($('#faker_plan').attr('checked')?"checked":"");*/
    var from_type_val = $('.from_type:checked').val();
    if(from_type_val == undefined ){
            var from_type_str = '<div class="form-group" id="path_switch"><label for="duration_switch" class="col-sm-2 control-label">输出通道数据:</label><div class="col-sm-5"><label class="radio-inline"><input type="radio" name="from_type" checked  value="1">A通道</label> <label class="radio-inline"><input type="radio" name="from_type"  value="2"> B通道 </label></div> </div>';
    }else{
        if(from_type_val == 1){
            var from_type_str = '<div class="form-group" id="path_switch"><label for="duration_switch" class="col-sm-2 control-label">输出通道数据:</label><div class="col-sm-5"><label class="radio-inline"><input type="radio" name="from_type" checked  value="1">A通道</label> <label class="radio-inline"><input type="radio" name="from_type"  value="2"> B通道 </label></div> </div>';
          
        }else{
            var from_type_str = '<div class="form-group" id="path_switch"><label for="duration_switch" class="col-sm-2 control-label">输出通道数据:</label><div class="col-sm-5"><label class="radio-inline"><input type="radio" name="from_type"   value="1">A通道</label> <label class="radio-inline"><input type="radio" name="from_type" checked  value="2"> B通道 </label></div> </div>';
        }
    }
    $('.data_type').click(function(){
        if($(this).val() == 0){
          if($('#path_switch').length > 0){
                $('#path_switch').remove();
            }
        }else {
            if($('#path_switch').length > 0){
                $('#path_switch').remove();
            }
            // $('#is_output').remove();
            $('#data_switch').after(from_type_str);
        }

    })


    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
        e.preventDefault();
        $("#dosubmit").attr("disabled","disabled");
        $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);
        $.ajax({
            type: "POST",
            url: edit?SITE_URL+folder_name+"/dataExport/edit/"+id:SITE_URL+folder_name+"/dataExport/add",
            data:  $("#validateform").serialize(),
            success:function(response){
                var dataObj=jQuery.parseJSON(response);
                if(dataObj.status)
                {
                    $.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
                    aci.GoUrl(SITE_URL+folder_name+'/dataExport/lists/',1);
                }else
                {
                    $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                    $("#dosubmit").removeAttr("disabled");
                }
            },
            error: function (request, status, error) {
                $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                $("#dosubmit").removeAttr("disabled");
            }
        });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);});

});

function change_display(){
    var len = arguments.length;
    for (var i = 1; i <= len; i++) {
        if(arguments[0]){
            $('.'+arguments[i]).show();
        }else{
            $('.'+arguments[i]).hide();
        }
    }
}