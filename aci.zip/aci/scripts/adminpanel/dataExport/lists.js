define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

     $("#pro_file").click(function(){
         $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/bypassManage/produce_xml",
            dataType:'text',
            async: false,
            success:function(response){
              if(response){
                alert('配置文件生成成功');
              } else{
                alert('配置文件生成失败');
              }
             },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
            }
        });
    });



});