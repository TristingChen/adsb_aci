/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 1;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');
    require('datepicker');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');

    //setInterval(send_buff,1000);
    //setInterval(send_heartbeat,10000);
    //setInterval(get_buff_data, 1000);
    //setInterval(get_statistics_data, 1000);
    $(function () {
        $("[data-toogle='tooltip']").tooltip();
    });
    var replayer_type ;
    $('.dosubmit').click(function(){
        replayer_type = $(this).val();
    })

    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            start_time: {
                validators: {
                    notEmpty: {
                        message: '开始时间不得为空'
                    }
                }
            },
            station_ip: {
                validators: {
                    notEmpty: {
                        message: '基站发送Ip'
                    }
                }
            },
            station_port: {
                validators: {
                    notEmpty: {
                        message: '基站发送端口'
                    }
                }
            },
            end_time: {
                validators: {
                    notEmpty: {
                        message: '结束时间不得为空'
                    }
                }
            },
            rate: {
                validators: {
                    notEmpty: {
                        message: '回放倍数不得为空'
                    }
                }
            },
        }
    }    
    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
    e.preventDefault();
    $(".dosubmit").attr("disabled","disabled");
    var station_arr = [];
    $('.checkbox:checked').each(function(i,obj){
        station_arr[i] = $(this).val();
    })
    var form_data = {
        'station_ids':station_arr,
		'replay_channel':$("#replay_channel").val(),
        'station_ip':$('#station_ip').val(),
        'station_port':$('#station_port').val(),
        'start_time':$('#start_time').val(),
        'end_time':$('#end_time').val(),
        'rate':$('#rate').val(),
        'replayer_type':replayer_type,
        'hardware_id':$('#hardware_id option:selected').val()
    }
    $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);
    $.ajax({
        type: "POST",
        url: SITE_URL+folder_name+"/replayerExportManage/produce_xml/",
        data: form_data,
        success:function(response){
            var dataObj=jQuery.parseJSON(response);
            if(dataObj.status)
            {
                $.scojs_message('操作成功', $.scojs_message.TYPE_OK);
                aci.GoUrl(SITE_URL+folder_name+'/replayerExportManage/lists/',1);
            }else
            {
                $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                $(".dosubmit").removeAttr("disabled");
            }
        },
        error: function (request, status, error) {
            $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
            $(".dosubmit").removeAttr("disabled");
        }
    });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);});

});


