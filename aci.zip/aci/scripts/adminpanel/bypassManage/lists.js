define(function (require) {
    var $ = require('jquery');
    var aci = require('aci');
    require('bootstrap');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');
    require('message');

     $("#pro_file").click(function(){
         $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/bypassManage/produce_xml",
            dataType:'text',
            async: false,
            success:function(response){
              if(response){
                alert('配置文件生成成功');
              } else{
                alert('配置文件生成失败');
              }
             },
            error: function (request, status, error) {
                //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
            }
        });
    });

     $('.main_switch').on('click',function(){

          if (confirm('是否切换当前总开关状态')) {
            var val = $(this).attr('value');
                 $.ajax({
                    type: "POST",
                    url: SITE_URL+folder_name+"/bypassManage/change_main_switch/"+val,
                    dataType:'text',
                    async: false,
                    success:function(response){
                      if(response){
                        alert('切换成功');
                        window.location.reload();
                      } else{
                        alert('切换失败');
                        window.location.reload();
                        
                      }
                     },
                    error: function (request, status, error) {
                        //$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                    }
                });
          }
     })

});