/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 1;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');
    require('datepicker');

    $('#clear_input').click(function(){
        $('#station_id option:first').prop('selected','selected');       
        $('#start_time').val('');
        $('#end_time').val('');
        $('#search_form').submit();
    })

});


