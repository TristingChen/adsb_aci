define(function (require) {
	var $ = require('jquery');
	var aci = require('aci');
	require('bootstrap');
	$("#reverseBtn").click(function(){
		aci.ReverseChecked('pid[]');
	});
	$("#deleteBtn").click(function(){
		var _arr = aci.GetCheckboxValue('pid[]');
		if(_arr.length==0)
		{
			alert("请先勾选明细");
			return false;
		}

		if(confirm("确定要删除黑名单吗？"))
		{
			$("#form_list").attr("action",SITE_URL+folder_name+"/blackList/delete/");
			$("#form_list").submit();
		}
	});
	$(".btn-update").click(function(){
		var _arr = aci.GetCheckboxValue('pid[]');
		if(_arr.length==0)
		{
			alert("请先勾选相应的版本");
			return false;
		}

		if(confirm("确定要更新该版本吗？"))
		{
			$("#form_list").attr("action",SITE_URL+folder_name+"/versionsCtrl/update/");
			$("#form_list").submit();
		}
	});
	window.onload=function(){
		var has_new = $('.btn-up').attr('has_new');
		if(has_new){
			$('.btn-up').addClass('has-new-versions');
		}else{
			$('.btn-up').removeClass('has-new-versions');
		}
	}
	$('.btn-up').click(function(){
		var id = $(this).attr('attr');
		if($(this).hasClass('has-new-versions')){
			if(confirm('确定要版本升级吗')){
				window.location.href=SITE_URL+folder_name+"/versionsCtrl/upgrade_versions/"+id;
			}else{
				window.location.reload();
			}
		}else{
			alert('暂无可更新的版本');
		}
		
	});
	$('.btn-down').click(function(){
		var id = $(this).attr('attr');
		if(confirm('确定要版本回退吗')){
			window.location.href=SITE_URL+folder_name+"/versionsCtrl/back_versions/"+id;
		}
	})
});