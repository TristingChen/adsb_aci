/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 1;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');
    require('datepicker');


    //setInterval(send_buff,1000);
    //setInterval(send_heartbeat,10000);
    //setInterval(get_buff_data, 1000);
    //setInterval(get_statistics_data, 1000);
    $('#sum_button').click(function(){
        if($("#station_name").val() == ''){
            alert('请填写基站名');
        }
        if($('#start_time').val() == ''){
            alert('请选择开始时间');
        }
        if($('#end_time').val() == ''){
            alert('请选择结束时间');
        }
        if($("#station_name").val() != '' && $('#start_time').val() != '' && $('#end_time').val() != ''){
            var check_start = Date.parse(new Date($('#start_time').val().replace('-','/').replace('-','/')))/1000;
            var check_end = Date.parse(new Date($('#end_time').val().replace('-','/').replace('-','/')))/1000;
            var sub = check_end - check_start;
            if(sub <= 0){
                alert('结束时间需大于开始时间');
            }else{
                //最多可选一个小时内的数据  
                
                    $('#search_form').submit();
                
            }
        }

    })

    $('#clear_input').click(function(){
        $("#station_name").val('');
        $('#start_time').val('');
        $('#end_time').val('');
    })
    $('#print_table').click(function(){
        bdhtml=window.document.body.innerHTML;   
        sprnstr="<!--startprint-->";   
        eprnstr="<!--endprint-->";   
        prnhtml=bdhtml.substr(bdhtml.indexOf(sprnstr)+17);   
        prnhtml=prnhtml.substring(0,prnhtml.indexOf(eprnstr));   
        window.document.body.innerHTML=prnhtml;  
        window.print();   
    })
    $(function () {
        $("[data-toogle='tooltip']").tooltip();
    });
});


