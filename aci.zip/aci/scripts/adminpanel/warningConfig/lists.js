/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 1;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');
    require('datepicker');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');

    //setInterval(send_buff,1000);
    //setInterval(send_heartbeat,10000);
    //setInterval(get_buff_data, 1000);
    //setInterval(get_statistics_data, 1000);
    
/*    var replayer_type ;
    $('.dosubmit').click(function(){
        replayer_type = $(this).val();
    })*/

    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        }
    }    
    var optionHtml = '<option value=-1>请选择</option>';
        optionHtml +=  '<option value=0>当天00:00</option>';
     optionHtml +=  ' <option value=1>当天01:00</option>';
      optionHtml +=  '<option value=2>当天02:00</option>';
     optionHtml +=  ' <option value=3>当天03:00</option>';
      optionHtml +=  '<option value=4>当天04:00</option>';
      optionHtml +=  '<option value=5>当天05:00</option>';
      optionHtml +=  '<option value=6>当天06:00</option>';
      optionHtml +=  '<option value=7>当天07:00</option>';
     optionHtml +=  ' <option value=8>当天08:00</option>';
      optionHtml +=  '<option value=9>当天09:00</option>';
      optionHtml +=  '<option value=10>当天10:00</option>';
      optionHtml +=  '<option value=11>当天11:00</option>';
      optionHtml +=  '<option value=12>当天12:00</option>';
      optionHtml +=  '<option value=13>当天13:00</option>';
     optionHtml +=  ' <option value=14>当天14:00</option>';
     optionHtml +=  ' <option value=15>当天15:00</option>';
     optionHtml +=  ' <option value=16>当天16:00</option>';
     optionHtml +=  ' <option value=17>当天17:00</option>';
     optionHtml +=  ' <option value=18>当天18:00</option>';
     optionHtml +=  ' <option value=19>当天19:00</option>';
     optionHtml +=  ' <option value=20>当天20:00</option>';
     optionHtml +=  ' <option value=21>当天21:00</option>';
     optionHtml +=  ' <option value=22>当天22:00</option>';
     optionHtml +=  ' <option value=23>当天23:00</option>';
     optionHtml +=  ' <option value=24>次日00:00</option>';
     optionHtml +=  ' <option value=25>次日01:00</option>';
     optionHtml +=  ' <option value=26>次日02:00</option>';
     optionHtml +=  ' <option value=27>次日03:00</option>';
     optionHtml +=  ' <option value=28>次日04:00</option>';
     optionHtml +=  ' <option value=29>次日05:00</option>';
     optionHtml +=  ' <option value=30>次日06:00</option>';
     optionHtml +=  ' <option value=31>次日07:00</option>';
     optionHtml +=  ' <option value=32>次日08:00</option>';
     optionHtml +=  ' <option value=33>次日09:00</option>';
     optionHtml +=  ' <option value=34>次日10:00</option>';
      optionHtml +=  '<option value=35>次日11:00</option>';
     optionHtml +=  ' <option value=36>次日12:00</option>';
     optionHtml +=  ' <option value=37>次日13:00</option>';
     optionHtml +=  ' <option value=38>次日14:00</option>';
     optionHtml +=  ' <option value=39>次日15:00</option>';
     optionHtml +=  ' <option value=40>次日16:00</option>';
     optionHtml +=  ' <option value=41>次日17:00</option>';
     optionHtml +=  ' <option value=42>次日18:00</option>';
     optionHtml +=  ' <option value=43>次日19:00</option>';
     optionHtml +=  ' <option value=44>次日20:00</option>';
     optionHtml +=  ' <option value=45>次日21:00</option>';
     optionHtml +=  ' <option value=46>次日22:00</option>';
     optionHtml +=  ' <option value=47>次日23:00</option>';

    $('#end_time1').change(function(){
        var start_time1 =Number($('#start_time1').val());
        var this_val =Number($(this).val());
        var start_time2 = $('#start_time2');
        // console.log(start_time1+this_val)
        if(start_time1 == -1){
            alert('请先进行开始时间的选择');
            $(this).html(optionHtml);
            return false;
        }
        // console.log($(this))
        if( this_val <= start_time1){
            alert('结束时间必须大于开始时间');
            $(this).html(optionHtml);
            return false;
        }
        // console.log(start_time1+this_val)
        if(start_time1+this_val > 24){
            alert('请选择24小时范围内的结束时间');
            $(this).html(optionHtml);
            return false;
        }else{
            $.each(start_time2.children(),function(i,obj){
                // console.log($(this).val())
                if($(this).val() == this_val){
                    $(this).attr('selected',true);
                    // start_time2.attr('disabled','disabled');
                }else{
                    $(this).attr('selected',false);
                    // start_time2.attr('disabled','');
                }
            });


        }
    })

    // $('#start_time2').click(function(){
    //     alert('该选择框的值自动生成，无需选择');
    // });
            
    $('#end_time2').change(function(){
        /*var end_time1 = $('#end_time1');
        var start_time1 = $('#start_time1');
        var end_time2 = $('#end_time2');
        var start_time2 = $('#start_time2');*/
        var end_time1 = Number($('#end_time1 option:checked').val());
        var start_time1 = Number($('#start_time1 option:checked').val());
        var time1_sub = end_time1-start_time1;
        var this_val = $(this).val();
        // console.log(3-1)
        var end_time2 = Number($('#end_time2 option:checked').val())
        var start_time2 = Number($('#start_time2 option:checked').val())

        if(end_time1 == -1 || start_time1 == -1 || end_time2 ==-1 || start_time2 == -1){
            $(this).html(optionHtml);
            return false;
        }
        if(end_time2 <= start_time2){
            alert('结束时间必须大于开始时间');
            $(this).html(optionHtml);
            return false;
        }
        var start_time3 = $('#start_time3');
        var end_time3 = $('#end_time3');
        /*console.log(Number($('#end_time1 option:checked').val()));
        console.log(Number($('#end_time2 option:checked').val()));
        console.log(  Number($('#end_time1 option:checked').val()) -Number($('start_time1 option:checked').val()))
        console.log(time2_sub)*/
        if(time1_sub+time2_sub > 24){
            alert('请选择24小时范围内的结束时间');
            $(this).html(optionHtml);
            return false;
        }else{

            $.each(start_time3.children(),function(i,obj){
                // console.log($(this).val())
                if($(this).val() == this_val){
                    $(this).attr('selected',true);
                    // start_time2.attr('disabled','disabled');
                }else{
                    $(this).attr('selected',false);
                    // start_time2.attr('disabled','');
                }
            });
           var time2_sub = Number($('#end_time2 option:checked').val()) - Number($('#start_time2 option:checked').val());
           /**/
            var end_time3_sub = 24-time1_sub-time2_sub;
           
            // console.log(time2_sub);

            var start_time3_val = $('#start_time3 option:checked').val();
            var end_time3_val =Number(start_time3_val)+end_time3_sub;
            /*console.log(end_time3_val)
            console.log(end_time3_sub)*/
            // console.log(start_time3_val)
            $.each(end_time3.children(),function(i,obj){
                if($(this).val() == end_time3_val){
                    // console.log($(this))
                    $(this).attr('selected',true);
                    // start_time2.attr('disabled','disabled');
                }else{
                    $(this).attr('selected',false);
                    // start_time2.attr('disabled','');
                }
            });


        }
    })


    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
        e.preventDefault();
        $("#dosubmit").attr("disabled","disabled");
        $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);
        $.ajax({
            type: "POST",
            url: SITE_URL+folder_name+"/warningConfig/lists/",
            data:  $("#validateform").serialize(),
            success:function(response){
                var dataObj=jQuery.parseJSON(response);
                if(dataObj.status)
                {
                    $.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
                    aci.GoUrl(SITE_URL+folder_name+'/warningConfig/lists/',1);
                }else
                {
                    $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                    $("#dosubmit").removeAttr("disabled");
                }
            },
            error: function (request, status, error) {
                $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                $("#dosubmit").removeAttr("disabled");
            }
        });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);});

});


