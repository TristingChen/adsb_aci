/**
 * Created with JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-22
 * Time: 下午4:25
 * To change this template use File | Settings | File Templates.
 */
var aci = null;
var enable = 1;
define(function (require) {
    var $ = require('jquery');
    aci = require('aci');
    require('bootstrap');
    require('message');
    require('datepicker');
    require('jquery-ui-dialog-extend');
    require('bootstrapValidator');

    //setInterval(send_buff,1000);
    //setInterval(send_heartbeat,10000);
    //setInterval(get_buff_data, 1000);
    //setInterval(get_statistics_data, 1000);
    
/*    var replayer_type ;
    $('.dosubmit').click(function(){
        replayer_type = $(this).val();
    })*/

    var validator_config = {
        message: '输入框不能为空',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        }
    } 
    var optionHtml =   '<option value="1">请选择</option>';
    var optionHtml1 = '<option value="1">请选择</option>';
    warning_value_time_arr = jQuery.parseJSON(warning_value_time)
    $('#time_value1').change(function(){
        var start_time1 =Number($('#time_value1').val());
        $.each(warning_value_time_arr,function(i,obj){
            if(i > start_time1){
              optionHtml += '<option value="'+i+'" >'+obj+'</option>';
            }
        })  
         $('#end_time_value1').html(optionHtml);
         $('#end_time_value2').html(optionHtml);
         $('#end_time_value3').html(optionHtml);
         $('#time_value2').html($(optionHtml)[0]);
         $('#time_value3').html($(optionHtml)[0]);

    })

    $('#end_time_value1').change(function(){
        var start_time1 =Number($('#time_value1').val());
        var this_val =Number($(this).val());
        var start_time2 = $('#time_value2');
        // console.log(start_time1+this_val)
        if(start_time1 == -1){
            alert('请先进行开始时间的选择');
            // $(this).html(optionHtml);
            return false;
        }
         
        // console.log($(this))
        if( this_val <= start_time1){
            alert('结束时间必须大于开始时间');
            $(this).html(optionHtml);
            return false;
        }
        // console.log(start_time1+this_val)
        if(start_time1+this_val > 24){
            alert('请选择24小时范围内的结束时间');
            $(this).html(optionHtml);
            return false;
        }
        $.each(warning_value_time_arr,function(i,obj){
            if(i > this_val){
              optionHtml1 += '<option value="'+i+'" >'+obj+'</option>';
            }
        })  
         
         // $('#time_value2').html($('#end_time_value1 option:selected'));
        start_time2.html('<option value="'+this_val+'">'+warning_value_time_arr[this_val]+'</option>');
         $('#end_time_value2').html(optionHtml1);
         $('#time_value3').html($(optionHtml1)[0]);
    })

    $('#end_time_value2').change(function(){
        var end_time1 = Number($('#end_time_value1 option:checked').val());
        var start_time1 = Number($('#time_value1 option:checked').val());
        var time1_sub = end_time1-start_time1;
        var this_val = $(this).val();
        var end_time2 = Number($('#end_time_value2 option:checked').val())
        var start_time2 = Number($('#time_value2 option:checked').val())

        if(end_time1 == -1 || start_time1 == -1 || end_time2 ==-1 || start_time2 == -1){
            $(this).html(optionHtml1);
             alert('请先进行前面时间的选择');
            return false;
        }
        $.each(warning_value_time_arr,function(i,obj){
            if(i >= start_time2){
              optionHtml1 += '<option value="'+obj.i+'" >'+obj+'</option>';
            }
        })   
        if(end_time2 <= start_time2){
            alert('结束时间必须大于开始时间');
            $(this).html(optionHtml1);
            return false;
        }
        var start_time3 = $('#time_value3');
        var end_time3 = $('#end_time_value3');
       
        if(time1_sub+time2_sub > 24){
            alert('请选择24小时范围内的结束时间');
            $(this).html(optionHtml1);
            return false;
        }else{
           
            start_time3.html('<option value="'+this_val+'">'+warning_value_time_arr[this_val]+'</option>');
            var time2_sub = Number($('#end_time_value2 option:checked').val()) - Number($('#time_value2 option:checked').val());
            var end_time3_sub = 24-time1_sub-time2_sub;
            var start_time3_val = $('#time_value3 option:checked').val();
            var end_time3_val =Number(start_time3_val)+end_time3_sub;
            end_time3.html('<option value="'+end_time3_val+'">'+warning_value_time_arr[end_time3_val]+'</option>');
        }
    })


    $('#validateform').bootstrapValidator(validator_config).on('success.form.bv', function(e) {
        e.preventDefault();
        $("#dosubmit").attr("disabled","disabled");
        $.scojs_message('请稍候...', $.scojs_message.TYPE_WAIT);
        $.ajax({
            type: "POST",
            url: is_edit?SITE_URL+folder_name+"/warningConfig/edit/"+station_id:SITE_URL+folder_name+"/warningConfig/add",
            data:  $("#validateform").serialize(),
            success:function(response){
                var dataObj=jQuery.parseJSON(response);
                if(dataObj.status)
                {
                    $.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
                    aci.GoUrl(SITE_URL+folder_name+'/warningConfig/lists/',1);
                }else
                {
                    $.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
                    $("#dosubmit").removeAttr("disabled");
                }
            },
            error: function (request, status, error) {
                $.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
                $("#dosubmit").removeAttr("disabled");
            }
        });

    }).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);});

});


