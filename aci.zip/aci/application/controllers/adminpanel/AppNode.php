<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-27
 * Time: 上午9:16
 * To change this template use File | Settings | File Templates.
 */
define('NOT_CONVERT',true);
class AppNode extends Admin_Controller {

    var $menus;
    function __construct()
    {
        parent::__construct();

        $this->load->library('tree');
        $this->load->helper(array('auto_codeIgniter','member_helper'));
        $this->load->model(array('App_node_model'));
    }

    function index($app_id=1)
    {
        if(is_ajax()) {
            $table_html= $this->node_table_html($app_id);
            echo $table_html;
        }else{
            $table_html= $this->node_table_html($app_id);
            $this->view('index',array('require_js'=>true,'app_id'=>$app_id,'table_html'=>$table_html));
        }
    }

    /**
     * @param $app_id应用模块ID
     * @return mixed
     */
    function node_table_html($app_id = 0)
    {
        $tree=$this->tree;
        $tree->icon = array('&nbsp;&nbsp;&nbsp;│ ','&nbsp;&nbsp;&nbsp;├─ ','&nbsp;&nbsp;&nbsp;└─ ');
        $tree->nbsp = '&nbsp;&nbsp;&nbsp;';

        $result = $this->App_node_model->select('app_id = '.$app_id,'*,`node_id` as id','','list_order ASC,node_id ASC');

        $array = array();

        foreach($result as $r) {
            //$r['node_name'] = $r['node_name'];
            $r['str_manage'] =aci_ui_a($this->page_data['folder_name'],$this->page_data['controller_name'],'add',$r['id'].'/'.$app_id,' class="btn btn-default btn-xs"','<span class="glyphicon glyphicon-plus"></span> 新增子节点',true);
            $r['str_manage'] .= " ". aci_ui_a($this->page_data['folder_name'],$this->page_data['controller_name'],'edit',$r['id'],' class="btn btn-default btn-xs"','<span class="glyphicon glyphicon-wrench"></span> 修改',true);
            $array[] = $r;
        }

        $str  = "<tr>
					<td><input type='checkbox' name='pid[]' value='\$node_id' /></td>
					<td>\$spacer\$node_name</td>
					<td>\$node_description</td>
                    <td>\$node_attribute</td>
                    <td>\$str_manage</td>
				</tr>";
        $tree->init($array);
        $table_html = $tree->get_tree(0, $str);
        return $table_html;
    }

    function set_menu()
    {
        if(isset($_POST))
        {
            $pidarr = isset($_POST['pid']) ? $_POST['pid'] : $this->showmessage('无效参数', HTTP_REFERER);
            $where = $this->Module_menu_model->to_sqls($pidarr, '', 'menu_id');
            $status = $this->Module_menu_model->update(array('is_side_menu'=>'^1'),$where);
            if($status)
            {
                $this->repair();
                $this->cache();
                $this->showmessage('操作成功', HTTP_REFERER);
            }else
            {
                $this->showmessage('操作失败');
            }
        }
    }

    function delete()
    {
        if(isset($_POST))
        {
            $pidarr = isset($_POST['pid']) ? $_POST['pid'] : $this->showmessage('无效参数', HTTP_REFERER);
            $where = $this->Module_menu_model->to_sqls($pidarr, '', 'menu_id');
            $status = $this->Module_menu_model->delete($where." ");
            if($status)
            {
                $this->repair();
                $this->cache();
                $this->showmessage('操作成功', HTTP_REFERER);
            }else
            {
                $this->showmessage('操作失败');
            }
        }
    }

    function add($parent_id=0,$app_id=1)
    {
        if(isset($_POST['parent_id'])&& is_ajax()) {
            $parent_id = intval($this->input->post('parent_id'));
            $node_name = trim($this->input->post('node_name',true));
            $node_description = trim($this->input->post('node_description',true));
            $app_id = $this->input->post('app_id');
            $table_name = trim($this->input->post('table_name'));
            $depth = $parent_id>0?$this->get_depth($parent_id):0;
            if($node_name=="")exit(json_encode(array('status'=>false,'tips'=>' 菜单名称不能为空')));
            $status = $this->App_node_model->insert(
                array(
                    'node_name'=>$node_name,
                    'app_id'=>$app_id,
                    'node_description'=>$node_description,
                    'parent_id'=>$parent_id,
                    'list_order'=>0,
                    'is_parent'=>0,
                    'table_name'=>$table_name
                ));
            $status = $this->App_node_model->update(
                array(
                    'is_parent'=>1
                ),array('node_id'=>$parent_id));

            if($status){
                //$this->repair();
                //$this->cache();
                echo json_encode(array('status'=>true,'tips'=>"ok"));
            }
            else
                echo json_encode(array('status'=>false,'tips'=>"false"));

        } else {
            $parent_id =  intval($parent_id);
            $tree=$this->tree;
            $result = $this->App_node_model->select('app_id = '.$app_id,'*,`node_id` as id','','list_order ASC,node_id DESC');
            $array = array();
            foreach($result as $r) {
                $r['cname'] = $r['node_name'];
                $r['selected'] = $r['node_id'] == $parent_id ? 'selected' : '';
                $array[] = $r;
            }
            $str  = "<option depth='\$depth' value='\$node_id' \$selected>\$spacer \$cname </option>";
            $tree->init($array);
            $select_categorys = $tree->get_tree(0, $str);

            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'app_id'=>$app_id,'select_categorys'=>$select_categorys,'data_info'=>$this->App_node_model->default_info()));
        }
    }

    function edit($node_id=0)
    {
        $node_id = intval($node_id);
        $datainfo = $this->App_node_model->get_one(array('node_id'=>$node_id));
        if(!$datainfo) $this->showmessage('菜单信息不存在');
        if(isset($_POST['parent_id'])&& is_ajax()) {
            $parent_id = intval($this->input->post('parent_id'));
            $node_name = trim($this->input->post('node_name',true));
            $node_description = trim($this->input->post('node_description',true));
            $node_attribute = trim($this->input->post('node_attribute',true));
            $table_name = trim($this->input->post('table_name'));
            if($node_name=="")exit(json_encode(array('status'=>false,'tips'=>' 菜单名称不能为空')));

            $status = $this->App_node_model->update(
                array(
                    'node_name'=>$node_name,
                    'parent_id'=>$parent_id,
                    'node_description'=>$node_description,
                    'node_attribute'=>$node_attribute,
                    'table_name'=>$table_name
                ),array('node_id'=>$node_id));

            if($status){
                //$this->repair();
                //$this->cache();
                echo json_encode(array('status'=>true,'tips'=>"ok"));
            }
            else
                echo json_encode(array('status'=>false,'tips'=>"false"));

        } else {
            $show_validator = $array = $r = '';
            $tree=$this->tree;
            $info = $this->App_node_model->get_one(array('node_id'=>$node_id));
            $app_id = $info['app_id'];
            $result = $this->App_node_model->select('app_id = '.$app_id,'*,`node_id` as id','','list_order ASC,node_id DESC');
            foreach($result as $r) {
                $r['cname'] = $r['node_name'];
                $r['selected'] = $r['node_id'] == $datainfo['parent_id'] ? 'selected' : '';
                $array[] = $r;
            }
            $str  = "<option depth='\$depth'  value='\$id' \$selected>\$spacer \$cname</option>";
            $tree->init($array);
            $select_categorys = $tree->get_tree(0, $str);
            $this->view('edit',array('is_edit'=>true,'require_js'=>true,'app_id'=>$app_id,'select_categorys'=>$select_categorys,'data_info'=>$datainfo));
        }
    }

    /**
     * 更新缓存
     */
    private  function get_depth($menu_id=0){
        $cache_module_menu_all = getcache('cache_module_menu_all');

        if( isset($cache_module_menu_all[$menu_id])){
            $arr = $cache_module_menu_all[$menu_id];
            $arr_parentid = explode(",",$arr['arr_parentid']);
            return count($arr_parentid);
        }

        return 0;
    }

    /**
     * 生成XML文件
     */
    function makeXML($app_id,$file_path='/home/adsbweb/deploy')
    {
        $datas = $this->App_node_model->select('app_id ='.$app_id,'*',10000,'list_order ASC,node_id asc');

    }

    /**
     * 更新缓存
     */
    private function cache() {
        $menus = array();
        $datas = $this->App_node_model->select('','*',10000,'list_order ASC,node_id asc');
        $array = array();
        foreach ($datas as $k =>$r) {
            $arr_parentid =  $r['arr_parentid'];
            $arr_parentid = explode(",",$arr_parentid);

            #缓存的时候自动将第一级要跳转的URL写入到缓存
            if(count($arr_parentid)==1) {
                #找到下面第一个子目录
                $first_child_arr = $this->App_node_model->get_one("arr_parentid like '0,".$r['app_id']."' and is_display = 1","*","list_order asc");
            }
            $menus[$r['menu_id']] = $r;

        }
        setcache('cache_module_menu_all', $menus);
        return true;
    }


    /**
     * 找出子目录列表
     * @param array $categorys
     */
    private function get_categorys($categorys = array()) {
        if (is_array($categorys) && !empty($categorys)) {
            foreach ($categorys as $catid => $c) {
                $this->menus[$catid] = $c;
                $result = array();
                foreach ($this->menus as $_k=>$_v) {
                    if($_v['parent_id']) $result[] = $_v;
                }
            }
        }
        return true;
    }


    /**
     *
     * 获取父栏目ID列表
     * @param integer $catid              栏目ID
     * @param array $arrparentid          父目录ID
     * @param integer $n                  查找的层次
     */
    private function get_arrparentid($catid, $arrparentid = '', $n = 1) {
        if($n > 5 || !is_array($this->menus) || !isset($this->menus[$catid])) return false;
        $parentid = $this->menus[$catid]['parent_id'];
        $arrparentid = $arrparentid ? $parentid.','.$arrparentid : $parentid;
        if($parentid) {
            $arrparentid = $this->get_arrparentid($parentid, $arrparentid, ++$n);
        } else {
            $this->menus[$catid]['arr_childid'] = $arrparentid;
        }
        $parentid = $this->menus[$catid]['parent_id'];
        return $arrparentid;
    }

    /**
     *
     * 获取子栏目ID列表
     * @param $catid 栏目ID
     */
    private function get_arrchildid($catid) {
        $arrchildid = $catid;
        if(is_array($this->menus)) {
            foreach($this->menus as $id => $cat) {
                if($cat['parent_id'] && $id != $catid && $cat['parent_id']==$catid) {
                    $arrchildid .= ','.$this->get_arrchildid($id);
                }
            }
        }
        return $arrchildid;
    }

    /**
     * 修复栏目数据
     */
    private function repair() {

        @set_time_limit(600);

        $this->menus = $categorys = array();
        $this->menus = $categorys = $this->Module_menu_model->select('', '*', '', 'list_order ASC, menu_id ASC', '', 'menu_id');

        $this->get_categorys($categorys);

        $categorys = $this->menus;
        if(is_array($this->menus)) {

            foreach($this->menus as $cid => $cat) {

                $arrparentid = $this->get_arrparentid($cid);

                $arrchildid = $this->get_arrchildid($cid);

                $is_parent = is_numeric($arrchildid) ? 0 : 1;

                if($categorys[$cid]['arr_parentid']!=$arrparentid || $categorys[$cid]['arr_childid']!=$arrchildid || $categorys[$cid]['is_parent']!=$is_parent)
                {
                    $this->Module_menu_model->update(array('arr_parentid'=>$arrparentid,'arr_childid'=>$arrchildid,'is_parent'=>$is_parent),array('menu_id'=>$cid));
                }


                $catname = $cat['menu_name'];
                $listorder = $cat['list_order'] ? $cat['list_order'] : $cid;
                if($categorys[$cid]['list_order']!=$listorder) $this->Module_menu_model->update(array('list_order'=>$listorder), array('menu_id'=>$cid));
            }
        }

        //删除在非正常显示的栏目
        foreach($this->menus as $cid => $cat) {
            if($cat['parent_id'] != 0 && !isset($this->menus[$cat['parent_id']])) {
                $this->Module_menu_model->delete(array('menu_id'=>$cid));
            }
        }

        return true;
    }
}
