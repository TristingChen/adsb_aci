<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class RaderManage extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Raders_model','Raders_config_model','Raders_xml_model','Replayer_data_info_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  to_name like '%{$keyword}%'";
        }
        $where = implode('and',$where_arr);
        $data_list = $this->Bypass_config_model->listinfo($where,'*',$orderby , $page_no, $this->Bypass_config_model->page_size,'',$this->Bypass_config_model->page_size,page_list_url('adminpanel/bypassManage/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Bypass_config_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['to_name'] = isset($_POST["to_name"])?trim(safe_replace($_POST["to_name"])):exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            if($_arr['to_name']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
             $_arr['cast_type'] = isset($_POST["cast_type"])?trim(safe_replace($_POST["cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            if($_arr['cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            $_arr['in_work_option'] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            if($_arr['in_work_option']=='')exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            $_arr['to_ip'] = isset($_POST["to_ip"])?trim(safe_replace($_POST["to_ip"])):exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            if($_arr['to_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            $_arr['to_port'] = isset($_POST["to_port"])?trim(safe_replace($_POST["to_port"])):exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            if($_arr['to_port']=='')exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            $_arr['interface_ip'] = isset($_POST["interface_ip"])?trim(safe_replace($_POST["interface_ip"])):exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));
            if($_arr['interface_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));

            $station_ids = $_POST['station_ids'];           
            $remark = trim(safe_replace($_POST["remark"]));
            $_arr['remark'] = $remark;
            if(!empty($station_id)){
                $station_ids_str = implode(',', $station_ids);
            }
            $_arr['dateline'] = time();
            $new_id = $this->Bypass_config_model->insert($_arr);
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $station_data = $this->Station_model->tables_select('','t_sys_station.station_id,station_name');
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_list'=>$this->Bypass_config_model->default_info(),'station_data'=>$station_data));
        }
    }

    function edit($id=0)
    {
        $id = intval($id);
        $data_info =$this->Bypass_config_model->get_one(array('id'=>$id));
        if($this->input->is_ajax_request())
        {
             //接收POST参数
            $_arr['to_name'] = isset($_POST["to_name"])?trim(safe_replace($_POST["to_name"])):exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            if($_arr['to_name']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
             $_arr['cast_type'] = isset($_POST["cast_type"])?trim(safe_replace($_POST["cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            if($_arr['cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            $_arr['in_work_option'] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            if($_arr['in_work_option']=='')exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            $_arr['to_ip'] = isset($_POST["to_ip"])?trim(safe_replace($_POST["to_ip"])):exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            if($_arr['to_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            $_arr['to_port'] = isset($_POST["to_port"])?trim(safe_replace($_POST["to_port"])):exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            if($_arr['to_port']=='')exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            $_arr['interface_ip'] = isset($_POST["interface_ip"])?trim(safe_replace($_POST["interface_ip"])):exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));
            if($_arr['interface_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));

            $station_ids = $_POST['station_ids'];           
            $remark = trim(safe_replace($_POST["remark"]));
            $_arr['remark'] = $remark;
            if(!empty($station_id)){
                $station_ids_str = implode(',', $station_ids);
            }
            $_arr['dateline'] = time();
            $status = $this->Bypass_config_model->update($_arr,array('id'=>$id));
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $data_info['station_ids'] = explode(',', $data_info['station_ids']);
            $station_data = $this->Station_model->tables_select('','t_sys_station.station_id,station_name');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_list'=>$data_info,'station_data'=>$station_data,'id'=>$id));
        }
    }

    function produce_xml(){
            $the_bypass_program = $this->App_model->get_join_one('app_id = 8','receive_watch_ip,receive_watch_port,receive_ip,receive_cast_type,send_watch_ip,send_watch_port,send_ip,send_cast_type,send_cycle,program_name,hardware_other_name,program_start_dir,program_log_dir,program_log_degree,is_master,time_out');  //旁路服务器的程序信息 id=8
            $bypasses = $this->Bypass_config_model->select('','id,to_name,to_ip,to_port,interface_ip,cast_type,in_work_option,station_ids');
            if($the_bypass_program){
                $the_bypass_program['children'] = $bypasses;
            }
            $xmlpatch = BYPATH_XML_PATH.'config.xml';
            $doc = new DOMDocument('1.0','utf-8');   
            $doc -> formatOutput = true;
            if(@$doc -> load($xmlpatch)) {   
            //备份以前的xml版本 2017_12_1_16_48
                $update_xml_file = 'config_'.date('Y_m_d H_i',time()).'.xml';
                rename($xmlpatch, BYPATH_XML_PATH.$update_xml_file);
                //进行修改
                $xml_id_arr = $this->Bypass_xml_model->get_one('`bypass_xml_name`= \'bypass.xml\'','id');
                $tmp_data['bypass_xml_name'] =  $update_xml_file;
                $tmp_data['dateline'] = time();
                $new_doc = new DOMDocument('1.0','utf-8'); 
                $ADSB_RECV = $new_doc -> createElement('ADSB_RECV_CONFIG');//新建节点
                $SendData =  $new_doc -> createElement('SendData');
                foreach ($the_bypass_program['children'] as $key => $value) {
                        $target = $new_doc->createElement('target');
                        $target = $this->create_target_xml($new_doc,$target,$key,$value);
                        $SendData->appendChild($target);
                 }
                $ADSB_RECV->appendChild($SendData);
                $ADSB_RECV = $this->create_only_xml($new_doc,$ADSB_RECV,$the_bypass_program);
                $new_doc->appendChild($ADSB_RECV);
                //进行唯一配置项的添加
                $xml_res = $new_doc->save($xmlpatch);
                 
            } else {
                $ADSB_RECV = $doc -> createElement('ADSB_RECV');//新建节点
                $SendData =  $doc -> createElement('SendData');
                foreach ($the_bypass_program['children'] as $key => $value) {
                        $target = $doc->createElement('target');
                        $target = $this->create_target_xml($doc,$target,$key,$value);
                        $SendData->appendChild($target);
                 }
                $ADSB_RECV->appendChild($SendData);
                $ADSB_RECV = $this->create_only_xml($doc,$ADSB_RECV,$the_bypass_program);
                $doc->appendChild($ADSB_RECV);
                //进行唯一配置项的添加
                $xml_res = $doc->save($xmlpatch);
            } 
            if($xml_res){
                $insert_data['bypass_xml_name'] = 'config.xml';
                $insert_data['dateline'] = time();
                $res = $this->Bypass_xml_model->insert($insert_data);
                if($res){
                    echo 1;
                }else {
                    echo 0;
                }
            }else {
                echo 0;
            }

    }



    //生成基站的_target_xml文件
    private function create_only_xml($doc,$ADSB_RECV,$data_list){
            $RecvMonitorInfo = $doc -> createElement('RecvMonitorInfo');
            $recvIp = $doc -> createElement('recvIp');
            $recvIp_text = $doc->createTextNode($data_list['receive_watch_ip']);
            $recvIp->appendChild($recvIp_text);

            $recvPort = $doc -> createElement('recvPort');
            $recvPort_text = $doc->createTextNode($data_list['receive_watch_port']);
            $recvPort->appendChild($recvPort_text);

            $interface = $doc -> createElement('interface');
            $interface_text = $doc->createTextNode($data_list['receive_ip']);
            $interface->appendChild($interface_text);

            $recvCast = $doc -> createElement('recvCast');
            $recvCast_text = $doc->createTextNode($data_list['receive_cast_type']);
            $recvCast->appendChild($recvCast_text);
            $RecvMonitorInfo->appendChild($recvIp);
            $RecvMonitorInfo->appendChild($recvPort);
            $RecvMonitorInfo->appendChild($interface);
            $RecvMonitorInfo->appendChild($recvCast);

            $SendMonitorInfo = $doc -> createElement('SendMonitorInfo');
            $monitorHostIp = $doc -> createElement('monitorHostIp');
            $monitorHostIp_text = $doc->createTextNode($data_list['send_watch_ip']);
            $monitorHostIp->appendChild($monitorHostIp_text);

            $sendPort = $doc -> createElement('sendPort');
            $sendPort_text = $doc->createTextNode($data_list['send_watch_port']);
            $sendPort->appendChild($sendPort_text);

            $interface = $doc -> createElement('interface');
            $interface_text = $doc->createTextNode($data_list['send_ip']);
            $interface->appendChild($interface_text);

            $sendCast = $doc -> createElement('sendCast');
            $sendCast_text = $doc->createTextNode($data_list['send_cast_type']);
            $sendCast->appendChild($sendCast_text);

            $sendCycle = $doc -> createElement('sendCycle');
            $sendCycle_text = $doc->createTextNode($data_list['send_cycle']);
            $sendCycle->appendChild($sendCycle_text);

            $SendMonitorInfo->appendChild($monitorHostIp);
            $SendMonitorInfo->appendChild($sendPort);
            $SendMonitorInfo->appendChild($interface);
            $SendMonitorInfo->appendChild($sendCast);
            $SendMonitorInfo->appendChild($sendCycle);

            $StartupParameter = $doc -> createElement('StartupParameter');
            $appName = $doc -> createElement('appName');
            $appName_text = $doc->createTextNode($data_list['program_name']);
            $appName->appendChild($appName_text);

            $moduleName = $doc -> createElement('moduleName');
            $moduleName_text = $doc->createTextNode($data_list['hardware_other_name']);
            $moduleName->appendChild($moduleName_text);

            $startUpPath = $doc -> createElement('startUpPath');
            $startUpPath_text = $doc->createTextNode($data_list['program_start_dir']);
            $startUpPath->appendChild($startUpPath_text);

            $logPath = $doc -> createElement('logPath');
            $logPath_text = $doc->createTextNode($data_list['program_log_dir']);
            $logPath->appendChild($logPath_text);

            $logLevel = $doc -> createElement('logLevel');
            $logLevel_text = $doc->createTextNode($data_list['program_log_degree']);
            $logLevel->appendChild($logLevel_text);

            $isMaster = $doc -> createElement('isMaster');
            $isMaster_text = $doc->createTextNode($data_list['is_master']);
            $isMaster->appendChild($isMaster_text);

            $timeOut = $doc -> createElement('timeOut');
            $timeOut_text = $doc->createTextNode($data_list['time_out']);
            $timeOut->appendChild($timeOut_text);

            $StartupParameter->appendChild($appName);
            $StartupParameter->appendChild($moduleName);
            $StartupParameter->appendChild($startUpPath);
            $StartupParameter->appendChild($logPath);
            $StartupParameter->appendChild($logLevel);
            $StartupParameter->appendChild($isMaster);
            $StartupParameter->appendChild($timeOut);

            $ADSB_RECV->appendChild($RecvMonitorInfo);
            $ADSB_RECV->appendChild($SendMonitorInfo);
            $ADSB_RECV->appendChild($StartupParameter);
            return $ADSB_RECV;
        }

    //生成基站的_target_xml文件
    private function create_target_xml($doc,$target,$key,$value){
            $id = $doc -> createElement('id');
            $id_text = $doc->createTextNode($value['id']);
            $id->appendChild($id_text);

            $note = $doc -> createElement('note');
            $note_text = $doc->createTextNode($value['to_name']);
            $note->appendChild($note_text);

            $sendIp = $doc -> createElement('sendIp');
            $sendIp_text = $doc->createTextNode($value['to_ip']);
            $sendIp->appendChild($sendIp_text);

            $sendPort = $doc -> createElement('sendPort');
            $sendPort_text = $doc->createTextNode($value['to_port']);
            $sendPort->appendChild($sendPort_text);

            $interface = $doc -> createElement('interface');
            $interface_text = $doc->createTextNode($value['interface_ip']);
            $interface->appendChild($interface_text);

            $sendCast = $doc -> createElement('sendCast');
            $sendCast_text = $doc->createTextNode($value['cast_type']);
            $sendCast->appendChild($sendCast_text);

            $sendType = $doc -> createElement('sendType');
            $sendType_text = $doc->createTextNode($value['in_work_option']);
            $sendType->appendChild($sendType_text);

            $idList = $doc -> createElement('idList');
            $idList_text = $doc->createTextNode($value['station_ids']);
            $idList->appendChild($idList_text);

            $target->appendChild($id);
            $target->appendChild($note);
            $target->appendChild($sendIp);
            $target->appendChild($sendPort);
            $target->appendChild($interface);
            $target->appendChild($sendCast);
            $target->appendChild($sendType);
            $target->appendChild($idList);
            return $target;
        }
}
