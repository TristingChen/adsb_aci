<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
class AppMonitor extends Admin_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('App_model', 'App_status_model', 'Hardware_model', 'Eth_manage_model', 'App_alert_model','Hardware_fault_logs_model','Hardware_eth_model','Hardware_relations_model'));
        $this->load->helper(array('member_helper','socket'));
    }

    function cache()
    {
        $this->reload_all_cache();
        $this->showmessage('全局缓存成功', site_url('adminpanel'));
    }

    function go($id = 0)
    {
        if ($id == 0) exit();
        if (isset($this->current_role_priv_arr[$id])) {

            $arr = $this->cache_module_menu_arr[$id];
            if (!isset($arr)) exit();
            $arr_parentid = explode(",", $arr['arr_parentid']);

            if (count($arr_parentid) > 2) redirect(base_url($arr['folder'] . '/' . $arr['controller'] . '/' . $arr['method']));
            else {
                foreach ($this->cache_module_menu_arr as $k => $v) {
                    if ($v['parent_id'] == $id) {
                        if (isset($this->current_role_priv_arr[$v['menu_id']])) {
                            redirect(base_url($v['folder'] . '/' . $v['controller'] . '/' . $v['method']));
                            break;
                        }
                    }
                }
            }
        }
        exit();
    }

    function index($page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $orderby ="hardware_id";
        $keyword = "";
        $data_list = $this->App_model->tables_listinfo('', 't_sys_app.*,t_sys_hardware.hardware_name', $orderby, $page_no, $this->App_model->page_size, '', $this->App_model->page_size, page_list_url('adminpanel/appMonitor/index', true));
        $this->view('index', array('data_list' => $data_list, 'pages' => $this->App_model->pages, 'keyword' => $keyword, 'require_js' => true));
    }

    //应用程序监控
    public function timing_app_status(){
        $all_app_list = $this->App_model->tables_select('','program_name,hardware_other_name,app_id');
        $alarm_data = array();
        if($all_app_list){
            $file_day = date('Ymd');
            foreach ($all_app_list as $key => $value) {
                $path = APP_LOG_PATH.$value['hardware_other_name'].'/'.$value['program_name'].'_'.$file_day.'.log';
                $alarm_data[$key]['app_id'] = $value['app_id'];

                if(file_exists($path)){
                    // var_dump(time()-filemtime($path));exit;
                    if(time()-filemtime($path) > 35){
                        $alarm_data[$key]['app_status'] = 'NO';
                        $alarm_data[$key]['aler_content'] = '程序运行终止';
                        @$this->App_model->update(array('app_status'=>$alarm_data[$key]['app_status']),'app_id='.$value['app_id']);
                    }else{

                        $file_open = fopen($path,'r');

                        fseek($file_open,-1,SEEK_END);
                        $s = '';
                        while(($c = fgetc($file_open)) !== false) 
                        {
                          if($c == "\n" && $s) break;
                          $s = $c . $s;
                          fseek($file_open, -2, SEEK_CUR);
                        }
                        fclose($file_open);
                        $status_site = strpos($s,'STATUS');
                        $runningtype_site =  strpos($s,'RUNNINGTYPE');
                        $alert_comment = strpos($s,'ALERTCONTENT');
                        $alarm_data[$key]['app_status'] = substr($s,$status_site+8, $runningtype_site-$status_site-10);
                        $alarm_data[$key]['app_report_time'] = substr($s,strpos($s,'REPORTTIME')+12,19);
                        $alarm_data[$key]['aler_content'] = substr($s,strpos($s,'ALERTCONTENT')+14,strpos($s,'REPORTTIME')-strpos($s,'ALERTCONTENT')-16);
                        @$this->App_model->update(array('app_status'=>$alarm_data[$key]['app_status']),'app_id='.$value['app_id']);
                        
                    }
                }else{
                    $alarm_data[$key]['app_status'] = 'NO';
                    $alarm_data[$key]['aler_content'] = '无监控信息报告';
                    @$this->App_model->update(array('app_status'=>$alarm_data[$key]['app_status']),'app_id='.$value['app_id']);                    
                }

            }
            echo json_encode($alarm_data);exit;
        }else{
            echo json_encode(array('app_status' => 'NO', 'app_id' => 0));exit;
        }

    }

        


    /**
     * app 应用列表
     * @param int $page_no
     */
    function app_lists($page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(app_name,hardware_name,program_name) like '%{$keyword}%'";
        }
        $where = implode(" and ", $where_arr);
        $data_list = $this->App_model->tables_listinfo($where, 't_sys_app.*,t_sys_hardware.hardware_name', $orderby, $page_no, $this->App_model->page_size, '', $this->App_model->page_size, page_list_url('adminpanel/appMonitor/app_lists', true));
        $this->view('app_lists', array('data_list' => $data_list, 'pages' => $this->App_model->pages, 'keyword' => $keyword, 'require_js' => true));
    }
    /**
     * 新增应用
     */
    function app_add()
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            
            $_arr['app_description'] = isset($_POST["app_description"]) ? trim(safe_replace($_POST["app_description"])) : "";
            $_arr['program_name'] = isset($_POST["program_name"]) ? trim(safe_replace($_POST["program_name"])) : exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));
            if ($_arr['program_name'] == '') exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));
             $_arr['hardware_id'] = isset($_POST["hardware_id"]) ? trim(safe_replace($_POST["hardware_id"])) : exit(json_encode(array('status' => false, 'tips' => '服务器不能为空')));
            if ($_arr['hardware_id'] == '') exit(json_encode(array('status' => false, 'tips' => '服务器不能为空')));


            $_arr['program_start_dir'] = isset($_POST["program_start_dir"]) ? trim(safe_replace($_POST["program_start_dir"])) : exit(json_encode(array('status' => false, 'tips' => '程序启动目录不能为空')));
            if ($_arr['program_start_dir'] == '') exit(json_encode(array('status' => false, 'tips' => '程序启动目录不能为空')));
            $_arr['program_log_dir'] = isset($_POST["program_log_dir"]) ? trim(safe_replace($_POST["program_log_dir"])) : exit(json_encode(array('status' => false, 'tips' => '日志目录不能为空')));
            if ($_arr['program_log_dir'] == '') exit(json_encode(array('status' => false, 'tips' => '日志目录不能为空')));
            $_arr['program_log_degree'] = isset($_POST["program_log_degree"]) ? trim(safe_replace($_POST["program_log_degree"])) : exit(json_encode(array('status' => false, 'tips' => '日志级别不能为空')));
            if ($_arr['program_log_degree'] == '') exit(json_encode(array('status' => false, 'tips' => '日志级别不能为空')));
            $_arr['is_master'] = isset($_POST["is_master"]) ? trim(safe_replace($_POST["is_master"])) : exit(json_encode(array('status' => false, 'tips' => '是否主用必选')));
            if ($_arr['is_master'] == '') exit(json_encode(array('status' => false, 'tips' => '是否主用必选')));
            $_arr['time_out'] = isset($_POST["time_out"]) ? trim(safe_replace($_POST["time_out"])) : exit(json_encode(array('status' => false, 'tips' => '心跳包超时周期必填')));
            if ($_arr['time_out'] == '') exit(json_encode(array('status' => false, 'tips' => '心跳包超时周期必填')));
            $_arr['receive_watch_ip'] = isset($_POST["receive_watch_ip"]) ? trim(safe_replace($_POST["receive_watch_ip"])) : exit(json_encode(array('status' => false, 'tips' => '接收监控ip必填')));
            if ($_arr['receive_watch_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '接收监控ip必填')));
            $_arr['receive_watch_port'] = isset($_POST["receive_watch_port"]) ? trim(safe_replace($_POST["receive_watch_port"])) : exit(json_encode(array('status' => false, 'tips' => '接收监控端口必填')));
            if ($_arr['receive_watch_port'] == '') exit(json_encode(array('status' => false, 'tips' => '接收监控端口必填')));
            $_arr['receive_ip'] = isset($_POST["receive_ip"]) ? trim(safe_replace($_POST["receive_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['receive_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['receive_ip'] = isset($_POST["receive_ip"]) ? trim(safe_replace($_POST["receive_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['receive_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['receive_cast_type'] = isset($_POST["receive_cast_type"]) ? trim(safe_replace($_POST["receive_cast_type"])) : exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            if ($_arr['receive_cast_type'] == '') exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            
            $_arr['send_watch_ip'] = isset($_POST["send_watch_ip"]) ? trim(safe_replace($_POST["send_watch_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送监控ip必填')));
            if ($_arr['send_watch_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送监控ip必填')));
            $_arr['send_watch_port'] = isset($_POST["send_watch_port"]) ? trim(safe_replace($_POST["send_watch_port"])) : exit(json_encode(array('status' => false, 'tips' => '发送监控端口必填')));
            if ($_arr['send_watch_port'] == '') exit(json_encode(array('status' => false, 'tips' => '发送监控端口必填')));
            $_arr['send_ip'] = isset($_POST["send_ip"]) ? trim(safe_replace($_POST["send_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['send_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['send_ip'] = isset($_POST["send_ip"]) ? trim(safe_replace($_POST["send_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['send_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['send_cast_type'] = isset($_POST["send_cast_type"]) ? trim(safe_replace($_POST["send_cast_type"])) : exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            if ($_arr['send_cast_type'] == '') exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            $_arr['send_cycle'] = isset($_POST["send_cycle"]) ? trim(safe_replace($_POST["send_cycle"])) : exit(json_encode(array('status' => false, 'tips' => '发送周期必填')));
            if ($_arr['send_cycle'] == '') exit(json_encode(array('status' => false, 'tips' => '发送周期必填')));

            $new_id = $this->App_model->insert($_arr);
            $this->_cache_app();
            if ($new_id) {
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $this->view('app_edit', array('is_edit' => false, 'require_js' => true, 'data_info' => $this->App_model->default_info()));
        }
    }

    /**
     * 编辑应用
     */
    function app_edit($id)
    {
        $id = intval($id);
        $data_info = $this->App_model->get_one(array('app_id' => $id));
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            if (!$data_info) exit(json_encode(array('status' => false, 'tips' => '信息不存在')));
            $hardware = getcache('cache_hardware');
            //接收POST参数
            $_arr['app_description'] = isset($_POST["app_description"]) ? trim(safe_replace($_POST["app_description"])) : "";
            $_arr['program_name'] = isset($_POST["program_name"]) ? trim(safe_replace($_POST["program_name"])) : exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));
            if ($_arr['program_name'] == '') exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));
             $_arr['hardware_id'] = isset($_POST["hardware_id"]) ? trim(safe_replace($_POST["hardware_id"])) : exit(json_encode(array('status' => false, 'tips' => '服务器不能为空')));
            if ($_arr['hardware_id'] == '') exit(json_encode(array('status' => false, 'tips' => '服务器不能为空')));
            $_arr['program_start_dir'] = isset($_POST["program_start_dir"]) ? trim(safe_replace($_POST["program_start_dir"])) : exit(json_encode(array('status' => false, 'tips' => '程序启动目录不能为空')));
            if ($_arr['program_start_dir'] == '') exit(json_encode(array('status' => false, 'tips' => '程序启动目录不能为空')));
            $_arr['program_log_dir'] = isset($_POST["program_log_dir"]) ? trim(safe_replace($_POST["program_log_dir"])) : exit(json_encode(array('status' => false, 'tips' => '日志目录不能为空')));
            if ($_arr['program_log_dir'] == '') exit(json_encode(array('status' => false, 'tips' => '日志目录不能为空')));
            $_arr['program_log_degree'] = isset($_POST["program_log_degree"]) ? trim(safe_replace($_POST["program_log_degree"])) : exit(json_encode(array('status' => false, 'tips' => '日志级别不能为空')));
            if ($_arr['program_log_degree'] == '') exit(json_encode(array('status' => false, 'tips' => '日志级别不能为空')));
            $_arr['is_master'] = isset($_POST["is_master"]) ? trim(safe_replace($_POST["is_master"])) : exit(json_encode(array('status' => false, 'tips' => '是否主用必选')));
            if ($_arr['is_master'] == '') exit(json_encode(array('status' => false, 'tips' => '是否主用必选')));
            $_arr['time_out'] = isset($_POST["time_out"]) ? trim(safe_replace($_POST["time_out"])) : exit(json_encode(array('status' => false, 'tips' => '心跳包超时周期必填')));
            if ($_arr['time_out'] == '') exit(json_encode(array('status' => false, 'tips' => '心跳包超时周期必填')));
            $_arr['receive_watch_ip'] = isset($_POST["receive_watch_ip"]) ? trim(safe_replace($_POST["receive_watch_ip"])) : exit(json_encode(array('status' => false, 'tips' => '接收监控ip必填')));
            if ($_arr['receive_watch_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '接收监控ip必填')));
            $_arr['receive_watch_port'] = isset($_POST["receive_watch_port"]) ? trim(safe_replace($_POST["receive_watch_port"])) : exit(json_encode(array('status' => false, 'tips' => '接收监控端口必填')));
            if ($_arr['receive_watch_port'] == '') exit(json_encode(array('status' => false, 'tips' => '接收监控端口必填')));
            $_arr['receive_ip'] = isset($_POST["receive_ip"]) ? trim(safe_replace($_POST["receive_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['receive_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['receive_ip'] = isset($_POST["receive_ip"]) ? trim(safe_replace($_POST["receive_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['receive_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['receive_cast_type'] = isset($_POST["receive_cast_type"]) ? trim(safe_replace($_POST["receive_cast_type"])) : exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            if ($_arr['receive_cast_type'] == '') exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            
            $_arr['send_watch_ip'] = isset($_POST["send_watch_ip"]) ? trim(safe_replace($_POST["send_watch_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送监控ip必填')));
            if ($_arr['send_watch_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送监控ip必填')));
            $_arr['send_watch_port'] = isset($_POST["send_watch_port"]) ? trim(safe_replace($_POST["send_watch_port"])) : exit(json_encode(array('status' => false, 'tips' => '发送监控端口必填')));
            if ($_arr['send_watch_port'] == '') exit(json_encode(array('status' => false, 'tips' => '发送监控端口必填')));
            $_arr['send_ip'] = isset($_POST["send_ip"]) ? trim(safe_replace($_POST["send_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['send_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['send_ip'] = isset($_POST["send_ip"]) ? trim(safe_replace($_POST["send_ip"])) : exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            if ($_arr['send_ip'] == '') exit(json_encode(array('status' => false, 'tips' => '发送ip必填')));
            $_arr['send_cast_type'] = isset($_POST["send_cast_type"]) ? trim(safe_replace($_POST["send_cast_type"])) : exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            if ($_arr['send_cast_type'] == '') exit(json_encode(array('status' => false, 'tips' => '传输类型必填')));
            $_arr['send_cycle'] = isset($_POST["send_cycle"]) ? trim(safe_replace($_POST["send_cycle"])) : exit(json_encode(array('status' => false, 'tips' => '发送周期必填')));
            if ($_arr['send_cycle'] == '') exit(json_encode(array('status' => false, 'tips' => '发送周期必填')));

            $status = $this->App_model->update($_arr, array('app_id' => $id));
            $this->_cache_app();
            if ($status) {
                exit(json_encode(array('status' => true, 'tips' => '信息修改成功')));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息修改失败')));
            }
        } else {
            if (!$data_info) $this->showmessage('信息不存在');
            $this->view('app_edit', array('require_js' => true, 'is_edit' => true, 'data_info' => $data_info));
        }
    }

    /**
     * 删除应用
     * @param int $id
     */
    function  delete_app_one($id = 1)
    {
        $id = intval($id);
        $data_info = $this->App_model->get_one(array('app_id' => $id));
        if (!$data_info) $this->showmessage('信息不存在');

        $status = $this->App_model->delete(array('app_id' => $id));
        if ($status) {
            $this->showmessage('删除成功');
        } else {
            $this->showmessage('删除失败');
        }
    }

    /**
     * 应用告警策略列表
     * @param $app_name
     */
    function  app_alert_lists($app_id = 0, $app_name = '', $page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(app_name,hardware_name,program_name) like '%{$keyword}%'";
        }
        $where_arr[] = "app_id = {$app_id}";
        $where = implode(" and ", $where_arr);
        $data_list = $this->App_alert_model->listinfo($where, '*', $orderby, $page_no, $this->App_alert_model->page_size, '', $this->App_alert_model->page_size, page_list_url('adminpanel/appMonitor/app_alaert_lists', true));
        $this->view('app_alert', array('data_list' => $data_list, 'pages' => $this->App_alert_model->pages, 'app_id' => $app_id, 'app_name' => $app_name, 'keyword' => $keyword, 'require_js' => true));
    }

    /**
     * 新增应用告警策略
     * @param $app_id
     */
    function  app_alert_add($app_id)
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['app_id'] = intval($app_id);
            $_arr['min_value'] = isset($_POST["min_value"]) ? trim(safe_replace($_POST["min_value"])) : 0;
            if ($_arr['min_value'] == '') 0;
            $_arr['max_value'] = isset($_POST["max_value"]) ? trim(safe_replace($_POST["max_value"])) : 0;
            if ($_arr['max_value'] == '') 0;
            $_arr['alert_description'] = isset($_POST["alert_description"]) ? trim(safe_replace($_POST["alert_description"])) : exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            if ($_arr['alert_description'] == '') exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            $_arr['alert_cycle'] = isset($_POST["alert_cycle"]) ? trim(safe_replace($_POST["alert_cycle"])) : 30;
            if ($_arr['alert_cycle'] == '') 30;
            $new_id = $this->App_alert_model->insert($_arr);
            if ($new_id) {
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $this->view('alert_edit', array('is_edit' => false, 'require_js' => true, 'app_id' => $app_id, 'data_info' => $this->App_alert_model->default_info()));
        }
    }

    /**
     * 删除应用告警策略
     * @param $app_id
     * @param $alert_id
     */
    function app_alert_delete_one($app_id, $alert_id)
    {

    }

    /**
     * 编辑应用告警策略
     * @param $app_id
     * @param $alert_id
     */
    function app_alert_edit($alert_id, $app_id)
    {
        $id = intval($alert_id);
        $app_id = intval($app_id);
        $data_info = $this->App_alert_model->get_one(array('alert_id' => $id));
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['min_value'] = isset($_POST["min_value"]) ? trim(safe_replace($_POST["min_value"])) : 0;
            if ($_arr['min_value'] == '') 0;
            $_arr['max_value'] = isset($_POST["max_value"]) ? trim(safe_replace($_POST["max_value"])) : 0;
            if ($_arr['max_value'] == '') 0;
            $_arr['alert_description'] = isset($_POST["alert_description"]) ? trim(safe_replace($_POST["alert_description"])) : exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            if ($_arr['alert_description'] == '') exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            $_arr['alert_cycle'] = isset($_POST["alert_cycle"]) ? trim(safe_replace($_POST["alert_cycle"])) : 30;
            if ($_arr['alert_cycle'] == '') 30;
            $status = $this->App_alert_model->update($_arr, array('alert_id' => $id));
            if ($status) {
                exit(json_encode(array('status' => true, 'tips' => '信息修改成功')));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息修改失败')));
            }
        } else {
            $this->view('alert_edit', array('is_edit' => true, 'require_js' => true, 'app_id' => $app_id, 'data_info' => $data_info));
        }
    }

    /**
     * 显示应用拓扑图
     */
    function topo()
    {
        $data_list = $this->_cache_hardware(); //全部设备的调用
        // print_r($data_list);exit;
        if(empty($data_list)){
            $this->showmessage('暂未添加设备');exit;
        }
        $this->view('topo', array('require_js' => true,'data_list'=>json_encode($data_list)));
    }


    /**
     * 列表显示应用监控信息
     * @param int $app_id
     * @param string $app_name
     */
    function data_lists($app_id = 0, $app_name = '', $page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(data_source,data_source_ip_port) like '%{$keyword}%'";
        }
        $where_arr[] = "app_id = {$app_id}";
        $where = implode(" and ", $where_arr);
        $data_list = $this->App_status_model->listinfo($where, '*', $orderby, $page_no, $this->App_status_model->page_size, '', $this->App_status_model->page_size, page_list_url('adminpanel/appMonitor/lists', true));
        $this->view('data_lists', array('data_list' => $data_list, 'app_id' => $app_id, 'app_name' => $app_name, 'pages' => $this->App_status_model->pages, 'keyword' => $keyword, 'require_js' => true));
    }

    /**
     * 图表显示应用监控信息
     * @param int $app_id
     * @param string $app_name
     */
    function data_charts($app_id = 0, $app_name = '')
    {
        $app_id = intval($app_id);
        $page_no = 1;
        $where_arr = array();
        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(data_source,data_source_ip_port) like '%{$keyword}%'";
        }
        $where_arr[] = "app_id = {$app_id}";
        $where = implode(" and ", $where_arr);
        $data_list = $this->App_status_model->listinfo($where, '*', $orderby, $page_no, $this->App_status_model->page_size, '', $this->App_status_model->page_size, page_list_url('adminpanel/appMonitor/charts', true));
        if (is_ajax()) {
            echo json_encode($data_list);
        } else {
            $this->view('data_charts', array('data_list' => $data_list, 'app_id' => $app_id, 'app_name' => $app_name, 'pages' => $this->App_status_model->pages, 'keyword' => $keyword, 'require_js' => true));
        }
    }

    /**
     * 新增连线
     * @param AJAX POST
     * @return void
     */
    function add_line()
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['start_node_id'] = isset($_POST["start_node_id"]) ? trim(safe_replace($_POST["start_node_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            if ($_arr['start_node_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            $_arr['end_node_id'] = isset($_POST["end_node_id"]) ? trim(safe_replace($_POST["end_node_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            if ($_arr['end_node_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            $_arr['line_type_id'] = isset($_POST["line_type_id"]) ? trim(safe_replace($_POST["line_type_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            if ($_arr['line_type_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            $_arr['line_color_id'] = isset($_POST["line_color_id"]) ? trim(safe_replace($_POST["line_color_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            if ($_arr['line_color_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            $_arr['start_node_eth_id'] = isset($_POST["start_node_eth_id"]) ? trim(safe_replace($_POST["start_node_eth_id"])) : '';
            $_arr['end_node_eth_id'] = isset($_POST["end_node_eth_id"]) ? trim(safe_replace($_POST["end_node_eth_id"])) : '';
            $_arr['description'] = isset($_POST["description"]) ? trim(safe_replace($_POST["description"])) : '';

            $new_id = $this->Line_model->insert($_arr);
            $this->_cache_line();
            if ($new_id) {
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $this->view('link', array('is_edit' => false, 'require_js' => true, 'data_info' => $this->Line_model->default_info()));
        }
    }

    /**
     * 删除单个连线
     * @param int id
     * @return void
     */
    function delete_line_one($id = 0)
    {
        $id = intval($id);
        $data_info = $this->Line_model->get_one(array('line_id' => $id));
        if (!$data_info) $this->showmessage('信息不存在');

        if ($id != SUPERADMIN_GROUP_ID) {
            $status = $this->Line_model->delete(array('line_id' => $id));
            $this->_cache_line();
            if ($status) {
                $this->showmessage('删除成功');
            } else
                $this->showmessage('删除失败');
        }
        $this->showmessage('删除失败');

    }

    /**
     * 修改连线
     * @param int id
     * @return void
     */
    function edit_line($id = 0)
    {
        $id = intval($id);

        $data_info = $this->Eth_manage_model->get_one(array('eth_id' => $id));
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            if (!$data_info) exit(json_encode(array('status' => false, 'tips' => '信息不存在')));
            //接收POST参数
            $_arr['hardware_id'] = isset($_POST["hardware_id"]) ? trim(safe_replace($_POST["hardware_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            if ($_arr['hardware_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            $_arr['hardware_id'] = isset($_POST["hardware_id"]) ? trim(safe_replace($_POST["hardware_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            if ($_arr['hardware_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            $_arr['line_type_id'] = isset($_POST["line_type_id"]) ? trim(safe_replace($_POST["line_type_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            if ($_arr['line_type_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            $_arr['color_id'] = isset($_POST["color_id"]) ? trim(safe_replace($_POST["color_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            if ($_arr['color_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            $_arr['start_node_eth_id'] = isset($_POST["start_node_eth_id"]) ? trim(safe_replace($_POST["start_node_eth_id"])) : '';
            $_arr['end_node_eth_id'] = isset($_POST["end_node_eth_id"]) ? trim(safe_replace($_POST["end_node_eth_id"])) : '';
            $_arr['description'] = isset($_POST["description"]) ? trim(safe_replace($_POST["description"])) : '';

            $status = $this->Line_model->update($_arr, array('line_id' => $id));
            $this->_cache_line();
            if ($status) {
                exit(json_encode(array('status' => true, 'tips' => '信息修改成功')));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息修改失败')));
            }
        } else {
            if (!$data_info) $this->showmessage('信息不存在');
            $this->view('link', array('require_js' => true, 'is_edit' => true, 'data_info' => $data_info));
        }
    }

    /**
     * 保存节点或容器移动后的位置
     */
/*    function save_axis()
    {
        $data = $_POST["json"];
        $hardware_name = $_POST["node_name"];
        $_arr["canvas_x"] = $data["x"];
        $_arr["canvas_y"] = $data["y"];
        $this->Hardware_model->update($_arr, array('hardware_name' => $hardware_name));
        $this->_cache_hardware();
    }*/

    /**
     * 获取设备对应的网口
     */
    function get_node_eths($hardware_id, $eth_id = -1)
    {
        $data_list = $this->Eth_manage_model->select("hardware_id={$hardware_id}", '*', '100', '');
        $_html = "<option value=''>==请选择==</option>";
        foreach ($data_list as $k => $v) {
            if ($eth_id == $v['eth_id'])
                $_html .= "<option value=\"{$v['eth_id']}\" selected=\"selected\">" . $v['eth_num'] . "</option>";
            else
                $_html .= "<option value=\"{$v['eth_id']}\" >" . $v["eth_num"] . "</option>";
        }
        echo $_html;
    }

    /**
     * 设备详细信息的缓存
     */
    private function _cache_hardware()
    {
        $infos = $this->Hardware_model->tables_select(array('is_hide'=>0), 't_sys_hardware.hardware_id,hardware_name,hardware_type_id,img_dir,canvas_x,canvas_y,is_accetive,to_notes,is_middel_server,hardware_other_name,is_main,kind_group,alarm_status');
        if ($infos) {
            setcache('cache_all_hardware', $infos);
        }else{
            $infos = array();
        }
        return $infos;
    }

    /**
     * 应用缓存
     */
    private function _cache_app()
    {
        $infos = $this->App_model->select('', '*', '', 'app_id ASC');
        $appid_arr = array();
        if ($infos) {
            foreach ($infos as $k => $v) {
                $appid_arr[$v['app_id']] = $v;
            }
            setcache('cache_app_all', $appid_arr);
        }
        return $appid_arr;
    }

    /**
     * 连线缓存
     */
    private function _cache_line()
    {
        $infos = $this->Line_model->select('', '*', '', 'line_id ASC');
        $lineid_arr = array();
        if ($infos) {
            foreach ($infos as $k => $v) {
                $lineid_arr[$v['line_id']] = $v;
            }
            setcache('cache_line', $lineid_arr);
        }
        return $lineid_arr;
    }


     //服务器监控的状态
     //服务器监控的状态
         //服务器监控的状态
    public function hardware_status(){
       date_default_timezone_set("UTC");
       $hardware_arr = $this->_cache_hardware();
       $s_count = getcache('s_count');  //进行5次文件的缓存数据
        if(!$s_count){
            $s_count = 1;
        }
        $now_time = time();
        $server_data = array();
        $echo_data = array();
        $old_server_data = getcache('cache_server_data_'.$s_count);
        // print_r($old_server_data);exit;
        $ping_fopen = fopen(PING_HARDWARE_FELE, 'r');
        $ping_last_line = last_line($ping_fopen);
        
        $line_time_site = strrpos($ping_last_line, ':');
        $line_time = substr($ping_last_line, 0,$line_time_site);
         $check_hardware_id = array();
        if($line_time){
            if(time()-strtotime($line_time) < 10){
            //进行读取
                $ip_str = rtrim(trim(substr($ping_last_line, $line_time_site+1)),',');
                $ip_arr = explode(',', $ip_str);
                
                foreach ($ip_arr as $kk => $vv) {
                    $tmp_hardware_id[] = $this->Hardware_eth_model->get_one(array('eth_ip'=>$vv),'hardware_id');
                }
                    // var_dump($ip_arr);exit;
                foreach ($tmp_hardware_id as $key => $value) {
                    $check_hardware_id[$key] = $value['hardware_id'];
                }
            }
        }
        $date_path = date('Ymd');  //读今天的数据
        foreach ($hardware_arr as $key => $value) {
            $file_path = SNMP_PATH.$value['hardware_other_name'].'/snmpret'.$date_path;
            $all_fault_status = 0;
            $echo_data[$value['hardware_id']]['hardware_id'] = $value['hardware_id'];
            $echo_data[$value['hardware_id']]['server_name'] = $value['hardware_name'];
            $echo_data[$value['hardware_id']]['hardware_id'] = $value['hardware_id'];
            $echo_data[$value['hardware_id']]['kind_group'] = $value['kind_group'];
            $echo_data[$value['hardware_id']]['server_type'] = $value['hardware_type_id'];
            $echo_data[$value['hardware_id']]['is_middel_server'] = $value['is_middel_server'];
            $echo_data[$value['hardware_id']]['is_main'] = $value['is_main'];
            $echo_data[$value['hardware_id']]['old_alarm_status'] = $value['alarm_status'];
            if(!empty($check_hardware_id)){
                     if(in_array($value['hardware_id'], $check_hardware_id)){
                            $all_fault_status +=1;
                     }
            }

            if(!file_exists($file_path) ){
                if($old_server_data){
                    $server_data = $old_server_data;
                    if(isset($old_server_data['alarm_status'])){
                        $echo_data[$value['hardware_id']]['alarm_status'] = 1;  //服务器报警
                    }else{
                        $echo_data[$value['hardware_id']]['alarm_status'] = 0;  //服务器报警
                    }
                }else{
                    $echo_data[$value['hardware_id']]['alarm_status'] = 1;  //服务器报警
                }
                 continue; 
            }
            $path_time = filemtime($file_path);
            if($now_time-$path_time>60){
                if($old_server_data){
                    $server_data = $old_server_data;
                    if(isset($old_server_data['alarm_status'])){
                        $echo_data[$value['hardware_id']]['alarm_status'] = 1;  //服务器报警
                    }else{
                        $echo_data[$value['hardware_id']]['alarm_status'] = 0;  //服务器报警
                    }
                }else{
                    $echo_data[$value['hardware_id']]['alarm_status'] = 1;  //服务器报警
                }
                // $echo_data[$value['hardware_id']]['alarm_status'] = 1;  //服务器报警
                $this->hardware_log($value['hardware_id'],'数据未及时发送','','数据未及时发送',5);
                continue;
            }else{
                //文件的修改时间
                // echo ($now_time-$path_time);
                $fh = fopen($file_path, "rb");
                $move_end = fseek($fh, -4,SEEK_END);
                $move_end_str = fread($fh, 4);
                // var_dump($move_end_str);
                if($move_end_str == '7777'){
                    $server_data[$value['hardware_id']]['status'] = 1;
                    $server_data[$value['hardware_id']]['is_main'] = $value['is_main'];
                    fseek($fh, -6, SEEK_END);
                    // print_r($move_end_str);exit;
                    $this_bag_len_str = fread($fh, 2);
                    $this_bag_len =  unpack('S*', $this_bag_len_str);//最后一次传输的包长度 315
                    //从包开始
                    fseek($fh, -$this_bag_len[1],SEEK_END);
                    $head = fread($fh, 2);
                    $head_len = unpack('S*', $head);//数据的长度  315
                    $time_str = fread($fh, 4);
                    $time = unpack('L*', $time_str);  //时间长度
                    $server_data[$value['hardware_id']]['send_time'] = implode('', $time)+1483200000;
                    /*if($old_server_data){
                        $cyctime = $server_data[$value['hardware_id']]['send_time']-$old_server_data[$value['hardware_id']]['send_time'];
                    }else{

                    }*/
                    /*print_r($server_data[$value['hardware_id']]['send_time']);
                    var_dump($cyctime);exit;*/
                    $server_data[$value['hardware_id']]['read_time'] = time();
                    $ser_len_str = fread($fh, 1);
                    $ser_len = unpack('C', $ser_len_str);  //服务器名称长度 8
                    $server_data[$value['hardware_id']]['server_name'] = fread($fh, $ser_len[1]);   //服务器名称
                    // print_r($server_data);exit;
                    $ip_len = fread($fh, 4);
                    $ip = unpack('C*', $ip_len);
                    $real_ip = $ip[1].'.'.$ip[2].'.'.$ip[3].'.'.$ip[4];  //ip地址
                    $server_data[$value['hardware_id']]['real_ip'] = $real_ip;   //服务器名称
                    $ser_kind_len = fread($fh, 1);
                    $ser_kind = unpack('C*', $ser_kind_len);    //服务器类型 array
                    $server_data[$value['hardware_id']]['ser_kind'] =  $ser_kind[1];
                    $cpu_idel_len = fread($fh, 1);
                    $cpu_idel_watch = unpack('C', $cpu_idel_len);  //cpuidel 监控与否
                        $cpu_idel_form_data_len = fread($fh, 1);
                        $cpu_idel_form_data = unpack('C', $cpu_idel_form_data_len); //cpuidel 是都来自data array
                        $cpu_idel_value_len = fread($fh, 1);
                        $cpu_idel_value = unpack('C', $cpu_idel_value_len);  //cpuidel的至98 array
                        // if($cpu_idel_form_data[1] == 1){
                            // var_dump($cpu_idel_form_data);exit;
                            $cpu_used_percent = (100-$cpu_idel_value[1]);
                            if($cpu_idel_watch[1] == 1){
                                if((100-$cpu_idel_value[1]) > 99){
                                        $this->hardware_log($value['hardware_id'],'cpu占用率',$cpu_used_percent,'cpu占用过高',1);
                                        $server_data[$value['hardware_id']]['cpu_used'] = array('status'=>0,'cpu_used_percent'=>$cpu_used_percent);
                                         $all_fault_status = $all_fault_status+1;
                                }else{
                                        $server_data[$value['hardware_id']]['cpu_used'] = array('status'=>'1','cpu_used_percent'=>$cpu_used_percent);
                                }
                            }
                            
                       
                    // }
                    $cpu_load_watch_len = fread($fh, 1);
                    $cpu_load_watch = unpack('C', $cpu_load_watch_len); // cpuload是否监控  1.0

                    if($cpu_load_watch[1] == 1){
                    //获取更多cpu 使用值数据
                        $cpu_load_pit_len = fread($fh, 1);
                        $cpu_load_pit = unpack('C', $cpu_load_pit_len);  //cpu核数
                        $cpu_load_pit_detail_len = fread($fh, ceil($cpu_load_pit[1]/8));
                        $cpu_load_pit_detail = unpack('C*', $cpu_load_pit_detail_len);   //array;
                       
                        $cpu_used_all = 0;
                        for ($i=1; $i <=$cpu_load_pit[1]; $i++) {  //每个核循环
                            $cpu_load_core_len = fread($fh, 1);
                            $cpu_load_core_value[$i] = implode('', unpack('C*', $cpu_load_core_len));   //array;
                            $cpu_used_all += $cpu_load_core_value[$i];
                        }

                        $cpu_used_percent = round($cpu_used_all/$cpu_load_pit[1],2);

                        if(round(($cpu_used_all/$cpu_load_pit[1]),2) >80){
                             $this->hardware_log($value['hardware_id'],'cpu',$cpu_used_percent,'cpu占用过高',1);
                              $server_data[$value['hardware_id']]['cpu_used'] = array('status'=>'0','cpu_used_percent'=>$cpu_used_percent);
                              $all_fault_status = $all_fault_status+1;
                        }else{
                            $server_data[$value['hardware_id']]['cpu_used'] = array('status'=>'1','cpu_used_percent'=>$cpu_used_percent);
                        }

                    }
                    //内存信息
                        $storage_len = fread($fh, 1);
                        $storage = unpack('C', $storage_len);  //内存监控
                        if($storage[1] == 1){
                            $storage_block_len = fread($fh, 1);
                            $storage_block = unpack('C', $storage_block_len);  //内存块数
                            //进行多内存的循环 
                            $storage_name_len = $storage_name = $storage_from_data = $cluster_size = $block_size = $blocked_size = array();
                            for ($i=1; $i <= $storage_block[1]; $i++) { 
                                $storage_name_len_str = fread($fh, 1);
                                $storage_name_len[$i] = implode('',unpack('C', $storage_name_len_str));  //内存名长度
                                $storage_name[$i] = fread($fh, $storage_name_len[$i]);  //Memory_Size  第一个为内存 后面为磁盘
                                $storage_from_data_len = fread($fh, 1);
                                $storage_from_data[$i] = implode('',unpack('C', $storage_from_data_len)); //244
                                    $cluster_size_len = fread($fh, 4);
                                    $cluster_size[$i] = implode('',unpack('L*', $cluster_size_len)); //簇大小
                                    // var_dump($cluster_size[$i]);
                                    $block_size_len = fread($fh, 4);
                                    $block_size[$i] = implode('',unpack('L*', $block_size_len)); //分区大小
                                    // print_r($block_size);
                                    $blocked_size_len = fread($fh, 4);
                                    $blocked_size[$i] = implode('',unpack('L*', $blocked_size_len)); //分区已用大小
                                    $all_block_size = round(($block_size[$i]*$cluster_size[$i])/(1024*1024*1024),2)!=0?round(($block_size[$i]*$cluster_size[$i])/(1024*1024*1024),2):1;
                                    $all_blocked_size = round(($blocked_size[$i]*$cluster_size[$i])/(1024*1024*1024),2);
                                    $all_block_used_percent = (round(($all_blocked_size/$all_block_size),2)*100);
                                    // if($storage_name[$i] !='Cached_Size'){
                                             
                                            if((round(($all_blocked_size/$all_block_size),2)*100) >99){
                                        //内存或分区超出限制
                                                $this->hardware_log($value['hardware_id'],$storage_name[$i], $all_block_used_percent,'内存占用过高',2);
                                                $all_fault_status = $all_fault_status+1;
                                                 $server_data[$value['hardware_id']]['storage_name'][$i] =array('storage_name'=>$storage_name[$i],'status'=>0,'all_block_size'=>$all_block_size,'all_blocked_size'=>$all_blocked_size,'all_block_used_percent'=>$all_block_used_percent);
                                            }else{
                                                // echo ($storage_name[$i]);
                                                $server_data[$value['hardware_id']]['storage_name'][$i] =array('storage_name'=>$storage_name[$i],'status'=>1,'all_block_size'=>$all_block_size,'all_blocked_size'=>$all_blocked_size,'all_block_used_percent'=>$all_block_used_percent);
                                            }
                                    // }
                            }

                        }
                        //网口(可变长度),网口信息一定启用，最少一个，即agent IP的网口
                        $net_num_len = fread($fh, 1);
                        $net_num = unpack('C', $net_num_len);  //网口数量
                        $net_name_len =$net_name= $net_data_from=$net_data_port=$ins_num=$lost_ins_num=$wrong_ins_num = $out_num =$lost_out_num=$wrong_out_num= array();
                        for ($i=1; $i <= $net_num[1]; $i++) { 
                            $net_name_len_str = fread($fh, 1);
                            $net_name_len[$i] = implode('',unpack('C', $net_name_len_str));  //网口名长度
                            $net_name[$i] = fread($fh, $net_name_len[$i]); //网口名  有乱码aaaaaaaaaaaaaaaaaaaaaaa
                            $net_data_from_str = fread($fh, 1);
                            $net_data_from[$i] = implode('',unpack('C', $net_data_from_str)); //Fx项，指示7个网口参数数据是否有来
                                $net_data_port_str = fread($fh, 1);
                                $net_data_port[$i] = implode('',unpack('C', $net_data_port_str)); //1—端口up 0—端口down
                                // print_r($net_data_port);
                                $ins_num_str = fread($fh, 4);
                                $ins_num[$i] = implode('',unpack('L*', $ins_num_str)); //In包数量  100794368
                                

                                if($ins_num[$i]<0){
                                    $ins_num[$i] = $ins_num[$i]+4294967295;
                                }

                                $lost_ins_num_str =fread($fh, 4);
                                $lost_ins_num[$i] = implode('',unpack('L*', $lost_ins_num_str));
                                
                               
                                // print_r($lost_ins_num);  //In包丢弃数量 812674661
                                $wrong_ins_num_str =fread($fh, 4);
                                $wrong_ins_num[$i] = implode('',unpack('L*', $wrong_ins_num_str));//in包错误数量
                                // print_r($wrong_ins_num);  //In包错误数量  33436531 
                                $out_num_str = fread($fh, 4);
                                $out_num[$i] = implode('',unpack('L*', $out_num_str)); //out包数量  100794368
                                $lost_out_num_str =fread($fh, 4);
                                $lost_out_num[$i] =  implode('',unpack('L*', $lost_out_num_str));
                                // print_r($lost_out_num);  //out包丢弃数量 812674661
                                $wrong_out_num_str =fread($fh, 4);
                                $wrong_out_num[$i] = implode('',unpack('L*', $wrong_out_num_str));//Out包错误数量
                                
                                // $n_status = 1;
                                 $server_data[$value['hardware_id']]['net_name'][$i] =array('status'=>1,'net_name'=>$net_name[$i],'ins_num'=>$ins_num[$i],'lost_ins_num'=>$lost_ins_num[$i],'wrong_ins_num'=>$wrong_ins_num[$i],'out_num'=>$out_num[$i],'lost_out_num'=>$lost_out_num[$i],'wrong_out_num'=>$wrong_out_num[$i]);
                                if(!empty($check_hardware_id)){
                                     if(in_array($value['hardware_id'], $check_hardware_id)){
                                        $all_fault_status = $all_fault_status+1;
                                            $server_data[$value['hardware_id']]['net_name'][$i] =array('status'=>0,'net_name'=>$net_name[$i],'ins_num'=>$ins_num[$i],'lost_ins_num'=>$lost_ins_num[$i],'wrong_ins_num'=>$wrong_ins_num[$i],'out_num'=>$out_num[$i],'lost_out_num'=>$lost_out_num[$i],'wrong_out_num'=>$wrong_out_num[$i]);
                                     }
                                }
                                  //进行告警
                            
                        }
                        /*if($value['hardware_id'] == 6){
                            print_r($server_data);exit;

                        }*/
                        // print_r($net_name);print_r($ins_num);print_r($lost_ins_num);exit;
                        //进程信息(可变长度)
                        $process_watch_len = fread($fh, 1);
                        $process_watch_len = unpack('C', $process_watch_len); 
                        if($process_watch_len[1] == 1){
                            $process_watch_num = $process_name_len = $process_name = $process_name_id = $process_data_from = $process_path_len= $process_path_name=$process_cpu_used=$process_storage_used = array();
                            $process_watch_num_str = fread($fh, 1);
                            $process_watch_num= unpack('C*', $process_watch_num_str);
                            
                            for ($i=1; $i <= $process_watch_num[1]; $i++) { 
                                
                                $process_name_len_str = fread($fh, 1);
                                $process_name_len[$i] = implode('',unpack('C*', $process_name_len_str));
                                $process_name[$i] = fread($fh, $process_name_len[$i]);
                                
                                // var_dump($process_name);exit;
                                $process_name_id_str = fread($fh, 4);
                                $process_name_id[$i] = implode('',unpack('L*', $process_name_id_str)); //244
                                // print_r($storage_from_data);
                                $process_data_from_str = fread($fh, 1);
                                $process_data_from[$i] = implode('',unpack('C*', $process_data_from_str)); //数据来源
                                $process_path_len_str = fread($fh, 1);
                                    // if($process_data_from == 244){
                                        $process_path_len[$i] = implode('',unpack('C*', $process_path_len_str)); //数据路径长度
                                        
                                        $process_path_name[$i] = @fread($fh, $process_path_len[$i]);  //路径名称
                                        $process_cpu_used_str = fread($fh, 4);
                                        $process_cpu_used[$i] = implode('',unpack('L*', $process_cpu_used_str)); //进程cpu使用值
                                        $process_storage_used_str = @fread($fh, 4);
                                        $process_storage_used[$i] = implode('',unpack('L*', $process_storage_used_str)); 
                                        //进程内存使用值
                                        $server_data[$value['hardware_id']]['process_name'][$i] =array('process_name'=>$process_name[$i],'status'=>1,'process_path_name'=>$process_path_name[$i],'process_cpu_used'=>$process_cpu_used[$i],'process_storage_used'=>$process_storage_used[$i],'process_cpu_used_add_status'=>0);
                                        
                            }
                        }
                }else{
                    //读取缓存  或则不进行判断
                    // $server_data = $old_server_data;
                }
                
                if($all_fault_status){
                    $echo_data[$value['hardware_id']]['alarm_status'] = 1;  //服务器报警  修改数据库字段 主备切换
                    $server_data[$value['hardware_id']]['alarm_status'] = 1;
                }else{
                     $echo_data[$value['hardware_id']]['alarm_status'] = 0;//服务器正常
                     $server_data[$value['hardware_id']]['alarm_status'] = 0;
                }
                /*if($value['hardware_id'] == 33){
                    var_dump($all_fault_status);
                    print_r($server_data[6]);exit;
                }*/
                /*if($value['hardware_id'] == 33){
                    print_r($server_data);exit;

                }*/
            }

         }
        $s_count_add = $s_count + 1;
          if($s_count_add > 5){
                
                setcache('s_count',1);
                setcache('cache_server_data_1',$server_data);

          }else{
              setcache('s_count',$s_count_add);
              setcache('cache_server_data_'.$s_count_add,$server_data);

          }
          
        //进行主备切换
        $container_data = array();
        $swith_data = $bypass_data = array();
        foreach ($echo_data as $key => $value) {
            if($value['server_type'] == 2 && $value['is_middel_server'] != 1){
                    $container_data[$value['kind_group']][] = $value; 
            }else{
                //交换机与旁路
                if($value['server_type'] == 1){
                    $switch_data['hardware_id'] = $value; 
                }else{
                    $bypass_data['hardware_id'] = $value;
                }
            }   
        }
        
        foreach ($switch_data as $key => $value) {
             if($value['alarm_status']){
                    $this->Hardware_model->update(array('alarm_status'=>1),array('hardware_id'=>$value['hardware_id']));

             }else{
                    $this->Hardware_model->update(array('alarm_status'=>0),array('hardware_id'=>$value['hardware_id']));
             }
        }

        foreach ($bypass_data as $key => $value) {
             if($value['alarm_status']){
                    $this->Hardware_model->update(array('alarm_status'=>1),array('hardware_id'=>$value['hardware_id']));

             }else{
                    $this->Hardware_model->update(array('alarm_status'=>0),array('hardware_id'=>$value['hardware_id']));
             }
        }

        foreach ($container_data as $kk => $vv) {
            $one_data = $vv[0];
            $two_data = $vv[1];
            $one_is_main = 0;
            $two_is_main = 1;
            // var_dump($two_data);exit;
            $updat_data = array();
            if($one_data['alarm_status'] == 1 && $two_data['alarm_status'] == 0){
                    $updat_data[1]['is_main'] = 0;
                     $updat_data[2]['is_main'] = 1;
                    $this->Hardware_model->update(array('alarm_status'=>1),array('hardware_id'=>$one_data['hardware_id']));
                    $this->Hardware_model->update(array('alarm_status'=>0),array('hardware_id'=>$two_data['hardware_id']));
            }
            // var_dump($one_data['alarm_status'] == 0 && $one_data['old_alarm_status'] == 1);
            if($one_data['alarm_status'] == 0 && $two_data['alarm_status'] == 1){
                    $updat_data[1]['is_main'] = 1;
                     $updat_data[2]['is_main'] = 0;
                    $this->Hardware_model->update(array('alarm_status'=>0),array('hardware_id'=>$one_data['hardware_id']));
                    $this->Hardware_model->update(array('alarm_status'=>1),array('hardware_id'=>$two_data['hardware_id']));

            }
            if($one_data['alarm_status'] == 0 && $two_data['alarm_status'] == 0){
                    $updat_data[1]['is_main'] = 0;
                     $updat_data[2]['is_main'] = 1;
                    $this->Hardware_model->update(array('alarm_status'=>0),array('hardware_id'=>$one_data['hardware_id']));
                    $this->Hardware_model->update(array('alarm_status'=>0),array('hardware_id'=>$two_data['hardware_id']));

            }
            if($one_data['alarm_status'] == 1 && $two_data['alarm_status'] == 1){
                    // var_dump(123);exit;
                    $updat_data[1]['is_main'] = 1;
                    $updat_data[2]['is_main'] = 0;
                    $this->Hardware_model->update(array('alarm_status'=>1),array('hardware_id'=>$one_data['hardware_id']));
                    $this->Hardware_model->update(array('alarm_status'=>1),array('hardware_id'=>$two_data['hardware_id']));

            }else{

            }

            /*if($one_data['alarm_status'] ==1 && $two_data['alarm_status'] == 0){
                
                $updat_data[1]['is_main'] = $one_is_main;
                $updat_data[2]['is_main'] = $two_is_main;
                $echo_data[$one_data['hardware_id']]['is_main'] =  $one_is_main;
                $echo_data[$two_data['hardware_id']]['is_main'] =  $two_is_main;

            }elseif($one_data['alarm_status'] ==0 && $two_data['alarm_status'] == 1) {
               
                $updat_data[1]['is_main'] = $two_is_main;
                $updat_data[2]['is_main'] = $one_is_main;
                $echo_data[$one_data['hardware_id']]['is_main'] =  $one_is_main;
                $echo_data[$two_data['hardware_id']]['is_main'] =  $two_is_main;
            }*/
                
            if(!empty($updat_data)){
                $this->Hardware_model->update($updat_data[1],array('hardware_id'=>$one_data['hardware_id']) );
                // echo $this->Hardware_model->last_query();
                $this->Hardware_model->update($updat_data[2],array('hardware_id'=>$two_data['hardware_id']) );
                // echo $this->Hardware_model->last_query();
                // exit;
            }
        }
        //进行为监控的数据的剔除
        unset($echo_data[17]);
        unset($echo_data[18]);
        unset($echo_data[19]);
        unset($echo_data[20]);
        unset($server_data);
        // print_r($echo_data);exit;
        echo json_encode($echo_data);
    }
    //topo图的报警信息的日志记录
    private function hardware_log($hardware_id,$fault_name='',$fault_value,$fault_content,$fault_type){
        $log_data = array();
        $log_data['hardware_id'] = $hardware_id;
        $log_data['fault_name'] = $fault_name;
        $log_data['fault_value'] = $fault_value;
        $log_data['fault_content'] = $fault_content;
        $log_data['fault_type'] = $fault_type;
        $log_data['dateline'] = time();
        // var_dump($log_data);
        // $this->Hardware_fault_logs_model->insert($log_data);

    }

     public function one_hardware_detail($hardware_id){
        if($hardware_id == 17 || $hardware_id == 18 || $hardware_id == 19 || $hardware_id == 20){
                $this->showmessage('该设备暂未监控');exit;
        }
        $s_count = getcache('s_count');
        // var_dump($s_count);
        $all_cache_data = getcache('cache_server_data_'.$s_count);
        print_r($all_cache_data);exit;
        if($all_cache_data){
            $this_server_data = isset($all_cache_data[$hardware_id])?$all_cache_data[$hardware_id]:'';
            if(!$this_server_data){
                $this->showmessage('系统详情暂不存在');exit;
            }
        }else{
            $this->showmessage('系统详情暂不存在');exit;
        }
        
        $old_server_data = array();
        for ($i=0; $i<=4 ; $i++) { 
            $old_count = $s_count-$i;
            if($old_count<=0){
                $old_count = 5+($s_count-$i);
            }

            $old_server_data[] = getcache('cache_server_data_'.$old_count)[$hardware_id]; //按顺序进行的过去五次数据的获取
        }
        $old_server_data =  array_reverse($old_server_data);
        $cpu_used_arr = $storage_used_arr = array();
        $server_kind = $this_server_data['ser_kind'];
        foreach ($old_server_data as $key => $value) {
            $cpu_used_arr[$key]['x'] = $value['read_time']*1000;
            $cpu_used_arr[$key]['y'] = $value['cpu_used']['cpu_used_percent'];
            if($server_kind !=3){
                $storage_used_arr[$key]['x'] = $value['read_time']*1000;
                $storage_used_arr[$key]['y'] = $value['storage_name'][1]['all_block_used_percent'];
            }
        }
        $app_name = $this_server_data['server_name'];
        //查找服务器相关表中的条件
        if($server_kind !=3){
            $is_main_limit = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id,'is_middel_server'=>0),'is_main');
        }else{
            $is_main_limit = array();
        }
        // print_r($this_server_data);exit;
        $this->view('one_hardware_detail', array('require_js' => true,'data_list'=>$this_server_data,'server_kind' => $server_kind,'hardware_id'=>$hardware_id,'app_name'=>$app_name,'is_main_limit'=>$is_main_limit,'cpu_used_arr'=>json_encode($cpu_used_arr),'storage_used_arr'=>json_encode($storage_used_arr)));
    }

    public function timing_hardware_detail($hardware_id){
        $hardware_id = intval($hardware_id);
        $s_count = getcache('s_count');
        $this_server_data = getcache('cache_server_data_'.$s_count)[$hardware_id];

        echo json_encode($this_server_data);


    }

    public function shift_main($hardware_id,$is_main){
        
        $hardware_id = intval($hardware_id);
        $is_main = intval($is_main);
        $kind_group = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id),'kind_group,hardware_other_name');
        $other_hardware = $this->Hardware_model->get_one('hardware_id !='.$hardware_id.' and kind_group ='.$kind_group['kind_group'],'hardware_id');
        $other_main = $is_main==1?0:1;
         $this->db->trans_start();
        $res = $this->Hardware_model->update(array('is_main'=>$other_main),array('hardware_id'=>$other_hardware['hardware_id']));
        $res = $this->Hardware_model->update(array('is_main'=>$is_main),array('hardware_id'=>$hardware_id));
        $this->db->trans_complete();
        if ($this->db->trans_status() !== FALSE){
            //发送udp
                //程序名
                $app_name = $this->App_model->get_one(array('hardware_id'=>$hardware_id),'program_name'); 'slave';
                if($is_main == 1){
                    $maink_kind = 'MAIN';
                }else{
                    $maink_kind = 'SLAVE';
                }
                if($app_name){
                     $msg = '<MSG TYPE="17" MODULENAME=\''.$kind_group['hardware_other_name'].'\' APPNAME=\''.$app_name['program_name'].'\' COMMAND="'.$maink_kind.'"  CHANGEDTYPE="1"  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
                     // echo $msg;exit;
                        send_udp(SYSTEMSENDIP, SYSTEMSENDPORT,$msg,0);
                }
            echo 1;
        }else{
            echo 0;
        }
    }
    //改变状态进行发送消息
    public function change_msg_confirm(){
        $app_id = $this->input->post('app_id');
        $msg_kind = $this->input->post('msg_kind');
        if(!$app_id || !$msg_kind){
            echo json_encode(array('status'=>FALSE,'tips'=>'参数错误'));exit;
        }
        $app_info = $this->App_model->tables_select(array('app_id'=>$app_id),'hardware_other_name,program_name');
        if($app_info){
            $app_data = $app_info[0];
            if($msg_kind == 1){  //关闭
                $msg = '<MSG TYPE="3" MODULENAME=\''.$app_data['hardware_other_name'].'\' APPNAME=\''.$app_data['program_name'].'\' FULLPATH="" CONFIGFILEPATH=""  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
            }elseif($msg_kind == 2) //启动
            {
                $msg = '<MSG TYPE="2" MODULENAME=\''.$app_data['hardware_other_name'].'\' APPNAME=\''.$app_data['program_name'].'\' FULLPATH="" CONFIGFILEPATH=""  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
            }
            elseif ($msg_kind == 3) { //重启
                 $msg = '<MSG TYPE="4" MODULENAME=\''.$app_data['hardware_other_name'].'\' APPNAME=\''.$app_data['program_name'].'\' FULLPATH="" CONFIGFILEPATH=""  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
            }
            // echo $msg;
                send_udp(SYSTEMSENDIP, SYSTEMSENDPORT,$msg,0);
            echo json_encode(array('status'=>true,'tips'=>'操作成功'));exit;

        }else{
            echo json_encode(array('status'=>FALSE,'tips'=>'应用程序不存在'));exit;
        } 
    }

    public function use_server($hardware_id,$use_kind){
        $ip_info = $this->Hardware_eth_model->tables_select(array('t_sys_hardware_eth.hardware_id'=>$hardware_id,'eth_type'=>0,'net_type'=>0),'eth_ip');
        if($ip_info){
            $ip_add = $ip_info[0]['eth_ip'];
            // var_dump(POWER_FILE.' '.$ip_add);exit;
            if($use_kind == 1){
                 exec(POWER_FILE.' '.$ip_add,$a,$status);
                 
                 
                     echo json_encode(array('status'=>FALSE,'tips'=>'关机成功'));exit;
                 
            }else{
                 exec(REBOOT_FILE.' '.$ip_add,$a);
                
                 // var_dump($status);
                
                     echo json_encode(array('status'=>FALSE,'tips'=>'重启成功'));exit;
                 
            }

        }else{
            echo json_encode(array('status'=>FALSE,'tips'=>'网口ip不存在'));exit;
        }
    }
    //业务关系图
    public function hardware_relation(){
        $data_list = $this->Hardware_relations_model->select(); //全部设备的调用
        // print_r($data_list);exit;
        if(empty($data_list)){
            $this->showmessage('暂未添加设备');exit;
        }
        $this->view('hardware_relation', array('require_js' => true,'data_list'=>json_encode($data_list)));
    }
}