<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
class AppMonitor extends Admin_Controller
{
    private  $snmpTime = 0;
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('App_model', 'App_status_model', 'Hardware_model', 'Eth_manage_model', 'App_alert_model',
        'Hardware_fault_logs_model','Hardware_eth_model','Hardware_relations_model','Station_model','Raders_model',
        'Station_config_model','All_xml_model','Xml_basic_config_model','Station_warning_logs_model','System_alert_info_model'));
        $this->load->model(array('Decoder_config_model'));
        $this->load->helper(array('member_helper','socket'));

    }

    function cache()
    {
        $this->reload_all_cache();
        $this->showmessage('全局缓存成功', site_url('adminpanel'));
    }

    function go($id = 0)
    {
        if ($id == 0) exit();
        if (isset($this->current_role_priv_arr[$id])) {

            $arr = $this->cache_module_menu_arr[$id];
            if (!isset($arr)) exit();
            $arr_parentid = explode(",", $arr['arr_parentid']);

            if (count($arr_parentid) > 2) redirect(base_url($arr['folder'] . '/' . $arr['controller'] . '/' . $arr['method']));
            else {
                foreach ($this->cache_module_menu_arr as $k => $v) {
                    if ($v['parent_id'] == $id) {
                        if (isset($this->current_role_priv_arr[$v['menu_id']])) {
                            redirect(base_url($v['folder'] . '/' . $v['controller'] . '/' . $v['method']));
                            break;
                        }
                    }
                }
            }
        }
        exit();
    }

    function index($page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $orderby ="hardware_id";
        $keyword = "";
        $data_list = $this->App_model->tables_listinfo('', 't_sys_app.*,t_sys_hardware.hardware_name', $orderby, $page_no, $this->App_model->page_size, '', $this->App_model->page_size, page_list_url('adminpanel/appMonitor/index', true));
        $this->view('index', array('data_list' => $data_list, 'pages' => $this->App_model->pages, 'keyword' => $keyword, 'require_js' => true));
    }

    //应用程序监控
    public function timing_app_status(){
        $all_app_list = $this->App_model->tables_select('is_del =0','program_name,hardware_other_name,app_id');
        $alarm_data = array();
        if($all_app_list){
            $file_day = date('Ymd');
            foreach ($all_app_list as $key => $value) {
                $path = APP_LOG_PATH.$value['hardware_other_name'].'/'.$value['program_name'].'_'.$file_day.'.log';
                $alarm_data[$key]['app_id'] = $value['app_id'];

                if(file_exists($path)){
                    // var_dump(time()-filemtime($path));exit;
                    if(time()-filemtime($path) > 35){
                        $alarm_data[$key]['app_status'] = 'NO';
                        $alarm_data[$key]['aler_content'] = '程序运行终止';
                        @$this->App_model->update(array('app_status'=>$alarm_data[$key]['app_status']),'app_id='.$value['app_id']);
                    }else{

                        $file_open = fopen($path,'r');

                        fseek($file_open,-1,SEEK_END);
                        $s = '';
                        while(($c = fgetc($file_open)) !== false)
                        {
                            if($c == "\n" && $s) break;
                            $s = $c . $s;
                            fseek($file_open, -2, SEEK_CUR);
                        }
                        fclose($file_open);
                        $status_site = strpos($s,'STATUS');
                        $runningtype_site =  strpos($s,'RUNNINGTYPE');
                        $alert_comment = strpos($s,'ALERTCONTENT');
                        //$alert_item_content = strpos($s,'ITEMCONTENT');

                        $alarm_data[$key]['app_status'] = substr($s,$status_site+8, $runningtype_site-$status_site-10);
                        $alarm_data[$key]['app_report_time'] = substr($s,strpos($s,'REPORTTIME')+12,19);
                        $alarm_data[$key]['aler_content'] = substr($s,strpos($s,'ALERTCONTENT')+14,strpos($s,'REPORTTIME')-strpos($s,'ALERTCONTENT')-16);

                        @$this->App_model->update(array('app_status'=>$alarm_data[$key]['app_status']),'app_id='.$value['app_id']);



                    }
                }else{
                    $alarm_data[$key]['app_status'] = 'NO';
                    $alarm_data[$key]['aler_content'] = '无监控信息报告';
                    @$this->App_model->update(array('app_status'=>$alarm_data[$key]['app_status']),'app_id='.$value['app_id']);
                }

            }
            echo json_encode($alarm_data);exit;
        }else{
            echo json_encode(array('app_status' => 'NO', 'app_id' => 0));exit;
        }

    }




    /**
     * app 应用列表
     * @param int $page_no
     */
    function app_lists($page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        $where = 'is_del = 0';

        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where .= " and concat(program_name,app_description) like '%{$keyword}%'";
        }
        // $where = implode(" and ", $where_arr);
        $data_list = $this->App_model->listinfo($where, '*', $orderby, $page_no, $this->App_model->page_size, '', $this->App_model->page_size, page_list_url('adminpanel/appMonitor/app_lists', true));
        foreach ($data_list as $key => $value) {
            $hardware_name_data = $this->Hardware_model->select("hardware_id in ({$value['hardware_id']})",'hardware_name');
            $tmp_str = '';
            if($hardware_name_data){
                foreach ($hardware_name_data as $k => $v) {
                    $tmp_str .= $v['hardware_name'].',';
                }
            }
            $data_list[$key]['hardware_name'] = rtrim($tmp_str,',');
        }

        /*if($data_list){
            foreach ($data_list as $key => $value) {
                $program_name = $value['program_name'];
                $program_name_xml = $program_name.'_config.xml';
                // var_dump($program_name_xml);
                $xml_info = $this->All_xml_model->get_one(array('xml_name'=>$program_name_xml,'is_old'=>0),'id');
                if($xml_info){
                    $data_list[$key]['xml_id'] = $xml_info['id'];
                }
            }
        }*/
        $this->view('app_lists', array('data_list' => $data_list, 'pages' => $this->App_model->pages, 'keyword' => $keyword, 'require_js' => true));
    }
    /**
     * 新增应用
     */
    function app_add()
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数

            $_arr['app_description'] = isset($_POST["app_description"]) ? trim(safe_replace($_POST["app_description"])) : "";
            $_arr['program_name'] = isset($_POST["program_name"]) ? trim(safe_replace($_POST["program_name"])) : exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));
            if ($_arr['program_name'] == '') exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));
            $_arr['hardware_id'] = $this->input->post('hardware_id');
            if(empty($_arr['hardware_id'])){
                exit(json_encode(array('status' => false, 'tips' => '服务器不能为空')));
            }else{
                $_arr['hardware_id'] = implode(',', $_arr['hardware_id']);
            }

            $new_id = $this->App_model->insert($_arr);
            $this->_cache_app();
            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '进行应用程序'.$_arr['program_name'].'的新增';
            if ($new_id) {
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息新增成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息新增失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $hardware_data = $this->Hardware_model->select(array('is_hide'=>0,'hardware_type_id'=>2));
            $this->view('app_edit', array('is_edit' => false, 'require_js' => true, 'data_info' => $this->App_model->default_info(),'hardware_data'=>$hardware_data));
        }
    }
    /**
     * 应用详情
     */
    function app_info($id)
    {
        //如果是AJAX请求
        $id = intval($id);
        $data_info = $this->App_model->get_one(array('app_id' => $id));
        if(!$data_info){
            $this->showmessage('信息不存在');exit;
        }
        $data_info['hardware_id'] = explode(',', $data_info['hardware_id']);
        $hardware_data = $this->Hardware_model->select(array('is_hide'=>0,'hardware_type_id'=>2));
        $this->view('app_info', array('require_js' => true, 'data_info' => $data_info,'hardware_data'=>$hardware_data));
    }
    /**
     * 编辑应用
     */
    function app_edit($id)
    {
        $id = intval($id);
        $data_info = $this->App_model->get_one(array('app_id' => $id));
        $hardware_data = $this->Hardware_model->select(array('is_hide'=>0,'hardware_type_id'=>2));
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            if (!$data_info) exit(json_encode(array('status' => false, 'tips' => '信息不存在')));
            //接收POST参数
            $_arr['app_description'] = isset($_POST["app_description"]) ? trim(safe_replace($_POST["app_description"])) : "";
            $_arr['program_name'] = isset($_POST["program_name"]) ? trim(safe_replace($_POST["program_name"])) : exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));
            if ($_arr['program_name'] == '') exit(json_encode(array('status' => false, 'tips' => '进程名不能为空')));


            $_arr['hardware_id'] = $this->input->post('hardware_id');
            if(empty($_arr['hardware_id'])){
                exit(json_encode(array('status' => false, 'tips' => '服务器不能为空')));
            }else{
                $_arr['hardware_id'] = implode(',', $_arr['hardware_id']);
            }
            $status = $this->App_model->update($_arr, array('app_id' => $id));
            $new_data_info = $this->App_model->get_one(array('app_id' => $id));
            $before_change_data = array_diff_assoc($data_info, $new_data_info);
            $this->_cache_app();
            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '进行应用程序'.$_arr['program_name'].'的修改';
            if ($status && !empty($before_change_data)) {
                $operate_info = array();
                $i = 0;
                foreach ($before_change_data as $key => $value) {
                    $operation_info[$i]['key'] = $key;
                    $operation_info[$i]['old_val'] = $value;
                    $operation_info[$i]['new_val'] = $_arr[$key];
                    $i++;
                }
                $operation_data['operate_info'] = json_encode($operation_info);
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息修改成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status' => true, 'tips' => '信息修改成功')));
            } else {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息修改失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status' => false, 'tips' => '信息修改失败')));
            }
        } else {
            if (!$data_info) $this->showmessage('信息不存在');
            $data_info['hardware_id'] = explode(',', $data_info['hardware_id']);
            $this->view('app_edit', array('require_js' => true, 'is_edit' => true, 'data_info' => $data_info,'hardware_data'=>$hardware_data));
        }
    }

    /**
     * 删除应用
     * @param int $id
     */
    function  delete_app_one($id = 1)
    {
        $id = intval($id);
        $data_info = $this->App_model->get_one(array('app_id' => $id));
        if (!$data_info) $this->showmessage('信息不存在');
        $operation_data = $this->operation_data;
        $operation_data['operate_explain'] = '删除'.$data_info['program_name'].'应用程序';
        $operation_data['info_url'] = 'appMonitor/app_info/'.$id;
        $operation_data['dateline'] = time();

        $status = $this->App_model->update(array('is_del'=>1),array('app_id' => $id));
        if ($status) {
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '删除成功';
            @$this->operationLogs($operation_data);
            $this->showmessage('删除成功');
        } else {
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '删除失败';
            @$this->operationLogs($operation_data);
            $this->showmessage('删除失败');
        }
    }

    /**
     * 应用告警策略列表
     * @param $app_name
     */
    function  app_alert_lists($app_id = 0, $app_name = '', $page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(app_name,hardware_name,program_name) like '%{$keyword}%'";
        }
        $where_arr[] = "app_id = {$app_id}";
        $where = implode(" and ", $where_arr);
        $data_list = $this->App_alert_model->listinfo($where, '*', $orderby, $page_no, $this->App_alert_model->page_size, '', $this->App_alert_model->page_size, page_list_url('adminpanel/appMonitor/app_alaert_lists', true));
        $this->view('app_alert', array('data_list' => $data_list, 'pages' => $this->App_alert_model->pages, 'app_id' => $app_id, 'app_name' => $app_name, 'keyword' => $keyword, 'require_js' => true));
    }

    /**
     * 新增应用告警策略
     * @param $app_id
     */
    function  app_alert_add($app_id)
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['app_id'] = intval($app_id);
            $_arr['min_value'] = isset($_POST["min_value"]) ? trim(safe_replace($_POST["min_value"])) : 0;
            if ($_arr['min_value'] == '') 0;
            $_arr['max_value'] = isset($_POST["max_value"]) ? trim(safe_replace($_POST["max_value"])) : 0;
            if ($_arr['max_value'] == '') 0;
            $_arr['alert_description'] = isset($_POST["alert_description"]) ? trim(safe_replace($_POST["alert_description"])) : exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            if ($_arr['alert_description'] == '') exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            $_arr['alert_cycle'] = isset($_POST["alert_cycle"]) ? trim(safe_replace($_POST["alert_cycle"])) : 30;
            if ($_arr['alert_cycle'] == '') 30;
            $new_id = $this->App_alert_model->insert($_arr);
            if ($new_id) {
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $this->view('alert_edit', array('is_edit' => false, 'require_js' => true, 'app_id' => $app_id, 'data_info' => $this->App_alert_model->default_info()));
        }
    }

    /**
     * 删除应用告警策略
     * @param $app_id
     * @param $alert_id
     */
    function app_alert_delete_one($app_id, $alert_id)
    {

    }

    /**
     * 编辑应用告警策略
     * @param $app_id
     * @param $alert_id
     */
    function app_alert_edit($alert_id, $app_id)
    {
        $id = intval($alert_id);
        $app_id = intval($app_id);
        $data_info = $this->App_alert_model->get_one(array('alert_id' => $id));
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['min_value'] = isset($_POST["min_value"]) ? trim(safe_replace($_POST["min_value"])) : 0;
            if ($_arr['min_value'] == '') 0;
            $_arr['max_value'] = isset($_POST["max_value"]) ? trim(safe_replace($_POST["max_value"])) : 0;
            if ($_arr['max_value'] == '') 0;
            $_arr['alert_description'] = isset($_POST["alert_description"]) ? trim(safe_replace($_POST["alert_description"])) : exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            if ($_arr['alert_description'] == '') exit(json_encode(array('status' => false, 'tips' => '应用告警说明不能为空')));
            $_arr['alert_cycle'] = isset($_POST["alert_cycle"]) ? trim(safe_replace($_POST["alert_cycle"])) : 30;
            if ($_arr['alert_cycle'] == '') 30;
            $status = $this->App_alert_model->update($_arr, array('alert_id' => $id));
            if ($status) {
                exit(json_encode(array('status' => true, 'tips' => '信息修改成功')));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息修改失败')));
            }
        } else {
            $this->view('alert_edit', array('is_edit' => true, 'require_js' => true, 'app_id' => $app_id, 'data_info' => $data_info));
        }
    }

    /**
     * 显示应用拓扑图
     */
    function topo()
    {
        // $str = 'new';
        $data_list = $this->_cache_hardware(); //全部设备的调用
        if(empty($data_list)){
            $this->showmessage('暂未添加设备');exit;
        }
        $all_stations = $this->all_stations();
        if(empty($all_stations)){
            $this->showmessage('暂未添加基站设备');exit;
        }

        $time = 3600;
        if(isset($_SERVER['HTTP_IF_MODIFIED_SINCE'])){
            $c_time = strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE'])+$time;
            if($c_time){
                header('HTTP/1.1 304 NOT MODIFIED');
                exit;
            }
        }
        header('Cache-Control:max-age='.$time);
        header("Expires: ".gmdate('D, d M Y H:i:s',time()+$time)." GMT");
        header('Last_Modified:'.gmdate('D, d M Y H:i:s').' GMT');
        $all_stations['hardware_datas'] = $data_list;
        $this->view('topo', array('require_js' => true,'data_list'=>json_encode($all_stations)));
    }


//基站监控
    function watch_list(){
        $data_list = $this->all_stations();
        $this->view('monitor',array('require_js'=>true,'data_list'=>json_encode($data_list)));
    }
    //全部基站与雷达状态的列表
    function all_stations(){
        $station_data = $this->Station_model->_cache_station();
        foreach($station_data as $key => $value ){
            $the_data = $this->Station_model->one_stations_status($value,$key,count($station_data)+2);
            $station_data[$key] = array_merge($value,$the_data);
        }
        foreach($station_data as $key => $value) {
            $station_data[$key]['data_upper_limit_A'] = jurge_station_limit(false,$value['channel_time_A'],$value['station_id']);
            $station_data[$key]['data_upper_limit_B'] = jurge_station_limit(false,$value['channel_time_B'],$value['station_id']);
        }
        $rader_data = $this->Raders_model->select('is_del = 0','id,name,switch,rader_alarm,rader_bag,canvas_x,canvas_y,rader_img,is_monitor,path_switch_a,path_switch_b,path_a_alarm,path_b_alarm,rader_a_bag,rader_b_bag,in_work_option,report_time');
        $data_list = array();
        $data_list['station'] = $station_data;
        $data_list['rader'] = $rader_data;
        // setcache('all_stations_cache',$data_list);
        return $data_list;
    }
    /**
     * 列表显示应用监控信息
     * @param int $app_id
     * @param string $app_name
     */
    function data_lists($app_id = 0, $app_name = '', $page_no = 1)
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(data_source,data_source_ip_port) like '%{$keyword}%'";
        }
        $where_arr[] = "app_id = {$app_id}";
        $where = implode(" and ", $where_arr);
        $data_list = $this->App_status_model->listinfo($where, '*', $orderby, $page_no, $this->App_status_model->page_size, '', $this->App_status_model->page_size, page_list_url('adminpanel/appMonitor/lists', true));
        $this->view('data_lists', array('data_list' => $data_list, 'app_id' => $app_id, 'app_name' => $app_name, 'pages' => $this->App_status_model->pages, 'keyword' => $keyword, 'require_js' => true));
    }

    /**
     * 图表显示应用监控信息
     * @param int $app_id
     * @param string $app_name
     */
    function data_charts($app_id = 0, $app_name = '')
    {
        $app_id = intval($app_id);
        $page_no = 1;
        $where_arr = array();
        $orderby = $keyword = "";
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(data_source,data_source_ip_port) like '%{$keyword}%'";
        }
        $where_arr[] = "app_id = {$app_id}";
        $where = implode(" and ", $where_arr);
        $data_list = $this->App_status_model->listinfo($where, '*', $orderby, $page_no, $this->App_status_model->page_size, '', $this->App_status_model->page_size, page_list_url('adminpanel/appMonitor/charts', true));
        if (is_ajax()) {
            echo json_encode($data_list);
        } else {
            $this->view('data_charts', array('data_list' => $data_list, 'app_id' => $app_id, 'app_name' => $app_name, 'pages' => $this->App_status_model->pages, 'keyword' => $keyword, 'require_js' => true));
        }
    }

    /**
     * 新增连线
     * @param AJAX POST
     * @return void
     */
    function add_line()
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['start_node_id'] = isset($_POST["start_node_id"]) ? trim(safe_replace($_POST["start_node_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            if ($_arr['start_node_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            $_arr['end_node_id'] = isset($_POST["end_node_id"]) ? trim(safe_replace($_POST["end_node_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            if ($_arr['end_node_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            $_arr['line_type_id'] = isset($_POST["line_type_id"]) ? trim(safe_replace($_POST["line_type_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            if ($_arr['line_type_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            $_arr['line_color_id'] = isset($_POST["line_color_id"]) ? trim(safe_replace($_POST["line_color_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            if ($_arr['line_color_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            $_arr['start_node_eth_id'] = isset($_POST["start_node_eth_id"]) ? trim(safe_replace($_POST["start_node_eth_id"])) : '';
            $_arr['end_node_eth_id'] = isset($_POST["end_node_eth_id"]) ? trim(safe_replace($_POST["end_node_eth_id"])) : '';
            $_arr['description'] = isset($_POST["description"]) ? trim(safe_replace($_POST["description"])) : '';

            $new_id = $this->Line_model->insert($_arr);
            $this->_cache_line();
            if ($new_id) {
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $this->view('link', array('is_edit' => false, 'require_js' => true, 'data_info' => $this->Line_model->default_info()));
        }
    }

    /**
     * 删除单个连线
     * @param int id
     * @return void
     */
    function delete_line_one($id = 0)
    {
        $id = intval($id);
        $data_info = $this->Line_model->get_one(array('line_id' => $id));
        if (!$data_info) $this->showmessage('信息不存在');

        if ($id != SUPERADMIN_GROUP_ID) {
            $status = $this->Line_model->delete(array('line_id' => $id));
            $this->_cache_line();
            if ($status) {
                $this->showmessage('删除成功');
            } else
                $this->showmessage('删除失败');
        }
        $this->showmessage('删除失败');

    }

    /**
     * 修改连线
     * @param int id
     * @return void
     */
    function edit_line($id = 0)
    {
        $id = intval($id);

        $data_info = $this->Eth_manage_model->get_one(array('eth_id' => $id));
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            if (!$data_info) exit(json_encode(array('status' => false, 'tips' => '信息不存在')));
            //接收POST参数
            $_arr['hardware_id'] = isset($_POST["hardware_id"]) ? trim(safe_replace($_POST["hardware_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            if ($_arr['hardware_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择头节点')));
            $_arr['hardware_id'] = isset($_POST["hardware_id"]) ? trim(safe_replace($_POST["hardware_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            if ($_arr['hardware_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择尾节点')));
            $_arr['line_type_id'] = isset($_POST["line_type_id"]) ? trim(safe_replace($_POST["line_type_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            if ($_arr['line_type_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择连线类型')));
            $_arr['color_id'] = isset($_POST["color_id"]) ? trim(safe_replace($_POST["color_id"])) : exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            if ($_arr['color_id'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择颜色')));
            $_arr['start_node_eth_id'] = isset($_POST["start_node_eth_id"]) ? trim(safe_replace($_POST["start_node_eth_id"])) : '';
            $_arr['end_node_eth_id'] = isset($_POST["end_node_eth_id"]) ? trim(safe_replace($_POST["end_node_eth_id"])) : '';
            $_arr['description'] = isset($_POST["description"]) ? trim(safe_replace($_POST["description"])) : '';

            $status = $this->Line_model->update($_arr, array('line_id' => $id));
            $this->_cache_line();
            if ($status) {
                exit(json_encode(array('status' => true, 'tips' => '信息修改成功')));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息修改失败')));
            }
        } else {
            if (!$data_info) $this->showmessage('信息不存在');
            $this->view('link', array('require_js' => true, 'is_edit' => true, 'data_info' => $data_info));
        }
    }

    /**
     * 保存节点或容器移动后的位置
     */
    function save_axis($server_id,$kind)
    {
        $data = $_POST["json"];
        $hardware_id = $server_id;
        if($kind == 0){
            $model = $this->Hardware_model;
            $key = 'hardware_id';
        }elseif($kind == 1){
            $model = $this->Station_model;
            $key = 'station_id';

        }else{
            $model = $this->Raders_model;
            $key = 'id';

        }
        // var_dump($data);var_dump($hardware_id);exit;
        $_arr["canvas_x"] = $data["x"];
        $_arr["canvas_y"] = $data["y"];
        $model->update($_arr, array($key => $hardware_id));
        // echo $model->last_query();exit;
        $this->_cache_hardware();
    }

    /**
     * 获取设备对应的网口
     */
    function get_node_eths($hardware_id, $eth_id = -1)
    {
        $data_list = $this->Eth_manage_model->select("hardware_id={$hardware_id}", '*', '100', '');
        $_html = "<option value=''>==请选择==</option>";
        foreach ($data_list as $k => $v) {
            if ($eth_id == $v['eth_id'])
                $_html .= "<option value=\"{$v['eth_id']}\" selected=\"selected\">" . $v['eth_num'] . "</option>";
            else
                $_html .= "<option value=\"{$v['eth_id']}\" >" . $v["eth_num"] . "</option>";
        }
        echo $_html;
    }

    /**
     * 设备详细信息的缓存
     */
    private function _cache_hardware()
    {
        $infos = $this->Hardware_model->tables_select(array('is_hide'=>0), 't_sys_hardware.hardware_id,hardware_name,hardware_type_id,img_dir,canvas_x,canvas_y,is_accetive,to_notes,is_middel_server,hardware_other_name,is_main,kind_group,alarm_status,is_monitor,sound_switch');

        if ($infos) {
            setcache('cache_all_hardware', $infos);
        }else{
            $infos = array();
        }
        return $infos;
    }


    /**
     * 应用缓存
     */
    private function _cache_app()
    {
        $infos = $this->App_model->select('', '*', '', 'app_id ASC');
        $appid_arr = array();
        if ($infos) {
            foreach ($infos as $k => $v) {
                $appid_arr[$v['app_id']] = $v;
            }
            setcache('cache_app_all', $appid_arr);
        }
        return $appid_arr;
    }

    /**
     * 连线缓存
     */
    private function _cache_line()
    {
        $infos = $this->Line_model->select('', '*', '', 'line_id ASC');
        $lineid_arr = array();
        if ($infos) {
            foreach ($infos as $k => $v) {
                $lineid_arr[$v['line_id']] = $v;
            }
            setcache('cache_line', $lineid_arr);
        }
        return $lineid_arr;
    }


    public function hardware_status(){
        // date_default_timezone_set("UTC");
        $hardware_arr = getcache('cache_all_hardware');
        $now_time = time();
        $date_path = date('Ymd');  //读今天的数据
        $old_hardware_info = getcache('hardware_info_cache');
        $new_hardware_info = array();
        //服务器的监控
        $ntp_server_data = $this->ntp_server_data();
        foreach ($hardware_arr as $key => $value) {
            //进行snmp 以及主备切换消息的切换的监控
            if(!$value['is_monitor']){
                continue;
            }
            $file_path = SNMP_DEAL_PATH.$value['hardware_other_name'].'/snmpret'.$date_path;
            // $msg_path = APP_LOG_PATH.$value['hardware_other_name'].$value['program_name'].$date_path;
            //是否监控
            $new_hardware_info[$value['hardware_id']]['hardware_id'] = $value['hardware_id'];
            $new_hardware_info[$value['hardware_id']]['server_type'] = $value['hardware_type_id'];
            $new_hardware_info[$value['hardware_id']]['hardware_name'] = $value['hardware_name'];
            $new_hardware_info[$value['hardware_id']]['is_main'] = $value['is_main'];
            $new_hardware_info[$value['hardware_id']]['is_monitor'] = $value['is_monitor'];
            $new_hardware_info[$value['hardware_id']]['is_middel_server'] = $value['is_middel_server'];
            $new_hardware_info[$value['hardware_id']]['kind_group'] = $value['kind_group'];
            $new_hardware_info[$value['hardware_id']]['sound_switch'] = $value['sound_switch'];
            $new_hardware_info[$value['hardware_id']]['sub_time'] = 0;

            if(file_exists($file_path)){
                setcache('not_exist_snmptime'.$value['hardware_id'],null);
                if($old_hardware_info){

                    if($old_hardware_info[$value['hardware_id']]['snmp_file_time'] == filemtime($file_path)){
                        $new_hardware_info[$value['hardware_id']] = $old_hardware_info[$value['hardware_id']];
                        //判断主备消息的更新
                        $new_hardware_info[$value['hardware_id']]['sub_time'] = time()-filemtime($file_path); //判断文件的更新时间
                        // var_dump(123);exit();

                    }else{
                        $fh = fopen($file_path, 'r');
                        $json_str = file_json_lines($fh,'{');
                        $new_hardware_info[$value['hardware_id']]['snmp_file_time'] = filemtime($file_path);
                        $new_hardware_info[$value['hardware_id']]['sub_time'] = time()-filemtime($file_path);
                        if(!$json_str){
                            if($value['is_middel_server'] == 2){
                                $json_str = $this->empty_ntp_data();
                            }else{
                                $json_str = $this->empty_snmp_data($value['hardware_type_id']);
                            }
                        }

                        $new_hardware_info[$value['hardware_id']]['snmp'] = json_decode($json_str,true);
                        if($value['is_middel_server'] == 2){
                            $new_hardware_info[$value['hardware_id']] = $this->ntp_deal($new_hardware_info[$value['hardware_id']]);
                        }else{
                            $new_hardware_info[$value['hardware_id']] = $this->snmp_deal($new_hardware_info[$value['hardware_id']],$ntp_server_data);
                        }

                    }
                }else{
                    //直接进行最后的json字符串的读取
                    $fh = fopen($file_path, 'r');
                    $json_str = file_json_lines($fh,'{');
                    $new_hardware_info[$value['hardware_id']]['snmp_file_time'] = filemtime($file_path);
                    $new_hardware_info[$value['hardware_id']]['sub_time'] = time()-filemtime($file_path);
                    if(!$json_str){
                        if($value['is_middel_server'] == 2){
                            $json_str = $this->empty_ntp_data();
                        }else{
                            $json_str = $this->empty_snmp_data($value['hardware_type_id']);
                        }
                    }

                    $new_hardware_info[$value['hardware_id']]['snmp'] = json_decode($json_str,true);
                    if($value['is_middel_server'] == 2){
                        $new_hardware_info[$value['hardware_id']] = $this->ntp_deal($new_hardware_info[$value['hardware_id']]);
                    }else{
                        $new_hardware_info[$value['hardware_id']] = $this->snmp_deal($new_hardware_info[$value['hardware_id']],$ntp_server_data);
                    }


                }

            }else{

                $snmp_exist_time = getcache('not_exist_snmptime'.$value['hardware_id']);
                if($snmp_exist_time){

                }else{
                    $snmp_exist_time = strtotime(date('Y-m-d 00:00:00',time()));
                    setcache('not_exist_snmptime'.$value['hardware_id'],$snmp_exist_time);
                }
                $sub_snmp_exist_time = time()-$snmp_exist_time;
                $new_hardware_info[$value['hardware_id']]['snmp_file_time'] = $snmp_exist_time;
                $new_hardware_info[$value['hardware_id']]['sub_time'] = $sub_snmp_exist_time;
                if($sub_snmp_exist_time > 60){
                    //文件不存在 而且超时进行预设数组的告警并添加
                    if($value['is_middel_server'] == 2){
                        $json_str = $this->empty_ntp_data();
                        $new_hardware_info[$value['hardware_id']]['snmp'] = json_decode($json_str,true);
                        $new_hardware_info[$value['hardware_id']] = $this->ntp_deal($new_hardware_info[$value['hardware_id']]);

                    }else{
                        $json_str = $this->empty_snmp_data();
                        $new_hardware_info[$value['hardware_id']]['snmp'] = json_decode($json_str,true);
                        $new_hardware_info[$value['hardware_id']] = $this->snmp_deal($new_hardware_info[$value['hardware_id']],$ntp_server_data);

                    }

                }else{
                    //文件不存在 但是未超过预设时间
                    if($old_hardware_info){
                        $new_hardware_info[$value['hardware_id']] = $old_hardware_info[$value['hardware_id']];
                    }else{
                        //旧数据不存在 只得预设值
                        if($value['is_middel_server'] == 2){
                            $new_hardware_info[$value['hardware_id']]['snmp'] = json_decode($this->empty_ntp_data(),true);
                            $new_hardware_info[$value['hardware_id']] = $this->ntp_deal($new_hardware_info[$value['hardware_id']]);
                        }else{
                            $new_hardware_info[$value['hardware_id']]['snmp'] = json_decode($this->empty_snmp_data($value['hardware_type_id']),true);
                            $new_hardware_info[$value['hardware_id']] = $this->snmp_deal($new_hardware_info[$value['hardware_id']],$ntp_server_data);

                        }
                    }
                }
            }

        }
        if(!empty($new_hardware_info)){

            //主备多加的判断
            $container_data = array();
            if(!empty($new_hardware_info)){
                foreach ($new_hardware_info as $key => $value) {
                    if($value['server_type'] == 2 && $value['is_middel_server'] == 0){
                        $container_data[$value['kind_group']][] = $value;
                    }
                }

            }
            if($container_data){
                foreach ($container_data as $kk => $vv) {
                    $one_data = $vv[0];
                    $two_data = $vv[1];
                    $new_hardware_info[$one_data['hardware_id']] = $this->compare_is_main($one_data,$two_data,$one_data);
                    $new_hardware_info[$two_data['hardware_id']] = $this->compare_is_main($two_data,$one_data,$two_data);
                }

            }

        }
        setcache('hardware_info_cache',$new_hardware_info); //设备信息的缓存
        $station_list = getcache('cache_all_station');
        $all_stations = array();
        if(!empty($station_list)){
            foreach ($station_list as $key => $st_value) {
                $the_data= $this->Station_model->one_stations_status($st_value,$key,count($station_list)+2);
                $all_stations[$key]  = array_merge($st_value,$the_data);
            }
        }
        //进行缓存
        foreach ($all_stations as $key => $value) {
            $all_stations[$key]['data_upper_limit_A'] = jurge_station_limit(false,$value['channel_time_A'],$value['station_id']);
            $all_stations[$key]['data_upper_limit_B'] = jurge_station_limit(false,$value['channel_time_B'],$value['station_id']);
        }
        //雷达
        $this->Station_model->rader_status();
        $rader_data = $this->Raders_model->select('is_del = 0','id,name,switch,rader_alarm,rader_bag,canvas_x,canvas_y,rader_img,is_monitor,path_switch_a,path_switch_b,path_a_alarm,path_b_alarm,rader_a_bag,rader_b_bag,in_work_option,report_time');
        $all_stations_data = array();
        $all_stations_data['station'] = $all_stations;
        $all_stations_data['rader'] = $rader_data;
        $all_stations_data['hardware_info'] = $new_hardware_info;
        header('Content-Type: text/event-stream');
        header('Cache-Control: no-cache');
        echo "retry:1000\ndata:".json_encode($all_stations_data)."\n\n";
        // echo json_encode($all_stations_data);
    }
    //获取主用ntp服务器的时间
    private function ntp_server_data(){
        $ntp_data = $this->Hardware_model->get_one(array('is_hide'=>0,'is_middel_server'=>2,'is_main'=>1), 'hardware_other_name,is_monitor');
        if(!$ntp_data){
            $new_ntp_data = array();
        }else{
            if($ntp_data['is_monitor']){
                $date_path = date('Ymd');
                $file_path = SNMP_DEAL_PATH.$ntp_data['hardware_other_name'].'/snmpret'.$date_path;
                if(file_exists($file_path)){
                        $fh = fopen($file_path, 'r');
                        $json_str = file_json_lines($fh,'{');
                        if(!$json_str){
                                $json_str = $this->empty_ntp_data();
                        }
                        $new_ntp_data = json_decode($json_str,true);
                        $new_ntp_data['filetime'] = filemtime($file_path);
                        setcache('cache_new_ntp_data',$new_ntp_data);
                }else{
                    //60秒内文件再次生成
                    if(time()-getcache('cache_new_ntp_data')['filetime'] > 60){
                        $new_ntp_data = getcache('cache_new_ntp_data');
                    }else{
                        $new_ntp_data = $this->empty_ntp_data();
                    }
                }
            }else{
                $new_ntp_data = array();
            }
        }
        return $new_ntp_data;
    }
    //设备主备切换的状态
    function app_log_msg($msg_path){
        $fh = fopen($msg_path, 'r');
        $last_line = last_line($fh);
        $data = array();
        //匹配是否是主用
        if(strpos($last_line, 'MAIN')){
            $is_main =1;
        }else{
            $is_main =0;

        }
        return $is_main;
    }
    //sanmp 错误等级解析
    public function snmp_deal($new_hardware_info,$ntp_server_data){
        $snmp_data = $new_hardware_info['snmp'];
        //网口的归属交换机代码
        $agent_array = isset($snmp_data['agentArray'])?$snmp_data['agentArray']:array();
        $error_info = '';
        if(!empty($agent_array)){
            foreach ($agent_array as $key => $value) {
                $belong_eths = $this->Hardware_eth_model->get_one(array('eth_ip'=>$value['ip']));
                if($belong_eths){
                    $eth_type = $belong_eths['eth_type'];
                    $net_type = $belong_eths['net_type'];
                    if($eth_type == 0){
                        if($net_type == 0){
                            $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 9;

                        }elseif($net_type == 1){
                            $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 7;

                        }else{
                            $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 8;

                        }
                    }elseif ($eth_type == 1) {

                        if($net_type == 0){

                        }elseif($net_type == 1){
                            $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 17;

                        }else{
                            $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 18;
                        }

                    }else{
                        if($net_type == 0){

                        }elseif($net_type == 1){
                            $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 19;

                        }else{
                            $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 20;

                        }
                    }
                }else{
                    $new_hardware_info['snmp']['agentArray'][$key]['switch_id'] = 0;

                }

            }
        }
        // print_r($new_hardware_info);exit;
        if($snmp_data['same_times'] > 1){
            $new_hardware_info['error_degree'] = 2;
            $error_info .= '设备挂断,';
        }else{
            if($new_hardware_info['sub_time'] <= 30){
                $agent_error_num = $snmp_data['agentErrorNum'];
                if($agent_error_num == 0){
                    $error_code = 0;
                    //进程
                    $red_error = false;
                    if($snmp_data['forkSwitch']){
                        foreach ($snmp_data['forkArray'] as $key => $value) {
                            // var_dump($value['application']['hearbeatTimeOut']);exit;
                            if($value['fx'] == 0 || $value['count'] >=1  || $value['application']['hearbeatTimeOut'] === false){
                                $red_error = true;
                                break;
                            }elseif($value['fx'] != 0 && $value['count'] ==0  && $value['application']['hearbeatTimeOut'] === true && $value['application']['appStatus'] !='OK'){
                                $error_code++;
                                $error_info .= '进程数据异常,';

                            }
                        }
                    }
                    if($red_error){
                        $error_info .= '设备进程挂断,';
                        $new_hardware_info['error_degree'] = 2;
                    }else{
                        //黄色告警与正常信息的判断 
                        //服务器与gps时钟校验告警
                        if($new_hardware_info['server_type'] == 2){
                            if(!empty($ntp_server_data)){
                                $server_time = $snmp_data['time'];
                                $ntp_server_time = $ntp_server_data['time'];
                                if(abs($server_time - $ntp_server_time) > 60){
                                    $error_code++;
                                    $error_info .= '该服务器时间与ntp时钟服务器的时间误差超过60秒';
                                }
                            }
                        }
                        
                        $agent_array = $snmp_data['agentArray'];
                        if(!empty($agent_array)){
                            foreach ($agent_array as $key => $value) {

                                if($value['switch'] != 1 || $value['fx'] == 0){
                                    $error_code++;
                                    $error_info .= '网口'.$value['name'].'出现异常,';

                                }
                            }
                        }else{
                            $error_code++;
                            $error_info .= '网口信息获取失败,';

                        }
                        
                        
                        $hardware_alert = $this->System_alert_info_model->get_one(array('id'=>1));
                        //cpu
                        $cpu_data = $snmp_data['cpu'];
                        if($cpu_data <0){
                            $error_info .= 'cpu信息获取失败,';

                            $error_code++;
                        }elseif($cpu_data > $hardware_alert['cpu_alert_value']){
                            $error_info .= 'cpu使用超过'. $hardware_alert['cpu_alert_value'] .'%;';
                            $error_code++;
                        }

                        //内存 磁盘
                        if($snmp_data['partSwitch']){
                            $memory_data = $snmp_data['diskArray'][0];
                            $mem_percent = $memory_data['use']/$memory_data['total'];

                            if($memory_data['fx']==0 || $memory_data['use'] < 0 || $memory_data['total'] <0){
                                $error_info .= '内存信息获取异常,';
                                $error_code++;
                            }elseif($mem_percent > ($hardware_alert['memory_alert_value']/100)){
                                $error_info .= '内存使用超过'.($hardware_alert['memory_alert_value']/100).'%;';
                                $error_code++;

                            }

                            foreach ($snmp_data['diskArray'] as $key => $value) {
                                if($key == 0 ){
                                    continue;
                                }else{
                                    if($value['fx']==0 || $value['use'] < 0 || $value['total'] <0){
                                        $error_code++;
                                        $error_info .= '磁盘信息获取异常,';

                                    }elseif(($value['use']/$value['total']) > ($hardware_alert['disk_alert_value']/100)){
                                        $error_code++;
                                        $error_info .= $value['name'].'磁盘使用超过'.($hardware_alert['disk_alert_value']/100).'%;';
                                    }
                                }
                            }
                        }

                        if($error_code >0){
                            $new_hardware_info['error_degree'] = 1;
                            // $new_hardware_info['fork_die'] = false;

                        }else{
                            $new_hardware_info['error_degree'] = 0;
                            // $new_hardware_info['fork_die'] = false;
                            if($new_hardware_info['sound_switch'] == 0){
                                // @$this->Hardware_model->update(array('sound_switch'=>1),array('hardware_id'=>$new_hardware_info['hardware_id']));
                            }
                            $new_hardware_info['sound_switch'] = 1;
                        }
                    }

                }else{
                    $new_hardware_info['error_degree'] = $agent_error_num>=3?2:1;
                    // $new_hardware_info['fork_die'] = false;
                    if($agent_error_num >= 3){
                        $error_info .= 'ABS三网不通,';
                    }

                }
            }else{
                //监控程序挂断
                $new_hardware_info['error_degree'] = 2;
                // $new_hardware_info['fork_die'] = false;
                $error_info .= 'snmp监控程序挂断,';

            }
        }

        $error_info = rtrim($error_info,',');
        $new_hardware_info['error_info'] = $error_info;
        return $new_hardware_info;
    }
    //时钟服务器的错误等级解析
    public function ntp_deal($new_hardware_info){
        $snmp_data = $new_hardware_info['snmp'];
        $error_info = '';
        $error_code = 0;
        if($snmp_data['same_times'] > 1){
            $error_info .= '服务器ping不通,网络异常';
            $error_code = 2;
        }
        
        if($snmp_data['runningType'] != $new_hardware_info['is_main']){
            $new_hardware_info['is_main'] = $snmp_data['runningType'];
            $this->Hardware_model->update(array('is_main'=>$snmp_data['runningType']),array('hardware_id'=>$new_hardware_info['hardware_id']));
        }
        $error_info = rtrim($error_info,',');
        $new_hardware_info['error_degree'] = $error_code;
        $new_hardware_info['error_info'] = $error_info;
        return $new_hardware_info;
    }
    //ping包结果
    function ping_result(){
        $ping_fopen = fopen(PING_HARDWARE_FELE, 'r');
        $ping_last_line = last_line($ping_fopen);
        $line_time_site = strrpos($ping_last_line, ':');
        $line_time = substr($ping_last_line, 0,$line_time_site);
        $check_hardware_id = array();
        $data_apear = array();
        $eth_hardware_id = array();
        $merge_data = array();

        if($line_time){
            if(time()-strtotime($line_time) < 10){
                //进行读取

                $ip_str = trim(substr($ping_last_line, $line_time_site+1));
                $ip_arr = explode(' ', $ip_str);
                //进行末位的ip出现次数检查
                // var_dump($ip_arr);exit;
                $ip_count = array();
                foreach ($ip_arr as $key => $value) {
                    $last_count = 0;
                    $tmp_str1_site = strrpos($value,'.');
                    $tmp_str1 = substr($value, $tmp_str1_site);
                    foreach ($ip_arr as $kk => $vv) {
                        $tmp_str2_site = strrpos($vv,'.');
                        $tmp_str2 = substr($vv, $tmp_str2_site);
                        if($tmp_str1 == $tmp_str2){
                            $last_count++;
                        }

                    }
                    //进行次数的匹配
                    $eth_hardware_id = $this->Hardware_eth_model->get_one(array('eth_ip'=>$value),'hardware_id,eth_num');
                    if($eth_hardware_id){
                        // $ip_count[$eth_hardware_id['hardware_id']] = $last_count;
                        $merge_data[$key]['hardware_id'] = $eth_hardware_id['hardware_id'];
                        $merge_data[$key]['eth_num'] = $eth_hardware_id['eth_num'];
                        $merge_data[$key]['ip_count'] = $last_count;
                    }
                }

            }
        }
        // print_r($merge_data);exit;
        return $merge_data;
    }

    function compare_is_main($one_data,$two_data,$new_hardware_info){
        $one_flag = false;
        $two_flag = false;

        $one_flag = $this->snmp_time_jurge($one_data,$one_flag);
        $two_flag = $this->snmp_time_jurge($two_data,$two_flag);

        if($one_flag && $two_flag ){

            $one_is_main = $this->snmp_main_jurge($one_data);
            $two_is_main = $this->snmp_main_jurge($two_data);
            // var_dump($one_is_main);var_dump($two_is_main);exit;
            $new_hardware_info['is_main'] = $one_is_main;
            // $new_hardware_info['is_main'] = $two_is_main;

            @$this->Hardware_model->update(array('is_main'=>$one_is_main),array('hardware_id'=>$one_data['hardware_id']));
            @$this->Hardware_model->update(array('is_main'=>$two_is_main),array('hardware_id'=>$two_data['hardware_id']));

        }elseif($one_flag && !$two_flag){
            $one_is_main = $this->snmp_main_jurge($one_data);
            if($one_is_main == 1){
                $one_is_main = 1;
                $two_is_main = 0;
            }else{
                $one_is_main = 0;
                $two_is_main = 1;
            }


            $new_hardware_info['is_main'] = $one_is_main;
            // $new_hardware_info['is_main'] = $two_is_main;


            @$this->Hardware_model->update(array('is_main'=>$one_is_main),array('hardware_id'=>$one_data['hardware_id']));
            @$this->Hardware_model->update(array('is_main'=>$two_is_main),array('hardware_id'=>$two_data['hardware_id']));

        }elseif(!$one_flag && $two_flag){
            $two_is_main = $this->snmp_main_jurge($two_data);

            if($two_is_main == 1){
                $one_is_main = 0;
                $two_is_main = 1;
            }else{
                $one_is_main = 1;
                $two_is_main = 0;
            }


            $new_hardware_info['is_main'] = $one_is_main;
            // $new_hardware_info['is_main'] = $two_is_main;

            @$this->Hardware_model->update(array('is_main'=>$one_is_main),array('hardware_id'=>$one_data['hardware_id']));
            @$this->Hardware_model->update(array('is_main'=>$two_is_main),array('hardware_id'=>$two_data['hardware_id']));
        }

        return $new_hardware_info;
    }

    function snmp_time_jurge($one_data,$one_flag){
        if(isset($one_data['sub_time']) && $one_data['sub_time']< 30){
            if($one_data['snmp']['forkSwitch'] == 1){
                $snmp_fork = $one_data['snmp']['forkArray'];
                if(isset($snmp_fork[1])){
                    $main_jurge = $snmp_fork[1];
                }else{
                    $main_jurge = $snmp_fork[0];
                }

                if(is_numeric($main_jurge['application']['appInterval']) && $main_jurge['application']['appInterval'] <30){
                    $one_flag = true;
                }
            }
        }
        return $one_flag;
    }

    function snmp_main_jurge($one_data){
        $one_forkArray = $one_data['snmp']['forkArray'];

        if(isset($one_forkArray[1])){
            $one_main_jurge = $one_forkArray[1]['application'];
        }else{
            $one_main_jurge = $one_forkArray[0]['application'];
        }
        if($one_main_jurge['appRunType'] != 'SLAVE'){
            $one_is_main = 1;
        }else{
            $one_is_main = 0;
        }
        return $one_is_main;
    }
    //topo图的报警信息的日志记录
    private function hardware_log($hardware_id,$fault_name='',$fault_value,$fault_content,$fault_type){
        $log_data = array();
        $log_data['hardware_id'] = $hardware_id;
        $log_data['fault_name'] = $fault_name;
        $log_data['fault_value'] = $fault_value;
        $log_data['fault_content'] = $fault_content;
        $log_data['fault_type'] = $fault_type;
        $log_data['dateline'] = time();
        // var_dump($log_data);
        // $this->Hardware_fault_logs_model->insert($log_data);

    }


    public function one_hardware_detail($hardware_id,$page_no=1){
        /*$old_hardware_info = getcache('hardware_info_cache');
        //获取该设备的信息
        $ntp_server_data = $this->ntp_server_data();
        if(!$old_hardware_info){
            $this->showmessage('请先进行缓存');exit;
        }
        if(!isset($old_hardware_info[$hardware_id])){
            $this->showmessage('设备暂时未监控');exit;
        }*/
        //是否监控状态下
        $is_monitor = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id),'is_monitor');
        if($is_monitor['is_monitor'] == 0){
            $this->showmessage('设备暂时未监控');exit;
        }
        /*if(getcache("cache_one_hardware_info_$hardware_id") && isset(getcache("cache_one_hardware_info_$hardware_id")['snmp'])){
            $the_hardware_info = getcache("cache_one_hardware_info_$hardware_id");
        }else{
            $the_hardware_info = $old_hardware_info[$hardware_id];
        }*/
        $the_hardware_info = $this->timing_hardware_data($hardware_id);

        if(isset($the_hardware_info['is_main'])){
            //进行数据
            $this->Hardware_model->update(array('is_main'=>$the_hardware_info['is_main']),array('hardware_id'=>$hardware_id));
        }
        // print_r($the_hardware_info);exit;
        if($the_hardware_info['server_type'] == 2){
            $is_main_limit = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id,'is_middel_server'=>0),'is_main');
        }else{
            $is_main_limit = array();
        }
        //进行监控进程的获取app_id
        $snmp_arr = $the_hardware_info['snmp'];
        if(!$snmp_arr){
            $this->showmessage('snmp程序暂未运行');
        }
        if(isset($snmp_arr['forkArray'])){
            foreach ($snmp_arr['forkArray'] as $key => $value) {
                $app_id = $this->App_model->get_one(array('program_name'=>$value['name']),'app_id');
                if($app_id){
                    $the_hardware_info['snmp']['forkArray'][$key]['app_id'] = $app_id['app_id'];
                }else{
                    $the_hardware_info['snmp']['forkArray'][$key]['app_id'] = 0;
                }
            }
        }
        /*if(empty($the_hardware_infontp_server_data)){
            $ntp_time = -1;
        }else{
            $ntp_time = $ntp_server_data['time'];
        }
        $ntp_server_subtime = abs($the_hardware_info['snmp']['time'] - $ntp_time);
        $ntp_status_info = '';
        if($ntp_time > 0 && $ntp_server_subtime > 60){
            $ntp_warning = true;
            $ntp_status_info = '异常';
        }elseif($ntp_time > 0 && $ntp_server_subtime < 60 ){
            $ntp_warning = false;
            $ntp_status_info = '正常';
        }else{
            $ntp_warning = false;
            $ntp_status_info = 'ntp服务器信息不存在或则未处于监控状态';
        }*/

        $hardware_alert = $this->System_alert_info_model->get_one(array('id'=>1));
        $the_hardware_info['hardware_alert'] = $hardware_alert;
        //应用进程的日志

        $this->view('one_hardware_detail', array('require_js' => true,'data_list'=>$the_hardware_info,'ntp_time'=>$the_hardware_info['ntp_time'],'ntp_server_subtime'=>$the_hardware_info['ntp_server_subtime'],'ntp_warning'=>$the_hardware_info['ntp_warning'],'ntp_status_info'=>$the_hardware_info['ntp_status_info'],'hardware_id'=>$hardware_id,'is_main_limit'=>$is_main_limit,'search_warning'=>false));
    }
    //时钟服务器详情
    public function one_ntp_detail($hardware_id){
       /* $old_hardware_info = getcache('hardware_info_cache');
        //获取该设备的信息
        if(!$old_hardware_info){
            $this->showmessage('请先进行缓存');exit;
        
}        if(!isset($old_hardware_info[$hardware_id])){
            $this->showmessage('设备暂时未监控');exit;
        }*/
        //是否监控状态下
        $is_monitor = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id),'is_monitor');
        if($is_monitor['is_monitor'] == 0){
            $this->showmessage('设备暂时未监控');exit;
        }

        /*if(getcache("cache_one_hardware_info_$hardware_id") && isset(getcache("cache_one_hardware_info_$hardware_id")['snmp'])){
            $the_hardware_info = getcache("cache_one_hardware_info_$hardware_id");
        }else{
            $the_hardware_info = $old_hardware_info[$hardware_id];
        }*/
        $the_hardware_info = $this->timing_hardware_data($hardware_id);

        $this->view('one_ntp_detail', array('require_js' => true,'data_list'=>$the_hardware_info,'hardware_id'=>$hardware_id));

    }
    //读取数据上线文件的
    private function data_log_files($path_basic,$start_time_stamp,$end_time_stamp){
        //1先判断文件存不存  2文件超时与否 3是否是写完 4是否告警
        $sub_time = $end_time_stamp-$start_time_stamp;
        //几天的间隔
        $sub_day = floor($sub_time/(24*60*60));
        $data_list = array();
        $j = 0;
        for($i=0; $i <= $sub_day; $i++) {
            $file_day = date('Ymd',$start_time_stamp+$i*60*60*24);
            $path = SYSLOG_PATH.$path_basic[0]['hardware_other_name'].'/'.$path_basic[0]['program_name'].'_'.$file_day.'.log';
            // var_dump($path);exit;
            if(file_exists($path)){
                $file_open = fopen($path,'r');
                while (!feof($file_open)) {
                    //逐行读取文件内容
                    $tmp_str = fgets($file_open);
                    $tmp_time = substr($tmp_str,0,14);
                    $read_time = strtotime($tmp_time);
                    if($read_time){
                        if($read_time >=$start_time_stamp && $read_time <=$end_time_stamp){
                            $data_list[$j]['dateline'] = date('Y-m-d H:i:s',$read_time);
                            $err_site = strpos($tmp_str,'.[');
                            $err_kind = substr($tmp_str, $err_site-1,1);
                            $err_info = substr($tmp_str,$err_site+1);
                            $data_list[$j]['err_kind'] = $err_kind;
                            $data_list[$j]['err_info'] = $err_info;
                            $j++;
                        }
                    }
                }

                fclose($file_open);
            }else{
                continue;
            }

        }
        return $data_list;
    }

    public function timing_hardware_detail($hardware_id){

        
        $new_hardware_info = $this->timing_hardware_data($hardware_id);
        // setcache("cache_one_hardware_info_$hardware_id",$new_hardware_info);
        //进行文件的解析
        echo json_encode($new_hardware_info);

    }

    private function timing_hardware_data($hardware_id){
        $hardware_id = intval($hardware_id);
        $tmp_arr = $this->Hardware_model->tables_select(array('is_hide'=>0,'t_sys_hardware.hardware_id'=>$hardware_id), 't_sys_hardware.hardware_id,hardware_name,hardware_type_id,img_dir,canvas_x,canvas_y,is_accetive,to_notes,is_middel_server,hardware_other_name,is_main,kind_group,alarm_status,sound_switch');
        $one_hardware_arr = $tmp_arr[0];
        $date_path = date('Ymd');  //读今天的数据
        if($one_hardware_arr['hardware_type_id'] == 2){
            //进行对立服务器的信息查找\
            if($one_hardware_arr['is_middel_server'] != 2){
                $other_hardware_info = $this->Hardware_model->tables_select(array('is_hide'=>0,'kind_group'=>$one_hardware_arr['kind_group']),'t_sys_hardware.hardware_id,hardware_type_id,hardware_name,hardware_type_id,is_middel_server,hardware_other_name,is_main,kind_group,alarm_status,sound_switch');
                $other_hardware_info = $other_hardware_info[0];
                // print_r($other_hardware_info);exit;
                $old_other_hardware_cache =  getcache('cache_one_hardware_info_\''.$other_hardware_info['hardware_id'].'\'');
                $other_file_path = SNMP_DEAL_PATH.$other_hardware_info['hardware_other_name'].'/snmpret'.$date_path;
                // $other_msg_path = APP_LOG_PATH.$other_hardware_info['hardware_other_name'].$other_hardware_info['program_name'].$date_path;
                $other_new_hardware_info =  $this->one_hardware_snmp($other_file_path,$old_other_hardware_cache,$other_hardware_info);
            }

        }
        $old_one_hardware_info = getcache("cache_one_hardware_info_$hardware_id");
        $file_path = SNMP_DEAL_PATH.$one_hardware_arr['hardware_other_name'].'/snmpret'.$date_path;
        $new_hardware_info = $this->one_hardware_snmp($file_path,$old_one_hardware_info,$one_hardware_arr);
        $ntp_server_data = $this->ntp_server_data();

        // if($one_hardware_arr['hardware_type_id'] == 2){
            if($one_hardware_arr['is_middel_server'] != 2){
                $new_hardware_info = $this->snmp_deal($new_hardware_info,$ntp_server_data);
            }else{
                $new_hardware_info = $this->ntp_deal($new_hardware_info);
            }
        // }
        if(empty($ntp_server_data)){
            $ntp_time = -1;
        }else{
            $ntp_time = $ntp_server_data['time'];
        }
        $ntp_server_subtime = abs($new_hardware_info['snmp']['time'] - $ntp_time);
        $ntp_status_info = '';
        $new_hardware_info['ntp_time'] = $ntp_time;
        $new_hardware_info['ntp_server_subtime'] = $ntp_server_subtime;
        if($ntp_time > 0 && $ntp_server_subtime > 60){
            $new_hardware_info['ntp_warning'] = true;
            $new_hardware_info['ntp_status_info'] = '异常';
        }elseif($ntp_time > 0 && $ntp_server_subtime < 60 ){
            $new_hardware_info['ntp_warning'] = false;
            $new_hardware_info['ntp_status_info'] = '正常';
        }else{
            $new_hardware_info['ntp_warning'] = false;
            $new_hardware_info['ntp_status_info'] = 'ntp服务器信息不存在或则未处于监控状态';
        }
        if($one_hardware_arr['hardware_type_id'] == 2 && $one_hardware_arr['is_middel_server'] == 0){
            $new_hardware_info = $this->compare_is_main($new_hardware_info,$other_new_hardware_info,$new_hardware_info);
        }


        if(isset($snmp_arr['forkArray'])){
            foreach ($snmp_arr['forkArray'] as $key => $value) {
                $app_id = $this->App_model->get_one(array('program_name'=>$value['name']),'app_id');
                $new_hardware_info['snmp']['forkArray'][$key]['app_id'] = $app_id['app_id'];
            }
        }
        return $new_hardware_info;
    }

    function one_hardware_snmp($file_path,$old_one_hardware_info,$one_hardware_arr){
        $new_hardware_info = array();
        $new_hardware_info['hardware_id'] = $one_hardware_arr['hardware_id'];
        $new_hardware_info['server_type'] = $one_hardware_arr['hardware_type_id'];
        $new_hardware_info['hardware_name'] = $one_hardware_arr['hardware_name'];
        $new_hardware_info['is_main'] = $one_hardware_arr['is_main'];
        $new_hardware_info['sound_switch'] = $one_hardware_arr['sound_switch'];
        $new_hardware_info['is_middel_server'] = $one_hardware_arr['is_middel_server'];
        if(file_exists($file_path)){
            if($old_one_hardware_info){
                //比较两次的文件修改时间
                if($old_one_hardware_info['snmp_file_time'] == filemtime($file_path)){
                    //未更新  不操作 
                    $new_hardware_info = $old_one_hardware_info;
                    //判断主备消息的更新
                    $new_hardware_info['sub_time'] = time()-filemtime($file_path);
                }else{
                    //
                    $fh = fopen($file_path, 'r');
                    $json_str = file_json_lines($fh,'{');
                    $new_hardware_info['snmp_file_time'] = filemtime($file_path);
                    $new_hardware_info['sub_time'] = time()-filemtime($file_path);
                    if(!$json_str){
                        if($one_hardware_arr['is_middel_server'] == 2){
                            $json_str = $this->empty_ntp_data();
                        }else{
                            $json_str = $this->empty_snmp_data($one_hardware_arr['hardware_type_id']);
                        }
                    }
                    $new_hardware_info['snmp'] = json_decode($json_str,true);

                }
            }else{
                $fh = fopen($file_path, 'r');
                $json_str = file_json_lines($fh,'{');
                $new_hardware_info['snmp_file_time'] = filemtime($file_path);
                $new_hardware_info['sub_time'] = time()-filemtime($file_path);
                if(!$json_str){
                    if($one_hardware_arr['is_middel_server'] == 2){
                        $json_str = $this->empty_ntp_data();
                    }else{
                        $json_str = $this->empty_snmp_data($one_hardware_arr['hardware_type_id']);
                    }
                }

                $new_hardware_info['snmp'] = json_decode($json_str,true);

            }

        }else{
//          continue; 进行告警或则获取缓存
            $snmp_exist_time = getcache('not_exist_snmptime'.$one_hardware_arr['hardware_id']);
            if($snmp_exist_time){

            }else{
                $snmp_exist_time = strtotime(date('Y-m-d 00:00:00',time()));
                setcache('not_exist_snmptime'.$one_hardware_arr['hardware_id'],$snmp_exist_time);
            }

            $sub_snmp_exist_time = time()-$snmp_exist_time;
            $new_hardware_info['snmp_file_time'] = $snmp_exist_time;
            $new_hardware_info['sub_time'] = $sub_snmp_exist_time;
            if($sub_snmp_exist_time > 60){
                //文件不存在 而且超时进行预设数组的告警并添加
                if($one_hardware_arr['is_middel_server'] == 2){
                    $json_str = $this->empty_ntp_data();
                }else{
                    $json_str = $this->empty_snmp_data($one_hardware_arr['hardware_type_id']);
                }
            }else{
                //文件不存在 但是未超过预设时间
                if($old_one_hardware_info){
                    $new_hardware_info = $old_one_hardware_info;
                }else{
                    //旧数据不存在 只得预设值
                    if($one_hardware_arr['is_middel_server'] == 2){
                        $json_str = $this->empty_ntp_data();
                    }else{
                        $json_str = $this->empty_snmp_data($one_hardware_arr['hardware_type_id']);
                    }

                }
            }
            $new_hardware_info['snmp'] = json_decode($json_str,true);


        }
        return $new_hardware_info ;
    }
    //主备切换
    public function shift_main($hardware_id,$is_main){
        $hardware_id = intval($hardware_id);
        $this_server = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id),'hardware_name,hardware_other_name');
        if(!$this_server){
            //参数错误
            echo -1;exit;
        }
        $is_main = intval($is_main);
        //程序名
        $app_name = $this->App_model->get_one("find_in_set($hardware_id,`hardware_id`)!=0",'program_name');

        if($is_main == 1){
            $maink_kind = 'MAIN';
        }else{
            $maink_kind = 'SLAVE';
        }
        if($app_name){
            $msg = '<MSG TYPE="17" MODULENAME=\''.$this_server['hardware_other_name'].'\' APPNAME=\''.$app_name['program_name'].'\' COMMAND="'.$maink_kind.'"  CHANGEDTYPE="1"  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
            $res = send_udp(SYSTEMSENDIP, SYSTEMSENDPORT,$msg,0);
        }else{
            $res = -1;
        }
        $operation_data= $this->operation_data;
        $operation_data['dateline'] = time();

        if($is_main == 1){
            $operation_data['operate_explain'] = '将服务器'.$this_server['hardware_name'].'切换至主用状态';
        }else{
            $operation_data['operate_explain'] = '将服务器'.$this_server['hardware_name'].'切换至备用状态';
        }
        if($res == 1){
            $operation_data['is_success'] = 2;
            $operation_data['status_explain'] = '操作成功并等待状态改变';

        }elseif($res == -1){
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '未找到相应的应用程序';
        }elseif ($res == 0) {
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '消息发送失败';
        }
        //日志记录
        @$this->operationLogs($operation_data);
        echo $res;
    }
    //应用程序操作
    public function change_msg_confirm(){
        $app_id = $this->input->post('app_id');
        $msg_kind = $this->input->post('msg_kind');
        $hardware_id = $this->input->post('hardware_id');
        if(!$app_id || !$msg_kind || !$hardware_id){
            echo json_encode(array('status'=>FALSE,'tips'=>'参数错误'));exit;
        }
        $app_info = $this->App_model->get_one(array('app_id'=>$app_id),'program_name');
        $hardware_info = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id),'hardware_other_name,hardware_name');
        $app_data = array_merge($app_info,$hardware_info);
        if($msg_kind == 1){  //启动
            $msg = '<MSG TYPE="2" MODULENAME=\''.$app_data['hardware_other_name'].'\' APPNAME=\''.$app_data['program_name'].'\' FULLPATH="" CONFIGFILEPATH=""  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
            // echo $msg;exit;
        }elseif($msg_kind == 2) //关闭
        {
            $msg = '<MSG TYPE="3" MODULENAME=\''.$app_data['hardware_other_name'].'\' APPNAME=\''.$app_data['program_name'].'\' FULLPATH="" CONFIGFILEPATH=""  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
        }
        elseif ($msg_kind == 3) { //重启
            $msg = '<MSG TYPE="4" MODULENAME=\''.$app_data['hardware_other_name'].'\' APPNAME=\''.$app_data['program_name'].'\' FULLPATH="" CONFIGFILEPATH=""  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
        }
        $res= send_udp(SYSTEMSENDIP, SYSTEMSENDPORT,$msg,0);
        $operation_data= $this->operation_data;
        $operation_data['dateline'] = time();

        if($msg_kind == 1){
            $operation_data['operate_explain'] = '启动服务器'.$app_data['hardware_name'].'的进程'.$app_data['program_name'];
        }elseif($msg_kind == 2){
            $operation_data['operate_explain'] = '关闭服务器'.$app_data['hardware_name'].'的进程'.$app_data['program_name'];
        }else {
            $operation_data['operate_explain'] = '重启服务器'.$app_data['hardware_name'].'的进程'.$app_data['program_name'];
        }
        if($res == 1){
            $operation_data['is_success'] = 2;
            $operation_data['status_explain'] = '操作成功并等待状态改变';
            @$this->operationLogs($operation_data);
            echo json_encode(array('status'=>true,'tips'=>'操作成功'));exit;

        }elseif($res == -1){
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '应用程序不存在';
            @$this->operationLogs($operation_data);
            echo json_encode(array('status'=>FALSE,'tips'=>'应用程序不存在'));exit;

        }elseif ($res == 0) {
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '消息发送失败';
            @$this->operationLogs($operation_data);
            echo json_encode(array('status'=>false,'tips'=>'socket消息发送失败'));exit;

        }
    }
    //设备的关机 重启
    public function use_server($hardware_id,$use_kind){
        $hardware_name = $this->input->post('hardware_name');
        $ip_info = $this->Hardware_eth_model->tables_select(array('t_sys_hardware_eth.hardware_id'=>$hardware_id,'eth_type'=>0,'net_type'=>0),'eth_ip');
        if($ip_info){
            $ip_add = $ip_info[0]['eth_ip'];
            if($use_kind == 1){
                exec(POWER_FILE.' '.$ip_add,$a,$status);
                if($status != 255){
                    $res = 0;
                }else {
                    $res = 1;
                }
            }else{
                exec(REBOOT_FILE.' '.$ip_add,$a,$status);
                if($status != 255){
                    $res = 0;
                }else {
                    $res = 1;
                }
            }

        }else{
            $res = -1;
        }
        $operation_data= $this->operation_data;
        $operation_data['dateline'] = time();
        if($use_kind == 1){
            $operation_data['operate_explain'] = '进行服务器'.$hardware_name.'关机';
        }else {
            $operation_data['operate_explain'] = '进行服务器'.$hardware_name.'重启';
        }
        if($res == 1){
            $operation_data['is_success'] = 2;
            $operation_data['status_explain'] = '操作成功并等待状态改变';
            @$this->operationLogs($operation_data);
            echo json_encode(array('status'=>true,'tips'=>'操作成功'));exit;

        }elseif($res == -1){
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '网口ip不存在';
            @$this->operationLogs($operation_data);
            echo json_encode(array('status'=>FALSE,'tips'=>'网口ip不存在'));exit;

        }elseif ($res == 0) {
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '脚本执行失败';
            @$this->operationLogs($operation_data);
            echo json_encode(array('status'=>false,'tips'=>'脚本执行失败'));exit;
        }

    }
    //业务关系图
    public function hardware_relation(){
        $data_list = $this->Hardware_relations_model->select(); //全部设备的调用
        //进行主用切换

        if(empty($data_list)){
            $this->showmessage('暂未添加设备');exit;
        }
        $this->view('hardware_relation', array('require_js' => true,'data_list'=>json_encode($data_list)));
    }

    //告警声音关闭
    public function sound_alarm_switch_off($id,$val,$kind){
        if($kind == 0){
            $model = $this ->Hardware_model;
            $find_cond = array('hardware_id'=>$id);
        }elseif($kind == 1){
            $model = $this->Station_model;
            $find_cond = array('station_id'=>$id);
        }else{
            $model = $this->Raders_model;
            $find_cond = array('id'=>$id);
        }
        $one_info = $model->get_one($find_cond,'sound_switch');
        if($one_info){
            $res = $model->update(array('sound_switch'=>$val),$find_cond);
            if($res){
                $this->_cache_hardware();
                $this->Station_model->_cache_station();
                echo json_encode(array('status'=>true,'tips'=>'操作成功'));exit;
            }else{
                json_encode(array('status'=>false,'tips'=>'操作失败'));
            }

        }else{
            echo json_encode(array('status'=>false,'tips'=>'操作失败'));
        }
    }
    /*    function sound_alarm_switch_off($hardware_id){
            $one_hardware_info = $this->Hardware_model->get_one(array('hardware_id'=>$hardware_id),'sound_switch');
            if($one_hardware_info){
                    $res = $this->Hardware_model->update(array('sound_switch'=>0),array('hardware_id'=>$hardware_id));
                    if($res){
                        echo json_encode(array('status'=>true,'tips'=>'操作成功'));
                        $this->_cache_hardware();
                    }else{
                        json_encode(array('status'=>false,'tips'=>'操作失败'));
                    }

            }else{
                echo json_encode(array('status'=>false,'tips'=>'操作失败'));
            }
        }*/


    //数据站的读取与检查
    private function xml_read_jurge($station_num_file,$data){
        $station_num_data = array();
        if(file_exists($station_num_file)){
            // var_dump(time()-filemtime($station_num_file));exit;
            if(time()-filemtime($station_num_file)>30){
                $station_num_data['alarm_status'] = 1;
            }else{
                $fh = fopen($station_num_file, 'r');
                $line_arr = lline_tail($fh);
                $a_error = 0;
                $b_error = 0;
                foreach ($line_arr as $key => $value) {
                    $line_arr[$key] = trim(strip_tags($value));
                }
                $line_arr = array_values(array_filter($line_arr));
                if($line_arr[17] == 'Master'){
                    $station_num_data['current_work_pass'] =  1;
                }else{
                    $station_num_data['current_work_pass'] =  2;
                }
                if(in_array('ERROR', $line_arr) || in_array('bad', $line_arr)){
                    $station_num_data['alarm_status'] = 1;
                    $station_num_data['station_img'] = 'station2.png';
                }else{
                    $station_num_data['alarm_status'] = 0;
                    $station_num_data['station_img'] = 'station1.png';

                }
                setcache('station_line_arr',$line_arr);
            }
        }else{
            $station_num_data['alarm_status'] = 1;
            $station_num_data['station_img'] = 'station2.png';

        }

        if($station_num_data['alarm_status'] != $data['alarm_status']){
            $res = $this->Station_model->update($station_num_data,array('station_id'=>$data['station_id']));


            // echo $this->Station_model->last_query();exit;
        }
        // return $station_num_data;

    }

    //返回空的snmp的数据
    private function empty_snmp_data($server_type=2){
        if($server_type == 2){
            $json_data  =  '{"serverName":   "",
                "ip":   "",
                "time": 0,
                "same_times":   99,
                "agentErrorNum":    3,
                "agentArray":   [{
                        "name": "eno1",
                        "fx":   0,
                        "switch":   1,
                        "inNum":    "0M",
                        "inDiscarded":  "0B",
                        "inError":  "0B",
                        "outNum":   "0M",
                        "outDiscarded": "0B",
                        "outError": "0B",
                        "ip":   "",
                        "pingInvertal": 0
                    }],
                "forkSwitch":   1,
                "forkArray":    [{
                        "name": "",
                        "count":    0,
                        "id":   0,
                        "fx":   0,
                        "path": "",
                        "cpu":  -1,
                        "mem":  -1,
                        "application":  {
                            "appStatus":    "NO",
                            "appAlertContent":  "",
                            "appRunType":   "",
                            "appReportTime":    "0-0-0 0:0:0",
                            "appItemContent":   "",
                            "appInterval":  -1,
                            "hearbeatTimeOut":  false
                        }
                    }],
                "partSwitch":   1,
                "diskArray":    [{
                        "name": "Memory_Size",
                        "fx":   0,
                        "use":  -1,
                        "total":    -1
                    }, {
                        "name": "root_space",
                        "fx":   0,
                        "use":  -1,
                        "total":    -1
                    }, {
                        "name": "Swap_space",
                        "fx":   0,
                        "use":  -1,
                        "total":    -1
                    }, {
                        "name": "Home_space",
                        "fx":   0,
                        "use":  -1,
                        "total":    -1
                    }],
                "cpu":  -1
            }';
        }elseif($server_type == 1){
            $json_data  =  '{"serverName":   "",
                "ip":   "",
                "time": 0,
                "same_times":   99,
                "agentErrorNum":    3,
                "agentArray":   [{
                        "name": "eno1",
                        "fx":   0,
                        "switch":   1,
                        "inNum":    "0M",
                        "inDiscarded":  "0B",
                        "inError":  "0B",
                        "outNum":   "0M",
                        "outDiscarded": "0B",
                        "outError": "0B",
                        "ip":   "",
                        "pingInvertal": 0
                    }],
                "forkSwitch":   0,
                "partSwitch":   0,
                "cpu":  -1
            }';
        }

        return $json_data;
    }
    //返回空的ntp的数据
    private function empty_ntp_data(){
        $data = '{
                        "serverName":   "",
                        "ip":   "",
                        "time": 0,
                        "same_times":   2,
                        "agentErrorNum":0,
                        "runningType":0,
                        "forkSwitch":   0,
                        "partSwitch":   0
                }';
        return $data;

    }
}