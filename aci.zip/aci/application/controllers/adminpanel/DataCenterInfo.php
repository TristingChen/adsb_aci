<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class DataCenterInfo extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('DataCenterInfo_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  data_center_name like '%{$keyword}%'";
        }

        $where = implode('and',$where_arr);
        $data_list = $this->DataCenterInfo_model->listinfo($where,'*',$orderby , $page_no, $this->DataCenterInfo_model->page_size,'',$this->DataCenterInfo_model->page_size,page_list_url('adminpanel/dataExport/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->DataCenterInfo_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['data_center_name'] = isset($_POST["data_center_name"])?trim(safe_replace($_POST["data_center_name"])):'';
            if($_arr['data_center_name']=='')exit(json_encode(array('status'=>false,'tips'=>'数据中心名称不得为空')));

            $_arr['level'] = isset($_POST["level"])?trim(safe_replace($_POST["level"])):'';
            if($_arr['level']=='')exit(json_encode(array('status'=>false,'tips'=>'系统级别不得为空')));
            
            $_arr['place'] = isset($_POST["place"])?trim(safe_replace($_POST["place"])):'';
            if($_arr['place']=='')exit(json_encode(array('status'=>false,'tips'=>'数据中心所在位置不得为空')));

            $_arr['sac'] = isset($_POST["sac"])?trim(safe_replace($_POST["sac"])):'';
            if($_arr['sac']=='')exit(json_encode(array('status'=>false,'tips'=>'sac码不得为空')));
            $_arr['sic'] = isset($_POST["sic"])?trim(safe_replace($_POST["sic"])):'';
            if($_arr['sic']=='')exit(json_encode(array('status'=>false,'tips'=>'sic码不得为空')));
            $_arr['lat'] = isset($_POST["lat"])?trim(safe_replace($_POST["lat"])):'';
            if($_arr['lat']=='')exit(json_encode(array('status'=>false,'tips'=>'纬度不得为空')));
            $_arr['lon'] = isset($_POST["lon"])?trim(safe_replace($_POST["lon"])):'';
            if($_arr['lon']=='')exit(json_encode(array('status'=>false,'tips'=>'经度不得为空')));
            $_arr['height'] = $this->input->post('height')?$this->input->post('height'):exit(json_encode(array('status'=>false,'tips'=>'高度不得为空')));
            $_arr['dateline'] = time();   
            $new_id = $this->DataCenterInfo_model->insert($_arr);
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_list'=>$this->DataCenterInfo_model->default_info()));
        }
    }

    function edit($id=0)
    {
        $id = intval($id);
        $data_info =$this->DataCenterInfo_model->get_one(array('id'=>$id));
        if($this->input->is_ajax_request())
        {
             //接收POST参数
           //接收POST参数
            $_arr['data_center_name'] = isset($_POST["data_center_name"])?trim(safe_replace($_POST["data_center_name"])):'';
            if($_arr['data_center_name']=='')exit(json_encode(array('status'=>false,'tips'=>'数据中心名称不得为空')));

            $_arr['level'] = isset($_POST["level"])?trim(safe_replace($_POST["level"])):'';
            if($_arr['level']=='')exit(json_encode(array('status'=>false,'tips'=>'系统级别不得为空')));
            
            $_arr['place'] = isset($_POST["place"])?trim(safe_replace($_POST["place"])):'';
            if($_arr['place']=='')exit(json_encode(array('status'=>false,'tips'=>'数据中心所在位置不得为空')));

            $_arr['sac'] = isset($_POST["sac"])?trim(safe_replace($_POST["sac"])):'';
            if($_arr['sac']=='')exit(json_encode(array('status'=>false,'tips'=>'sac码不得为空')));
            $_arr['sic'] = isset($_POST["sic"])?trim(safe_replace($_POST["sic"])):'';
            if($_arr['sic']=='')exit(json_encode(array('status'=>false,'tips'=>'sic码不得为空')));
            $_arr['lat'] = isset($_POST["lat"])?trim(safe_replace($_POST["lat"])):'';
            if($_arr['lat']=='')exit(json_encode(array('status'=>false,'tips'=>'纬度不得为空')));
            $_arr['lon'] = isset($_POST["lon"])?trim(safe_replace($_POST["lon"])):'';
            if($_arr['lon']=='')exit(json_encode(array('status'=>false,'tips'=>'经度不得为空')));
            $_arr['height'] = $this->input->post('height')?$this->input->post('height'):exit(json_encode(array('status'=>false,'tips'=>'高度不得为空')));
            $_arr['dateline'] = time(); 
            $status = $this->DataCenterInfo_model->update($_arr,array('id'=>$id));
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_list'=>$data_info,'id'=>$id));
        }
    }


}
