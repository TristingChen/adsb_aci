<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-20
 * Time: 上午9:51
 * To change this template use File | Settings | File Templates.
 */
class EthManage extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Eth_manage_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  index()
    {
        $this->view('index',array('require_js'=>true));
    }

    function lists($page_no=1)
    {
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = "hardware_id";
        $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "concat(eth_num,eth_ip) like '%{$keyword}%'";
        }
        $where = implode(" and ",$where_arr);
        // var_dump($where);exit;
        $data_list = $this->Eth_manage_model->listinfo($where,'*',$orderby , $page_no, $this->Eth_manage_model->page_size,'',$this->Eth_manage_model->page_size,page_list_url('adminpanel/ethManage/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Eth_manage_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    /**
     * 新增数据
     * @param AJAX POST
     * @return void
     */
    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['hardware_id'] = isset($_POST["hardware_id"])?trim(safe_replace($_POST["hardware_id"])):exit(json_encode(array('status'=>false,'tips'=>'请选择设备')));
            if($_arr['hardware_id']=='')exit(json_encode(array('status'=>false,'tips'=>'请选择设备')));
            $_arr['eth_num'] = isset($_POST["eth_num"])?trim(safe_replace($_POST["eth_num"])):exit(json_encode(array('status'=>false,'tips'=>'网口编号不能为空')));
            if($_arr['eth_num']=='')exit(json_encode(array('status'=>false,'tips'=>'网口编号不能为空')));
             $_arr['eth_ip'] = isset($_POST["eth_ip"])?trim(safe_replace($_POST["eth_ip"])):'';
            if(!$_arr['eth_ip'])exit(json_encode(array('status'=>false,'tips'=>'请选择ip')));
             $_arr['eth_type'] = isset($_POST["eth_type"])?trim(safe_replace($_POST["eth_type"])):'';
            if($_arr['eth_type']=='')exit(json_encode(array('status'=>false,'tips'=>'请选择网口类型')));
            $_arr['net_type'] = isset($_POST["net_type"])?trim(safe_replace($_POST["net_type"])):'';
            if($_arr['net_type']=='')exit(json_encode(array('status'=>false,'tips'=>'请选择网络类型')));
            $new_id = $this->Eth_manage_model->insert($_arr);
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_info'=>$this->Eth_manage_model->default_info()));
        }
    }

    /**
     * 删除单个数据
     * @param int id
     * @return void
     */
    function delete_one($id=0)
    {
        $id = intval($id);
        $data_info =$this->Eth_manage_model->get_one(array('eth_id'=>$id));
        if(!$data_info)$this->showmessage('信息不存在');

        $status = $this->Eth_manage_model->delete(array('eth_id'=>$id));
        if($status)
        {
             $this->showmessage('删除成功');
        }else{
            $this->showmessage('删除失败');
        }
    }

    /**
     * 修改数据
     * @param int id
     * @return void
     */
    function edit($id=0)
    {
        $id = intval($id);

        $data_info =$this->Eth_manage_model->get_one(array('eth_id'=>$id));
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            if(!$data_info)exit(json_encode(array('status'=>false,'tips'=>'信息不存在')));
            //接收POST参数
            $_arr['hardware_id'] = isset($_POST["hardware_id"])?trim(safe_replace($_POST["hardware_id"])):exit(json_encode(array('status'=>false,'tips'=>'请选择设备')));
            if($_arr['hardware_id']=='')exit(json_encode(array('status'=>false,'tips'=>'请选择设备')));
            $_arr['eth_num'] = isset($_POST["eth_num"])?trim(safe_replace($_POST["eth_num"])):exit(json_encode(array('status'=>false,'tips'=>'网口编号不能为空')));
            if($_arr['eth_num']=='')exit(json_encode(array('status'=>false,'tips'=>'网口编号不能为空')));
             $_arr['eth_ip'] = isset($_POST["eth_ip"])?trim(safe_replace($_POST["eth_ip"])):'';
            if(!$_arr['eth_ip'])exit(json_encode(array('status'=>false,'tips'=>'请选择ip')));
             $_arr['eth_type'] = isset($_POST["eth_type"])?trim(safe_replace($_POST["eth_type"])):'';
            if($_arr['eth_type']=='')exit(json_encode(array('status'=>false,'tips'=>'请选择网口类型')));
            $_arr['net_type'] = isset($_POST["net_type"])?trim(safe_replace($_POST["net_type"])):'';
            if($_arr['net_type']=='')exit(json_encode(array('status'=>false,'tips'=>'请选择网络类型')));
            $status = $this->Eth_manage_model->update($_arr,array('eth_id'=>$id));
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info));
        }
    }

    /**
     * 设备缓存
     */
    private function _cache_hardware_type() {
        $infos = $this->Eth_manage_model->select('',  '*', '', 'eth_id ASC');
        $typeid_arr=array();
        if($infos) {
            foreach($infos as $k=>$v){
                $typeid_arr[$v['type_id']]=$v;
            }
            setcache('cache_hardware_type', $typeid_arr);
        }
        return $typeid_arr;
    }

}