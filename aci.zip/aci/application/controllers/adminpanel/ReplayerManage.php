<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class ReplayerManage extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Replayer_config_model','All_xml_model','Hardware_model','Hardware_eth_model','Station_model','Replayer_data_info_model','Xml_basic_config_model'));
        $this->load->helper(array('member','auto_codeIgniter','string','socket'));
    }

    function  lists($page_no=0)
    {   
        $station_data = $this->Station_model->tables_select('is_del =0','t_sys_station.station_id,station_name');
        $data_info = $this->Replayer_data_info_model->get_one(array('type'=>1));
        if($data_info){
            $data_info['choose_datas'] = explode(',', $data_info['choose_datas']);
        }else{
            $data_info = $this->Replayer_data_info_model->default_info();
        }
        // print_r($data_info);exit;
        $this->view('list',array('station_data'=>$station_data,'require_js'=>true,'data_info'=>$data_info));
    }


    function produce_xml(){
           // var_dump($_POST);exit;
            $replayer_config = $this->Replayer_config_model->get_one();  //旁路服务器的程序信息 id=8
            if(!$replayer_config){
                $this->showmessage('请先进行回放参数基础数据的配置');eixt;
            }
            $_arr['station_ip'] = isset($_POST["station_ip"])?trim(safe_replace($_POST["station_ip"])):exit(json_encode(array('status'=>false,'tips'=>'基站ip不得为空')));
            if($_arr['station_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'基站ip不得为空')));
			$_arr['replay_channel'] = isset($_POST["replay_channel"])?trim(safe_replace($_POST["replay_channel"])):exit(json_encode(array('status'=>false,'tips'=>'请选择回放通道')));
            if($_arr['replay_channel']=='')exit(json_encode(array('status'=>false,'tips'=>'请选择回放通道')));
             $_arr['station_port'] = isset($_POST["station_port"])?trim(safe_replace($_POST["station_port"])):exit(json_encode(array('status'=>false,'tips'=>'基站端口不得为空')));
            if($_arr['station_port']=='')exit(json_encode(array('status'=>false,'tips'=>'基站端口不得为空')));
            $_arr['start_time'] = isset($_POST["start_time"])?trim(safe_replace($_POST["start_time"])):exit(json_encode(array('status'=>false,'tips'=>'开始时间不得为空')));
            if($_arr['start_time']=='')exit(json_encode(array('status'=>false,'tips'=>'开始时间不得为空')));
            $_arr['end_time'] = isset($_POST["end_time"])?trim(safe_replace($_POST["end_time"])):exit(json_encode(array('status'=>false,'tips'=>'结束时间不得为空')));
            if($_arr['end_time']=='')exit(json_encode(array('status'=>false,'tips'=>'结束时间不得为空')));
            $_arr['rate'] = isset($_POST["rate"])?trim(safe_replace($_POST["rate"])):'';
            if($_arr['rate']=='')exit(json_encode(array('status'=>false,'tips'=>'回放倍数不得为空')));
            $_arr['hardware_id'] = isset($_POST["hardware_id"])?trim(safe_replace($_POST["hardware_id"])):'';
            if($_arr['hardware_id']=='')exit(json_encode(array('status'=>false,'tips'=>'服务器不得为空')));
            $_arr['station_ids'] = isset($_POST["station_ids"])?$_POST["station_ids"]:array();
            if(empty( $_arr['station_ids']))exit(json_encode(array('status'=>false,'tips'=>'基站选择不得为空')));
            $replayer_type = isset($_POST["replayer_type"])?$_POST["replayer_type"]:'';
            if(!$replayer_type)exit(json_encode(array('status'=>false,'tips'=>'参数错误')));
            $station_data = $this->Station_model->tables_select('','t_sys_station.station_id,station_name');
            $num = array();
            foreach ($station_data as $key => $value) {
                if(in_array($value['station_id'], $_arr['station_ids'])){
                    $num[] = $key;
                }
            }
            $source_id = implode(',', $num);
            $hardware_data = $this->Hardware_eth_model->tables_get_one(array('t_sys_hardware_eth.hardware_id'=>$_arr['hardware_id'],'eth_type'=>0,'net_type'=>0),'ftp_dir,eth_ip,hardware_other_name,hardware_name');

            $operation_data= $this->operation_data;
            $operation_data['dateline'] = time();
            try{
                if($replayer_type != 1){
                    //仅进行发送消息
                    if ($replayer_type == 2) {
                             $msg = '<MSG TYPE="11" MODULENAME="'.$hardware_data['hardware_other_name'].'" APPNAME="replayer"   SENDTIME="'.date('Y-m-d H:i:s').'"  CHANNEL="'.$_arr['replay_channel'].'" SENDIP="'.$_arr['station_ip'].'" SENDPORT="'.$_arr['station_port'].'" BEGTIME="'.$_arr['start_time'].'" ENDTIME="'.$_arr['end_time'].'" RATE="'.$_arr['rate'].'" SOURCEID="'.$source_id.'"/>';
                                $update_data['msg_type'] = 2;
                                $operation_data['operate_explain'] = '暂停输入回放消息的发送';

                        }elseif ($replayer_type == 3) {
                             $msg = '<MSG TYPE="9" MODULENAME="'.$hardware_data['hardware_other_name'].'" APPNAME="replayer"   SENDTIME="'.date('Y-m-d H:i:s').'"  CHANNEL="'.$_arr['replay_channel'].'" SENDIP="'.$_arr['station_ip'].'" SENDPORT="'.$_arr['station_port'].'" BEGTIME="'.$_arr['start_time'].'" ENDTIME="'.$_arr['end_time'].'" RATE="'.$_arr['rate'].'" SOURCEID="'.$source_id.'"/>';
                            $update_data['msg_type'] = 3;
                                $operation_data['operate_explain'] = '终止输入回放消息的发送';


                        }elseif ($replayer_type ==4) {
                             $msg = '<MSG TYPE="12" MODULENAME="'.$hardware_data['hardware_other_name'].'" APPNAME="replayer"   SENDTIME="'.date('Y-m-d H:i:s').'"  CHANNEL="'.$_arr['replay_channel'].'" SENDIP="'.$_arr['station_ip'].'" SENDPORT="'.$_arr['station_port'].'" BEGTIME="'.$_arr['start_time'].'" ENDTIME="'.$_arr['end_time'].'" RATE="'.$_arr['rate'].'" SOURCEID="'.$source_id.'"/>';
                            $update_data['msg_type'] = 4;
                            $operation_data['operate_explain'] = '恢复输入回放消息的发送';
                    }
                    $id_arr = $this->Replayer_data_info_model->get_one(array('type'=>1,'is_old'=>0),'id');
                    $this->Replayer_data_info_model->update($update_data,array('id'=>$id_arr['id']));
                    $res = send_udp(SYSTEMSENDIP, SYSTEMSENDPORT,$msg,0);
                    if($res != 1){
                        throw new Exception("socket消息发送失败");
                    }
                }else{
                    //进行查找 删除与重新插入
                    $operation_data['operate_explain'] = '开始输入回放消息的发送';
                    $update_data['type'] = 1;
                    $update_data['choose_datas'] = implode(',', $_arr['station_ids']);
                    $update_data['replay_channel'] = $_arr['replay_channel'];
                    $update_data['hardware_id'] =  $_arr['hardware_id'];
                    $update_data['send_ip'] =  $_arr['station_ip'];
                    $update_data['send_port'] =  $_arr['station_port'];
                    $update_data['start_time'] =  $_arr['start_time'];
                    $update_data['end_time'] =  $_arr['end_time'];
                    $update_data['replayer_rate'] =  $_arr['rate'];
                    $update_data['msg_type'] = 1;
                    $id_arr = $this->Replayer_data_info_model->get_one(array('type'=>1,'is_old'=>0),'id');
                    if($id_arr){
                        $in_db =  $this->Replayer_data_info_model->update($update_data,array('id'=>$id_arr['id']));
                    }else{
                        $in_db = $this->Replayer_data_info_model->insert($update_data);
                    }
                    if(!$in_db){
                        throw new Exception("数据库操作更新失败");
                    }
                    $xmlpatch = REPLAYER_XML_PATH.'replayer_config.xml';
                    $doc = new DOMDocument('1.0','utf-8');   
                    $flag = false;
                    if(file_exists($xmlpatch)) {   
                    //备份以前的xml版本 2017_12_1_16_48
                        $flag = true;
                    }
                    $doc -> formatOutput = true;

                    $all_station_arr = $this->Station_model->select('','station_id');
                    foreach ($all_station_arr as $key => $value) {
                        foreach ($_arr['station_ids'] as $kk => $vv) {
                            if($value['station_id'] == $vv){
                                $_arr['station_ids_arr'][] = $key;
                            }
                        }
                    }
                    $program = $doc -> createElement('program');//新建节点
                    $program = $this->create_only_xml($doc,$program,$replayer_config);
                    $program = $this->create_target_xml($doc,$program,$_arr,$replayer_config['is_send_timestamp_prefix'],$replayer_config['is_filter'],$replayer_config['send_all_ip'],$replayer_config['send_all_port']);
                    $doc->appendChild($program);
                    create_dir(REPLAYER_XML_PATH);
                    $update_xml_file = 'replayer_config_'.date('Y_m_d_H_i',time()).'.xml';
                    $kind_id = $this->Xml_basic_config_model->get_one(array('name'=>'回放配置文件','is_del'=>0),'id');
                    if(!$kind_id){
                        throw new Exception("输入回放配置文件服务器的配置信息不存在");
                    }
                    $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'replayer_config_.xml\'','id');
                    $res = $this->All_xml_model->xml_produce($xml_id_arr,$update_xml_file,'replayer_config.xml',$kind_id['id'],REPLAYER_XML_PATH,'输入回放配置文件');
                    if(!$res){
                        throw new Exception("数据库操作更新失败");

                    }else{
                        if($flag){
                            rename($xmlpatch, REPLAYER_XML_PATH.$update_xml_file);
                        }
                        $xml_save = $doc->save($xmlpatch);
                    }
                    
                    $this->load->library('ftp');
                    $config['hostname'] = $hardware_data['eth_ip'];
                    $config['username'] = 'root';
                    $config['password'] = 'atc4';
                    $config['debug'] = TRUE;
                    $this->ftp->connect($config);
                    $status = $this->ftp->upload($xmlpatch,$hardware_data['ftp_dir'].'/replayer_config.xml','ascii',0775);
                    $this->ftp->close();
                    if(!$status){
                        throw new Exception('上传配置文件至'.$hardware_data['hardware_name'].'失败');
                    }
                    $msg = '<MSG TYPE="66" MODULENAME="'.$hardware_data['hardware_other_name'].'" APPNAME="replayer"   SENDTIME="'.date('Y-m-d H:i:s').'"  CHANNEL="'.$_arr['replay_channel'].'" SENDIP="'.$_arr['station_ip'].'" SENDPORT="'.$_arr['station_port'].'" BEGTIME="'.$_arr['start_time'].'" ENDTIME="'.$_arr['end_time'].'" RATE="'.$_arr['rate'].'" SOURCEID="'.$source_id.'"/>';
                    //echo $msg;
                    $res_start = send_udp(SYSTEMSENDIP, SYSTEMSENDPORT,$msg,0);
                    if($res_start != 1){
                        throw new Exception('发送socket消息失败');
                    }

                }

            }catch (Exception $e){

                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = $e->getMessage();
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>$e->getMessage())));
            }
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '操作成功';
            @$this->operationLogs($operation_data);
            exit(json_encode(array('status'=>true,'tips'=>'操作成功')));
    }

    //生成基站的_target_xml文件
    private function create_only_xml($doc,$program,$data_list){
			$replay_channel = $this->Replayer_data_info_model->get_one(array('type'=>1,'is_old'=>0),'replay_channel');
            // var_dump($replay_channel);exit;
			$channel = "";
			if($replay_channel['replay_channel'] == 1){
                $channel = "A";
            }else{
                $channel = "B";

            }
                $recordPath = $doc -> createElement('recordPath');
                $fileDir = $doc -> createElement('fileDir');
                $fileDir_text = $doc->createTextNode($data_list['file_dir'].$channel."/");
                $fileDir->appendChild($fileDir_text);

                $fileTempDir = $doc -> createElement('fileTempDir');
                $fileTempDir_text = $doc->createTextNode($data_list['file_temp_dir'].$channel."/");
                $fileTempDir->appendChild($fileTempDir_text);

                $commpressFileDir = $doc -> createElement('commpressFileDir');
                $commpressFileDir_text = $doc->createTextNode($data_list['commpress_file_dir'].$channel."/");
                $commpressFileDir->appendChild($commpressFileDir_text);
            $recordPath->appendChild($fileDir);
            $recordPath->appendChild($fileTempDir);
            $recordPath->appendChild($commpressFileDir);
            
            $log = $doc -> createElement('log');
                $path = $doc -> createElement('path');
                $path_text = $doc->createTextNode($data_list['log_path']);
                $path->appendChild($path_text);
                $level = $doc -> createElement('level');
                $level_text = $doc->createTextNode($data_list['log_level']);
                $level->appendChild($level_text);
            $log->appendChild($path);
            $log->appendChild($level);

            $monitor = $doc -> createElement('monitor');
                $interval = $doc -> createElement('interval');
                $interval_text = $doc->createTextNode($data_list['interval']);
                $interval->appendChild($interval_text);
                $missCnt = $doc -> createElement('missCnt');
                $missCnt_text = $doc->createTextNode($data_list['miss_count']);
                $missCnt->appendChild($missCnt_text);
                $sendStatus = $doc -> createElement('sendStatus');
                    $ip = $doc -> createElement('ip');
                    $ip_text = $doc->createTextNode($data_list['send_ip']);
                    $ip->appendChild($ip_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_list['send_port']);
                    $port->appendChild($port_text);
                $sendStatus->appendChild($ip);
                $sendStatus->appendChild($port);

                $sendHeartbeat = $doc -> createElement('sendHeartbeat');
                    $ip = $doc -> createElement('ip');
                    $ip_text = $doc->createTextNode($data_list['send_heart_ip']);
                    $ip->appendChild($ip_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_list['send_heart_port']);
                    $port->appendChild($port_text);
                $sendHeartbeat->appendChild($ip);
                $sendHeartbeat->appendChild($port);

                $sendPercentage = $doc -> createElement('sendPercentage');
                    $ip = $doc -> createElement('ip');
                    $ip_text = $doc->createTextNode($data_list['send_percent_ip']);
                    $ip->appendChild($ip_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_list['send_percent_port']);
                    $port->appendChild($port_text);
                $sendPercentage->appendChild($ip);
                $sendPercentage->appendChild($port);

                $recvCmd = $doc -> createElement('recvCmd');
                    $ip = $doc -> createElement('ip');
                    $ip_text = $doc->createTextNode($data_list['recv_cmd_ip']);
                    $ip->appendChild($ip_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_list['recv_cmd_port']);
                    $port->appendChild($port_text);
                $recvCmd->appendChild($ip);
                $recvCmd->appendChild($port);
            
            $monitor->appendChild($interval);
            $monitor->appendChild($missCnt);
            $monitor->appendChild($sendStatus);
            $monitor->appendChild($sendHeartbeat);
            $monitor->appendChild($sendPercentage);
            $monitor->appendChild($recvCmd);

            $program->appendChild($recordPath);
            $program->appendChild($log);
            $program->appendChild($monitor);

            
            return $program;
        }

    //生成基站的_target_xml文件
    private function create_target_xml($doc,$program,$data_list,$is_send_timestamp_prefix,$is_filter,$send_all_ip,$send_all_port){
            $sendModule = $doc -> createElement('sendModule');
            $isSendTimestampPrefix = $doc -> createElement('isSendTimestampPrefix');
            $isSendTimestampPrefix_text = $doc->createTextNode($is_send_timestamp_prefix);
            $isSendTimestampPrefix->appendChild($isSendTimestampPrefix_text);

            $isFilter = $doc -> createElement('isFilter');
            $isFilter_text = $doc->createTextNode($is_filter);
            $isFilter->appendChild($isFilter_text);

            $sendAllAddr = $doc -> createElement('sendAllAddr');
                $ip = $doc -> createElement('ip');
                $ip_text = $doc->createTextNode($send_all_ip);
                $ip->appendChild($ip_text);
                $port = $doc -> createElement('port');
                $port_text = $doc->createTextNode($send_all_port);
                $port->appendChild($port_text);
            $sendAllAddr->appendChild($ip);
            $sendAllAddr->appendChild($port);

            $sendFilterAddrs = $doc -> createElement('sendFilterAddrs');
            foreach ($data_list['station_ids_arr'] as $key => $value) {
                $sourceIdAddrMapItem = $doc -> createElement('sourceIdAddrMapItem');
                $sourceId = $doc -> createElement('sourceId');
                $sourceId_text = $doc->createTextNode($value);
                $sourceId->appendChild($sourceId_text);

                $sendAddr = $doc -> createElement('sendAddr');
                    $ip = $doc -> createElement('ip');
                    $ip_text = $doc->createTextNode($data_list['station_ip']);
                    $ip->appendChild($ip_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_list['station_port']);
                    $port->appendChild($port_text);

                $sendAddr->appendChild($ip);
                $sendAddr->appendChild($port);
                $sourceIdAddrMapItem->appendChild($sourceId);
                $sourceIdAddrMapItem->appendChild($sendAddr);

                $sendFilterAddrs->appendChild($sourceIdAddrMapItem);
            }
            $sendModule->appendChild($isSendTimestampPrefix);
            $sendModule->appendChild($isFilter);
            $sendModule->appendChild($sendAllAddr);
            $sendModule->appendChild($sendFilterAddrs);

            $replayTask = $doc -> createElement('replayTask');
                $dAllAddr = $doc -> createElement('sendAllAddr');
                $beginTime = $doc -> createElement('beginTime');
                $beginTime_text = $doc->createTextNode($data_list['start_time']);
                $beginTime->appendChild($beginTime_text);
                $endTime = $doc -> createElement('endTime');
                $endTime_text = $doc->createTextNode($data_list['end_time']);
                $endTime->appendChild($endTime_text);
                $rate = $doc -> createElement('rate');
                $rate_text = $doc->createTextNode($data_list['rate']);
                $rate->appendChild($rate_text);
            $replayTask->appendChild($beginTime);
            $replayTask->appendChild($endTime);
            $replayTask->appendChild($rate);

           $program->appendChild($sendModule);
           $program->appendChild($replayTask);
           return $program;
        }
}
