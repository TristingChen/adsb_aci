<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class RecorderConfig extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Recorder_config_model','All_xml_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists()
    {   
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['input_ip_a'] = $this->input->post('input_ip_a') !=''?$this->input->post('input_ip_a'):exit(json_encode(array('status'=>false,'tips'=>'请输入输入ip')));
            $_arr['input_ip_a_port'] = $this->input->post('input_ip_a_port') !=''?$this->input->post('input_ip_a_port'):exit(json_encode(array('status'=>false,'tips'=>'请输入输入端口')));
            $_arr['output_ip_a'] = $this->input->post('output_ip_a') !=''?$this->input->post('output_ip_a'):exit(json_encode(array('status'=>false,'tips'=>'请输入输出ip')));
            $_arr['output_ip_a_port'] = $this->input->post('output_ip_a_port') !=''?$this->input->post('output_ip_a_port'):exit(json_encode(array('status'=>false,'tips'=>'请输入输出端口')));

            $_arr['input_ip_b'] = $this->input->post('input_ip_b') !=''?$this->input->post('input_ip_b'):exit(json_encode(array('status'=>false,'tips'=>'请输入输入ip')));
            $_arr['input_ip_b_port'] = $this->input->post('input_ip_b_port') !=''?$this->input->post('input_ip_b_port'):exit(json_encode(array('status'=>false,'tips'=>'请输入输入端口')));
            $_arr['output_ip_b'] = $this->input->post('output_ip_b') !=''?$this->input->post('output_ip_b'):exit(json_encode(array('status'=>false,'tips'=>'请输入输出ip')));
            $_arr['output_ip_b_port'] = $this->input->post('output_ip_b_port') !=''?$this->input->post('output_ip_b_port'):exit(json_encode(array('status'=>false,'tips'=>'请输入输出端口')));
            $_arr['recorder_a_dir'] = $this->input->post('recorder_a_dir') !=''?$this->input->post('recorder_a_dir'):exit(json_encode(array('status'=>false,'tips'=>'请输入通道A文件目录')));
            $_arr['recorder_b_dir'] = $this->input->post('recorder_b_dir') !=''?$this->input->post('recorder_b_dir'):exit(json_encode(array('status'=>false,'tips'=>'请输入通道B文件目录')));
            $new_id = $this->Recorder_config_model->update($_arr,array('id'=>1));
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败','new_id'=>0)));
            }
        }else{
            $fresh_xml_data = $this->All_xml_model->get_one(array('kind'=>9,'is_old'=>0),'id');
            $data_list = $this->Recorder_config_model->get_one();
            if(!$data_list){
                $data_list = $this->Recorder_config_model->default_info();
            }
            $this->view('lists',array('data_list'=>$data_list,'require_js'=>true,'fresh_xml_data'=>$fresh_xml_data));
        }

        
    }


    //配置文件生成
    function produce_xml(){
            $data_config = $this->Recorder_config_model->get_one();  //数据输出基础数据
            //针对range进行多边形的查找
            $xmlpatch = RECORDER_XML_PATH.'recorder_config.xml';
            $doc = new DOMDocument('1.0','utf-8');   
            $flag = false;
            if(file_exists($xmlpatch)) {   
            //备份以前的xml版本 2017_12_1_16_48
                $flag = true;
            }
            $doc -> formatOutput = true;
            $program = $doc -> createElement('program');//新建节点
            $program = $this->create_config_xml($doc,$program,$data_config);
            $doc->appendChild($program);
            $xml_str =  $doc->saveXML();

            if($this->input->is_ajax_request()){
                create_dir(RECORDER_XML_PATH);
                if($flag){
                    $update_xml_file = 'recorder_config_'.date('Y_m_d_H_i',time()).'.xml';
                    $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'recorder_config.xml\'','id');
                    if($xml_id_arr){
                        $this->All_xml_model->update(array('xml_name'=>$update_xml_file,'is_old'=>1),array('id'=>$xml_id_arr['id']));
                    }
                    rename($xmlpatch, RECORDER_XML_PATH.$update_xml_file);
                }
                $xml_res = $doc->save($xmlpatch);
                if($xml_res){
                    $insert_data['xml_name'] = 'recorder_config.xml';
                    $insert_data['dateline'] = time();
                    $insert_data['kind'] = 9;
                    $insert_data['xml_path'] = RECORDER_XML_PATH;
                    $insert_data['config_name'] = '录制参数配置文件';
                    $res = $this->All_xml_model->insert($insert_data);
                    if($res){
                        exit(json_encode(array('status'=>true,'tips'=>'文件生成失败')));
                        
                    }else {
                        exit(json_encode(array('status'=>false,'tips'=>'文件生成成功')));
                    }
                }else {
                    $this->showmessage('生成xml失败');
                }
            }else{
                $this->view('produce_xml',array('xml_data'=>htmlentities($xml_str),'require_js'=>true));
            }

    }
    //生成输入数据的基础文件
    private function create_config_xml($doc,$program,$data_config){
            $recvs = $doc -> createElement('recvs');
                $recv1 = $doc -> createElement('recv');
                     $ip = $doc -> createElement('ip');
                     $ip_text = $doc->createTextNode($data_config['input_ip_a']);
                     $ip->appendChild($ip_text);

                     $port = $doc -> createElement('port');
                     $port_text = $doc->createTextNode($data_config['input_ip_a_port']);
                     $port->appendChild($port_text);
                $recv1->appendChild($ip);
                $recv1->appendChild($port);
                $recv2 = $doc -> createElement('recv');
                     $ip = $doc -> createElement('ip');
                     $ip_text = $doc->createTextNode($data_config['output_ip_a']);
                     $ip->appendChild($ip_text);

                     $port = $doc -> createElement('port');
                     $port_text = $doc->createTextNode($data_config['output_ip_a_port']);
                     $port->appendChild($port_text);
                $recv2->appendChild($ip);
                $recv2->appendChild($port);
            $recvs->appendChild($recv1);
            $recvs->appendChild($recv2);

            $recvs2 = $doc -> createElement('recvs');
                $recv1 = $doc -> createElement('recv');
                     $ip = $doc -> createElement('ip');
                     $ip_text = $doc->createTextNode($data_config['input_ip_b']);
                     $ip->appendChild($ip_text);

                     $port = $doc -> createElement('port');
                     $port_text = $doc->createTextNode($data_config['input_ip_b_port']);
                     $port->appendChild($port_text);
                $recv1->appendChild($ip);
                $recv1->appendChild($port);
                $recv2 = $doc -> createElement('recv');
                     $ip = $doc -> createElement('ip');
                     $ip_text = $doc->createTextNode($data_config['output_ip_b']);
                     $ip->appendChild($ip_text);

                     $port = $doc -> createElement('port');
                     $port_text = $doc->createTextNode($data_config['output_ip_b_port']);
                     $port->appendChild($port_text);
                $recv2->appendChild($ip);
                $recv2->appendChild($port);
            $recvs2->appendChild($recv1);
            $recvs2->appendChild($recv2);

            $log = $doc -> createElement('log');
                 $path = $doc -> createElement('path');
                 $path_text = $doc->createTextNode($data_config['log_path']);
                 $path->appendChild($path_text);

                 $level = $doc -> createElement('level');
                 $level_text = $doc->createTextNode($data_config['log_level']);
                 $level->appendChild($level_text);
            $log->appendChild($path);
            $log->appendChild($level);

            $monitor = $doc -> createElement('monitor');
             $interval = $doc -> createElement('interval');
             $interval_text = $doc->createTextNode($data_config['interval']);
             $interval->appendChild($interval_text);

             $missCnt = $doc -> createElement('missCnt');
             $missCnt_text = $doc->createTextNode($data_config['miss_count']);
             $missCnt->appendChild($missCnt_text);

             $sendStatus = $doc -> createElement('sendStatus');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['send_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['send_port']);
                 $port->appendChild($port_text);
             $sendStatus->appendChild($ip);
             $sendStatus->appendChild($port);

             $sendHeartbeat = $doc -> createElement('sendHeartbeat');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['send_heart_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['send_heart_port']);
                 $port->appendChild($port_text);
             $sendHeartbeat->appendChild($ip);
             $sendHeartbeat->appendChild($port);

              $recvCmd = $doc -> createElement('recvCmd');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['recv_cmd_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['recv_cmd_port']);
                 $port->appendChild($port_text);
             $recvCmd->appendChild($ip);
             $recvCmd->appendChild($port);

            $monitor->appendChild($interval);
            $monitor->appendChild($missCnt);
            $monitor->appendChild($sendStatus);
            $monitor->appendChild($sendHeartbeat);
            $monitor->appendChild($recvCmd);
           
            $bufSize = $doc -> createElement('bufSize');
            $bufSize_text = $doc->createTextNode($data_config['bufsize']);
            $bufSize->appendChild($bufSize_text);

            $recordDir = $doc -> createElement('recordDir');
            $recordDir_text = $doc->createTextNode($data_config['recorder_a_dir']);
            $recordDir->appendChild($recordDir_text);

            $recordDir2 = $doc -> createElement('recordDir2');
            $recordDir2_text = $doc->createTextNode($data_config['recorder_b_dir']);
            $recordDir2->appendChild($recordDir2_text);
            $program->appendChild($recvs);
            $program->appendChild($recvs2);
            $program->appendChild($log);
            $program->appendChild($monitor);
            $program->appendChild($bufSize);
            $program->appendChild($recordDir);
            $program->appendChild($recordDir2);
            return $program;
        }
}
