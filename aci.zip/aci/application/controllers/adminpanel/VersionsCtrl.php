<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenjialing
 * Date: 17-2-16
 * Time: 下午2:54
 * To change this template use File | Settings | File Templates.
 */
class VersionsCtrl extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Versions_list_model','Versions_log_model','Versions_relation_model','Hardware_model','Member_model','App_model','Hardware_eth_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    //版本管理  进行上传增删改查
    function  versions_manage($page_no=0)
    {

        $page_no = max(intval($page_no),1);
        $where = 'is_old=0';
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!=""){
                $where .= " and concat(version_content,version_num) like '%{$keyword}%'";

            } 
        }
        $data_list = $this->Versions_list_model->listinfo($where,'*','update_time desc' , $page_no, $this->Versions_list_model->page_size,'',$this->Versions_list_model->page_size,page_list_url('adminpanel/VersionsCtrl/versions_manage',true));
        if($data_list){
            foreach ($data_list as $key => $value) {
                $data_list[$key]['program'] = $this->App_model->get_one(array('app_id'=>$value['app_id']),'program_name')['program_name'];
                $data_list[$key]['has_children']  = $this->Versions_list_model->get_one(array('is_old'=>1,'app_id'=>$value['app_id']),'id,version_num');
            }
        }
        $this->view('versions_manage',array('data_list'=>$data_list,'pages'=>$this->Versions_list_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    //版本回退
    function back_versions($id=0)
    {
        $the_app_data = $this->Versions_list_model->get_one(array('id'=>$id));
        if(!$the_app_data){
            exit(json_encode(array('status'=>false,'tips'=>'参数错误')));
        }
        $app_list = $this->Versions_list_model->select(array('is_old'=>1,'app_id'=>$the_app_data['app_id']),'id,version_num,version_content');
        if(!$app_list){
            $this->showmessage('无过去版本');exit;
        }
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $version_id = isset($_POST["app_id"])?trim(safe_replace($_POST["app_id"])):exit(json_encode(array('status'=>false,'tips'=>'版本名称不能为空')));
            if($version_id=='')exit(json_encode(array('status'=>false,'tips'=>'版本名称不能为空')));
            //进行查重限制
            $_arr['version_content'] = isset($_POST["version_content"])?trim(safe_replace($_POST["version_content"])):exit(json_encode(array('status'=>false,'tips'=>'版本说明不能为空')));
            if($_arr['version_content']=='')exit(json_encode(array('status'=>false,'tips'=>'版本说明不能为空')));

            $new_remark = isset($_POST["new_remark"])?trim(safe_replace($_POST["new_remark"])):exit(json_encode(array('status'=>false,'tips'=>'操作备注不能为空')));
            if($new_remark=='')exit(json_encode(array('status'=>false,'tips'=>'操作备注不能为空')));
            $_arr['version_content'] = $_arr['version_content'].';'. $new_remark;


            /*$upload_data = $this->do_upload('versions_file','VersionsCtrl');

            if(!empty($upload_data['error'])){
                //出错
                exit(json_encode(array('status'=>false,'tips'=>'文件上传错误')));
            }*/
            //服务器的上传  成功后 进行存储
            $versions_data = $this->Versions_list_model->get_one(array('id'=>$version_id));
            if(!$versions_data){
                exit(json_encode(array('status'=>false,'tips'=>'程序版本查找失败')));
            }

            $app_data = $this->App_model->get_one(array('app_id'=>$versions_data['app_id']),'hardware_id,program_start_dir,program_name,version_num');
            if(!$app_data){
                exit(json_encode(array('status'=>false,'tips'=>'服务器列表查找失败')));
            }
            $hardware_ids = explode(',', $app_data['hardware_id']);
            
            $local_path = $versions_data['file_path'].$versions_data['file_name'];
            $this->ftp_versions($hardware_ids,$local_path,$app_data['program_start_dir'],$app_data['program_name'],$app_data['version_num']);  

            // $_arr['version_num'] = $app_data['program_name'].date('YmdHis',time());
            $_arr['update_time'] = time();
            $_arr['is_old'] = 0;
            $this->db->trans_start();
            $this->Versions_list_model->update(array('is_old'=>1),array('id'=>$id));
            //修改状态
            $this->Versions_list_model->update($_arr,array('id'=>$version_id));
            $this->db->trans_complete();
            $operation_data = $this->operation_data;
            $operation_data['operate_explain'] = '回退版本号为'.$app_data['version_content'].'的'.$app_data['program_name'].'程序';
            if($this->db->trans_status() !== false)
            {
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '回退成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'版本回退成功')));
            }else
            {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '回退失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'版本回退失败')));
            }
        }else
        {
            $this->view('back_versions',array('require_js'=>true,'data_info'=>$this->Versions_list_model->default_info(),'app_list'=>$app_list,'id'=>$id));
        }
    }

     //版本上传
    function upgrade_versions($id=0)
    {
        $the_app_data = $this->Versions_list_model->get_one(array('id'=>$id));
        if(!$the_app_data){
            exit(json_encode(array('status'=>false,'tips'=>'参数错误')));
        }
        $app_list = $this->App_model->select(array('is_del'=>0,'app_id'=>$the_app_data['app_id']),'app_id,program_name');
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['app_id'] = isset($_POST["app_id"])?trim(safe_replace($_POST["app_id"])):exit(json_encode(array('status'=>false,'tips'=>'程序名称不能为空')));
            if($_arr['app_id']=='')exit(json_encode(array('status'=>false,'tips'=>'程序名称不能为空')));
            //进行查重限制
            $_arr['version_content'] = isset($_POST["version_content"])?trim(safe_replace($_POST["version_content"])):exit(json_encode(array('status'=>false,'tips'=>'版本说明不能为空')));
            if($_arr['version_content']=='')exit(json_encode(array('status'=>false,'tips'=>'版本说明不能为空')));

            $upload_data = $this->do_upload('versions_file','VersionsCtrl');
            if(!empty($upload_data['error'])){
                //出错
                exit(json_encode(array('status'=>false,'tips'=>'文件上传错误')));
            }
            //服务器的上传  成功后 进行存储
            $app_data = $this->App_model->get_one(array('app_id'=>$_arr['app_id']));
            if(!$app_data){
                exit(json_encode(array('status'=>false,'tips'=>'程序名查找失败')));
            }
            $hardware_ids = explode(',', $app_data['hardware_id']);
            $local_path = $upload_data['upload_data']['file_path'].$upload_data['upload_data']['file_name'];
            $_arr['version_num'] = $app_data['program_name'].date('YmdHis',time());
            $this->ftp_versions($hardware_ids,$local_path,$app_data['program_start_dir'],$app_data['program_name'],$_arr['version_num']);                
            $_arr['update_time'] = time();
            $_arr['is_old'] = 0;
            $_arr['file_name'] = $upload_data['upload_data']['file_name'];
            $_arr['file_path'] = $upload_data['upload_data']['file_path'];
            $_arr['file_ext'] = $upload_data['upload_data']['file_ext'];
            $_arr['file_size'] = $upload_data['upload_data']['file_size'];
            $_arr['old_name'] = $upload_data['upload_data']['client_name'];
            $this->db->trans_start();
            $this->Versions_list_model->update(array('is_old'=>1),array('id'=>$id));
            $this->Versions_list_model->insert($_arr);
            $this->db->trans_complete();
            $operation_data = $this->operation_data;
            $operation_data['operate_explain'] = '更新版本号为'.$_arr['version_content'].'的'.$app_data['program_name'].'程序';
            if($this->db->trans_status() !== false)
            {
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '更新成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'版本更新成功')));
            }else
            {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '更新失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'版本更新失败')));
            }
        }else
        {
            $this->view('upgrade_versions',array('require_js'=>true,'data_info'=>$this->Versions_list_model->default_info(),'app_list'=>$app_list,'id'=>$id));
        }
    }

     /**
     * 新增数据
     * @param is_back 0升级,1回退,2上传文件
     * @return array
     */
    private function ftp_versions($hardware_id_arr=array(),$local_path,$file_path,$file_name,$version_num = ''){
            //进行ftp的上传
            foreach($hardware_id_arr as $k=>$v){
                $hardware_data = $this->Hardware_eth_model->tables_get_one(array('t_sys_hardware_eth.hardware_id'=>$v,'eth_type'=>0,'net_type'=>0),'eth_ip,hardware_name');
                $exc_words = $local_path.' root@'.$hardware_data['eth_ip'].':'.$file_path.'/'.$file_name;
                exec('scp '.$exc_words,$a,$status);
                if($status !=0){
                    $operation_data = $this->operation_data;
                    $operation_data['operate_explain'] = '版本号为'.$version_num.'的文件上传至'.$hardware_data['hardware_name'].'失败';
                    $operation_data['is_success'] = 0;
                    $operation_data['status_explain'] = '文件上传失败';
                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>false,'tips'=>'文件上传至'.$hardware_data['hardware_name'].'失败')));
                    break;
                }
            }
            //进行事物操作
    }
    /**
     * 新增数据
     * @param AJAX POST
     * @return void
     */
    function edit()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['app_id'] = isset($_POST["app_id"])?trim(safe_replace($_POST["app_id"])):exit(json_encode(array('status'=>false,'tips'=>'程序名称不能为空')));
            if($_arr['app_id']=='')exit(json_encode(array('status'=>false,'tips'=>'程序名称不能为空')));
            //进行查重限制
            $old_info = $this->Versions_list_model->get_one(array('app_id'=>$_arr['app_id']));
            if($old_info){
                exit(json_encode(array('status'=>false,'tips'=>'该程序已存在，请进行更新或则选择其他程序添加')));
            }


            $_arr['version_content'] = isset($_POST["version_content"])?trim(safe_replace($_POST["version_content"])):exit(json_encode(array('status'=>false,'tips'=>'版本说明不能为空')));
            if($_arr['version_content']=='')exit(json_encode(array('status'=>false,'tips'=>'版本说明不能为空')));

            $upload_data = $this->do_upload('versions_file','VersionsCtrl');
            if(!empty($upload_data['error'])){
                //出错
                exit(json_encode(array('status'=>false,'tips'=>'文件上传错误')));
            }else{
                //服务器的上传  成功后 进行存储
                $app_data = $this->App_model->get_one(array('app_id'=>$_arr['app_id']));
                if(!$app_data){
                    exit(json_encode(array('status'=>false,'tips'=>'程序名查找失败')));
                }
                $hardware_ids = explode(',', $app_data['hardware_id']);
                $local_path = $upload_data['upload_data']['file_path'].$upload_data['upload_data']['file_name'];
                $_arr['version_num'] = $app_data['program_name'].date('YmdHis',time());
                $this->ftp_versions($hardware_ids,$local_path,$app_data['program_start_dir'],$app_data['program_name'],$_arr['version_num']);                
                $_arr['update_time'] = time();
                $_arr['is_old'] = 0;
                $_arr['file_name'] = $upload_data['upload_data']['file_name'];
                $_arr['file_path'] = $upload_data['upload_data']['file_path'];
                $_arr['file_ext'] = $upload_data['upload_data']['file_ext'];
                $_arr['file_size'] = $upload_data['upload_data']['file_size'];
                $_arr['old_name'] = $upload_data['upload_data']['client_name'];
                $new_log_id = $this->Versions_list_model->insert($_arr);
            }
            $operation_data = $this->operation_data;
            $operation_data['operate_explain'] = '新增版本号为'.$_arr['version_content'].'的'.$app_data['program_name'].'程序';
            if($new_log_id)
            {
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息新增成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功')));
            }else
            {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息新增失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败')));
            }
        }else
        {
            $app_list = $this->App_model->select(array('is_del'=>0),'app_id,program_name');
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_info'=>$this->Versions_list_model->default_info(),'app_list'=>$app_list));
        }
    }

    /**
     * 服务器版本新增数据
     * @param AJAX POST
     * @return void
     */
    function versions_relation_add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
             //接收POST参数
            $versions_id = isset($_POST["versions_old_id"])?trim(intval($_POST["versions_old_id"])):exit(json_encode(array('status'=>false,'tips'=>'版本不能为空')));
            if(!$versions_id)exit(json_encode(array('status'=>false,'tips'=>'版本不能为空')));
            $hardware_id_arr = isset($_POST["hardware_id"])?$_POST["hardware_id"]:exit(json_encode(array('status'=>false,'tips'=>'版本不能为空')));
            if(empty($hardware_id_arr))exit(json_encode(array('status'=>false,'tips'=>'服务器选择不能为空')));
            $remark = safe_replace($_POST["remark"]);
            //进行ftp的上传
            $status = $this->ftp_versions($versions_id,$hardware_id_arr,$remark,2);
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'程序版本添加成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'程序版本添加失败')));
            }
        }else
        {
            $versions_data = $this->Versions_list_model->son_select(' v_degree in (SELECT MAX(v_degree) FROM `t_sys_versions`  GROUP BY program) ','id,program');  //最新版本数据的集合
            $server_data = $this->Hardware_model->select('hardware_type_id = 2','hardware_id,hardware_name');
            $data_info = array('versions_data'=>$versions_data,'server_data'=>$server_data);
            $this->view('versions_relation_add',array('is_edit'=>false,'require_js'=>true,'data_info'=>$data_info));
        }
    }
    /**
     * 删除单个数据
     * @param int id
     * @return void
     */
    function delete_one($id=0)
    {
        $id = intval($id);
        $data_info =$this->Hardware_model->get_one(array('hardware_id'=>$id));
        if(!$data_info)$this->showmessage('信息不存在');
        $status = $this->Hardware_model->delete(array('hardware_id'=>$id));
        $this->_cache_hardware();
        if($status)
        {
            $this->showmessage('删除成功');
        }else{
            $this->showmessage('删除失败');
        }
    }

    /**
     * 设备缓存
     */
    private function _cache_hardware() {
        $infos = $this->Hardware_model->select('',  '*', '', 'hardware_id ASC');
        $hardwareid_arr=array();
        if($infos) {
            foreach($infos as $k=>$v){
                $hardwareid_arr[$v['hardware_id']]=$v;
            }
            setcache('cache_hardware', $hardwareid_arr);
        }
        return $hardwareid_arr;
    }

    public function ajax_versions($id){
        if(!$id){
            exit(json_encode(array('status'=>false,'tips'=>'参数错误')));
        }
        $version_content = $this->Versions_list_model->get_one(array('id'=>$id),'version_content');
        if($version_content){
            exit(json_encode(array('status'=>true,'data'=>htmlspecialchars($version_content['version_content']))));
        }else{
            exit(json_encode(array('status'=>false,'tips'=>'查找失败')));
        }
    }

}