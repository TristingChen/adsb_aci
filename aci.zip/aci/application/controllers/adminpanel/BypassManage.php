<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class BypassManage extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Bypass_config_model','Station_model','App_model','All_xml_model','Xml_basic_config_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  to_name like '%{$keyword}%'";
        }
        $where = implode('and',$where_arr);
        $fresh_xml_data = $this->All_xml_model->get_one(array('kind'=>3,'is_old'=>0),'id');

        $data_list = $this->Bypass_config_model->listinfo($where,'*',$orderby , $page_no, $this->Bypass_config_model->page_size,'',$this->Bypass_config_model->page_size,page_list_url('adminpanel/bypassManage/lists',true));
        $main_swtich = $this->App_model->get_one('app_id=8','main_switch');
        // var_dump($main_swtich);exit;
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Bypass_config_model->pages,'keyword'=>$keyword,'fresh_xml_data'=>$fresh_xml_data,'require_js'=>true,'main_swtich'=>$main_swtich));
    }

    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['to_name'] = isset($_POST["to_name"])?trim(safe_replace($_POST["to_name"])):exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            if($_arr['to_name']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
             $_arr['cast_type'] = isset($_POST["cast_type"])?trim(safe_replace($_POST["cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            if($_arr['cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            $_arr['in_work_option'] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            if($_arr['in_work_option']=='')exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            $_arr['to_ip'] = isset($_POST["to_ip"])?trim(safe_replace($_POST["to_ip"])):exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            if($_arr['to_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            $_arr['to_port'] = isset($_POST["to_port"])?trim(safe_replace($_POST["to_port"])):exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            if($_arr['to_port']=='')exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            $_arr['interface_ip'] = isset($_POST["interface_ip"])?trim(safe_replace($_POST["interface_ip"])):exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));
            if($_arr['interface_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));

            /*$_arr['program_start_dir'] = isset($_POST["program_start_dir"])?trim(safe_replace($_POST["program_start_dir"])):exit(json_encode(array('status'=>false,'tips'=>'程序启动目录不得为空')));
            if($_arr['program_start_dir']=='')exit(json_encode(array('status'=>false,'tips'=>'程序启动目录不得为空')));
            $_arr['program_log_dir'] = isset($_POST["program_log_dir"])?trim(safe_replace($_POST["program_log_dir"])):exit(json_encode(array('status'=>false,'tips'=>'日志目录不得为空')));
            if($_arr['program_log_dir']=='')exit(json_encode(array('status'=>false,'tips'=>'日志目录不得为空')));
          
            $_arr['program_log_degree'] = isset($_POST["program_log_degree"])?trim(safe_replace($_POST["program_log_degree"])):exit(json_encode(array('status'=>false,'tips'=>'日志级别不得为空')));
            if($_arr['program_log_degree']=='')exit(json_encode(array('status'=>false,'tips'=>'日志级别不得为空')));

            $_arr['is_master'] = isset($_POST["is_master"])?trim(safe_replace($_POST["is_master"])):exit(json_encode(array('status'=>false,'tips'=>'是否主用不得为空')));
            if($_arr['is_master']=='')exit(json_encode(array('status'=>false,'tips'=>'是否主用不得为空')));

            $_arr['time_out'] = isset($_POST["time_out"])?trim(safe_replace($_POST["time_out"])):exit(json_encode(array('status'=>false,'tips'=>'心跳包超时周期不得为空')));
            if($_arr['time_out']=='')exit(json_encode(array('status'=>false,'tips'=>'心跳包超时周期不得为空')));
            $_arr['receive_watch_ip'] = isset($_POST["receive_watch_ip"])?trim(safe_replace($_POST["receive_watch_ip"])):exit(json_encode(array('status'=>false,'tips'=>'接收监控消息ip不得为空')));
            if($_arr['receive_watch_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'接收监控消息ip不得为空')));
            $_arr['receive_watch_port'] = isset($_POST["receive_watch_port"])?trim(safe_replace($_POST["receive_watch_port"])):exit(json_encode(array('status'=>false,'tips'=>'接收接口ip不得为空')));
            if($_arr['receive_watch_port']=='')exit(json_encode(array('status'=>false,'tips'=>'接收接口ip不得为空')));

            $_arr['receive_cast_type'] = isset($_POST["receive_cast_type"])?trim(safe_replace($_POST["receive_cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));
            if($_arr['receive_cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));

            $_arr['send_watch_ip'] = isset($_POST["send_watch_ip"])?trim(safe_replace($_POST["send_watch_ip"])):exit(json_encode(array('status'=>false,'tips'=>'发送监控消息ip不得为空')));
            if($_arr['send_watch_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'发送监控消息ip不得为空')));

            $_arr['send_watch_port'] = isset($_POST["send_watch_port"])?trim(safe_replace($_POST["send_watch_port"])):exit(json_encode(array('status'=>false,'tips'=>'发送监控消息端口不得为空')));
            if($_arr['send_watch_port']=='')exit(json_encode(array('status'=>false,'tips'=>'发送监控消息端口不得为空')));

            $_arr['send_ip'] = isset($_POST["send_ip"])?trim(safe_replace($_POST["send_ip"])):exit(json_encode(array('status'=>false,'tips'=>'发送接口ip不得为空')));
            if($_arr['send_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'发送接口ip不得为空')));

            $_arr['send_cast_type'] = isset($_POST["send_cast_type"])?trim(safe_replace($_POST["send_cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));
            if($_arr['send_cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));

            $_arr['send_cycle'] = isset($_POST["send_cycle"])?trim(safe_replace($_POST["send_cycle"])):exit(json_encode(array('status'=>false,'tips'=>'数据发送周期不得为空')));
            if($_arr['send_cycle']=='')exit(json_encode(array('status'=>false,'tips'=>'数据发送周期不得为空')));     */
            

            $station_ids = $this->input->post('station_ids');          
            $remark = trim(safe_replace($_POST["remark"]));
            $_arr['remark'] = $remark;
            if(!empty($station_ids)){
                $station_ids_str = implode(',', $station_ids);
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'基站不得为空')));
            }
            $_arr['dateline'] = time();
            $_arr['station_ids'] = $station_ids_str;
            $new_id = $this->Bypass_config_model->insert($_arr);
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $station_data = $this->Station_model->tables_select('is_del =0','t_sys_station.station_id,station_name');
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_list'=>$this->Bypass_config_model->default_info(),'station_data'=>$station_data));
        }
    }

    function edit($id=0)
    {
        $id = intval($id);
        $data_info =$this->Bypass_config_model->get_one(array('id'=>$id));
        if($this->input->is_ajax_request())
        {
             //接收POST参数
            $_arr['to_name'] = isset($_POST["to_name"])?trim(safe_replace($_POST["to_name"])):exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            if($_arr['to_name']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
             $_arr['cast_type'] = isset($_POST["cast_type"])?trim(safe_replace($_POST["cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            if($_arr['cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'传输方式不得为空')));
            $_arr['in_work_option'] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            if($_arr['in_work_option']=='')exit(json_encode(array('status'=>false,'tips'=>'通道状态不得为空')));
            $_arr['to_ip'] = isset($_POST["to_ip"])?trim(safe_replace($_POST["to_ip"])):exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            if($_arr['to_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'目标ip不得为空')));
            $_arr['to_port'] = isset($_POST["to_port"])?trim(safe_replace($_POST["to_port"])):exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            if($_arr['to_port']=='')exit(json_encode(array('status'=>false,'tips'=>'目标端口不得为空')));
            $_arr['interface_ip'] = isset($_POST["interface_ip"])?trim(safe_replace($_POST["interface_ip"])):exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));
            if($_arr['interface_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'接口ip不得为空')));

            /*$_arr['program_start_dir'] = isset($_POST["program_start_dir"])?trim(safe_replace($_POST["program_start_dir"])):exit(json_encode(array('status'=>false,'tips'=>'程序启动目录不得为空')));
            if($_arr['program_start_dir']=='')exit(json_encode(array('status'=>false,'tips'=>'程序启动目录不得为空')));
            $_arr['program_log_dir'] = isset($_POST["program_log_dir"])?trim(safe_replace($_POST["program_log_dir"])):exit(json_encode(array('status'=>false,'tips'=>'日志目录不得为空')));
            if($_arr['program_log_dir']=='')exit(json_encode(array('status'=>false,'tips'=>'日志目录不得为空')));
          
            $_arr['program_log_degree'] = isset($_POST["program_log_degree"])?trim(safe_replace($_POST["program_log_degree"])):exit(json_encode(array('status'=>false,'tips'=>'日志级别不得为空')));
            if($_arr['program_log_degree']=='')exit(json_encode(array('status'=>false,'tips'=>'日志级别不得为空')));

            $_arr['is_master'] = isset($_POST["is_master"])?trim(safe_replace($_POST["is_master"])):exit(json_encode(array('status'=>false,'tips'=>'是否主用不得为空')));
            if($_arr['is_master']=='')exit(json_encode(array('status'=>false,'tips'=>'是否主用不得为空')));

            $_arr['time_out'] = isset($_POST["time_out"])?trim(safe_replace($_POST["time_out"])):exit(json_encode(array('status'=>false,'tips'=>'心跳包超时周期不得为空')));
            if($_arr['time_out']=='')exit(json_encode(array('status'=>false,'tips'=>'心跳包超时周期不得为空')));
            $_arr['receive_watch_ip'] = isset($_POST["receive_watch_ip"])?trim(safe_replace($_POST["receive_watch_ip"])):exit(json_encode(array('status'=>false,'tips'=>'接收监控消息ip不得为空')));
            if($_arr['receive_watch_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'接收监控消息ip不得为空')));
            $_arr['receive_watch_port'] = isset($_POST["receive_watch_port"])?trim(safe_replace($_POST["receive_watch_port"])):exit(json_encode(array('status'=>false,'tips'=>'接收接口ip不得为空')));
            if($_arr['receive_watch_port']=='')exit(json_encode(array('status'=>false,'tips'=>'接收接口ip不得为空')));

            $_arr['receive_cast_type'] = isset($_POST["receive_cast_type"])?trim(safe_replace($_POST["receive_cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));
            if($_arr['receive_cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));

            $_arr['send_watch_ip'] = isset($_POST["send_watch_ip"])?trim(safe_replace($_POST["send_watch_ip"])):exit(json_encode(array('status'=>false,'tips'=>'发送监控消息ip不得为空')));
            if($_arr['send_watch_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'发送监控消息ip不得为空')));

            $_arr['send_watch_port'] = isset($_POST["send_watch_port"])?trim(safe_replace($_POST["send_watch_port"])):exit(json_encode(array('status'=>false,'tips'=>'发送监控消息端口不得为空')));
            if($_arr['send_watch_port']=='')exit(json_encode(array('status'=>false,'tips'=>'发送监控消息端口不得为空')));

            $_arr['send_ip'] = isset($_POST["send_ip"])?trim(safe_replace($_POST["send_ip"])):exit(json_encode(array('status'=>false,'tips'=>'发送接口ip不得为空')));
            if($_arr['send_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'发送接口ip不得为空')));

            $_arr['send_cast_type'] = isset($_POST["send_cast_type"])?trim(safe_replace($_POST["send_cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));
            if($_arr['send_cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'数据发送方式不得为空')));

            $_arr['send_cycle'] = isset($_POST["send_cycle"])?trim(safe_replace($_POST["send_cycle"])):exit(json_encode(array('status'=>false,'tips'=>'数据发送周期不得为空')));
            if($_arr['send_cycle']=='')exit(json_encode(array('status'=>false,'tips'=>'数据发送周期不得为空')));   */  

            $station_ids = $this->input->post('station_ids');          
            $remark = trim(safe_replace($_POST["remark"]));
            $_arr['remark'] = $remark;
            if(!empty($station_ids)){
                $station_ids_str = implode(',', $station_ids);
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'基站不得为空')));
            }
            $_arr['dateline'] = time();
            $_arr['station_ids'] = $station_ids_str;
            $status = $this->Bypass_config_model->update($_arr,array('id'=>$id));
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $data_info['station_ids'] = explode(',', $data_info['station_ids']);
            $station_data = $this->Station_model->tables_select('is_del =0','t_sys_station.station_id,station_name');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_list'=>$data_info,'station_data'=>$station_data,'id'=>$id));
        }
    }

    function change_main_switch($val){
        $res = $this->App_model->update(array('main_switch'=>$val),array('app_id'=>8));
        echo $res;
    }

    function produce_xml(){
            $the_bypass_program = $this->Bypass_config_model->get_one('','receive_watch_ip,receive_watch_port,receive_ip,receive_cast_type,send_watch_ip,send_watch_port,send_ip,send_cast_type,send_cycle,program_start_dir,program_log_dir,program_log_degree,is_master,time_out,main_switch');  //旁路服务器的程序信息 id=8
            
            $the_bypass_program['program_name'] = 'bypasser';
            $the_bypass_program['hardware_other_name'] = 'BADP';

            if(!$the_bypass_program){
                $this->showmessage('请先添加旁路服务器程序');eixt;
            }
            $bypasses = $this->Bypass_config_model->select('','id,to_name,to_ip,to_port,interface_ip,cast_type,in_work_option,station_ids');
            if($the_bypass_program){
                $the_bypass_program['children'] = $bypasses;
            }
            $xmlpatch = BYPATH_XML_PATH.'bypasser_config.xml';
            $doc = new DOMDocument('1.0','utf-8');   
            
            $flag = false;
            if(file_exists($xmlpatch)) {   
            //备份以前的xml版本 2017_12_1_16_48
                $flag = true;
            }
            $doc -> formatOutput = true;
            $ADSB_RECV = $doc -> createElement('ADSB_RECV_CONFIG');//新建节点
            $SendData =  $doc -> createElement('SendData');
            foreach ($the_bypass_program['children'] as $key => $value) {
                //进行station_id的位置查找
                    $station_data = $this->Station_model->select('station_id in ('.$value["station_ids"].')','station_id');
                    // var_dump($station_data);exit;
                    $all_station_arr = $this->Station_model->select('','station_id');
                    $value['station_ids'] = '';
                    foreach ($all_station_arr as $k => $v) {
                        foreach ($station_data as $kk => $vv) {
                            if($vv['station_id'] == $v['station_id']){
                                $value['station_ids'] .= $k.';';
                            }
                        }
                    }
                    $target = $doc->createElement('target');
                    $target = $this->create_target_xml($doc,$target,$key,$value);
                    $SendData->appendChild($target);
             }
            $ADSB_RECV->appendChild($SendData);
            $ADSB_RECV = $this->create_only_xml($doc,$ADSB_RECV,$the_bypass_program);
            $doc->appendChild($ADSB_RECV);
            $xml_str =  $doc->saveXML();

            if($this->input->is_ajax_request()){
                create_dir(BYPATH_XML_PATH);
                $update_xml_file = 'bypasser_config_'.date('Y_m_d_H_i',time()).'.xml';
                $kind_id = $this->Xml_basic_config_model->get_one(array('name'=>'旁路配置文件','is_del'=>0),'id');
                if(!$kind_id){
                    exit(json_encode(array('status'=>false,'tips'=>'请先进行旁路配置文件服务器的配置')));
                }
                $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'bypasser_config.xml\'','id');
                $res = $this->All_xml_model->xml_produce($xml_id_arr,$update_xml_file,'bypasser_config.xml',$kind_id['id'],BYPATH_XML_PATH,'旁路配置文件');
                $operation_data= $this->operation_data;
                $operation_data['dateline'] = time();
                if($flag){
                    $operation_data['operate_explain'] = '生成新的旁路配置文件并将原有的配置文件修改为'.$update_xml_file;
                }else{
                    $operation_data['operate_explain'] = '生成新的旁路配置文件';
                }
                if($res){
                     if($flag){
                        rename($xmlpatch, BYPATH_XML_PATH.$update_xml_file);
                    }
                    $doc->save($xmlpatch);
                    $operation_data['is_success'] = 1;
                    $operation_data['status_explain'] = '信息新增成功';
                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>true,'tips'=>'文件生成成功')));
                }else {
                    $operation_data['is_success'] = 0;
                    $operation_data['status_explain'] = '信息新增失败';
                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>false,'tips'=>'文件生成失败')));
                }
            }else{
                $this->view('produce_xml',array('xml_data'=>htmlentities($xml_str),'require_js'=>true));
            }

    }

     //删除
     function delete($id){
        $id = intval($id);
        $del_res = $this->Bypass_config_model->delete('id='.$id);
        if($del_res){
              $this->showmessage('删除成功');
        }else{
              $this->showmessage('删除失败');
        }
     }


    //生成基站的_target_xml文件
    private function create_only_xml($doc,$ADSB_RECV,$data_list){
            $RecvMonitorInfo = $doc -> createElement('RecvMonitorInfo');
            $recvIp = $doc -> createElement('recvIp');
            $recvIp_text = $doc->createTextNode($data_list['receive_watch_ip']);
            $recvIp->appendChild($recvIp_text);

            $recvPort = $doc -> createElement('recvPort');
            $recvPort_text = $doc->createTextNode($data_list['receive_watch_port']);
            $recvPort->appendChild($recvPort_text);

            $interface = $doc -> createElement('interface');
            $interface_text = $doc->createTextNode($data_list['receive_ip']);
            $interface->appendChild($interface_text);

            $recvCast = $doc -> createElement('recvCast');
            $recvCast_text = $doc->createTextNode($data_list['receive_cast_type']);
            $recvCast->appendChild($recvCast_text);
            $RecvMonitorInfo->appendChild($recvIp);
            $RecvMonitorInfo->appendChild($recvPort);
            $RecvMonitorInfo->appendChild($interface);
            $RecvMonitorInfo->appendChild($recvCast);

            $SendMonitorInfo = $doc -> createElement('SendMonitorInfo');
            $monitorHostIp = $doc -> createElement('monitorHostIp');
            $monitorHostIp_text = $doc->createTextNode($data_list['send_watch_ip']);
            $monitorHostIp->appendChild($monitorHostIp_text);

            $sendPort = $doc -> createElement('sendPort');
            $sendPort_text = $doc->createTextNode($data_list['send_watch_port']);
            $sendPort->appendChild($sendPort_text);

            $interface = $doc -> createElement('interface');
            $interface_text = $doc->createTextNode($data_list['send_ip']);
            $interface->appendChild($interface_text);

            $sendCast = $doc -> createElement('sendCast');
            $sendCast_text = $doc->createTextNode($data_list['send_cast_type']);
            $sendCast->appendChild($sendCast_text);

            $sendCycle = $doc -> createElement('sendCycle');
            $sendCycle_text = $doc->createTextNode($data_list['send_cycle']);
            $sendCycle->appendChild($sendCycle_text);

            $SendMonitorInfo->appendChild($monitorHostIp);
            $SendMonitorInfo->appendChild($sendPort);
            $SendMonitorInfo->appendChild($interface);
            $SendMonitorInfo->appendChild($sendCast);
            $SendMonitorInfo->appendChild($sendCycle);

            $StartupParameter = $doc -> createElement('StartupParameter');
            $appName = $doc -> createElement('appName');
            $appName_text = $doc->createTextNode($data_list['program_name']);
            $appName->appendChild($appName_text);

            $moduleName = $doc -> createElement('moduleName');
            $moduleName_text = $doc->createTextNode($data_list['hardware_other_name']);
            $moduleName->appendChild($moduleName_text);

            $startUpPath = $doc -> createElement('startUpPath');
            $startUpPath_text = $doc->createTextNode($data_list['program_start_dir']);
            $startUpPath->appendChild($startUpPath_text);

            $logPath = $doc -> createElement('logPath');
            $logPath_text = $doc->createTextNode($data_list['program_log_dir']);
            $logPath->appendChild($logPath_text);

            $logLevel = $doc -> createElement('logLevel');
            $logLevel_text = $doc->createTextNode($data_list['program_log_degree']);
            $logLevel->appendChild($logLevel_text);

            $isMaster = $doc -> createElement('isMaster');
            $isMaster_text = $doc->createTextNode($data_list['is_master']);
            $isMaster->appendChild($isMaster_text);

            $timeOut = $doc -> createElement('timeOut');
            $timeOut_text = $doc->createTextNode($data_list['time_out']);
            $timeOut->appendChild($timeOut_text);

            $mainSwitch = $doc -> createElement('mainSwitch');
            $mainSwitch_text = $doc->createTextNode($data_list['main_switch']);
            $mainSwitch->appendChild($mainSwitch_text);
            $StartupParameter->appendChild($appName);
            $StartupParameter->appendChild($moduleName);
            $StartupParameter->appendChild($startUpPath);
            $StartupParameter->appendChild($logPath);
            $StartupParameter->appendChild($logLevel);
            $StartupParameter->appendChild($isMaster);
            $StartupParameter->appendChild($timeOut);
            $StartupParameter->appendChild($mainSwitch);
            

            $ADSB_RECV->appendChild($RecvMonitorInfo);
            $ADSB_RECV->appendChild($SendMonitorInfo);
            $ADSB_RECV->appendChild($StartupParameter);
            return $ADSB_RECV;
        }

    //生成基站的_target_xml文件
    private function create_target_xml($doc,$target,$key,$value){
            $id = $doc -> createElement('id');
            $id_text = $doc->createTextNode($value['id']);
            $id->appendChild($id_text);

            $note = $doc -> createElement('note');
            $note_text = $doc->createTextNode($value['to_name']);
            $note->appendChild($note_text);

            $sendIp = $doc -> createElement('sendIp');
            $sendIp_text = $doc->createTextNode($value['to_ip']);
            $sendIp->appendChild($sendIp_text);

            $sendPort = $doc -> createElement('sendPort');
            $sendPort_text = $doc->createTextNode($value['to_port']);
            $sendPort->appendChild($sendPort_text);

            $interface = $doc -> createElement('interface');
            $interface_text = $doc->createTextNode($value['interface_ip']);
            $interface->appendChild($interface_text);

            $sendCast = $doc -> createElement('sendCast');
            $sendCast_text = $doc->createTextNode($value['cast_type']);
            $sendCast->appendChild($sendCast_text);

            $switch = $doc -> createElement('switch');
            $switch_text = $doc->createTextNode($value['in_work_option']);
            $switch->appendChild($switch_text);

            $idList = $doc -> createElement('idList');
            $idList_text = $doc->createTextNode($value['station_ids']);
            $idList->appendChild($idList_text);

            $target->appendChild($id);
            $target->appendChild($note);
            $target->appendChild($sendIp);
            $target->appendChild($sendPort);
            $target->appendChild($interface);
            $target->appendChild($sendCast);
            $target->appendChild($switch);
            $target->appendChild($idList);
            return $target;
        }
}
