<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class SystemAlertInfo extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('System_alert_info_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  data_center_name like '%{$keyword}%'";
        }

        $where = implode('and',$where_arr);
        $data_list = $this->System_alert_info_model->listinfo($where,'*',$orderby , $page_no, $this->System_alert_info_model->page_size,'',$this->System_alert_info_model->page_size,page_list_url('adminpanel/dataExport/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->System_alert_info_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    function edit($id=0)
    {
        $id = intval($id);
        $data_info =$this->System_alert_info_model->get_one(array('id'=>$id));
        if($this->input->is_ajax_request())
        {
             //接收POST参数
           //接收POST参数
            $_arr['cpu_alert_value'] = isset($_POST["cpu_alert_value"])?trim(safe_replace($_POST["cpu_alert_value"])):'';
            if($_arr['cpu_alert_value']=='')exit(json_encode(array('status'=>false,'tips'=>'CPU告警值不得为空')));

            $_arr['memory_alert_value'] = isset($_POST["memory_alert_value"])?trim(safe_replace($_POST["memory_alert_value"])):'';
            if($_arr['memory_alert_value']=='')exit(json_encode(array('status'=>false,'tips'=>'内存告警值不得为空')));
            
            $_arr['disk_alert_value'] = isset($_POST["disk_alert_value"])?trim(safe_replace($_POST["disk_alert_value"])):'';
            if($_arr['disk_alert_value']=='')exit(json_encode(array('status'=>false,'tips'=>'内存告警值不得为空')));

            $_arr['NIC_recv_min_value'] = isset($_POST["NIC_recv_min_value"])?trim(safe_replace($_POST["NIC_recv_min_value"])):0.0;

            $_arr['NIC_recv_max_value'] = isset($_POST["NIC_recv_max_value"])?trim(safe_replace($_POST["NIC_recv_max_value"])):102400;

            $_arr['NIC_send_min_value'] = isset($_POST["NIC_send_min_value"])?trim(safe_replace($_POST["NIC_send_min_value"])):0.0;

            $_arr['NIC_send_max_value'] = isset($_POST["NIC_send_max_value"])?trim(safe_replace($_POST["NIC_send_max_value"])):102400;

            $status = $this->System_alert_info_model->update($_arr,array('id'=>$id));
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_list'=>$data_info,'id'=>$id));
        }
    }


}
