<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-13
 * Time: 下午3:26
 * To change this template use File | Settings | File Templates.
 */
class TrackAlert extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Track_alert_model','Track_alert_tactics_model','App_model','Track_config_model','All_xml_model','Xml_basic_config_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function lists($page_no=1)
    {
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "concat(priority,track_addr,track_id,track_source_station) like '%{$keyword}%'";
        }
        $where = implode(" and ",$where_arr);
        $data_list = $this->Track_alert_model->listinfo($where,'*',$orderby , $page_no, $this->Track_alert_model->page_size,'',$this->Track_alert_model->page_size,page_list_url('adminpanel/alert/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Track_alert_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    function choose($page_no=1)
    {
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "concat(priority,alert_app,alert_time) like '%{$keyword}%'";
        }
        $fresh_xml_data = $this->All_xml_model->get_one(array('kind'=>5,'is_old'=>0),'id');
        $where = implode(" and ",$where_arr);
        $data_list = $this->Track_config_model->listinfo($where,'*',$orderby , $page_no, $this->Track_config_model->page_size,'',$this->Track_config_model->page_size,page_list_url('adminpanel/alert/setting',true));
        $this->view('choose',array('data_list'=>$data_list,'pages'=>$this->Track_config_model->pages,'keyword'=>$keyword,'require_js'=>true,'fresh_xml_data'=>$fresh_xml_data));
    }

    /**
     * 新增数据
     * @param AJAX POST
     * @return void
     */
    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
			$_arr['chkDrationMicroSec'] = isset($_POST["chkDrationMicroSec"])?(trim(safe_replace($_POST["chkDrationMicroSec"]))*1000000):exit(json_encode(array('status'=>false,'tips'=>'请输入数据质量统计周期')));
            if($_arr['chkDrationMicroSec']=='')exit(json_encode(array('status'=>false,'tips'=>'请输入数据质量统计周期')));			
			/*$_arr['fuserDataVersion'] = isset($_POST["fuserDataVersion"])?trim(safe_replace($_POST["fuserDataVersion"])):exit(json_encode(array('status'=>false,'tips'=>'融合数据版本不能为空')));
            if($_arr['fuserDataVersion']=='')exit(json_encode(array('status'=>false,'tips'=>'融合数据版本不能为空')));*/
			$_arr['maxSpeed'] = isset($_POST["maxSpeed"])?trim(safe_replace($_POST["maxSpeed"])):exit(json_encode(array('status'=>false,'tips'=>'航空器最大速度不能为空')));
            if($_arr['maxSpeed']=='')exit(json_encode(array('status'=>false,'tips'=>'航空器最大速度不能为空')));
			
            $_arr['disappearTimeSec'] = isset($_POST["disappearTimeSec"])?trim(safe_replace($_POST["disappearTimeSec"])):exit(json_encode(array('status'=>false,'tips'=>'判断航迹消失时间不能为空')));
            if($_arr['disappearTimeSec']=='')exit(json_encode(array('status'=>false,'tips'=>'判断航迹消失时间不能为空')));
            $_arr['inJumpTimeSec'] = isset($_POST["inJumpTimeSec"])?trim(safe_replace($_POST["inJumpTimeSec"])):exit(json_encode(array('status'=>false,'tips'=>'判断位置或高度发生跳变时间不能为空')));
            if($_arr['inJumpTimeSec']=='')exit(json_encode(array('status'=>false,'tips'=>'判断位置或高度发生跳变时间不能为空')));
			$_arr['jumpPositionDistance'] = isset($_POST["jumpPositionDistance"])?trim(safe_replace($_POST["jumpPositionDistance"])):exit(json_encode(array('status'=>false,'tips'=>'判断位置跳变距离不能为空')));
            if($_arr['jumpPositionDistance']=='')exit(json_encode(array('status'=>false,'tips'=>'判断位置跳变距离不能为空')));
            $_arr['jumpHeightDistance'] = isset($_POST["jumpHeightDistance"])?trim(safe_replace($_POST["jumpHeightDistance"])):exit(json_encode(array('status'=>false,'tips'=>'判断高度跳变值不能为空')));
            if($_arr['jumpHeightDistance']=='')exit(json_encode(array('status'=>false,'tips'=>'判断高度跳变值不能为空')));
			
            $_arr['timeDelay'] = isset($_POST["timeDelay"])?trim(safe_replace($_POST["timeDelay"])):exit(json_encode(array('status'=>false,'tips'=>'判断数据延时时间不能为空')));
            if($_arr['timeDelay']=='')exit(json_encode(array('status'=>false,'tips'=>'判断数据延时时间不能为空')));			
			
            //$new_id = $this->Track_alert_tactics_model->insert($_arr);
            $new_id = $this->Track_config_model->insert($_arr);
            $this->_cache_alert_stactics();
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_info'=>$this->Track_alert_tactics_model->default_info()));
        }
    }

    /**
     * 删除单个数据
     * @param int id
     * @return void
     */
    function delete_one($id=0)
    {
        $id = intval($id);
        $data_info =$this->Track_alert_tactics_model->get_one(array('alert_set_id'=>$id));
        if(!$data_info)$this->showmessage('信息不存在');
        $status = $this->Track_alert_tactics_model->delete(array('alert_set_id'=>$id));
        $this->_cache_alert_stactics();
        if($status)
        {
            $this->showmessage('删除成功');
        }else{
            $this->showmessage('删除失败');
        }
    }



    /**
     * 修改数据
     * @param int id
     * @return void
     */
    function edit($id=0)
    {
        $id = intval($id);

        $data_info =$this->Track_config_model->get_one(array('id'=>$id));
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            if(!$data_info)exit(json_encode(array('status'=>false,'tips'=>'信息不存在')));
            //接收POST参数
			$_arr['chkDrationMicroSec'] = isset($_POST["chkDrationMicroSec"])?(trim(safe_replace($_POST["chkDrationMicroSec"]))*1000000):exit(json_encode(array('status'=>false,'tips'=>'请输入数据质量统计周期')));
            if($_arr['chkDrationMicroSec']=='')exit(json_encode(array('status'=>false,'tips'=>'请输入数据质量统计周期')));			
			/*$_arr['fuserDataVersion'] = isset($_POST["fuserDataVersion"])?trim(safe_replace($_POST["fuserDataVersion"])):exit(json_encode(array('status'=>false,'tips'=>'融合数据版本不能为空')));
            if($_arr['fuserDataVersion']=='')exit(json_encode(array('status'=>false,'tips'=>'融合数据版本不能为空')));*/
			$_arr['maxSpeed'] = isset($_POST["maxSpeed"])?trim(safe_replace($_POST["maxSpeed"])):exit(json_encode(array('status'=>false,'tips'=>'航空器最大速度不能为空')));
            if($_arr['maxSpeed']=='')exit(json_encode(array('status'=>false,'tips'=>'航空器最大速度不能为空')));
            $_arr['disappearTimeSec'] = isset($_POST["disappearTimeSec"])?trim(safe_replace($_POST["disappearTimeSec"])):exit(json_encode(array('status'=>false,'tips'=>'策略名不能为空')));
            if($_arr['disappearTimeSec']=='')exit(json_encode(array('status'=>false,'tips'=>'判断航迹消失时间不能为空')));
            $_arr['inJumpTimeSec'] = isset($_POST["inJumpTimeSec"])?trim(safe_replace($_POST["inJumpTimeSec"])):exit(json_encode(array('status'=>false,'tips'=>'判断位置或高度发生跳变时间不能为空')));
            if($_arr['inJumpTimeSec']=='')exit(json_encode(array('status'=>false,'tips'=>'判断位置或高度发生跳变时间不能为空')));
			$_arr['jumpPositionDistance'] = isset($_POST["jumpPositionDistance"])?trim(safe_replace($_POST["jumpPositionDistance"])):exit(json_encode(array('status'=>false,'tips'=>'判断位置跳变距离不能为空')));
            if($_arr['jumpPositionDistance']=='')exit(json_encode(array('status'=>false,'tips'=>'判断位置跳变距离不能为空')));
            $_arr['jumpHeightDistance'] = isset($_POST["jumpHeightDistance"])?trim(safe_replace($_POST["jumpHeightDistance"])):exit(json_encode(array('status'=>false,'tips'=>'判断高度跳变值不能为空')));
            if($_arr['jumpHeightDistance']=='')exit(json_encode(array('status'=>false,'tips'=>'判断高度跳变值不能为空')));
			
			$_arr['timeDelay'] = isset($_POST["timeDelay"])?trim(safe_replace($_POST["timeDelay"])):exit(json_encode(array('status'=>false,'tips'=>'判断数据延时时间不能为空')));
            if($_arr['timeDelay']=='')exit(json_encode(array('status'=>false,'tips'=>'判断数据延时时间不能为空')));
            
			//$status = $this->Track_alert_tactics_model->update($_arr,array('tactics_id'=>$id));
			$status = $this->Track_config_model->update($_arr,array('id'=>$id));

            //$this->_cache_alert_stactics();
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info));
        }
    }

    /**
     * 策略缓存
     */
    private function _cache_alert_stactics() {
        $infos = $this->Track_alert_tactics_model->select('',  '*', '', 'tactics_id ASC');
        $tacticid_arr=array();
        if($infos) {
            foreach($infos as $k=>$v){
                $tacticid_arr[$v['tactics_id']]=$v;
            }
            setcache('cache_alert_tactics', $tacticid_arr);
        }
        return $tacticid_arr;
    }

        function produce_xml(){

            $data_config = $this->Track_config_model->get_one();  //数据输出基础数据
            if(!$data_config){
                $this->showmessage('请先进行基础参数配置');
            }

            $data_list = $this->Track_alert_tactics_model->select();
            $xmlpatch = QUALITY_STATICSTICIAN_XML_PATH.'quality_staticstician_config.xml';
            $doc = new DOMDocument('1.0','utf-8');   
            $flag = false;
            if(file_exists($xmlpatch)) {   
            //备份以前的xml版本 2017_12_1_16_48
                $flag = true;
            }
            $doc -> formatOutput = true;
            $program = $doc -> createElement('program');//新建节点
            $program = $this->create_config_xml($doc,$program,$data_config);
			/*
            $feature = $doc->createElement('feature');
            foreach ($data_list as $key => $value) {
                $feature = $this->create_only_xml($doc,$feature,$value);
            }
            $program->appendChild($feature);
			*/
            $doc->appendChild($program);
            $xml_str =  $doc->saveXML();

            if($this->input->is_ajax_request()){
                create_dir(QUALITY_STATICSTICIAN_XML_PATH);
                if($flag){
                    $update_xml_file = 'quality_staticstician_config_'.date('Y_m_d_H_i',time()).'.xml';
                    $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'quality_staticstician_config.xml\'','id');
                    if($xml_id_arr){
                        $this->All_xml_model->update(array('xml_name'=>$update_xml_file,'is_old'=>1),array('id'=>$xml_id_arr['id']));
                    }
                    rename($xmlpatch, QUALITY_STATICSTICIAN_XML_PATH.$update_xml_file);
                }
                $xml_res = $doc->save($xmlpatch);
                if($xml_res){
                    $kind_id = $this->Xml_basic_config_model->get_one(array('name'=>'质量统计配置文件','is_del'=>0),'id');
                    if(!$kind_id){
                        exit(json_encode(array('status'=>false,'tips'=>'请先进行基站配置文件服务器的配置')));
                    }
                    $insert_data['xml_name'] = 'quality_staticstician_config.xml';
                    $insert_data['dateline'] = time();
                    $insert_data['kind'] = $kind_id['id'];
                    $insert_data['xml_path'] = QUALITY_STATICSTICIAN_XML_PATH;
                    $insert_data['config_name'] = '质量统计配置文件';
                    $res = $this->All_xml_model->insert($insert_data);
                    if($res){
                        exit(json_encode(array('status'=>true,'tips'=>'文件生成失败')));
                        
                    }else {
                        exit(json_encode(array('status'=>false,'tips'=>'文件生成成功')));
                    }
                }else {
                    $this->showmessage('生成xml失败');
                }
            }else{
                $this->view('produce_xml',array('xml_data'=>htmlentities($xml_str),'require_js'=>true));
            }

    }
    //生成输入数据的基础文件
    private function create_config_xml($doc,$program,$data_config){
            $receives = $doc -> createElement('receives');

            $channel = $doc -> createElement('channel');
            $channel->setAttribute('id','0');
                $addr = $doc -> createElement('addr');
                    $interface = $doc -> createElement('ip');
                    $interface_text = $doc->createTextNode($data_config['channel_a_interface']);
                    $interface->appendChild($interface_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_config['channel_a_port']);
                    $port->appendChild($port_text);
                $addr->appendChild($interface);
                $addr->appendChild($port);
            $channel->appendChild($addr);
            $receives->appendChild($channel);

            $channel = $doc -> createElement('channel');
            $channel->setAttribute('id','1');
                $addr = $doc -> createElement('addr');
                    $interface = $doc -> createElement('ip');
                    $interface_text = $doc->createTextNode($data_config['channel_b_interface']);
                    $interface->appendChild($interface_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_config['channel_b_port']);
                    $port->appendChild($port_text);
                $addr->appendChild($interface);
                $addr->appendChild($port);
            $channel->appendChild($addr);
            $receives->appendChild($channel);

            $channel = $doc -> createElement('channel');
            $channel->setAttribute('id','2');
				$version = $doc->createElement('version');
				$version_text = $doc->createTextNode($data_config['fuserDataVersion']);
				$version->appendChild($version_text);
                $addr = $doc -> createElement('addr');
                    $interface = $doc -> createElement('ip');
                    $interface_text = $doc->createTextNode($data_config['channel_c_interface']);
                    $interface->appendChild($interface_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_config['channel_c_port']);
                    $port->appendChild($port_text);
                $addr->appendChild($interface);
                $addr->appendChild($port);
				
				$addr2 = $doc -> createElement('addr2');
                    $interface = $doc -> createElement('ip');
                    $interface_text = $doc->createTextNode($data_config['channel_c_interface_2']);
                    $interface->appendChild($interface_text);
                    $port = $doc -> createElement('port');
                    $port_text = $doc->createTextNode($data_config['channel_c_port_2']);
                    $port->appendChild($port_text);
                $addr2->appendChild($interface);
                $addr2->appendChild($port);
			$channel->appendChild($version);
            $channel->appendChild($addr);
            $channel->appendChild($addr2);
            $receives->appendChild($channel);


            $log = $doc -> createElement('log');
             $path = $doc -> createElement('path');
             $path_text = $doc->createTextNode($data_config['log_path']);
             $path->appendChild($path_text);

             $level = $doc -> createElement('level');
             $level_text = $doc->createTextNode($data_config['log_level']);
             $level->appendChild($level_text);
            $log->appendChild($path);
            $log->appendChild($level);

            $path = $doc -> createElement('path');
             $outputDir = $doc -> createElement('outputDir');
             $outputDir_text = $doc->createTextNode($data_config['out_put_dir']);
             $outputDir->appendChild($outputDir_text);
             $stationCfgFile = $doc -> createElement('stationCfgFile');
             $stationCfgFile_text = $doc->createTextNode($data_config['station_config_file']);
             $stationCfgFile->appendChild($stationCfgFile_text);
             $asterix = $doc -> createElement('asterix');
             $asterix_text = $doc->createTextNode($data_config['asterix']);
             $asterix->appendChild($asterix_text);
            $path->appendChild($outputDir);
            $path->appendChild($stationCfgFile);
            $path->appendChild($asterix);


            $offLine = $doc -> createElement('offLine');
                $switch = $doc -> createElement('switch');
                $switch_text = $doc->createTextNode($data_config['offline_switch']);
                $switch->appendChild($switch_text);
                $channelId = $doc -> createElement('channelId');
                $channelId_text = $doc->createTextNode($data_config['offline_channelid']);
                $channelId->appendChild($channelId_text);
                $rate = $doc -> createElement('rate');
                $rate_text = $doc->createTextNode($data_config['offline_rate']);
                $rate->appendChild($rate_text);
                $fileDir = $doc -> createElement('fileDir');
                $fileDir_text = $doc->createTextNode($data_config['offline_dir']);
                $fileDir->appendChild($fileDir_text);
                $beginTime = $doc -> createElement('beginTime');
                $beginTime_text = $doc->createTextNode($data_config['offline_begin_time']);
                $beginTime->appendChild($beginTime_text);
                $endTime = $doc -> createElement('endTime');
                $endTime_text = $doc->createTextNode($data_config['offline_end_time']);
                $endTime->appendChild($endTime_text);
            $offLine->appendChild($switch);
            $offLine->appendChild($channelId);
            $offLine->appendChild($rate);
            $offLine->appendChild($fileDir);
            $offLine->appendChild($beginTime);
            $offLine->appendChild($endTime);

            $monitor = $doc -> createElement('monitor');
             $interval = $doc -> createElement('interval');
             $interval_text = $doc->createTextNode($data_config['interval']);
             $interval->appendChild($interval_text);

             $missCnt = $doc -> createElement('missCnt');
             $missCnt_text = $doc->createTextNode($data_config['miss_count']);
             $missCnt->appendChild($missCnt_text);

             $sendStatus = $doc -> createElement('sendStatus');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['send_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['send_port']);
                 $port->appendChild($port_text);
             $sendStatus->appendChild($ip);
             $sendStatus->appendChild($port);

             $sendHeartbeat = $doc -> createElement('sendHeartbeat');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['send_heart_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['send_heart_port']);
                 $port->appendChild($port_text);
             $sendHeartbeat->appendChild($ip);
             $sendHeartbeat->appendChild($port);

              $recvCmd = $doc -> createElement('recvCmd');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['recv_cmd_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['recv_cmd_port']);
                 $port->appendChild($port_text);
              $recvCmd->appendChild($ip);
              $recvCmd->appendChild($port);
            $monitor->appendChild($interval);
            $monitor->appendChild($missCnt);
            $monitor->appendChild($sendStatus);
            $monitor->appendChild($sendHeartbeat);
            $monitor->appendChild($recvCmd);

            $sendProblemAircraft = $doc-> createElement('sendProblemAircraft');
				 $type = $doc -> createElement('type');
                 $type_text = $doc->createTextNode($data_config['sendProblemAircraftType']);
                 $type->appendChild($type_text);
				 
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['send_problem_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['send_problem_port']);
                 $port->appendChild($port_text);
			$sendProblemAircraft->appendChild($type);
            $sendProblemAircraft->appendChild($ip);
            $sendProblemAircraft->appendChild($port);
            

            $chkDrationMicroSec = $doc-> createElement('chkDrationMicroSec');
            $chkDrationMicroSec_text = $doc->createTextNode($data_config['chkDrationMicroSec']);
            $chkDrationMicroSec->appendChild($chkDrationMicroSec_text);

            $minTrackPoints = $doc-> createElement('minTrackPoints');
            $minTrackPoints_text = $doc->createTextNode($data_config['count_min_dot']);
            $minTrackPoints->appendChild($minTrackPoints_text);

			
			$feature = $doc->createElement('feature');
			
            $maxSpeed = $doc-> createElement('maxSpeed');
            $maxSpeed_text = $doc-> createTextNode($data_config['maxSpeed']);			
            $maxSpeed->appendChild($maxSpeed_text);		
			$disappearTimeSec = $doc-> createElement('disappearTimeSec');
            $disappearTimeSec_text = $doc-> createTextNode($data_config['disappearTimeSec']);
			$disappearTimeSec->appendChild($disappearTimeSec_text);	
			$inJumpTimeSec = $doc-> createElement('inJumpTimeSec');
            $inJumpTimeSec_text = $doc-> createTextNode($data_config['inJumpTimeSec']);
			$inJumpTimeSec->appendChild($inJumpTimeSec_text);	
			$jumpPositionDistance = $doc-> createElement('jumpPositionDistance');
            $jumpPositionDistance_text = $doc-> createTextNode($data_config['jumpPositionDistance']);
			$jumpPositionDistance->appendChild($jumpPositionDistance_text);
			$jumpHeightDistance = $doc-> createElement('jumpHeightDistance');
            $jumpHeightDistance_text = $doc-> createTextNode($data_config['jumpHeightDistance']);
			$jumpHeightDistance->appendChild($jumpHeightDistance_text);
						
			$feature->appendChild($maxSpeed);
			$feature->appendChild($disappearTimeSec);
			$feature->appendChild($inJumpTimeSec);
			$feature->appendChild($jumpPositionDistance);
			$feature->appendChild($jumpHeightDistance);
						
            $program->appendChild($receives);
            $program->appendChild($log);
            $program->appendChild($path);
            $program->appendChild($offLine);
            $program->appendChild($monitor);
            $program->appendChild($sendProblemAircraft);
            $program->appendChild($chkDrationMicroSec);
            $program->appendChild($minTrackPoints);
            $program->appendChild($feature);
            return $program;
        }

   
    private function create_only_xml($doc,$feature,$value){
            $tmp_key = $doc -> createElement($value['tactics_name']);
            $tmp_key_text = $doc->createTextNode($value['min_value']);
            $tmp_key->appendChild($tmp_key_text);

            $feature->appendChild($tmp_key);
            return $feature;
        }

}