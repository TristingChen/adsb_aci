<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class WarningConfig extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Warning_config_model','Station_model'));
        $this->load->helper(array('member','auto_codeIgniter','string','socket'));
    }

    public function lists($page_no=1){
        $page_no = max(intval($page_no),1);
        $data_list = $this->Warning_config_model->tables_listinfo('t_sys_station.is_del = 0','t_sys_station.station_name,t_sys_station_warning_config.*','' , $page_no, $this->Warning_config_model->page_size,'',$this->Warning_config_model->page_size,page_list_url('adminpanel/warningConfig/lists',true));
        $warning_value_time = $this->warning_value_time();
        if($data_list){
            foreach ($data_list as $key => $value) {
                $data_list[$key]['warning_time1'] = $warning_value_time[$value['time_value1']].'--'.$warning_value_time[$value['end_time_value1']];
                $data_list[$key]['warning_time2'] = $warning_value_time[$value['time_value2']].'--'.$warning_value_time[$value['end_time_value3']];
                $data_list[$key]['warning_time3'] = $warning_value_time[$value['time_value2']].'--'.$warning_value_time[$value['end_time_value3']];
            }
        }
        $this->view('list',array('data_list'=>$data_list,'page_no'=>$page_no,'pages'=>$this->Warning_config_model->pages,'require_js'=>true));
    }

    function  add()
    {   
        

        if ($this->input->is_ajax_request()) {
            $_arr['station_id'] = $this->input->post('station_id')?$this->input->post('station_id'):exit(json_encode(array('status'=>false,'tips'=>'请选择基站')));
            $_arr['warning_switch'] = (int)$this->input->post('warning_switch') !==null ?(int)$this->input->post('warning_switch'):exit(json_encode(array('status'=>false,'tips'=>'请选择监控开启状态')));
            $_arr['time_value1'] = (int)$this->input->post('time_value1') != -1?(int)$this->input->post('time_value1'):exit(json_encode(array('status'=>false,'tips'=>'请选择开始时间一')));
            $_arr['end_time_value1'] = (int)$this->input->post('end_time_value1') != -1?(int)$this->input->post('end_time_value1'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间一')));
            $_arr['time_value2'] = (int)$this->input->post('time_value2') != -1?(int)$this->input->post('time_value2'):exit(json_encode(array('status'=>false,'tips'=>'请选择开始时间二')));
            $_arr['end_time_value2'] = (int)$this->input->post('end_time_value2') != -1?(int)$this->input->post('end_time_value2'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间二'))); 
            $_arr['time_value3'] = (int)$this->input->post('time_value3') != -1?(int)$this->input->post('time_value3'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间三')));
            $_arr['end_time_value3'] = (int)$this->input->post('end_time_value3') != -1?(int)$this->input->post('end_time_value3'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间三')));
            $_arr['value1'] = (int)$this->input->post('value1') != 0?(int)$this->input->post('value1'):exit(json_encode(array('status'=>false,'tips'=>'最小航迹数一不得为0或空')));
            $_arr['value2'] = (int)$this->input->post('value2') != 0?(int)$this->input->post('value2'):exit(json_encode(array('status'=>false,'tips'=>'最小航迹数二不得为0或空')));
            $_arr['value3'] = (int)$this->input->post('value3') != 0?(int)$this->input->post('value3'):exit(json_encode(array('status'=>false,'tips'=>'最小航迹数三不得为0或空')));
            $insert_id = $this->Warning_config_model->insert($_arr);
            if($insert_id){
               $cache_data = $this->Warning_config_model->get_one(array('station_id'=>$_arr['station_id']));
               setcache('cache_warning_config_'.$_arr['station_id'],$cache_data);
               exit(json_encode(array('status'=>true,'tips'=>'添加成功')));
            }else{
               exit(json_encode(array('status'=>false,'tips'=>'添加失败')));
            }

        }else{
            $warning_station = $this->Warning_config_model->select('','station_id');
            $had_stations = array();
            if($warning_station){
              foreach ($warning_station as $key => $value) {
                 $had_stations[$key] = $value['station_id'];
              }
            }
            $had_stations_str = implode(',', $had_stations)?implode(',', $had_stations):0;
            $rest_stations = $this->Station_model->select('is_del =0 and station_id not in ('.$had_stations_str.')','station_id,station_name');
            $warning_value_time = $this->warning_value_time();
            $this->view('edit',array('data_info'=>$this->Warning_config_model->default_info(),'rest_stations'=>$rest_stations,'warning_value_time'=>$warning_value_time,'is_edit'=>false,'require_js'=>true));
            }
    }

    function  edit($station_id)
    {   
        

        if ($this->input->is_ajax_request()) {
            $_arr['station_id'] = $this->input->post('station_id')?$this->input->post('station_id'):exit(json_encode(array('status'=>false,'tips'=>'请选择基站')));
            $_arr['warning_switch'] = (int)$this->input->post('warning_switch') !==null ?(int)$this->input->post('warning_switch'):exit(json_encode(array('status'=>false,'tips'=>'请选择监控开启状态')));
            $_arr['time_value1'] = (int)$this->input->post('time_value1') != -1?(int)$this->input->post('time_value1'):exit(json_encode(array('status'=>false,'tips'=>'请选择开始时间一')));
            $_arr['end_time_value1'] = (int)$this->input->post('end_time_value1') != -1?(int)$this->input->post('end_time_value1'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间一')));
            $_arr['time_value2'] = (int)$this->input->post('time_value2') != -1?(int)$this->input->post('time_value2'):exit(json_encode(array('status'=>false,'tips'=>'请选择开始时间二')));
            $_arr['end_time_value2'] = (int)$this->input->post('end_time_value2') != -1?(int)$this->input->post('end_time_value2'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间二'))); 
            $_arr['time_value3'] = (int)$this->input->post('time_value3') != -1?(int)$this->input->post('time_value3'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间三')));
            $_arr['end_time_value3'] = (int)$this->input->post('end_time_value3') != -1?(int)$this->input->post('end_time_value3'):exit(json_encode(array('status'=>false,'tips'=>'请选择结束时间三')));
            $_arr['value1'] = (int)$this->input->post('value1') != 0?(int)$this->input->post('value1'):exit(json_encode(array('status'=>false,'tips'=>'最小航迹数一不得为0或空')));
            $_arr['value2'] = (int)$this->input->post('value2') != 0?(int)$this->input->post('value2'):exit(json_encode(array('status'=>false,'tips'=>'最小航迹数二不得为0或空')));
            $_arr['value3'] = (int)$this->input->post('value3') != 0?(int)$this->input->post('value3'):exit(json_encode(array('status'=>false,'tips'=>'最小航迹数三不得为0或空')));
            $insert_id = $this->Warning_config_model->update($_arr,array('station_id'=>$station_id));
            if($insert_id){
               $cache_data = $this->Warning_config_model->get_one(array('station_id'=>$station_id));
               setcache('cache_warning_config_'.$station_id,$cache_data);
               exit(json_encode(array('status'=>true,'tips'=>'更新成功')));
            }else{
               exit(json_encode(array('status'=>false,'tips'=>'更新失败')));
            }

        }else{
            $data_info = $this->Warning_config_model->tables_get_one('t_sys_station_warning_config.station_id ='.$station_id.' and is_del = 0','t_sys_station.station_name,t_sys_station_warning_config.*');
            $warning_station = $this->Warning_config_model->select('','station_id');
            $had_stations = array();
            if($warning_station){
              foreach ($warning_station as $key => $value) {
                 $had_stations[$key] = $value['station_id'];
              }
            }
            $had_stations_str = implode(',', $had_stations)?implode(',', $had_stations):0;
            $rest_stations = $this->Station_model->select('is_del =0 and station_id not in ('.$had_stations_str.')','station_id,station_name');
            $warning_value_time = $this->warning_value_time();
            $this->view('edit',array('data_info'=>$data_info,'rest_stations'=>$rest_stations,'warning_value_time'=>$warning_value_time,'is_edit'=>true,'station_id'=>$station_id,'require_js'=>true));
        }
        
    }

    public function delete($station_id){
        $the_one = $this->Warning_config_model->get_one(array('station_id'=>$station_id));
        if(!$the_one){
            $this->showmessage('参数错误');
        }
        $status = $this->Warning_config_model->delete(array('station_id'=>$station_id));
        if($status){
            @setcache('cache_warning_config_'.$station_id,null);
            $this->showmessage('删除成功');

        }else {
            $this->showmessage('删除失败');
        }

    }

    private function warning_value_time(){
      return array(
        '-1'=>'请选择',
        '0'=>'当天00:00',
        '1'=>'当天01:00',
        '2'=>'当天02:00',
        '3'=>'当天03:00',
        '4'=>'当天04:00',
        '5'=>'当天05:00',
        '6'=>'当天06:00',
        '7'=>'当天07:00',
        '8'=>'当天08:00',
        '9'=>'当天09:00',
        '10'=>'当天10:00',
        '11'=>'当天11:00',
        '12'=>'当天12:00',
        '13'=>'当天13:00',
        '14'=>'当天14:00',
        '15'=>'当天15:00',
        '16'=>'当天16:00',
        '17'=>'当天17:00',
        '18'=>'当天18:00',
        '19'=>'当天19:00',
        '20'=>'当天20:00',
        '21'=>'当天21:00',
        '22'=>'当天22:00',
        '23'=>'当天23:00',
        '24'=>'次日00:00',
        '25'=>'次日01:00',
        '26'=>'次日02:00',
        '27'=>'次日03:00',
        '28'=>'次日04:00',
        '29'=>'次日05:00',
        '30'=>'次日06:00',
        '31'=>'次日07:00',
        '32'=>'次日08:00',
        '33'=>'次日09:00',
        '34'=>'次日10:00',
        '35'=>'次日11:00',
        '36'=>'次日12:00',
        '37'=>'次日13:00',
        '38'=>'次日14:00',
        '39'=>'次日15:00',
        '40'=>'次日16:00',
        '41'=>'次日17:00',
        '42'=>'次日18:00',
        '43'=>'次日19:00',
        '44'=>'次日20:00',
        '45'=>'次日21:00',
        '46'=>'次日22:00',
        '47'=>'次日23:00',
        '48'=>'次日24:00',
      );
    }

}
