<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-5-11
 * Time: 上午9:18
 * To change this template use File | Settings | File Templates.
 */
class AppDeploy extends Admin_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('App_model', 'App_status_model'));
        $this->load->model(array('App_node_model'));
        $this->load->model(array('Exchange_DstBCast_model', 'Exchange_DstMCast_model', 'Exchange_DstUCast_model'));
        $this->load->model(array('Exchange_RecvBCast_model', 'Exchange_RecvMCast_model', 'Exchange_RecvUCast_model'));
        $this->load->model(array('Exchange_Static_model', 'Exchange_Status_model'));
        $this->load->model(array('Process_input_model', 'Process_output_model', 'Process_blackOrwhite_model', 'Process_startup_parameter_model', 'Process_systemCentre_model'));
        $this->load->model(array('Publish_filepath_model', 'Publish_recvGroup_model', 'Publish_send_model'));
        $this->load->model(array('Record_recvMCast_model', 'Record_recvUCast_model', 'Record_others_model', 'Record_SendStatus_model'));
        $this->load->model(array('Replay_app_model', 'Replay_task_model'));
        $this->load->helper(array('member_helper'));
    }

    function lists($network_type=1,$app_name)
    {

    }

    function make_deploy_html($app_name)
    {

    }

    function get_table_content($app_id,$network_type)
    {
        $model = new Base_Model();
        $where = 'app_id = '.$app_id;
        $app_node = $this->App_node_model->select($where,'*');
        foreach($app_node as $k=>$v)
        {
            if(isset($v['table_name']))
            {
                $model->set_table_name($v['table_name']);
                $result = $model->select();
                foreach($result as $j=>$h)
                {

                }
            }
        }

    }

}