<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-27
 * Time: 上午10:24
 * To change this template use File | Settings | File Templates.
 */
class AtmbDataDeploy extends Admin_Controller
{

    var $method_config;

    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Exchange_DstUCast_model', 'Exchange_DstMCast_model', 'Exchange_DstBCast_model'));
        $this->load->model(array('Exchange_RecvUCast_model', 'Exchange_RecvMCast_model', 'Exchange_RecvBCast_model'));
        $this->load->model(array('Recv_cast_data_model'));
        $this->load->helper(array('member', 'auto_codeIgniter', 'string'));

        $this->method_config['upload'] = array(
            'thumb' => array('upload_size' => 1024, 'upload_file_type' => 'jpg|png|gif', 'upload_path' => 'uploadfile/user', 'upload_url' => SITE_URL . 'uploadfile/user/'),
        );
    }

    function lists($page_no = 1, $network_type = 1)
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        $data_list = array();
        $keyword = "";
        $i = 1;
        if (isset($_GET['dosubmit'])) {
            $keyword = isset($_GET['keyword']) ? safe_replace(trim($_GET['keyword'])) : '';
            if ($keyword != "") $where_arr[] = "concat(DstCastIp,DstCastPort,note) like '%{$keyword}%'";
        }
        $where[] = "NTId = " . $network_type;
        $where[] = "usetype = 0";
        $where = implode(" and ", $where_arr);
        if ($keyword == '单播' || $keyword == '') {
            $ucast_arr = $this->Exchange_DstUCast_model->select($where);
            foreach ($ucast_arr as $ucast) {
                $data_list[0]['cast_type'] = 1;
                $data_list[0]['cast_type'] = $ucast['Note'];
                $data_list[0]['cast_ip'] = $ucast['DstCastIp'];
                $data_list[0]['cast_port'] = $ucast['DstCastPort'];
                $i++;
            }
        } else if ($keyword == '组播' || $keyword == '') {
            $mcast_arr = $this->Exchange_DstMCast_model->select($where);
            foreach ($mcast_arr as $mcast) {
                $data_list[1]['cast_type'] = 2;
                $data_list[1]['cast_type'] = $mcast['Note'];
                $data_list[1]['cast_ip'] = $mcast['DstCastIp'];
                $data_list[1]['cast_port'] = $mcast['DstCastPort'];
                $i++;
            }
        } else if ($keyword == '广播' || $keyword == '') {
            $bcast_arr = $this->Exchange_DstBCast_model->select($where);
            foreach ($bcast_arr as $bcast) {
                $data_list[2]['cast_type'] = 3;
                $data_list[2]['cast_type'] = $bcast['Note'];
                $data_list[2]['cast_ip'] = $bcast['DstCastIp'];
                $data_list[2]['cast_port'] = $bcast['DstCastPort'];
                $i++;
            }
        }
        $pages = pages($i, $page_no, 20, page_list_url('adminpanel/atmbDataDeploy/lists'));
        $this->view('lists', array('data_list' => $data_list, 'pages' => $pages, 'keyword' => $keyword, 'require_js' => true));
    }

    function add($network_type=1)
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['cast_type'] = isset($_POST["cast_type"]) ? trim(safe_replace($_POST["cast_type"])) : exit(json_encode(array('status' => false, 'tips' => '请选择数据发送方式')));
            if ($_arr['cast_type'] == '') exit(json_encode(array('status' => false, 'tips' => '请选择数据发送方式')));
            $_arr['Note'] = isset($_POST["Note"]) ? trim(safe_replace($_POST["Note"])) : exit(json_encode(array('status' => false, 'tips' => '备注不能为空')));
            if ($_arr['Note'] == '') exit(json_encode(array('status' => false, 'tips' => '备注不能为空')));
            $_arr['DstCastIp'] = isset($_POST["DstCastIp"]) ? trim(safe_replace($_POST["DstCastIp"])) : exit(json_encode(array('status' => false, 'tips' => '发送目标IP不能为空')));
            if ($_arr['DstCastIp'] == '') exit(json_encode(array('status' => false, 'tips' => '发送目标IP不能为空')));
            $_arr['DstCastPort'] = isset($_POST["DstCastPort"]) ? trim(safe_replace($_POST["DstCastPort"])) : exit(json_encode(array('status' => false, 'tips' => '发送目标端口不能为空')));
            if ($_arr['DstCastPort'] == '') exit(json_encode(array('status' => false, 'tips' => '发送目标端口不能为空')));
            if ($_arr['cast_type'] == 1) {
                $new_id = $this->Exchange_DstUCast_model->insert($_arr);
            } else if ($_arr['cast_type'] == 2) {
                $new_id = $this->Exchange_DstMCast_model->insert($_arr);
            } else if ($_arr['cast_type'] == 3) {
                $new_id = $this->Exchange_DstBCast_model->insert($_arr);
            }
            if ($new_id) {
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $data_info = array(
                'Note' => "",
                'DstCastIp' => "",
                'DstCastPort' => "",
                'eth_num' => "",
                'cast_type' => 0
            );
            $recv_lists = $this->recv_data_lists();
            $this->view('edit', array('is_edit' => false, 'require_js' => true,'network_type'=>$network_type,'data_info' => $data_info,
                'recv_lists'=>$recv_lists,'page_size'=>$this->Recv_cast_data_model->page_size,'count'=>$this->Recv_cast_data_model->count()));
        }
    }

    function recv_data_lists($page_no = 1, $network_type = 1,$keyword='',$orderby='')
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        if ($keyword != "") $where_arr[] = "concat(note,RecvCastIp,Interface,RecvCastPort) like '%{$keyword}%'";
        $where_arr[] = "NTId = ".intval($network_type);
        $where = implode(" and ", $where_arr);
        $data_list = $this->Recv_cast_data_model->listinfo($where, '*', $orderby, $page_no, $this->Recv_cast_data_model->page_size, '', $this->Recv_cast_data_model->page_size, 'javascrip:void(0)');
        if($this->input->is_ajax_request())
        {
            echo json_encode($data_list);
        }else
        {
            return $data_list;
        }
    }

    function  recv_data_pages($page_no = 1, $network_type = 1,$keyword='',$orderby='')
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        if ($keyword != "") $where_arr[] = "concat(note,RecvCastIp,Interface,RecvCastPort) like '%{$keyword}%'";
        $where_arr[] = "NTId = ".intval($network_type);
        $where = implode(" and ", $where_arr);
        echo ajax_pages($this->Recv_cast_data_model->count($where),$page_no, $this->Recv_cast_data_model->page_size,'', 'get_recv_source');
    }
}