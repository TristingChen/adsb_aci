<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
class Api extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('App_model','Hardware_model'));
        $this->load->helper(array('member_helper'));
    }

    public function index(){
        return 123123123123;
    }
}