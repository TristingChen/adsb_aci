<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class PolygonsManage extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Polygons_model','Polygons_dots_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  name like '%{$keyword}%'";
        }
        $where = implode('and',$where_arr);
        $data_list = $this->Polygons_model->listinfo($where,'*',$orderby , $page_no, $this->Polygons_model->page_size,'',$this->Polygons_model->page_size,page_list_url('adminpanel/PolygonsManage/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Polygons_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'名称不得为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'名称不得为空')));
            /* $_arr['kind'] = isset($_POST["kind"])?trim(safe_replace($_POST["kind"])):exit(json_encode(array('status'=>false,'tips'=>'类型不得为空')));
            if($_arr['kind']=='')exit(json_encode(array('status'=>false,'tips'=>'类型不得为空')));*/
            // $polygons_ids_arr = $_POST["polygons_ids"];
              $longtitude_arr = $this->input->post("longtitude");
              $latitude_arr  =  $this->input->post("latitude");
              if(!$longtitude_arr || !$latitude_arr || in_array('', $longtitude_arr) ||  in_array('', $latitude_arr)){
                    exit(json_encode(array('status'=>false,'tips'=>'经维度不得有空值')));
              }
            
            $_arr['dateline'] = time();
            $min_height = isset($_POST["min_height"])?trim(safe_replace($_POST["min_height"])):exit(json_encode(array('status'=>false,'tips'=>'最小高度不得为空')));
            if($min_height=='')exit(json_encode(array('status'=>false,'tips'=>'最小高度不得为空')));
            $max_height = isset($_POST["max_height"])?trim(safe_replace($_POST["max_height"])):exit(json_encode(array('status'=>false,'tips'=>'最大高度不得为空')));
            if($max_height=='')exit(json_encode(array('status'=>false,'tips'=>'最大高度不得为空')));
            $_arr['height_list'] = $min_height.';'.$max_height;
            $_arr['flip_switch'] = isset($_POST["flip_switch"])?trim(safe_replace($_POST["flip_switch"])):exit(json_encode(array('status'=>false,'tips'=>'多边形屏蔽开关不得为空')));
            if($_arr['flip_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'多边形屏蔽开关不得为空')));

            $this->db->trans_start();            
            $insert_id = $this->Polygons_model->insert($_arr);
            $dots_arr = array();
            foreach ($longtitude_arr as $key => $value) {
                $dots_arr[$key]['longtitude'] = $value;
                $dots_arr[$key]['latitude'] = $latitude_arr[$key];
                $dots_arr[$key]['polygons_id'] = $insert_id;
            }

             $this->Polygons_dots_model->insert_batch($dots_arr);
            $this->db->trans_complete();
            if($this->db->trans_status() !== false){
                  exit(json_encode(array('status'=>true,'tips'=>'信息添加成功')));
            }else{
                  exit(json_encode(array('status'=>false,'tips'=>'信息添加失败')));
            }
         }else{
             $this->view('edit',array('data_info'=>$this->Polygons_model->default_info(),'require_js'=>true,'is_edit'=>false));
         }   
    }

    function edit($id=0)
    {
        $id = intval($id);
        $data_info =$this->Polygons_model->get_one(array('id'=>$id));
        $dots_arr = $this->Polygons_dots_model->select(array('polygons_id'=>$id));
        if($this->input->is_ajax_request())
        {
             //接收POST参数
           $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'名称不得为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'名称不得为空')));
             /*$_arr['kind'] = isset($_POST["kind"])?trim(safe_replace($_POST["kind"])):exit(json_encode(array('status'=>false,'tips'=>'类型不得为空')));
            if($_arr['kind']=='')exit(json_encode(array('status'=>false,'tips'=>'类型不得为空')));*/
            $longtitude_arr = $_POST["longtitude"];
            $latitude_arr  =  $_POST["latitude"];
            if(!empty($longtitude_arr)){
                if(in_array('', $longtitude_arr)){
                    exit(json_encode(array('status'=>false,'tips'=>'经度不得有空值')));
                }

            }else{
                exit(json_encode(array('status'=>false,'tips'=>'多边形的点与经度必填')));
            }
            

            if(!empty($latitude_arr)){
                if(in_array('', $latitude_arr)){
                    exit(json_encode(array('status'=>false,'tips'=>'纬度不得有空值')));
                }
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'多边形的点与纬度必填')));
            }
            $_arr['dateline'] = time();
            $min_height = isset($_POST["min_height"])?trim(safe_replace($_POST["min_height"])):exit(json_encode(array('status'=>false,'tips'=>'最小高度不得为空')));
            if($min_height=='')exit(json_encode(array('status'=>false,'tips'=>'最小高度不得为空')));
            $max_height = isset($_POST["max_height"])?trim(safe_replace($_POST["max_height"])):exit(json_encode(array('status'=>false,'tips'=>'最大高度不得为空')));
            if($max_height=='')exit(json_encode(array('status'=>false,'tips'=>'最大高度不得为空')));
            $_arr['height_list'] = $min_height.';'.$max_height;
            $_arr['flip_switch'] = isset($_POST["flip_switch"])?trim(safe_replace($_POST["flip_switch"])):exit(json_encode(array('status'=>false,'tips'=>'多边形屏蔽开关不得为空')));
            if($_arr['flip_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'多边形屏蔽开关不得为空')));

            $this->db->trans_start();            
            $this->Polygons_model->update($_arr,array('id'=>$id));
            $this->Polygons_dots_model->delete('polygons_id ='.$id);
            $dots_arr = array();
            foreach ($longtitude_arr as $key => $value) {
                $dots_arr[$key]['longtitude'] = $value;
                $dots_arr[$key]['latitude'] = $latitude_arr[$key];
                $dots_arr[$key]['polygons_id'] = $id;
            }
            $this->Polygons_dots_model->insert_batch($dots_arr);
            $this->db->trans_complete();
            if($this->db->trans_status() !== false){
                  exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else{
                  exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
            
        }else{
            if(!$data_info)$this->showmessage('信息不存在');
            $data_info['dots_arr'] = $dots_arr;
            $data_info['min_height'] = explode(';', $data_info['height_list'])[0];
            $data_info['max_height'] = explode(';', $data_info['height_list'])[1];
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info,'id'=>$id));
        }
    }
     //删除
     function delete($id){
        $id = intval($id);
        $this->db->trans_start();  
        $this->Polygons_model->delete('id='.$id);
        $this->Polygons_dots_model->delete('polygons_id='.$id);
        $this->db->trans_complete();
        if($this->db->trans_status() !== false){
              $this->showmessage('删除成功');
        }else{
              $this->showmessage('删除失败');
        }
     }
}
