<?php
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-11-20
 * Time: 上午10:50
 * To change this template use File | Settings | File Templates.
 */
class DataAnalyse extends Admin_Controller
{
    function __construct()
    {
        date_default_timezone_set("UTC");
        parent::__construct();
        $this->load->model(array('Station_model', 'Station_config_model', 'Track_config_model', 'Data_export_users_model', 'DataCenterInfo_model', 'Station_grade_model'));
        $this->load->helper(array('auto_codeIgniter', 'member_helper', 'socket_helper'));
    }

    function index($station_name = "", $channel_name = "", $station_id = -1, $channel_id = -1)
    {
        $this->view('index', array('require_js' => true, 'station_id' => $station_id, 'channel_id' => $channel_id,
            'station_name' => urldecode($station_name), 'channel_name' => $channel_name));
    }

    function statistics($station_name = "", $channel_name = "", $station_id = -1, $channel_id = -1)
    {
        $this->view('statistics', array('require_js' => true, 'station_id' => $station_id, 'channel_id' => $channel_id,
            'station_name' => urldecode($station_name), 'channel_name' => $channel_name));
    }

    function offline($station_id = 0, $channel_id = 0, $start_time = "", $end_time = "")
    {
        $this->view('offline', array('require_js' => true));
    }

    /*
     * 实时数据统计
     */
    function read_statistics_data($station_id = 0, $channel_id = 0)
    {
        $data_info = $this->Track_config_model->get_one(array('id' => 1));
        $time_delay = $data_info["timeDelay"];

        $date = date("Y-m-d");
        $re_arr = null;
        $file_path = STATISTICS_PATH . $channel_id . "/" . $date . "/" . STATISTICSDATA;
        $all_station_arr = $this->Station_model->select('is_del=0', 'station_id');
        $station_orser = 0;
        $time_delay_count = 0;
        $NACp = $NUCp = $SIL = 0;
        foreach ($all_station_arr as $key => $value) {
            if ($station_id == $value['station_id']) {
                $station_orser = $key;
            }
        }

        if ($station_id == 0 || $channel_id == 2) $station_orser = 0;
        if (file_exists($file_path)) {
            $fopen = fopen($file_path, 'r');
            $contens = lline_tail($fopen, count($all_station_arr) + 2);
            $station_check = 'SOURCEID:' . $station_orser;
            $tmp_str = '';
            foreach ($contens as $key => $value) {
				if (strpos($value, 'begin;') !== false) {
                        $item = explode(';', $value);
                        $time_str = $item[1];
                        continue;
                }
                /*
				if (strpos($value, $station_check) !== FALSE) {
                    $tmp_str = $value;
                    break;
                }
				*/
				$v = explode(';', $value);						
				if($station_check == $v[0])
				{
					$tmp_str = $value;
                    break;
				}
            }
            $arr = explode(";", $tmp_str);
            if (count($arr) == 16) {
                $item = explode(":", $arr[0]);
                if ($item[1] == $station_orser) {
                    for ($j = 0; $j < 15; $j++) {
                        if ($j == 0) {
                            //$re_arr["DATE"] = date("Y-m-d H:i:s");
							$re_arr["DATE"] = date('Y-m-d H:i:s', strtotime(trim(safe_replace($time_str))));
                        } else {
                            $item = explode(":", $arr[$j]);
                            if ($j != 0) {
                                if (count($item) > 1 && $j < 10) {
                                    $re_arr[$item[0]] = $item[1];
                                }
                                if ($j == 8) {
                                    $sum_arr = explode(',', $item[1]);
                                    $sum_all = $sum_arr[0] + $sum_arr[1] + $sum_arr[2];
                                    $re_arr["GHOST_TARGET_CNT"] = $sum_all;
                                }
                                if ($j == 9) {
                                    $time_distribution = explode(',', $item[1]);
                                    foreach ($time_distribution as $k => $v) {
                                        if ($k >= $time_delay) {
                                            $time_delay_count += $v;
                                        }
                                    }
                                    $re_arr['ERROR_TIMEMARK'] = $time_delay_count;
                                }


                                if ($j == 10) {
                                    $nacp_arr = explode(',', $item[1]);
                                    $NACp = $NACp[0] + $nacp_arr[1] + $nacp_arr[2] + $nacp_arr[3] + $nacp_arr[4] + $nacp_arr[5];
                                }
                                if ($j == 12) {
                                    $nucp_arr = explode(',', $item[1]);
                                    $NUCp = $nucp_arr[0] + $nucp_arr[1] + $nucp_arr[2] + $nucp_arr[3] + $nucp_arr[4];
                                }
                                if ($j == 13) {
                                    $sil_arr = explode(',', $item[1]);
                                    $SIL = $sil_arr[0] + $sil_arr[1] + $sil_arr[2];
                                }

                                $re_arr["LOW_QUALITY"] = ($NACp > $NUCp) ? $NACp : $NUCp;
                                $re_arr["LOW_QUALITY"] = ($re_arr["LOW_QUALITY"] > $SIL) ? $re_arr["LOW_QUALITY"] : $SIL;
                            }
                        }
                    }
                }
            }
        }
        echo json_encode($re_arr);
    }

    function get_ini_statistics_data($station_id = 0, $channel_id = 0)
    {
        $data_info = $this->Track_config_model->get_one(array('id' => 1));
        $time_delay = $data_info["timeDelay"];
        $date_time = date("H:i:s");
		$re_arr = null;
		$i = 0;
        for ($h = 0; $h < 2; $h++) {
            $date = date("Y-m-d");
            $date = date('Y-m-d', strtotime('+' . $h - 1 . ' day', strtotime($date)));
            
            $file_path = STATISTICS_PATH . $channel_id . "/" . $date . "/" . STATISTICSDATA;
            $all_station_arr = $this->Station_model->select('is_del=0', 'station_id');
            $station_orser = 0;
            $time_delay_count = 0;
            $NACp = $NUCp = $SIL = 0;
            foreach ($all_station_arr as $key => $value) {
                if ($station_id == $value['station_id']) {
                    $station_orser = $key;
                }
            }

            if ($station_id == 0 || $channel_id == 2) $station_orser = 0;
			//echo $file_path;
            if (file_exists($file_path)) {
                $fopen = fopen($file_path, 'r');
                //$contens = lline_tail($fopen, count($all_station_arr) + 2);
                $station_check = 'SOURCEID:' . $station_orser;

                $tmp_str = '';
                $time_str = '';
                
				
                while (!feof($fopen)) {
                    //if($i >= 4320) break;
                    $tmp_str = fgets($fopen);
                    if (strpos($tmp_str, 'begin;') !== false) {
                        $item = explode(';', $tmp_str);
                        $time_str = $item[1];
                        continue;
                    }
                    $recoder_time = date('H:i:s', strtotime(trim(safe_replace($time_str))));
                    if ($h == 0 && ($recoder_time < $date_time)) continue;
                    //if (strpos($tmp_str, 'SOURCEID:' . $station_orser) !== 0) continue;
                    $value = explode(';', $tmp_str);						
					if('SOURCEID:' . $station_orser !== $value[0]) continue;
                    $arr = explode(";", $tmp_str);
                    $item = explode(":", $arr[0]);
                    if ($item[1] == $station_orser) {						
                        for ($j = 0; $j < 15; $j++) {
                            if ($j == 0) {
                                $re_arr[$i]["DATE"] = date('Y-m-d H:i:s', strtotime(trim(safe_replace($time_str))));
                            } else {
                                $item = explode(":", $arr[$j]);
                                if ($j != 0) {
                                    if (count($item) > 1 && $j < 10) {
                                        $re_arr[$i][$item[0]] = $item[1];
                                    }
                                    if ($j == 8) {
                                        $sum_arr = explode(',', $item[1]);
                                        $sum_all = $sum_arr[0] + $sum_arr[1] + $sum_arr[2];
                                        $re_arr[$i]["GHOST_TARGET_CNT"] = $sum_all;
                                    }
                                    if ($j == 9) {
                                        $time_distribution = explode(',', $item[1]);
                                        if ($time_delay <= 0.4) {
                                            $time_delay_count = $time_distribution[0] + $time_distribution[1] + $time_distribution[2] + $time_distribution[3] + $time_distribution[4] + $time_distribution[5] + $time_distribution[6];
                                        } elseif ($time_delay > 0.4 && $time_delay <= 0.8) {
                                            $time_delay_count = $time_distribution[1] + $time_distribution[2] + $time_distribution[3] + $time_distribution[4] + $time_distribution[5] + $time_distribution[6];
                                        } elseif ($time_delay > 0.8 && $time_delay <= 1.2) {
                                            $time_delay_count = $time_distribution[2] + $time_distribution[3] + $time_distribution[4] + $time_distribution[5] + $time_distribution[6];
                                        } elseif ($time_delay > 1.2 && $time_delay <= 1.8) {
                                            $time_delay_count = $time_distribution[3] + $time_distribution[4] + $time_distribution[5] + $time_distribution[6];
                                        } elseif ($time_delay > 1.8 && $time_delay <= 10) {
                                            $time_delay_count = $time_distribution[4] + $time_distribution[5] + $time_distribution[6];
                                        } elseif ($time_delay > 10 && $time_delay <= 1800) {
                                            $time_delay_count = $time_distribution[5] + $time_distribution[6];
                                        } elseif ($time_delay > 1800) {
                                            $time_delay_count = $time_distribution[6];
                                        }
                                        $re_arr[$i]['ERROR_TIMEMARK'] = $time_delay_count;
                                    }
                                    if ($j == 10) {
                                        $nacp_arr = explode(',', $item[1]);
                                        $NACp = $NACp[0] + $nacp_arr[1] + $nacp_arr[2] + $nacp_arr[3] + $nacp_arr[4] + $nacp_arr[5];
                                    }
                                    if ($j == 12) {
                                        $nucp_arr = explode(',', $item[1]);
                                        $NUCp = $nucp_arr[0] + $nucp_arr[1] + $nucp_arr[2] + $nucp_arr[3] + $nucp_arr[4];
                                    }
                                    if ($j == 13) {
                                        $sil_arr = explode(',', $item[1]);
                                        $SIL = $sil_arr[0] + $sil_arr[1] + $sil_arr[2];
                                    }

                                    $re_arr[$i]["LOW_QUALITY"] = ($NACp > $NUCp) ? $NACp : $NUCp;
                                    $re_arr[$i]["LOW_QUALITY"] = ($re_arr[$i]["LOW_QUALITY"] > $SIL) ? $re_arr[$i]["LOW_QUALITY"] : $SIL;
                                }
                            }
                        }
                    }
					$i++;
                }
            }
        }
        echo json_encode($re_arr);
    }

    /*
     * 读取离线数据统计
     */
    function read_offline_data($station_id = 0, $channel_id = 0, $start_time = '', $end_time = '')
    {
        $ghost_distribute_total = array(0, 0, 0);
        $error_timemark_total = array(0, 0, 0, 0, 0, 0, 0);
        $sil_arr_total = array(0, 0, 0, 0);
        //$nic_arr = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0); //取值范围 0-11
        $nuc_arr_total = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); //取值范围 0-9，DO260A/B时定义为NIC取值为0-11
        $nac_arr_total = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); //取值范围 0-11，取值精度跟NIC一致
        $begin_break_time = "";
        $end_break_time = "";
        $record_break_off_time = "";
        $record_break_off = 0;
        $delay_total = 0;
        $nuc_low_quality = 0;
        $nac_low_quality = 0;
        $sil_low_quality = 0;

        $data_list = array();
        $start_time = strtotime(trim(safe_replace($start_time)));
        $end_time = strtotime(trim(safe_replace($end_time)));
        if ($start_time == '' || $end_time == '') {
            echo 'statistics time is wrong!';
            return 0;
        }
        $start_date = date('Y-m-d', $start_time);
        $end_date = date('Y-m-d', $end_time);

        if ($station_id == 0) $channel_id = 2;

        $diff_day = round((strtotime($end_date) - strtotime($start_date)) / 3600 / 24); //计算需要统计的天数

        //echo $diff_day;
        $data_count = $target_count = $test_dispear_count = $dispear_count = $error_count = 0;
        $pos_jump_count = $height_jump_count = $ghost_target_count = $error_timemark = $start = 0;
        $html = "";
        $station_orser = 0;
        $all_station_arr = $this->Station_model->select('is_del=0', 'station_id');

        foreach ($all_station_arr as $key => $value) {
            if ($station_id == $value['station_id']) {
                $station_orser = $key;
            }
        }

        $channel_info = $this->Station_config_model->get_one(array('station_id' => $station_id), 'data_version_A,data_version_B');

        if ($channel_id == 2) $station_orser = 0;

        for ($i = 0; $i <= $diff_day; $i++) {
            $date = date('Y-m-d', strtotime('+' . $i . ' day', strtotime($start_date)));

            $file_path = STATISTICS_PATH . $channel_id . "/" . $date . "/" . STATISTICSDATA;

            //echo $file_path;
            if (file_exists($file_path)) {
                $fopen = fopen($file_path, 'r');

                //echo $file_path;
                while (!feof($fopen)) {
                    $tmp_str = fgets($fopen);
                    if (strpos($tmp_str, 'begin;') !== false) {
                        $tmp_time = substr($tmp_str, 6);
                        $read_time = strtotime($tmp_time);

                        if ($read_time > $start_time) {
                            $start = 1;
                        }
                        if ($read_time > $end_time) {
                            $start = 0;
                            break;
                        }
                    }

                    //var_dump($tmp_str);

                    if ($start) {
                        if (strpos($tmp_str, 'begin') !== false) {
                            $begin_break_time = substr($tmp_str, 6);
                            continue;
                        }

                        if (strpos($tmp_str, 'end') !== false) {
                            $end_break_time = substr($tmp_str, 4);
                            continue;
                        }

                        //if (strpos($tmp_str, 'SOURCEID:' . $station_orser) !== 0) continue;
                        $value = explode(';', $tmp_str);						
						if('SOURCEID:' . $station_orser !== $value[0]) continue;						
						$temp_count = (int)(substr($value[1], 6));
                        $data_count += $temp_count;
                        if ($temp_count == 0 && $record_break_off == 0) {
                            $record_break_off_time .= $begin_break_time . "- ";
                            $record_break_off = 1;
                        }
                        if ($temp_count > 0 && $record_break_off) {
                            $record_break_off_time .= $end_break_time . ";";
                            $record_break_off = 0;
                        }

                        $value = explode(';', $tmp_str);
                        //$data_count += (int)(substr($value[1], 6));											
                        $target_count += (int)(substr($value[2], 11));
                        $error_count += (int)(substr($value[5], 10));
                        $pos_jump_count += (int)(substr($value[6], 13));
                        $height_jump_count += (int)(substr($value[7], 16));
                        $ghost_distribute_arr = explode(',', substr($value[8], 17));
                        //var_dump($value[8]);
                        foreach ($ghost_distribute_arr as $g => $h) {
                            $ghost_distribute_total[$g] += $h;
                        }
                        $error_timemark_arr = explode(',', substr($value[9], 15));

                        foreach ($error_timemark_arr as $g => $h) {
                            $error_timemark_total[$g] += $h;
                            if ($g > 3) //超过1.8秒就算延时
                            {
                                $delay_total += $h;
                            }
                        }
                        $nac_arr = explode(',', substr($value[10], 5));

                        foreach ($nac_arr as $k => $v) {
                            $nac_arr_total[$k] += $v;
                            if ($v < 6) {
                                $nac_low_quality += $v;
                            }
                        }
                        $nuc_arr = explode(',', substr($value[12], 9));

                        $data_version = ($channel_id == 0) ? $channel_info['data_version_A'] : (($channel_id == 1) ? $channel_info['data_version_B'] : 2.1);
                        foreach ($nuc_arr as $k => $v) {
                            $nuc_arr_total[$k] += $v;
                            if ($data_version != 0.26) {
                                if (6 > $v) {
                                    $nuc_low_quality += $v;
                                }
                            } else {
                                if (5 > $v) {
                                    $nuc_low_quality += $v;
                                }
                            }
                        }

                        $sil_arr = explode(',', substr($value[13], 4));

                        foreach ($sil_arr as $k => $v) {
                            $sil_arr_total[$k] += $v;
                            if (2 > $v) {
                                $sil_low_quality += $v;
                            }
                        }
                    }
                }
            }
        }
        if ($record_break_off == 1) $record_break_off_time .= $end_break_time . ";";
        $data_list["COUNT"] = $data_count;
        $data_list["DISPEAR_CNT"] = $dispear_count;
        $data_list["TEST_DISPEAR_CNT"] = $test_dispear_count;
        $data_list["ERROR_CNT"] = $error_count;
        $data_list["POS_JUMP_CNT"] = $pos_jump_count;
        $data_list["HEIGHT_JUMP_CNT"] = $height_jump_count;
        $data_list["GHOST_TARGET_CNT"] = $ghost_distribute_total;
        $data_list["ERROR_TIMEMARK"] = $error_timemark_total;
        $data_list["NAC"] = $nac_arr_total;
        $data_list["NUC"] = $nuc_arr_total;
        $data_list["SIL"] = $sil_arr_total;
        $data_list["BREAK_OFF"] = $record_break_off_time;
        $data_list["DELAY"] = $delay_total;
        $data_list["NUC_LOW_QUALITY"] = $nuc_low_quality;
        $data_list["NAC_LOW_QUALITY"] = $nac_low_quality;
        $data_list["SIL_LOW_QUALITY"] = $sil_low_quality;
        //echo json_encode($data_list);
        return $data_list;
    }

    function echo_offline_data($station_id = 0, $channel_id = 0, $start_time = '', $end_time = '')
    {
        $datalist = $this->read_offline_data($station_id, $channel_id, $start_time, $end_time);
        echo json_encode($datalist);
    }

    /*
     * 实时数据包显示
     */
    function read_buff_data($station_id = -1, $channel_id = -1, $keyword = '')
    {
        if ($station_id == -1) exit;
		
        //while(1)
        //{
        $buff = recv_udp(SYSTEMSENDIP, REALTIMEBUFFPORT);
        //setcache('realtimebuff_'.$station_id,$buff);
        //}              

        $station_id = trim($station_id);
        $file_path = STATISTICS_PATH . "/" . BUFFDATA;
        $contens = file($file_path);
        $html = "";
        $chn_sac = 0;
        $chn_sic = 0;
        $errinfo = 0;
        $track_buff = "";
        //var_dump($station_id);exit;
        if ($station_id == 0) {
            $station_info = $this->DataCenterInfo_model->get_one(array('id' => 1));
            $chn_sac = $station_info["sac"];
            $chn_sic = $station_info["sic"];
            $channel_id = 2;
        } else {
            $channel_info = $this->Station_config_model->get_one(array('station_id' => $station_id), 'sac_code_A,sic_code_A,sac_code_B,sic_code_B');
            if ($channel_id == 0) {
                $chn_sac = $channel_info['sac_code_A'];
                $chn_sic = $channel_info['sic_code_A'];
            } elseif ($channel_id == 1) {
                $chn_sac = $channel_info['sac_code_B'];
                $chn_sic = $channel_info['sic_code_B'];
            }
        }

        $arr = explode(",", $buff);
        //var_dump($arr);exit;
        if (count($arr) == 10) {
            $html .= "<tr>";
            $arr[8] = ($arr[8] == 0) ? '0.26' : (($arr[8] == 1) ? '1.4' : '2.1');

            $html .= "<td>";
            $html .= $arr[1];
            $html .= "</td>";

            $html .= "<td>";
            $html .= $arr[2];
            $html .= "</td>";

            $html .= "<td>";
            $html .= $arr[3];
            $html .= "</td>";

            $html .= "<td>";
            $html .= $arr[4];
            $html .= "</td>";

            $html .= "<td>";
            $html .= $arr[5];
            $html .= "</td>";

            $html .= "<td>";
            $html .= $arr[6];
            $html .= "</td>";

            $html .= "<td>";
            $html .= $arr[8];
            $html .= "</td>";


            $html .= "<td>";
            if ($station_id != 0) {
                $arr[9] = substr($arr[9], 4);
            }
            $html .= "<a href='#' data-toggle='tooltip' title='" . $arr[8] . "'>";
            $sub_arr = substr($arr[9], 0, 24) . "... ...";
            $html .= $sub_arr . "</a>";
            $html .= "</td>";

            $html .= "<td>";
            switch ($arr[0]) {
                case 0:
                    $html .= "正常";
                    break;
                case 1:
                    $html .= '<span style="color:red" >实际长度和声明不符</span>';
                    break;
                case 2:
                    $html .= '<span style="color:red" >SAC/SIC与本通道定义不符</span>';
                    break;
                case 3:
                    $html .= '<span style="color:red" >时标检验不通过</span>';
                    break;
                case 4:
                    $html .= '<span style="color:red" >缺少必传数据项</span>';
                    break;
                case 5:
                    $html .= '<span style="color:red" >格式错误</span>';
                    break;
                case 6:
                    $html .= '<span style="color:red" >数据包长度超长或过短</span>';
                    break;
            }
            $html .= "</td>";

            if ($arr[0] < 5) {
                $str = "<a href=" . base_url("/adminpanel/dataAnalyse/send_buff/" . $station_id . "/" . $channel_id . "/" . $arr[8] . "/" . $arr[9]) . " </a>";
                $html .= "<td>" . $str . "数据帧分析</td>";
            } else {
                $str = "<a href='#' </a>";
                $html .= "<td>" . $str . "数据帧分析</td>";
            }
            $html .= "</tr>";
        }
        echo $html;
		
    }

    /*
     * 实时数据源选择
     */
    function choose_source($station_id=0, $channel_id=0,$keyword="")
    {
        $all_station_arr = $this->Station_model->select('is_del=0', 'station_id');
        $station_orser = 0;
        foreach ($all_station_arr as $key => $value) {
            if ($station_id == $value['station_id']) {
                $station_orser = $key;
            }
        }
        if ($station_id == 0) $channel_id = 2;
        $buff = '<MSG TYPE="19" MODULENAME="CMLR-A" FILTER="'.$keyword.'" APPNAME="quality_staticstician" STATIONID="' . $station_orser . '" CHANNEL="' . $channel_id . '" SENDTIME="' . date("H:i:s Y:m:d") . '" />';
		//echo htmlspecialchars($buff);
        send_udp(SYSTEMSENDIP, SYSTEMSENDPORT, $buff, 0);
        exit(json_encode(array('status' => true, 'tips' => '数据源设置成功', 0)));
    }

    function send_offline_msg($station_id = -1, $channel_id = -1, $begin = "", $end = "")
    {
        $qian = array(" ", " ", "\t", "\n", "\r");
        $buff = str_replace($qian, '', $buff);
        $data_info = $this->Station_model->get_one(array('station_id' => $station_id));
        $version = $data_info['data_version'];
        $msg = '<MSG TYPE="20" MODULENAME="CMLR-A" APPNAME="quality_staticstician" VERSION="' . $version . '"  BEGIN="' . $start . '" END="' . $end . '" SENDTIME="' . date("H:i:s Y:m:d") . '" />';
        send_udp(SYSTEMSENDIP, SYSTEMSENDPORT, $msg, 0);
        exit(json_encode(array('status' => true, 'tips' => '离线分析设置成功', 0)));
    }

    /*
     * 发送需要解析的数据包给后台解析程序
     */
    function send_buff($station_id = -1, $channel_id = -1, $version = "2.1", $buff = "")
    {
        $qian = array(" ", " ", "\t", "\n", "\r");
        $buff = str_replace($qian, '', $buff);
        $data_info = $this->Station_model->get_one(array('station_id' => $station_id));
        $channel_info = $this->Station_config_model->get_one(array('station_id' => $station_id));

        if ($channel_id == 2 || $station_id == 0) {
            $data_info["station_name"] = "ronghe";
            $data_list = $this->Data_export_users_model->get_one(array('type = 0'));
            $version = $data_list['select_item_version'];
        } else {
            if ($channel_id == 0) {
                $version = $channel_info['data_version_A'];
            } elseif ($channel_id == 1) {
                $version = $channel_info['data_version_B'];
            }
        }

        $msg = '<MSG TYPE="21" VERSION="' . $version . '" CHANNEL="' . $channel_id . '" BUFF="' . $buff . '" SENDTIME="' . date("H:i:s Y:m:d") . '" />';
        send_udp(SYSTEMSENDIP, BUFFDETAILPORT, $msg, 0);
        //var_dump(htmlspecialchars($msg));exit;		
        $channel_name = ($channel_id == 0) ? "A" : (($channel_id == 1) ? "B" : "R");
        $this->view('detail', array('require_js' => true, 'station_id' => $station_id, 'channel_id' => $channel_id, 'buff' => $buff));
    }

    function send_msg_test()
    {
        //$msg = '<MSG TYPE="5" MODULENAME="BDCD-A" APPNAME="decoder" FULLPATH="" SENDTIME="08:02:55 2018:06:15" />';
        //send_udp(SYSTEMSENDIP, SYSTEMSENDPORT, $msg, 0);
        echo "你好";
    }

    /*
     * 读取后台解析程序解析结果文件
     */
    function get_buff_detail($station_id = -1, $channel_id = -1)
    {
        if ($channel_id == 2 || $station_id == 0) {
            $data_info = $this->DataCenterInfo_model->get_one(array('id' => 1));
            $sac = $data_info['sac'];
            $sic = $data_info['sic'];
            echo $sic;
        } else {
            $channel_info = $this->Station_config_model->get_one(array('station_id' => $station_id), 'sac_code_A,sic_code_A,sac_code_B,sic_code_B');
            if ($channel_id == 0) {
                $sac = $channel_info['sac_code_A'];
                $sic = $channel_info['sic_code_A'];
            } elseif ($channel_id == 1) {
                $sac = $channel_info['sac_code_B'];
                $sic = $channel_info['sic_code_B'];
            }
        }

        $str = $sac . "_" . $sic;
        $file_path = BUFF_DETAIL_PATH . (($channel_id == 0) ? "A" : (($channel_id == 1) ? "B" : "R")) . "/" . $str;
        //echo $file_path;
        $html = "";
        $i = 0;
        if (file_exists($file_path)) {
            $contens = file($file_path);
            foreach ($contens as $v) {
                if ($i > 1)
                    $html .= $v;
                $i++;
            }
        } else {
            $html = '暂无文件信息';
        }
        echo $html;
    }

    function excelData($str, $filename)
    {
        /*
        $str = "<html xmlns:o=\"urn:schemas-microsoft-com:office:office\"\r\nxmlns:x=\"urn:schemas-microsoft-com:office:excel\"\r\nxmlns=\"http://www.w3.org/TR/REC-html40\">\r\n<head>\r\n<meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\r\n</head>\r\n<body>"; 
        $str .="<table border=1><head>".$titlename."</head>"; 
        $str .= $title; 
        foreach ($datas as $key=> $rt ) 
        { 
            $str .= "<tr>"; 
            foreach ( $rt as $k => $v ) 
            { 
                $str .= "<td>{$v}</td>"; 
            } 
            $str .= "</tr>\n"; 
        } 
        $str .= "</table></body></html>"; 
        */
        header("Content-Type: application/vnd.ms-excel; name='excel'");
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment; filename=" . $filename);
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Pragma: no-cache");
        header("Expires: 0");
        exit($str);
    }

    function exportExcel($start_time = '', $end_time = '')
    {
        $channel_cout = 1;
        $dataResult_A = array();
        $dataResult_B = array();
        $str = "<html xmlns:o=\"urn:schemas-microsoft-com:office:office\"\r\nxmlns:x=\"urn:schemas-microsoft-com:office:excel\"\r\nxmlns=\"http://www.w3.org/TR/REC-html40\">\r\n<head>\r\n<meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\r\n</head>\r\n<body>";
        $date = date('Y-m-d H:i:s');
        $headTitle = "广州数据质量分析";
        $title = "广州二级数据中心质量分析" . date('YmdHis');
        $headtitle = "<tr style='height:50px;border-style:none;><td border=\"0\" style='height:60px;width:270px;font-size:22px;' colspan='11' >{$headTitle}</td></tr>";
        $titlename = "<tr>
						<th style='width:100px;' rowspan='3'>站点</th>
						<th style='width:150px;' rowspan='3'>站点类型</th>
						<th style='width:120px;' rowspan='3'>开始时间</th>
						<th style='width:120px;' rowspan='3'>结束时间</th>
						<th style='width:100px;' rowspan='3'>数据帧总数</th>
						<th style='width:100px;' rowspan='2' colspan='2'>错误数据帧数</th>
						<th style='width:130px;' rowspan='2' colspan='2'>高度跳变数据帧数</th>
						<th style='width:130px;' rowspan='2' colspan='2'>位置跳变数据帧数</th>
						<th style='width:80px;' rowspan='2' colspan='2'>数据延时(大于1.8s)帧数</th>
						<th style='width:300px;' colspan='6'>数据完好度过低</th>
						<th style='width:100px;' colspan='6'>虚假目标验证</th>
						<th style='width:150px;' rowspan='3'>数据中断记录</th>
					</tr>
					<tr>
						<th style='width:100px;' colspan='2'>NUC(<5)或NIC(<6)</th>
						<th style='width:100px;' colspan='2'>NAC(<6)</th>
						<th style='width:100px;' colspan='2'>SIL(<2)</th>
						<th style='width:100px;' colspan='2'>范围验证</th>
						<th style='width:100px;' colspan='2'>雷达验证</th>
						<th style='width:100px;' colspan='2'>TDOA验证</th>
					</tr>
					<tr>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
						<th style='width:100px;'>总数</th>
						<th style='width:100px;'>占比</th>
					</tr>";

        $str .= "<table border=1><head>" . $titlename . "</head>";
        $all_station_arr = $this->Station_model->select('is_del=0', 'station_id,station_name,is_station', '', 'is_station ASC ,station_name DESC');
        foreach ($all_station_arr as $key => $value) {
            if ($value['station_id'] == 0) {
                $channel_id = 2;
                $channel_cout = 1;
                $dataResult_A = $this->read_offline_data($value['station_id'], $channel_id, $start_time, $end_time);
            } else {
                $channel_cout = 2;
                $dataResult_A = $this->read_offline_data($value['station_id'], 0, $start_time, $end_time);
                $dataResult_B = $this->read_offline_data($value['station_id'], 1, $start_time, $end_time);
            }
            //$str .= $title;

            $station_type = $this->Station_grade_model->get_one(array('station_level_id' => $value['is_station']), 'station_level_name');

            $start_date = strtotime(trim(safe_replace($start_time)));
            $end_date = strtotime(trim(safe_replace($end_time)));
            $start_date = date('Y-m-d H:i:s', $start_date);
            $end_date = date('Y-m-d H:i:s', $end_date);

            for ($i = 0; $i < $channel_cout; $i++) {
                $channel_name = ($i == 0) ? "A" : "B";
                $dataResult = ($i == 0) ? $dataResult_A : $dataResult_B;
                $datacount = ($dataResult['COUNT'] > 0) ? $dataResult['COUNT'] : 1;

                $error_count_per = number_format($dataResult['ERROR_CNT'] / $datacount, 6);
                $post_jump_count_per = number_format($dataResult['POS_JUMP_CNT'] / $datacount, 6);
                $height_jump_count_per = number_format($dataResult['HEIGHT_JUMP_CNT'] / $datacount, 6);
                $error_count_per = number_format($dataResult['ERROR_CNT'] / $datacount, 6);
                $delay_count_per = number_format($dataResult['DELAY'] / $datacount, 6);
                $nac_count_per = number_format($dataResult['NAC_LOW_QUALITY'] / $datacount, 6);
                $nuc_count_per = number_format($dataResult['NUC_LOW_QUALITY'] / $datacount, 6);
                $sil_count_per = number_format($dataResult['SIL_LOW_QUALITY'] / $datacount, 6);
                $range_per = number_format($dataResult['GHOST_TARGET_CNT'][0] / $datacount, 6);
                $radar_per = number_format($dataResult['GHOST_TARGET_CNT'][1] / $datacount, 6);
                $tdoa_per = number_format($dataResult['GHOST_TARGET_CNT'][2] / $datacount, 6);

                $str .= "<tr>
				<td>{$value['station_name']}{$channel_name}</td>
				<td>{$station_type['station_level_name']}</td>
				<td>{$start_date}</td>
				<td>{$end_date}</td>
				<td>{$dataResult['COUNT']}</td>
				<td>{$dataResult['ERROR_CNT']}</td>
				<td>{$error_count_per}%</td>
				<td>{$dataResult['HEIGHT_JUMP_CNT']}</td>
				<td>{$height_jump_count_per}%</td>
				<td>{$dataResult['POS_JUMP_CNT']}</td>
				<td>{$post_jump_count_per}%</td>
				<td>{$dataResult['DELAY']}</td>
				<td>{$delay_count_per}%</td>
				<td>{$dataResult['NUC_LOW_QUALITY']}</td>
				<td>{$nuc_count_per}%</td>
				<td>{$dataResult['NAC_LOW_QUALITY']}</td>
				<td>{$nac_count_per}%</td>
				<td>{$dataResult['SIL_LOW_QUALITY']}</td>
				<td>{$sil_count_per}%</td>
				<td>{$dataResult['GHOST_TARGET_CNT'][0]}</td>
				<td>{$range_per}%</td>
				<td>{$dataResult['GHOST_TARGET_CNT'][1]}</td>
				<td>{$radar_per}%</td>
				<td>{$dataResult['GHOST_TARGET_CNT'][2]}</td>
				<td>{$tdoa_per}%</td>
				<td>{$dataResult['BREAK_OFF']}</td>
				</tr>";
            }
        }
        $str .= "</table></body></html>";
        //echo $str;
        $filename = $title . ".xls";
        //echo $titlename;
        $this->excelData($str, $filename);
        return "OK";
    }
}
