<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-10
 * Time: 上午9:01
 * To change this template use File | Settings | File Templates.
 */
class AppLogs extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('App_model'));
        $this->load->helper(array('global_helper'));
    }

    function lists($page_no=1)
    {
        // $post_data = $_POST;
        /*exec('ping 166.2.3.11',$arr,$status);
        var_dump($arr);
        var_dump($status);exit;*/

        $data_list = array();
        $pages = '';
        $start_time =  trim(safe_replace($this->input->get('start_time')));
        $end_time = trim(safe_replace($this->input->get('end_time')));
        $station_name = trim(safe_replace($this->input->get('station_name')));
        
        //进行单个文件的数据量查看
        if(!$station_name){
            $station_name = $this->App_model->get_one('','app_id')['app_id'];
        }
        if(!$start_time){
            $start_time = strtotime(date('Y-m-d 00:00:00'));
        }else {
            $start_time = strtotime($start_time);
        }
        if(!$end_time){
            $end_time = $start_time + 6*60*60;//六小时内的数据
        }else {
            $end_time = strtotime($end_time);
        }

        if(!$station_name  || !$start_time || !$end_time){
            $search_warning = true;
        }else{
            $search_warning = false;
        }
        if($station_name  && $start_time && $end_time){
            //进行读文件 
            if($start_time == $end_time){
                //进行往后十分钟的添加
                $end_time_stamp =$start_time+24*60*60; 
            }else{
                $end_time_stamp =$end_time; 
            }

            if($start_time > $end_time){
                $start_time = $end_time;
                $end_time = $start_time;
            }
            //获取服务器的别名
            $path_basic = $this->App_model->tables_select(array('app_id'=>$station_name),'program_name,hardware_other_name');
            if(!$path_basic){
                $this->showmessage('程序不在服务器上');exit;
            }
          
            $data_list = $this->read_data_limit_file($path_basic,$start_time,$end_time_stamp);
                $pagesize = 20;
                $setpages = 10;
                $urlrule = page_list_url('adminpanel/appLogs/lists',true);
                $number = count($data_list);
                if($number>0){
                    //进行分页
                        $page = max(intval($page_no),1);
                        $offset = $pagesize*($page-1);
                        if($offset>$number)
                        {
                            $page=round($number/$pagesize);
                            $offset = max($pagesize*($page-1),0);
                        }
                        if($number >$pagesize)
                            $pages = pages($number, $page, $pagesize, $urlrule, array(), $setpages);
                        else
                            $pages = "";
                        $data_list = array_slice($data_list, $offset,$pagesize);
                }
            
        }
        $app_list = $this->App_model->tables_select('','app_id,program_name,is_main');
        foreach ($app_list as $key => $value) {
            if($value['is_main'] == 1){
                $app_list[$key]['program_name'] = $value['program_name'].'_A';
            }else{
                $app_list[$key]['program_name'] = $value['program_name'].'_B';
            }
        }
        if(!$app_list){
            $this->showmessage('请先进行应用程序的添加');exit;
        }
        $this->view('lists',array('require_js'=>true,'data_list'=>$data_list,'app_list'=>$app_list,'search_warning'=>$search_warning,'station_name'=>$station_name,'pages' =>$pages));   
    }

    //读取数据上线文件的
    private function read_data_limit_file($path_basic,$start_time_stamp,$end_time_stamp){
        //1先判断文件存不存  2文件超时与否 3是否是写完 4是否告警
        $sub_time = $end_time_stamp-$start_time_stamp;
        //几天的间隔
        // var_dump($sub_time/(24*60*60));exit;
        $sub_day = floor($sub_time/(24*60*60));
        $data_list = array();
        $j = 0;
        // var_dump($sub_day);exit;
        for($i=0; $i <= $sub_day; $i++) { 
            $file_day = date('Ymd',$start_time_stamp+$i*60*60*24);   
            $path = SYSLOG_PATH.$path_basic[0]['hardware_other_name'].'/'.$path_basic[0]['program_name'].'_'.$file_day.'.log';
            // var_dump($path);exit;
            if(file_exists($path)){
                    $file_open = fopen($path,'r');
                    while (!feof($file_open)) {
                        //逐行读取文件内容
                        $tmp_str = fgets($file_open);
                        $tmp_time = substr($tmp_str,0,14);
                        $read_time = strtotime($tmp_time);
                        if($read_time){
                            if($read_time >=$start_time_stamp && $read_time <=$end_time_stamp){
                                   $data_list[$j]['dateline'] = date('Y-m-d H:i:s',$read_time);
                                   $err_site = strpos($tmp_str,'.[');
                                   $err_kind = substr($tmp_str, $err_site-1,1);
                                   $err_info = substr($tmp_str,$err_site+1);
                                   $data_list[$j]['err_kind'] = $err_kind;
                                   $data_list[$j]['err_info'] = $err_info;
                                   $j++;
                            }
                        }
                    }

                    fclose($file_open);
            }else{
                continue;
            }

        }
        return $data_list;
    }

}