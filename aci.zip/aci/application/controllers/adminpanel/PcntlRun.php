<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class PcntlRun extends Admin_Controller {
	public function __construct() {  
        parent::__construct();
        $this->load->helper(array('member_helper'));
        pcntl_signal(SIGHUP, array($this, 'sigHandler'));  
        pcntl_signal(SIGINT, array($this, 'sigHandler'));  
        pcntl_signal(SIGQUIT, array($this, 'sigHandler'));  
        pcntl_signal(SIGILL, array($this, 'sigHandler'));  
        pcntl_signal(SIGFPE, array($this, 'sigHandler'));  
        pcntl_signal(SIGALRM, array($this, 'sigHandler'));  
        pcntl_signal(SIGTSTP, array($this, 'sigHandler'));  
        pcntl_signal(SIGABRT, array($this, 'sigHandler'));  
        pcntl_signal(SIGTERM, array($this, 'sigHandler'));  
        
        // shutdown  
        register_shutdown_function(array($this, 'sigHandler'));  
    }  

      public function sigHandler() { 
    	$this->stock_run();

    } 

    public function stock_run(){
    		// dump('1');
    		ignore_user_abort(true);
			set_time_limit(0);
		do{
			/*$run = require_once(file_name());//跳出关键！
			if(!$run)break;*/
				//这里改成你调用的方法  现在是这里每5秒在/run/目录生成一个文件
				$file=STATION_XML_PATH.'station.xml'; 
                $fh = fopen($file, 'r');
                $str =fread($fh, filesize($file));
                $str = $str.time();
		  		// file_put_contents($file,date("s"));
		  		//这里改成你调用的方法
                // var_dump($str);exit;
                setcache('test_cahce',$str);
				pcntl_signal_dispatch();  //进程断了会通知构造函数register_shutdown_function下的sigHandler方法 他会再次调用stock_run方法行成一个死循环
				sleep(1); //单位为秒
		  		ob_flush();
	     		flush();
		}while(true);
	}	
	

}