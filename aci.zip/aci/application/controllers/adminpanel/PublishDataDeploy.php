<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-5-10
 * Time: 上午10:12
 * To change this template use File | Settings | File Templates.
 */
class PublishDataDeploy extends Admin_Controller
{
    var $method_config;

    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Publish_send_model','App_model'));
        $this->load->model(array('Exchange_RecvUCast_model', 'Exchange_RecvMCast_model', 'Exchange_RecvBCast_model','Hardware_model','Hardware_eth_model','Xml_basic_config_model'));
        $this->load->model(array('Recv_cast_data_model','Config_hardware_relation_model','All_xml_model'));
        $this->load->helper(array('member', 'auto_codeIgniter', 'string', 'socket_helper'));

        $this->method_config['upload'] = array(
            'thumb' => array('upload_size' => 1024, 'upload_file_type' => 'jpg|png|gif', 'upload_path' => 'uploadfile/user', 'upload_url' => SITE_URL . 'uploadfile/user/'),
        );
    }

    function lists($page_no = 1)
    {
       $page_no = max(intval($page_no),1);
        $where ='is_del = 0';
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where = " and config_name like '%{$keyword}%' ";
        }
       
        $data_list = $this->Config_hardware_relation_model->tables_listinfo($where,'config_name,insert_time,xml_name,t_sys_config_hardware_relation.id,is_old,xml_id,do_main_socket_send,do_slave_socket_send',$orderby , $page_no, $this->Config_hardware_relation_model->page_size,'',$this->Config_hardware_relation_model->page_size,page_list_url('adminpanel/PublishDataDeploy/lists',true));
        //进行新版本的提醒查询  is_old 判断有无新的文件进行了覆盖
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Config_hardware_relation_model->pages,'keyword'=>$keyword,'require_js'=>true)); 
    }

    function add($network_type=1)
    {
        //如果是AJAX请求
        if ($this->input->is_ajax_request()) {
            //接收POST参数
            $_arr['Name'] = isset($_POST["Name"]) ? trim(safe_replace($_POST["Name"])) : exit(json_encode(array('status' => false, 'tips' => '请选择数据发送方式')));
            if ($_arr['Name'] == '') exit(json_encode(array('status' => false, 'tips' => '请输入用户说明')));
            $_arr['SendAddr'] = isset($_POST["SendAddr"]) ? trim(safe_replace($_POST["SendAddr"])) : exit(json_encode(array('status' => false, 'tips' => '备注不能为空')));
            if ($_arr['SendAddr'] == '') exit(json_encode(array('status' => false, 'tips' => '发送IP和端口不能为空')));
            $_arr['Pri'] = isset($_POST["Pri"]) ? trim(safe_replace($_POST["Pri"])) : "";
            $_arr['delay'] = isset($_POST["delay"]) ? trim(safe_replace($_POST["delay"])) : "";
            $_arr['Freq'] = isset($_POST["Freq"]) ? trim(safe_replace($_POST["Freq"])) : "";

            if ($_arr['cast_type'] == 1) {
                $new_id = $this->Exchange_DstUCast_model->insert($_arr);
            } else if ($_arr['cast_type'] == 2) {
                $new_id = $this->Exchange_DstMCast_model->insert($_arr);
            } else if ($_arr['cast_type'] == 3) {
                $new_id = $this->Exchange_DstBCast_model->insert($_arr);
            
}            if ($new_id) {
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            } else {
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => 0)));
            }
        } else {
            $data_info = array(
                'Note' => "",
                'DstCastIp' => "",
                'DstCastPort' => "",
                'eth_num' => "",
                'cast_type' => 0
            );
            $recv_lists = $this->recv_data_lists();
            $this->view('edit', array('is_edit' => false, 'require_js' => true,'network_type'=>$network_type,'data_info' =>$this->Publish_send_model->default_info(),
                'recv_lists'=>$recv_lists,'page_size'=>$this->Recv_cast_data_model->page_size,'count'=>$this->Recv_cast_data_model->count()));
        }
    }

    function recv_data_lists($page_no = 1, $network_type = 1,$keyword='',$orderby='')
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        if ($keyword != "") $where_arr[] = "concat(note,RecvCastIp,Interface,RecvCastPort) like '%{$keyword}%'";
        $where_arr[] = "NTId = ".intval($network_type);
        $where = implode(" and ", $where_arr);
        $data_list = $this->Recv_cast_data_model->listinfo($where, '*', $orderby, $page_no, $this->Recv_cast_data_model->page_size, '', $this->Recv_cast_data_model->page_size, 'javascrip:void(0)');
        if($this->input->is_ajax_request())
        {
            echo json_encode($data_list);
        }else
        {
            return $data_list;
        }
    }

    function  recv_data_pages($page_no = 1, $network_type = 1,$keyword='',$orderby='')
    {
        $page_no = max(intval($page_no), 1);
        $where_arr = array();
        if ($keyword != "") $where_arr[] = "concat(note,RecvCastIp,Interface,RecvCastPort) like '%{$keyword}%'";
        $where_arr[] = "NTId = ".intval($network_type);
        $where = implode(" and ", $where_arr);
        echo ajax_pages($this->Recv_cast_data_model->count($where),$page_no, $this->Recv_cast_data_model->page_size,'', 'get_recv_source');
    }

    //版本回退
    function back_versions($id=0)
    {
        $id = intval($id);
        $data_info = $this->Config_hardware_relation_model->get_one(array('id'=>$id));
         if($this->input->is_ajax_request())
        {
            //接收POST参数
             //接收POST参数
            $xml_id = isset($_POST["xml_id"])?trim(intval($_POST["xml_id"])):exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            if(!$xml_id)exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            $remark = trim(safe_replace($_POST["remark"]));
            if(!$remark){
                exit(json_encode(array('status'=>FALSE,'tips'=>'备注不能为空')));
            }
            //进行重复添加判断
            //进行重复添加判断
            $xml_info = $this->All_xml_model->get_one(array('id'=>$xml_id));
            $check_kind = $this->Config_hardware_relation_model->get_one(array('xml_kind'=>$xml_info['kind'],'is_del'=>0),'id');

            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '进行配置文件'.$xml_info['xml_name'].'的回退';
            try{
                $this->db->trans_begin();

                if($check_kind){
                    //进行旧版本的删除
                    $up_old_res = $this->Config_hardware_relation_model->update(array('is_del'=>1),array('id'=>$check_kind['id']));
                    if(!$up_old_res){
                        // exit(json_encode(array('status'=>FALSE,'tips'=>'旧版本删除失败，请联系管理员')));
                        throw new Exception($xml_info['config_name']."旧版本删除失败，请联系管理员");

                    }
                    //修改数据库的名字
                }
                $hardware_ids = $this->Xml_basic_config_model->get_one(array('name'=>$xml_info['config_name'],'is_del'=>0),'hardware_ids');

                if(!$hardware_ids){
                        throw new Exception('请先进行'.$xml_info['config_name'].'参数目标服务器配置');
                    // exit(json_encode(array('status'=>FALSE,'tips'=>'请先进行'.$xml_info['config_name'].'参数目标服务器配置')));
                }else{
                    $hardware_id_arr = explode(',', $hardware_ids['hardware_ids']);
                }
                //进行ftp的上传
                $this->ftp_versions($xml_id,$hardware_id_arr,$remark,0);
            
           
                
                 $relate_data = array('xml_id'=>$xml_id,'xml_kind'=>$xml_info['kind'],'insert_time'=>time(),'remark'=>$remark,'hardware_ids'=>implode(',', $hardware_id_arr));
                //进行修改

                $status = $this->Config_hardware_relation_model->insert($relate_data);
                 if(!$status){
                        throw new Exception($xml_info['config_name'].'程序版本信息回退失败');

                 }

                $current_xml = $this->All_xml_model->get_one(array('kind'=>$xml_info['kind'],'is_old'=>0));
                $xml_name = $current_xml['xml_name'];
                $current_xml_name_site = strpos($xml_name,'.');
                $current_xml_name = substr($xml_name,0, strlen($xml_name)-4);
                $current_xml_name = $current_xml_name.'_'.date('Y-m-d H:i:s');
                //新 旧版本调换更名
                $this->All_xml_model->update(array('xml_name'=>$current_xml_name,'is_old'=>1),array('id'=>$current_xml['id']));
                $this->All_xml_model->update(array('xml_name'=>$xml_name,'is_old'=>0),array('id'=>$xml_id));


            }catch(Exception $e){
                    $operation_data['is_success'] = 0;
                    $operation_data['status_explain'] = $e->getMessage();
                    $this->db->trans_rollback();

                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>false,'tips'=>$e->getMessage())));
            }
            $operation_data['info_url'] = SITE_URL.'PublishDataDeploy/publish_file_info/'.$xml_id;
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '回退成功';
            $this->db->trans_commit();

            @$this->operationLogs($operation_data);
            exit(json_encode(array('status'=>true,'tips'=>'程序版本回退成功')));  
           
        }else{
            //配置文件查找
           if(!$data_info){
                $this->showmessage('参数错误');
            }
            $data_info['hardware_id_arr'] = explode(',', $data_info['hardware_ids']);
            $the_config_xml = $this->All_xml_model->get_one(array('id'=>$data_info['xml_id']));
            if(!$the_config_xml){
                $this->showmessage('旧版本已被删除，请联系管理员');exit;
            }

             $xml_path = $the_config_xml['xml_path'].$the_config_xml['xml_name'];
             if(file_exists($xml_path)){
                 $doc = new DOMDocument();
                 $doc -> load($xml_path);
                 $xml_data =  $doc->saveXML();
             }else{
                 $xml_data = -1;
             }

            $data_xmls = $this->All_xml_model->select(array('kind'=>$the_config_xml['kind'],'is_old'=>1),'*','','dateline DESC');
            if(!$data_xmls){
                $this->showmessage('旧版本不存在');exit;
            }
             $remark_info = $this->Config_hardware_relation_model->get_one(array('xml_kind'=>$data_xmls[0]['kind'],'is_del'=>1),'remark','id DESC');
             if(!$remark_info){
                 $remark_info = '该文件暂未上传至对应服务器';
             }else{
                 $remark_info = $remark_info['remark'];
             }
             $all_hardware_lists = $this->Hardware_model->select('','hardware_id,hardware_name');
             $this->view('back_versions',array('is_back'=>true,'require_js'=>true,'data_xmls'=>$data_xmls,'remark_info'=>$remark_info,'all_hardware_lists'=>$all_hardware_lists,'data_info'=>$data_info,'id'=>$id,'xml_data'=>htmlentities($xml_data)));
        }
    }

     //版本上传
    function upgrade_versions($id=0)
    {
        $id = intval($id);
        $data_info = $this->Config_hardware_relation_model->get_one(array('id'=>$id));
         if($this->input->is_ajax_request())
        {
            //接收POST参数
             //接收POST参数
            $xml_id = isset($_POST["xml_id"])?trim(intval($_POST["xml_id"])):exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            if(!$xml_id)exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            $remark = trim(safe_replace($this->input->post('remark')));
            if(!$remark)exit(json_encode(array('status'=>false,'tips'=>'备注不能为空')));

            //进行重复添加判断
            $xml_info = $this->All_xml_model->get_one(array('id'=>$xml_id));
            $check_kind = $this->Config_hardware_relation_model->get_one(array('xml_kind'=>$xml_info['kind'],'is_del'=>0),'id');

            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '进行配置文件'.$xml_info['xml_name'].'的更新';
            try{
                $this->db->trans_begin();

                if($check_kind){
                    //进行旧版本的删除
                    $up_old_res = $this->Config_hardware_relation_model->update(array('is_del'=>1),array('id'=>$check_kind['id']));
                    if(!$up_old_res){
                        // exit(json_encode(array('status'=>FALSE,'tips'=>'旧版本删除失败，请联系管理员')));
                        throw new Exception($xml_info['config_name']."旧版本删除失败，请联系管理员");

                    }
                    //修改数据库的名字
                }
                $hardware_ids = $this->Xml_basic_config_model->get_one(array('name'=>$xml_info['config_name'],'is_del'=>0),'hardware_ids');

                if(!$hardware_ids){
                        throw new Exception('请先进行'.$xml_info['config_name'].'参数目标服务器配置');
                    // exit(json_encode(array('status'=>FALSE,'tips'=>'请先进行'.$xml_info['config_name'].'参数目标服务器配置')));
                }else{
                    $hardware_id_arr = explode(',', $hardware_ids['hardware_ids']);
                }
                //进行ftp的上传
                $this->ftp_versions($xml_id,$hardware_id_arr,$remark,1);
            
           
                
                 $relate_data = array('xml_id'=>$xml_id,'xml_kind'=>$xml_info['kind'],'insert_time'=>time(),'remark'=>$remark,'hardware_ids'=>implode(',', $hardware_id_arr));
                //进行修改

                $status = $this->Config_hardware_relation_model->insert($relate_data);
                 if(!$status){
                        throw new Exception($xml_info['config_name'].'程序版本信息更新失败');

                 }
            }catch(Exception $e){
                    $operation_data['is_success'] = 0;
                    $operation_data['status_explain'] = $e->getMessage();
                    $this->db->trans_rollback();

                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>false,'tips'=>$e->getMessage())));
            }
            $operation_data['info_url'] = SITE_URL.'PublishDataDeploy/publish_file_info/'.$status;
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '更新成功';
            $this->db->trans_commit();

            @$this->operationLogs($operation_data);
            exit(json_encode(array('status'=>true,'tips'=>'程序版本更新成功')));  
           
        }else{
            //配置文件查找
            if(!$data_info){
                $this->showmessage('参数错误');
            }
            $data_info['hardware_id_arr'] = explode(',', $data_info['hardware_ids']);
            $the_config_xml = $this->All_xml_model->get_one(array('id'=>$data_info['xml_id']));
            if(!$the_config_xml){
                $this->showmessage('旧版本已被删除，请联系管理员');exit;
            }
             $xml_path = $the_config_xml['xml_path'].$the_config_xml['xml_name'];
             if(file_exists($xml_path)){
                 $doc = new DOMDocument();
                 $doc -> load($xml_path);
                 $xml_data =  $doc->saveXML();
             }else{
                 $xml_data = -1;
             }
            $data_xmls = $this->All_xml_model->get_one(array('kind'=>$the_config_xml['kind'],'is_old'=>0));
            if(!$data_xmls){
                $this->showmessage('新版本不存在');exit;
            }
            $all_hardware_lists = $this->Hardware_model->select('','hardware_id,hardware_name');
            $this->view('back_versions',array('is_back'=>false,'require_js'=>true,'data_xmls'=>$data_xmls,'all_hardware_lists'=>$all_hardware_lists,'data_info'=>$data_info,'id'=>$id,'xml_data'=>htmlentities($xml_data)));
        }
    }

     /**
     * 新增数据
     * @param is_back 0升级,1回退,2上传文件
     * @return array
     */
    private function ftp_versions($station_xml_id,$hardware_id_arr=array(),$remark = '',$is_back = 0){
            //进行ftp的上传
            $xml_one = $this->All_xml_model->get_one('id='.$station_xml_id);
            
            if(strpos($xml_one['xml_name'],'2')){
                $new_name = substr($xml_one['xml_name'], 0,strlen($xml_one['xml_name'])-21).'.xml';
            }else{
                $new_name = $xml_one['xml_name'];
            }
            $local_path = $xml_one['xml_path'].$xml_one['xml_name'];
            //test



            if(file_exists($local_path)){
                $config['debug']    = TRUE;
                $station_relate_data  = array();
                $flag = true;
                foreach($hardware_id_arr as $k=>$v){
                    $status = -1;
                    $hardware_data = $this->Hardware_eth_model->tables_get_one(array('t_sys_hardware_eth.hardware_id'=>$v,'eth_type'=>0,'net_type'=>0),'ftp_dir,eth_ip,hardware_name');
                   /* exec("ping -c 1 {$hardware_data['eth_ip']}", $outcome, $status);
                    if($status != 0) continue;*/
                    if($hardware_data && $hardware_data['eth_ip']!=''&&$hardware_data['ftp_dir'] !=''){
                        if($new_name == 'station.xml'){
                            if($v == 33){
                                $new_name = 'bypasser_station.xml';
                            }
                            $doc = new DOMDocument(); 
                            if($doc -> load($local_path)) {
                                $channelA = $doc -> getElementsByTagName('channelA');
                                $channelB = $doc -> getElementsByTagName('channelB');
                                foreach ($channelA as $key => $value) {
                                   $channelA =  $value->getElementsByTagName('interfaceIp')->item(0)->nodeValue;
                                   $find_arr = $this->Hardware_eth_model->get_one(array('hardware_id'=>$v,'eth_num'=>$channelA),'eth_ip');
                                   if($find_arr){
                                        $value->getElementsByTagName('interfaceIp')->item(0)->nodeValue = $find_arr['eth_ip'];
                                   }
                                }
                                foreach ($channelB as $key => $value) {
                                    $channelB =  $value->getElementsByTagName('interfaceIp')->item(0)->nodeValue;
                                    $find_arr = $this->Hardware_eth_model->get_one(array('hardware_id'=>$v,'eth_num'=>$channelB),'eth_ip');
                                    if($find_arr){
                                        $value->getElementsByTagName('interfaceIp')->item(0)->nodeValue = $find_arr['eth_ip'];
                                    }
                                }
                                 $new_local_path = $local_path.'1';
                                 $doc->save($new_local_path);
                                 // $local_path = $new_local_path;
                            }

                        }elseif($new_name == 'publisher_config.xml'){
                            $doc = new DOMDocument(); 
                            if($doc -> load($local_path)) {
                                $send = $doc -> getElementsByTagName('send');
                                foreach ($send as $key => $value) {
                                   $type =  $value->getElementsByTagName('type')->item(0)->nodeValue;
                                   $ip =  $value->getElementsByTagName('ip')->item(0)->nodeValue;
                                   if($type == 2){
                                       $find_arr = $this->Hardware_eth_model->get_one(array('hardware_id'=>$v,'eth_num'=>$ip),'eth_ip');
                                       if($find_arr){
                                            $value->getElementsByTagName('ip')->item(0)->nodeValue = $find_arr['eth_ip'];
                                       }
                                   }
                                }
                                 $new_local_path = $local_path.'1';
                                 $doc->save($new_local_path);
                             }
                        }elseif($new_name == 'varifier_config.xml'){
                            $doc = new DOMDocument(); 

                            if($doc -> load($local_path)) {
                                $channel_a = $doc -> getElementsByTagName('channel_a');
                                foreach ($channel_a as $key => $value) {
                                    $type = $value->getElementsByTagName('type')->item(0)->nodeValue;
                                    if($type != 3){
                                        $ip =  $value->getElementsByTagName('ip')->item(0)->nodeValue;
                                        $find_arr = $this->Hardware_eth_model->get_one(array('hardware_id'=>$v,'eth_num'=>$ip),'eth_ip');
                                        if($find_arr){
                                                $value->getElementsByTagName('ip')->item(0)->nodeValue = $find_arr['eth_ip'];
                                        }
                                    }
                               }
                                       
                                $channel_b = $doc -> getElementsByTagName('channel_b');
                                foreach ($channel_b as $key => $value) {
                                       $type = $value->getElementsByTagName('type')->item(0)->nodeValue;
                                       if($type !=3){
                                            $ip =  $value->getElementsByTagName('ip')->item(0)->nodeValue;
                                            $find_arr = $this->Hardware_eth_model->get_one(array('hardware_id'=>$v,'eth_num'=>$ip),'eth_ip');
                                            if($find_arr){
                                                $value->getElementsByTagName('ip')->item(0)->nodeValue = $find_arr['eth_ip'];
                                            }
                                       }
                                       
                                }
                                 $new_local_path = $local_path.'1';
                                 $doc->save($new_local_path);
                             }
                        }else{
                            $new_local_path = $local_path;
                        }
                        $exc_words = $new_local_path.' root@'.$hardware_data['eth_ip'].':'.$hardware_data['ftp_dir'].'/'.$new_name;
                        // $app_data = $this->App_model->select('hardware_id = '.$v);
                        $h_d = $this->Hardware_model->get_one('hardware_id = '.$v);
                        // exec('scp '.$exc_words,$a,$status);
                        $this->load->library('ftp');
                        $config['hostname'] = $hardware_data['eth_ip'];
                        $config['username'] = 'root';
                        $config['password'] = 'atc4';
                        $config['debug'] = TRUE;

                        $this->ftp->connect($config);
                        $status = $this->ftp->upload($new_local_path,$hardware_data['ftp_dir'].'/'.$new_name,'ascii',0775);

                        // $status = curl_ftp_upload($hardware_data['ftp_dir'],$new_local_path,$new_name,$hardware_data['eth_ip']);
                        if(!$status){
                            // var_dump($exc_words);exit;
                            throw new Exception('上传至'.$h_d['hardware_name'].'失败');
                            
                            // $flag = false;
                            break;
                        }
                        
                                             
                    }else{
                        throw new Exception($hardware_data['hardware_name'].'网口信息不存在');
                        /*$flag  = false;
                        break;*/
                    }
                }
                 $this->ftp->close();
                // return $flag;
            }else{
                throw new Exception($xml_one['xml_name'].'的资源不存在');
                // return false;
            }                       
    }


    //发布参数配置文件 kind 1基站2雷达3旁路4数据输出
    public function publish_file_add($xml_id = 0){
         if($this->input->is_ajax_request())
        {
             //接收POST参数
            $xml_id = isset($_POST["xml_id"])?trim(intval($_POST["xml_id"])):exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            if(!$xml_id)exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
           /* $hardware_id_arr = isset($_POST["hardware_id"])?$_POST['hardware_id']:array();


            if(empty($hardware_id_arr)){
                exit(json_encode(array('status'=>false,'tips'=>'服务器不能为空')));
            }*/
            $remark = trim(safe_replace($this->input->post('remark')));
            if(!$remark)exit(json_encode(array('status'=>false,'tips'=>'备注不能为空')));
            //进行重复添加判断
            $xml_info = $this->All_xml_model->get_one(array('id'=>$xml_id));
            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '进行配置文件'.$xml_info['xml_name'].'的发布';
            try{
                    $hardware_ids = $this->Xml_basic_config_model->get_one(array('name'=>$xml_info['config_name'],'is_del'=>0),'hardware_ids');
                    if(!$hardware_ids){
                        // exit(json_encode(array('status'=>FALSE,'tips'=>'请先进行'.$xml_info['config_name'].'参数目标服务器配置')));
                        throw new Exception("参数目标服务器配置");

                    }else{
                        $hardware_id_arr = explode(',', $hardware_ids['hardware_ids']);
                    }
                    $xml_path = $xml_info['xml_path'].$xml_info['xml_name'];
                   
                    if(!file_exists($xml_path)){
                        throw new Exception($xml_info['xml_name']."上传的资源不存在");
                        // exit(json_encode(array('status'=>FALSE,'tips'=>'上传的资源不存在')));
                    }
                    //开启事务
                    $this->db->trans_begin();
                    $this->ftp_versions($xml_id,$hardware_id_arr,$remark,2);
                    //进行同一类型的比较
                    $check_kind = $this->Config_hardware_relation_model->get_one(array('xml_kind'=>$xml_info['kind'],'is_del'=>0),'id');
                    if($check_kind){
                        //进行旧版本的删除
                        $up_old_res = $this->Config_hardware_relation_model->update(array('is_del'=>1),array('id'=>$check_kind['id']));
                        if(!$up_old_res){
                            throw new Exception("旧版本删除失败，请联系管理员");
                            // exit(json_encode(array('status'=>FALSE,'tips'=>'旧版本删除失败，请联系管理员')));
                        }
                    }

                    $relate_data = array('xml_id'=>$xml_id,'insert_time'=>time(),'xml_kind'=>$xml_info['kind'],'remark'=>$remark,'hardware_ids'=>implode(',', $hardware_id_arr),'do_main_socket_send'=>0,'do_slave_socket_send'=>0);
                    //进行修改
                    $status = $this->Config_hardware_relation_model->insert($relate_data);
            }catch (Exception $e){

                    $operation_data['is_success'] = 0;
                    $operation_data['status_explain'] = $e->getMessage();
                    $this->db->trans_rollback();

                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>false,'tips'=>$e->getMessage())));
            }
            $operation_data['info_url'] = 'PublishDataDeploy/publish_file_info/'.$status;
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '发布成功';
            $this->db->trans_commit();

            @$this->operationLogs($operation_data);
            exit(json_encode(array('status'=>true,'tips'=>'程序版本添加成功')));
        }else{
            //配置文件查找
            //ssh scp /var/www/test.php root@192.168.0.101:/var/www/
            if($xml_id){
                $all_config_xml = $this->All_xml_model->select(array('id'=>$xml_id));
                $xml_path = $all_config_xml[0]['xml_path'].$all_config_xml[0]['xml_name'];
            }else{
                $all_config_xml = $this->All_xml_model->select('is_old = 0 and kind !=6');
                $xml_path = $all_config_xml[0]['xml_path'].$all_config_xml[0]['xml_name'];

            }

            if(file_exists($xml_path)){
                $doc = new DOMDocument(); 
                $doc -> load($xml_path);
                $xml_data =  $doc->saveXML();
            }else{
                $xml_data = -1;
            }
            if(!$all_config_xml){
                $this->showmessage('请先生成配置文件');exit;
            }
            //进行xml查看
            $all_hardware_lists = $this->Hardware_model->select('hardware_type_id = 2','hardware_id,hardware_name');
            $this->view('publish_file',array('is_edit'=>false,'require_js'=>true,'all_config_xml'=>$all_config_xml,'all_hardware_lists'=>$all_hardware_lists,'xml_id'=>$xml_id,'xml_data'=>htmlentities($xml_data)));
        }
    }

        //发布参数配置文件 kind 1基站2雷达3旁路4数据输出
    public function publish_file_info($id){
        $id = intval($id);
        $data_info = $this->Config_hardware_relation_model->get_one(array('id'=>$id));
         if($this->input->is_ajax_request())
        {
            //接收POST参数
             //接收POST参数
            $xml_id = isset($_POST["xml_id"])?trim(intval($_POST["xml_id"])):exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            if(!$xml_id)exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            $hardware_id_arr = isset($_POST["hardware_id"])?$_POST['hardware_id']:array();
            if(empty($hardware_id_arr)){
                exit(json_encode(array('status'=>false,'tips'=>'服务器不能为空')));
            }
            $remark = safe_replace($_POST["remark"]);

            //进行重复添加判断
            $xml_info = $this->Config_hardware_relation_model->get_one(array('xml_id'=>$xml_id),'id');
            if($xml_info){
                exit(json_encode(array('status'=>false,'tips'=>'该配置文件已经添加，请进行更新')));
            }
            //进行ftp的上传
             // $status = $upload_status = $this->ftp_versions($xml_id,$hardware_id_arr,$remark,2);
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'程序版本添加成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'程序版本添加失败')));
            }
        }else{
            //配置文件查找
            if(!$data_info){
                $this->showmessage('参数错误');
            }
            $data_info['hardware_id_arr'] = explode(',', $data_info['hardware_ids']);
            $all_config_xml = $this->All_xml_model->select(array('id'=>$data_info['xml_id']));
            if(!$all_config_xml){
                $this->showmessage('请先生成配置文件');exit;
            }
            $xml_path = $all_config_xml[0]['xml_path'].$all_config_xml[0]['xml_name'];
             if(file_exists($xml_path)){
                $doc = new DOMDocument(); 
                $doc -> load($xml_path);
                $xml_data =  $doc->saveXML();
            }else{
                $xml_data = -1;
            }

            $all_hardware_lists = $this->Hardware_model->select('','hardware_id,hardware_name');
            $this->view('publish_file',array('is_edit'=>true,'require_js'=>true,'all_config_xml'=>$all_config_xml,'all_hardware_lists'=>$all_hardware_lists,'data_info'=>$data_info,'xml_data'=>htmlentities($xml_data)));
        }
    }

    public function xml_info_show($xml_id){
        $this_xml_info = $this->All_xml_model->get_one(array('id'=>$xml_id));
        if($this_xml_info){
            $xml_path = $this_xml_info['xml_path'].$this_xml_info['xml_name'];
            if(file_exists($xml_path)){
                $doc = new DOMDocument(); 
                $doc -> load($xml_path);
                $xml_data =  $doc->saveXML();
            }else{
                $xml_data = '资源已经被删除';
            }
        }else{
            $xml_data = '参数错误';
        }
        //进行备注资源的倒叙查找
        $remark_info = $this->Config_hardware_relation_model->get_one(array('xml_id'=>$xml_id,'remark'));
        if(!$remark_info){
            $remark_info = '该文件暂未上传至对应服务器';
        }else{
            $remark_info = $remark_info['remark'];
        }
        echo json_encode(array('xml_data'=>htmlentities($xml_data),'remark_info'=>$remark_info));
    }

    //参数目标服务器配置列表
    public function goalFileManage($page_no = 0){
        $page_no = max(intval($page_no),1);
        $where ='is_del = 0';
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where = " and name like '%{$keyword}%' ";
        }
        $data_list = $this->Xml_basic_config_model->listinfo($where,'*',$orderby , $page_no, $this->Xml_basic_config_model->page_size,'',$this->Xml_basic_config_model->page_size,page_list_url('adminpanel/PublishDataDeploy/goalFileManage',true));
        //进行新版本的提醒查询  is_old 判断有无新的文件进行了覆盖
        $this->view('goal_file_lists',array('data_list'=>$data_list,'pages'=>$this->Xml_basic_config_model->pages,'keyword'=>$keyword,'require_js'=>true)); 
    }
    //添加
    public function goal_file_add($id = 0){
        if($this->input->is_ajax_request())
        {
            $hardware_id_arr = isset($_POST["hardware_id"])?$_POST['hardware_id']:array();
            if(empty($hardware_id_arr)){
                exit(json_encode(array('status'=>false,'tips'=>'服务器不能为空')));
            }
            $_arr['hardware_ids'] = implode(',', $hardware_id_arr);
            $_arr['name'] = $this->input->post('name')?$this->input->post('name'):exit(json_encode(array('status'=>false,'tips'=>'参数文件名称不能为空')));
            $_arr['basic_xml_name'] = $this->input->post('basic_xml_name')?$this->input->post('basic_xml_name'):exit(json_encode(array('status'=>false,'tips'=>'xml文件名不能为空')));
            $_arr['remark'] = $this->input->post('remark')?$this->input->post('remark'):'';
            $_arr['dateline'] = time();
            $new_id = $this->Xml_basic_config_model->insert($_arr);
            if($new_id){
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            }else{
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => $new_id)));
            }
            
        }else{
            //配置文件查找
            //ssh scp /var/www/test.php root@192.168.0.101:/var/www/
            $all_hardware_lists = $this->Hardware_model->select('hardware_type_id = 2','hardware_id,hardware_name');
            $this->view('goal_file_edit', array('is_edit' => false, 'require_js' => true, 'data_info' => $this->Xml_basic_config_model->default_info(),'all_hardware_lists'=>$all_hardware_lists));
            
        }
    }
    //编辑
    public function goal_file_edit($id = 0){
        if($this->input->is_ajax_request())
        {
            $hardware_id_arr = isset($_POST["hardware_id"])?$_POST['hardware_id']:array();
            if(empty($hardware_id_arr)){
                exit(json_encode(array('status'=>false,'tips'=>'服务器不能为空')));
            }
            $_arr['hardware_ids'] = implode(',', $hardware_id_arr);
            $_arr['name'] = $this->input->post('name')?$this->input->post('name'):exit(json_encode(array('status'=>false,'tips'=>'文件名不能为空')));
            $_arr['basic_xml_name'] = $this->input->post('basic_xml_name')?$this->input->post('basic_xml_name'):exit(json_encode(array('status'=>false,'tips'=>'xml文件名不能为空')));
            $_arr['remark'] = $this->input->post('remark')?$this->input->post('remark'):'';
            $_arr['dateline'] = time();
            $new_id = $this->Xml_basic_config_model->update($_arr,array('id'=>$id));
            if($new_id){
                exit(json_encode(array('status' => true, 'tips' => '信息新增成功', 'new_id' => $new_id)));
            }else{
                exit(json_encode(array('status' => false, 'tips' => '信息新增失败', 'new_id' => $new_id)));
            }
            
        }else{
            //配置文件查找
            //ssh scp /var/www/test.php root@192.168.0.101:/var/www/
            $id = intval($id);
            $data_info = $this->Xml_basic_config_model->get_one(array('id' => $id));
            if(!$data_info){
                $this->showmessage('参数错误');
            }
            $data_info['hardware_id_arr'] = explode(',', $data_info['hardware_ids']);
            // print_r($data_info);exit;
            $all_hardware_lists = $this->Hardware_model->select('hardware_type_id = 2','hardware_id,hardware_name');
            $this->view('goal_file_edit', array('is_edit' => true,'id'=>$id, 'require_js' => true, 'data_info' => $data_info,'all_hardware_lists'=>$all_hardware_lists));
            
        }
    }

    //删除
    public function goal_file_delete($id =0){
        $id = intval($id);
        $old_data = $this->Xml_basic_config_model->get_one(array('id'=>$id));
        if(!$old_data){
                $this->showmessage('参数错误');
        }
        $up_res = $this->Xml_basic_config_model->update(array('is_del = 1'),array('id'=>$id));
        $operation_data = $this->operation_data;
        $operation_data['dateline'] = time();
        $operation_data['operate_explain'] = '进行目标服务器配置文件'.$old_data['name'].'的发布';
        // $operation_data['info_url'] = 'PublishDataDeploy/info/'.$id;
        if($up_res){
             $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '删除成功';
            @$this->operationLogs($operation_data);
                $this->showmessage('删除成功');
        }else{
             $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '删除失败';
            @$this->operationLogs($operation_data);
                $this->showmessage('删除失败');
        }
    }
    /*
    *发布文件之后，重启进程
    *
    */
    public function server_config_restart($id =0,$kind=1){
        $id = intval($id);
        $kind = intval($kind);
        $hardware_id_arr = $this->Config_hardware_relation_model->tables_select(array('config_hardware_relation.id'=>$id),'hardware_ids,config_name')[0];
        if(!$hardware_id_arr){
            $this->showmessage('参数有误');
        }
        $the_hardware = $this->Hardware_model->select('hardware_id in ('.$hardware_id_arr['hardware_ids'].') and is_main ='.$kind,'hardware_other_name,hardware_id');
        if(!$the_hardware){
            $this->showmessage('未找到目标服务器');
        }
        foreach ($the_hardware as $key => $value) {
                $the_hardware[$key]['program_name'] = $this->App_model->get_one('locate('.$value['hardware_id'].',hardware_id) and is_del = 0','program_name')['program_name'];
        }        
        $operation_data = $this->operation_data;
        $operation_data['dateline'] = time();
        $operation_data['operate_explain'] = '进行配置文件'.$hardware_id_arr['config_name'].'的重读生效';
        try{
            foreach($the_hardware as $key => $val)
            {
                // $msg = '<MSG TYPE="5" MODULENAME="'.$h_d['hardware_other_name'].'" APPNAME="'.$val['program_name'].'" FULLPATH="" SENDTIME="' . date("H:i:s Y:m:d") . '" />';
                $msg = '<MSG TYPE="4" MODULENAME=\''.$val['hardware_other_name'].'\' APPNAME=\''.$val['program_name'].'\' FULLPATH="" CONFIGFILEPATH=""  SENDTIME=\''.date('Y-m-d H:i:s').'\' />';
                $status = send_udp(SYSTEMSENDIP, SYSTEMSENDPORT, $msg, 0);
                if(!$status){
                    throw new Exception("发送至".$val['hardware_other_name']."重读配置文件失败");
                }
            }  
            //进行数据库修改
            if($kind == 1){
                $this->Config_hardware_relation_model->update(array('do_main_socket_send'=>1),array('id'=>$id));
            }else{
                $this->Config_hardware_relation_model->update(array('do_slave_socket_send'=>1),array('id'=>$id));
            }
        }catch(Exception $e){
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = $e->getMessage();
            @$this->operationLogs($operation_data);
            $this->showmessage('重读配置文件生效失败','',3000);
            exit;
        }
        $operation_data['is_success'] = 1;
        $operation_data['status_explain'] = '发布成功';
        @$this->operationLogs($operation_data);
        $this->showmessage('重读配置文件生效成功','',3000);
        exit;

    }
}
