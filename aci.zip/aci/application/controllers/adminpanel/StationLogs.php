<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-10
 * Time: 上午9:01
 * To change this template use File | Settings | File Templates.
 */
class Stationlogs extends Admin_Controller {
    function __construct()
    {
        // date_default_timezone_set("UTC");
        parent::__construct();
        $this->load->model(array('Station_model','Station_config_model'));
    }

    function lists($page_no=1)
    {
        // $post_data = $_POST;
        $data_list = array();
        $pages = '';
        $start_time =  trim(safe_replace($this->input->get('start_time')));
        $end_time = trim(safe_replace($this->input->get('end_time')));
        $station_id = trim(safe_replace($this->input->get('station_id')));
        $channel_id = $this->input->get('channel_id');
        $log_kind = $this->input->get('log_kind');

        if(!$station_id){
            $station_id = $this->Station_model->get_one('','station_id')['station_id'];
        }
        if(!$channel_id){
            $channel_id = 2;
        }
        if(!$log_kind){
            $log_kind = 0;
        }
        if(!$start_time){
            $start_time = strtotime(date('Y-m-d 00:00:00'));
        }else {
            $start_time = strtotime($start_time);
        }
        if(!$end_time){
            $end_time = $start_time + 24*60*60;//一天内的数据
        }else {
            $end_time = strtotime($end_time);
        }

        if(!$station_id || !$channel_id || !$start_time || !$end_time){
            $search_warning = true;
        }else{
            $search_warning = false;
        }
        // var_dump($_GET);exit;
        //进行单个文件的数据量查看
        
        if($station_id && $channel_id && $start_time && $end_time){
            //进行读文件 
            if($start_time == $end_time){
                //进行往后6小时的添加
                $end_time_stamp =$start_time+6*60*60; 
            }else{
                $end_time_stamp =$end_time; 
            }

            if($start_time > $end_time){
                $start_time = $end_time;
                $end_time = $start_time;
            }else{

            }
            $all_station_arr = $this->Station_model->select('','station_id');

            if($station_id){
                $souce_id = 0;
                foreach ($all_station_arr as $key => $value) {
                    if($value['station_id'] == $station_id){
                        $souce_id = $key;
                    }
                }
                $data_upper_limit = 10000;
                $track_upper_limit = 4096;
                if($channel_id == 2)
                {
                    $config_data = $this->Station_config_model->get_one(array('station_id'=>$station_id),'data_upper_limit_A,track_upper_limit_A');
                    $data_upper_limit = $config_data["data_upper_limit_A"];
                    $track_upper_limit = $config_data["track_upper_limit_A"];
                }
                elseif($channel_id == 3)
                {
                    $config_data = $this->Station_config_model->get_one(array('station_id'=>$station_id),'data_upper_limit_B,track_upper_limit_B'); 
                    $data_upper_limit = $config_data["data_upper_limit_B"];
                    $track_upper_limit = $config_data["track_upper_limit_B"];                   
                }


                                // var_dump($start_time);exit;
                $data_list = $this->read_data_limit_file($channel_id,$souce_id,$start_time,$end_time_stamp,$log_kind,$data_upper_limit,$track_upper_limit);
                $pagesize = 20;
                $setpages = 10;
                $urlrule = page_list_url('adminpanel/stationLogs/lists',true);
                $number = count($data_list);
                if($number>0){
                    //进行分页
                        $page = max(intval($page_no),1);
                        $offset = $pagesize*($page-1);
                        if($offset>$number)
                        {
                            $page=round($number/$pagesize);
                            $offset = max($pagesize*($page-1),0);
                        }
                        if($number >$pagesize)
                            $pages = pages($number, $page, $pagesize, $urlrule, array(), $setpages);
                        else
                            $pages = "";
                        $data_list = array_slice($data_list, $offset,$pagesize);
                }
            }
        }
        // print_r($data_list);exit;
        $station_list = $this->Station_model->select('is_del = 0','station_id,station_name');
        $this->view('lists',array('require_js'=>true,'data_list'=>$data_list,'search_warning'=>$search_warning,'station_id'=>$station_id,'pages' =>$pages,'station_list'=>$station_list));   
    }

    //读取数据上线文件的
    private function read_data_limit_file($channel_id,$souce_id,$start_time_stamp,$end_time_stamp,$log_kind,$data_upper_limit,$track_upper_limit){
        //1先判断文件存不存  2文件超时与否 3是否是写完 4是否告警
        $start_day = date('d',$start_time_stamp);
        $end_day = date('d',$end_time_stamp);
        if($start_day == $end_day){
            $sub_day = 0;
        }else {
            $sub_day = 1;
        }
        $data_list = array();
        for($i=0; $i <= $sub_day; $i++) { 
            $date_path = date('Y-m-d',$start_time_stamp+$i*60*60*24);
            if($channel_id == 2){
                $path = DATA_LIMIT_REPORT.'0/'.$date_path.'/REPORT_ADSB_QUALITY_COUNT.dat';
            }else if($channel_id == 3){
                $path = DATA_LIMIT_REPORT.'1/'.$date_path.'/REPORT_ADSB_QUALITY_COUNT.dat';
            }else if($channel_id == 1){
                $path = DATA_LIMIT_REPORT.'2/'.$date_path.'/REPORT_ADSB_QUALITY_COUNT.dat';
            }
            if(file_exists($path)){
                $file_open = fopen($path,'r');              
                $match_source_id = "SOURCEID:".$souce_id.";";
                //var_dump($match_source_id);exit;
                $tmp_arr = $data_list = array();
                $j = 0;
                while (!feof($file_open)) {
                    //逐行读取文件内容
                    $tmp_str = fgets($file_open);
                    if(strpos($tmp_str,'begin;') !== false){
                        $tmp_time = substr($tmp_str, 6);
                        $read_time = strtotime($tmp_time);
                        if($read_time >=$start_time_stamp && $read_time <=$end_time_stamp){
                            //放入缓存中
                            setcache('cache_read_time',$read_time);
                        } else{
                            setcache('cache_read_time',null);
                        }
                            //清除缓存
                    }
                    if(strpos($tmp_str, $match_source_id) !==false && getcache('cache_read_time')){
                        //进行读取 并添加时间
                        $tmp_arr[$j] = $tmp_str.';dateline:'.getcache('cache_read_time');
                        $j++;
                    }
                }
                // print_r($tmp_arr);exit;
                //var_dump($source_id);exit;

                if(empty($tmp_arr)){
                    continue;
                }else{

                    foreach ($tmp_arr as $key => $value) {
                       $value = explode(';', $value);
                       if($log_kind == 1){
                        //所有日志

                           $data_list[$i][$key]['count'] = substr($value[1], 6);                      
                           $data_list[$i][$key]['target_cnt'] = substr($value[2], 11);
                           $data_list[$i][$key]['dispear_cnt'] = substr($value[3], 12);
                           $data_list[$i][$key]['test_dispear_cnt'] = substr($value[4], 17);
                           $data_list[$i][$key]['error_cnt'] = substr($value[5], 10);
                           $data_list[$i][$key]['post_jump_cnt'] = substr($value[6], 13);
                           $data_list[$i][$key]['height_jump_cnt'] = substr($value[7], 16);
                           $data_list[$i][$key]['dateline'] = substr($value[16], 9);
                           if(substr($value[1], 6) > $data_upper_limit)
                            {
                                $data_list[$i][$key]['station_status'] = '<dd style="color:red;">数据帧数量超载</dd>';
                                // return $data_list;
                            }
                            elseif(substr($value[2], 11) > $track_upper_limit)
                            {
                                $data_list[$i][$key]['station_status'] = '<dd style="color:red;">航迹数量超载</dd>';
                                // return $data_list;
                            }                      
							
                            if($data_list[$i][$key]['count'] >0 && $data_list[$i][$key]['target_cnt'] >0 && $data_list[$i][$key]['dispear_cnt'] ==0 &&$data_list[$i][$key]['test_dispear_cnt'] == 0 && $data_list[$i][$key]['error_cnt'] == 0 && $data_list[$key]['post_jump_cnt'] == 0 && $data_list[$key]['height_jump_cnt'] == 0){
                                    $data_list[$key]['station_status'] = '正常';                                                   
                            }else {                            
                                $data_list[$i][$key]['station_status'] = '<dd style="color:red;">数据异常</dd>';
                             }

                       }else{
                            if($log_kind == 0){
                                //异常过滤
                                if(intval(substr($value[1],6)) == 0 || intval(substr($value[2],11)) !=0 && intval(substr($value[3],12)) !=0 ||intval(substr($value[4],17)) != 0 && intval(substr($value[5],10)) != 0 && intval(substr($value[6],13)) != 0 &&intval(substr($value[5],16)) != 0){
                                    $data_list[$i][$key]['count'] = substr($value[1], 6);                      
                                   $data_list[$i][$key]['target_cnt'] = substr($value[2], 11);
                                   $data_list[$i][$key]['dispear_cnt'] = substr($value[3], 12);
                                   $data_list[$i][$key]['test_dispear_cnt'] = substr($value[4], 17);
                                   $data_list[$i][$key]['error_cnt'] = substr($value[5], 10);
                                   $data_list[$i][$key]['post_jump_cnt'] = substr($value[6], 13);
                                   $data_list[$i][$key]['height_jump_cnt'] = substr($value[7], 16);
                                   $data_list[$i][$key]['dateline'] = substr($value[16], 9);
                                   $data_list[$i][$key]['station_status'] = '<dd style="color:red;">数据异常</dd>';
                                }

                            }else{
                                //超载
                                if($log_kind == 2 && (substr($value[1], 6) > $data_upper_limit || substr($value[2], 11) > $track_upper_limit)){
                                       $data_list[$i][$key]['count'] = substr($value[1], 6);                      
                                       $data_list[$i][$key]['target_cnt'] = substr($value[2], 11);
                                       $data_list[$i][$key]['dispear_cnt'] = substr($value[3], 12);
                                       $data_list[$i][$key]['test_dispear_cnt'] = substr($value[4], 17);
                                       $data_list[$i][$key]['error_cnt'] = substr($value[5], 10);
                                       $data_list[$i][$key]['post_jump_cnt'] = substr($value[6], 13);
                                       $data_list[$i][$key]['height_jump_cnt'] = substr($value[7], 16);
                                       $data_list[$i][$key]['dateline'] = substr($value[16], 9);
                                       if(substr($value[1], 6) > $data_upper_limit)
                                        {
                                            $data_list[$i][$key]['station_status'] = '<dd style="color:red;">数据帧数量超载</dd>';
                                            // return $data_list;
                                        }
                                        elseif(substr($value[2], 11) > $track_upper_limit)
                                        {
                                            $data_list[$i][$key]['station_status'] = '<dd style="color:red;">航迹数量超载</dd>';
                                            // return $data_list;
                                        }
                                            
                                }
                            }
                       }

                       
                    }
                        @setcache('cache_read_time',null);
                        // return $data_list;
                    }
            }else{
                // return array();

            }
        }
        // print_r($data_list);exit;
        $new_data = array();
        if(!empty($data_list)){
            foreach ($data_list as $key => $value) {
                foreach ($value as $k => $v) {
                    $new_data[] = $v; 
                }
            }
        }

        return $new_data;
    }

}