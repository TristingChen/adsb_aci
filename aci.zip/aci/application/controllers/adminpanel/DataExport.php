<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class DataExport extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Data_export_model','Data_export_users_model','Area_model','Polygons_dots_model','All_xml_model','Xml_basic_config_model','Polygons_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  name like '%{$keyword}%'";
        }

        $where = implode('and',$where_arr);
        $fresh_xml_data = $this->All_xml_model->get_one(array('kind'=>4,'is_old'=>0),'id');

        $data_list = $this->Data_export_users_model->listinfo($where,'*',$orderby , $page_no, $this->Data_export_users_model->page_size,'',$this->Data_export_users_model->page_size,page_list_url('adminpanel/dataExport/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Data_export_users_model->pages,'keyword'=>$keyword,'require_js'=>true,'fresh_xml_data'=>$fresh_xml_data));
    }

    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            /*$_arr['user_id'] = isset($_POST["user_id"])?trim(safe_replace($_POST["user_id"])):exit(json_encode(array('status'=>false,'tips'=>'用户名id不得为空')));
            if($_arr['user_id']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名id不得为空')));*/

            $_arr['type'] = isset($_POST["type"])?trim(safe_replace($_POST["type"])):exit(json_encode(array('status'=>false,'tips'=>'数据传输不得为空')));
            if($_arr['type']=='')exit(json_encode(array('status'=>false,'tips'=>'数据传输不得为空')));
             
            $_arr['duration_switch'] = isset($_POST["duration_switch"])?trim(safe_replace($_POST["duration_switch"])):exit(json_encode(array('status'=>false,'tips'=>'周期输出开关不得为空')));
            if($_arr['duration_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'周期输出开关不得为空')));
            
             if($_arr['duration_switch']){
                $_arr['duration_val'] = isset($_POST["duration_val"])?trim(safe_replace($_POST["duration_val"])):exit(json_encode(array('status'=>false,'tips'=>'周期输出时长不得为空')));
                if($_arr['duration_val']=='')exit(json_encode(array('status'=>false,'tips'=>'周期输出时长不得为空')));
            }
            

            $_arr['delay_switch'] = isset($_POST["delay_switch"])?trim(safe_replace($_POST["delay_switch"])):exit(json_encode(array('status'=>false,'tips'=>'延迟输出开关不得为空')));
            if($_arr['delay_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'延迟输出开关不得为空')));
            if( $_arr['delay_switch']){
                 $_arr['delay_val'] = isset($_POST["delay_val"])?trim(safe_replace($_POST["delay_val"])):exit(json_encode(array('status'=>false,'tips'=>'延迟输出时长不得为空')));
                 if($_arr['delay_val']=='')exit(json_encode(array('status'=>false,'tips'=>'延迟输出时长不得为空')));
            }

            $_arr['cast_type'] = isset($_POST["cast_type"])?trim(safe_replace($_POST["cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'cast_type不得为空')));
            if($_arr['cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'cast_type不得为空')));
            
            if($_arr['cast_type'] == 2){
                $_arr['eth_num'] = trim(safe_replace($_POST["eth_num"]))?trim(safe_replace($_POST["eth_num"])):exit(json_encode(array('status'=>false,'tips'=>'发送服务器网口不得为空')));
                $_arr['cast_type_ip']  = trim(safe_replace($_POST["cast_type_ip"]))?trim(safe_replace($_POST["cast_type_ip"])):exit(json_encode(array('status'=>false,'tips'=>'组播地址不得为空')));
            }else{
                $_arr['send_a_ip'] = isset($_POST["send_a_ip"])?trim(safe_replace($_POST["send_a_ip"])):exit(json_encode(array('status'=>false,'tips'=>'发送IP不得为空')));
                if($_arr['send_a_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'发送IP不得为空')));
            }
             $_arr['send_a_port'] = isset($_POST["send_a_port"])?trim(safe_replace($_POST["send_a_port"])):exit(json_encode(array('status'=>false,'tips'=>'发送端口不得为空')));
            if($_arr['send_a_port']=='')exit(json_encode(array('status'=>false,'tips'=>'发送端口不得为空')));
           
            $_arr['station_switch'] = isset($_POST["station_switch"])?trim(safe_replace($_POST["station_switch"])):exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            if($_arr['station_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            $_arr['station_switch'] = isset($_POST["station_switch"])?trim(safe_replace($_POST["station_switch"])):exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            if($_arr['station_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            $station_list = $this->input->post('station_list');
            if($_arr['station_switch']){
                if(!empty($station_list)){
                    $_arr['station_list'] = implode(',', $station_list);
                }else{
                    exit(json_encode(array('status'=>false,'tips'=>'基站选择不得为空')));
                }
            }
            
            $_arr['station_flip'] = isset($_POST["station_flip"])?trim(safe_replace($_POST["station_flip"])):exit(json_encode(array('status'=>false,'tips'=>'基站取反不得为空')));
            if($_arr['station_flip']=='')exit(json_encode(array('status'=>false,'tips'=>'基站取反不得为空')));
            
            $_arr['select_item_switch'] = isset($_POST["select_item_switch"])?trim(safe_replace($_POST["select_item_switch"])):"";
            $_arr['select_item_version'] = isset($_POST["select_item_version"])?trim(safe_replace($_POST["select_item_version"])):"";
            // $_arr['select_item_val'] = isset($_POST["select_item_val"])?trim(safe_replace($_POST["select_item_val"])):"";
            
            $select_item_val = $this->input->post('select_item_val');
            $cat_version_data = $this->cat_version_data();
            if(!empty($select_item_val)){
                $the_chosed_data = $cat_version_data[$_arr['select_item_version']];
                $tmp_data = array();
                foreach ($the_chosed_data as $key => $value) {
                    if(in_array($key, $select_item_val)){
                        $tmp_data[$key] = 1;
                    }else{
                        $tmp_data[$key] = 0;
                    }
                }
                $_arr['select_item_val'] = implode(',', $tmp_data);
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'版本输出项不得为空')));
            }
            $_arr['target_add_switch'] = isset($_POST["target_add_switch"])?trim(safe_replace($_POST["target_add_switch"])):exit(json_encode(array('status'=>false,'tips'=>'24位地址码开关不得为空')));
            if($_arr['target_add_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'24位地址码开关不得为空')));
            if($_arr['target_add_switch']){
                $_arr['target_add_list'] = isset($_POST["target_add_list"])?trim(safe_replace($_POST["target_add_list"])):exit(json_encode(array('status'=>false,'tips'=>'24位地址码不得为空')));
                if($_arr['target_add_list']=='')exit(json_encode(array('status'=>false,'tips'=>'24位地址码不得为空')));
                $_arr['station_flip'] = isset($_POST["station_flip"])?trim(safe_replace($_POST["station_flip"])):exit(json_encode(array('status'=>false,'tips'=>'24位地址码取反不得为空')));
                if($_arr['station_flip']=='')exit(json_encode(array('status'=>false,'tips'=>'24位地址码取反不得为空')));
            }
            

            $_arr['company_switch'] = isset($_POST["company_switch"])?trim(safe_replace($_POST["company_switch"])):exit(json_encode(array('status'=>false,'tips'=>'公司三字码开关不得为空')));
            if($_arr['company_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'公司三字码开关不得为空')));
            if($_arr['company_switch']){
                 $_arr['company_list'] = isset($_POST["company_list"])?trim(safe_replace($_POST["company_list"])):exit(json_encode(array('status'=>false,'tips'=>'公司三字码不得为空')));
                if($_arr['company_list']=='')exit(json_encode(array('status'=>false,'tips'=>'公司三字码不得为空')));
                $_arr['company_flip'] = isset($_POST["company_flip"])?trim(safe_replace($_POST["company_flip"])):exit(json_encode(array('status'=>false,'tips'=>'公司三字码取反不得为空')));
                if($_arr['company_flip']=='')exit(json_encode(array('status'=>false,'tips'=>'公司三字码取反不得为空')));
            }

            $_arr['range_switch'] = isset($_POST["range_switch"])?trim(safe_replace($_POST["range_switch"])):exit(json_encode(array('status'=>false,'tips'=>'区域开关不得为空')));
            if($_arr['range_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'区域开关不得为空')));
            if( $_arr['range_switch']){
                 $_arr['range_list'] = isset($_POST["range_list"])?trim(safe_replace($_POST["range_list"])):exit(json_encode(array('status'=>false,'tips'=>'区域不得为空')));
                if($_arr['range_list']=='')exit(json_encode(array('status'=>false,'tips'=>'区域不得为空')));
            }
            $_arr['dateline'] = time();
            $_arr['faker_range'] = (int)$this->input->post('faker_range');
            $_arr['faker_radar'] = (int)$this->input->post('faker_radar');
            $_arr['faker_tdoa'] = (int)$this->input->post('faker_tdoa');
            $_arr['faker_plan'] = (int)$this->input->post('faker_plan');
            $_arr['from_type'] = (int)$this->input->post('from_type');
            // $_arr['is_output'] = (int)$this->input->post('is_output');
            $user_id = $this->Data_export_users_model->get_one('','max(user_id) as user_id');
            if(!$user_id){
                $_arr['user_id'] = 1000;
            }else{
                if($user_id['user_id'] > 65535){
                    $_arr['user_id'] = 1000;
                }else{
                    $_arr['user_id'] = $user_id['user_id']+1;
                }
            }
            $new_id = $this->Data_export_users_model->insert($_arr);
            // print_r($this->Data_export_users_model->last_query());exit;
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $station_data = $this->Station_model->tables_select('is_del = 0','t_sys_station.station_id,station_name');
            $area_data = $this->Area_model->select();
            if(!$station_data || !$area_data){
                $this->showmessage('请先进行基站与区域管理的添加');exit;
            }
            $cat_version_data = $this->cat_version_data();
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_list'=>$this->Data_export_users_model->default_info(),'station_data'=>$station_data,'area_data'=>$area_data,'cat_version_data'=>$cat_version_data));
        }
    }

    function edit($id=0)
    {
        $id = intval($id);
        $data_info =$this->Data_export_users_model->get_one(array('id'=>$id));
        $cat_version_data = $this->cat_version_data();
        if($this->input->is_ajax_request())
        {
             //接收POST参数
            $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名不得为空')));
            /*$_arr['user_id'] = isset($_POST["user_id"])?trim(safe_replace($_POST["user_id"])):exit(json_encode(array('status'=>false,'tips'=>'用户名id不得为空')));
            if($_arr['user_id']=='')exit(json_encode(array('status'=>false,'tips'=>'用户名id不得为空')));*/

            $_arr['type'] = isset($_POST["type"])?trim(safe_replace($_POST["type"])):exit(json_encode(array('status'=>false,'tips'=>'数据传输不得为空')));
            if($_arr['type']=='')exit(json_encode(array('status'=>false,'tips'=>'数据传输不得为空')));
             
            $_arr['duration_switch'] = isset($_POST["duration_switch"])?trim(safe_replace($_POST["duration_switch"])):exit(json_encode(array('status'=>false,'tips'=>'周期输出开关不得为空')));
            if($_arr['duration_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'周期输出开关不得为空')));
            
            if($_arr['duration_switch']){
                $_arr['duration_val'] = isset($_POST["duration_val"])?trim(safe_replace($_POST["duration_val"])):exit(json_encode(array('status'=>false,'tips'=>'周期输出时长不得为空')));
                if($_arr['duration_val']=='')exit(json_encode(array('status'=>false,'tips'=>'周期输出时长不得为空')));
            }
            

            $_arr['delay_switch'] = isset($_POST["delay_switch"])?trim(safe_replace($_POST["delay_switch"])):exit(json_encode(array('status'=>false,'tips'=>'延迟输出开关不得为空')));
            if($_arr['delay_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'延迟输出开关不得为空')));
            if( $_arr['delay_switch']){
                 $_arr['delay_val'] = isset($_POST["delay_val"])?trim(safe_replace($_POST["delay_val"])):exit(json_encode(array('status'=>false,'tips'=>'延迟输出时长不得为空')));
                 if($_arr['delay_val']=='')exit(json_encode(array('status'=>false,'tips'=>'延迟输出时长不得为空')));
            }

            $_arr['cast_type'] = isset($_POST["cast_type"])?trim(safe_replace($_POST["cast_type"])):exit(json_encode(array('status'=>false,'tips'=>'cast_type不得为空')));
            if($_arr['cast_type']=='')exit(json_encode(array('status'=>false,'tips'=>'cast_type不得为空')));
            
            if($_arr['cast_type'] == 2){
                $_arr['eth_num'] = trim(safe_replace($_POST["eth_num"]))?trim(safe_replace($_POST["eth_num"])):exit(json_encode(array('status'=>false,'tips'=>'发送服务器网口不得为空')));
                $_arr['cast_type_ip']  = trim(safe_replace($_POST["cast_type_ip"]))?trim(safe_replace($_POST["cast_type_ip"])):exit(json_encode(array('status'=>false,'tips'=>'组播地址不得为空')));
            }else{
                $_arr['send_a_ip'] = isset($_POST["send_a_ip"])?trim(safe_replace($_POST["send_a_ip"])):exit(json_encode(array('status'=>false,'tips'=>'发送IP不得为空')));
                if($_arr['send_a_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'发送IP不得为空')));
            }
             $_arr['send_a_port'] = isset($_POST["send_a_port"])?trim(safe_replace($_POST["send_a_port"])):exit(json_encode(array('status'=>false,'tips'=>'发送端口不得为空')));
            if($_arr['send_a_port']=='')exit(json_encode(array('status'=>false,'tips'=>'发送端口不得为空')));

           /* $_arr['send_b_ip'] = isset($_POST["send_b_ip"])?trim(safe_replace($_POST["send_b_ip"])):exit(json_encode(array('status'=>false,'tips'=>'B通道发送IP不得为空')));
            if($_arr['send_b_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'B通道发送IP不得为空')));
             $_arr['send_b_port'] = isset($_POST["send_b_port"])?trim(safe_replace($_POST["send_b_port"])):exit(json_encode(array('status'=>false,'tips'=>'B通道发送端口不得为空')));
            if($_arr['send_b_port']=='')exit(json_encode(array('status'=>false,'tips'=>'B通道发送端口不得为空')));*/

            //过滤
            $_arr['station_switch'] = isset($_POST["station_switch"])?trim(safe_replace($_POST["station_switch"])):exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            if($_arr['station_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            $_arr['station_switch'] = isset($_POST["station_switch"])?trim(safe_replace($_POST["station_switch"])):exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            if($_arr['station_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'基站输出开关不得为空')));
            $station_list = $this->input->post('station_list');
            if($_arr['station_switch'] ){
                if(!empty($station_list)){
                    $_arr['station_list'] = implode(',', $station_list);
                }else{
                    exit(json_encode(array('status'=>false,'tips'=>'基站选择不得为空')));
                }
                $_arr['station_flip'] = isset($_POST["station_flip"])?trim(safe_replace($_POST["station_flip"])):exit(json_encode(array('status'=>false,'tips'=>'基站取反不得为空')));
                if($_arr['station_flip']=='')exit(json_encode(array('status'=>false,'tips'=>'基站取反不得为空')));
            }
            
            
            $_arr['select_item_switch'] = isset($_POST["select_item_switch"])?trim(safe_replace($_POST["select_item_switch"])):"";
            $_arr['select_item_version'] = isset($_POST["select_item_version"])?trim(safe_replace($_POST["select_item_version"])):"";
           /* $_arr['select_item_val'] = isset($_POST["select_item_val"])?trim(safe_replace($_POST["select_item_val"])):"";*/
            $select_item_val = $this->input->post('select_item_val');
            if(!empty($select_item_val)){
                $the_chosed_data = $cat_version_data[$_arr['select_item_version']];
                $tmp_data = array();
                foreach ($the_chosed_data as $key => $value) {
                    if(in_array($key, $select_item_val)){
                        $tmp_data[$key] = 1;
                    }else{
                        $tmp_data[$key] = 0;
                    }
                }
                $_arr['select_item_val'] = implode(',', $tmp_data);
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'版本输出项不得为空')));
            }


            $_arr['target_add_switch'] = isset($_POST["target_add_switch"])?trim(safe_replace($_POST["target_add_switch"])):exit(json_encode(array('status'=>false,'tips'=>'24位地址码开关不得为空')));
            if($_arr['target_add_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'24位地址码开关不得为空')));
            if($_arr['target_add_switch']){
                $_arr['target_add_list'] = isset($_POST["target_add_list"])?trim(safe_replace($_POST["target_add_list"])):exit(json_encode(array('status'=>false,'tips'=>'24位地址码不得为空')));
                if($_arr['target_add_list']=='')exit(json_encode(array('status'=>false,'tips'=>'24位地址码不得为空')));
                $_arr['target_add_flip'] = (int)$this->input->post('target_add_flip');
            }

            $_arr['company_switch'] = isset($_POST["company_switch"])?trim(safe_replace($_POST["company_switch"])):exit(json_encode(array('status'=>false,'tips'=>'公司三字码开关不得为空')));
            if($_arr['company_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'公司三字码开关不得为空')));
            if($_arr['company_switch']){
                 $_arr['company_list'] = isset($_POST["company_list"])?trim(safe_replace($_POST["company_list"])):exit(json_encode(array('status'=>false,'tips'=>'公司三字码不得为空')));
                if($_arr['company_list']=='')exit(json_encode(array('status'=>false,'tips'=>'公司三字码不得为空')));
                $_arr['company_flip'] = isset($_POST["company_flip"])?trim(safe_replace($_POST["company_flip"])):exit(json_encode(array('status'=>false,'tips'=>'公司三字码取反不得为空')));
                if($_arr['company_flip']=='')exit(json_encode(array('status'=>false,'tips'=>'公司三字码取反不得为空')));
            }

            $_arr['range_switch'] = isset($_POST["range_switch"])?trim(safe_replace($_POST["range_switch"])):exit(json_encode(array('status'=>false,'tips'=>'区域开关不得为空')));
            if($_arr['range_switch']=='')exit(json_encode(array('status'=>false,'tips'=>'区域开关不得为空')));
            if( $_arr['range_switch']){
                 $_arr['range_list'] = isset($_POST["range_list"])?trim(safe_replace($_POST["range_list"])):exit(json_encode(array('status'=>false,'tips'=>'区域不得为空')));
                if($_arr['range_list']=='')exit(json_encode(array('status'=>false,'tips'=>'区域不得为空')));
            }
            $_arr['dateline'] = time();   
            $_arr['faker_range'] = (int)$this->input->post('faker_range');
            $_arr['faker_radar'] = (int)$this->input->post('faker_radar');
            $_arr['faker_tdoa'] = (int)$this->input->post('faker_tdoa');
            $_arr['faker_plan'] = (int)$this->input->post('faker_plan');
            $_arr['from_type'] = (int)$this->input->post('from_type');
            // $_arr['is_output'] = (int)$this->input->post('is_output');
            $status = $this->Data_export_users_model->update($_arr,array('id'=>$id));
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $select_item_val_str = $data_info['select_item_val'];
            $select_item_val_arr = explode(',', $select_item_val_str);
            $the_chosed_data = $cat_version_data[$data_info['select_item_version']];
            $data_info['station_list'] = explode(',', $data_info['station_list']);

            /*$data_info['min_height'] = explode(';', $data_info['height_list'])[0];
            $data_info['max_height'] = explode(';', $data_info['height_list'])[1];*/
            $station_data = $this->Station_model->tables_select('is_del = 0','t_sys_station.station_id,station_name');
            $area_data = $this->Area_model->select();
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_list'=>$data_info,'station_data'=>$station_data,'area_data'=>$area_data,'id'=>$id,'cat_version_data'=>$cat_version_data,'the_chosed_data'=>$the_chosed_data,'select_item_val_arr'=>$select_item_val_arr));
        }
    }
    
    function delete($id=0)
    {
        $status = $this->Data_export_users_model->delete(array('id'=>$id));
        if($status)
        {
            $this->showmessage('删除成功');
        }else{
            $this->showmessage('删除失败');
        }
    }

    function produce_xml(){
            $data_config = $this->Data_export_model->get_one();  //数据输出基础数据

            $data_list = $this->Data_export_users_model->select();
            // print_r($data_list);exit;
            //针对range进行多边形的查找
            foreach ($data_list as $key => $value) {
                if($value['range_list'] == 0){
                    $polygons_ids = $this->Area_model->get_one(array('id'=>1),'polygons_ids'); //目前区域单选
                }else{
                    $polygons_ids = $this->Area_model->get_one(array('id'=>$value['range_list']),'polygons_ids'); //目前区域单选
                }
                $polygons_ids_arr = explode(',', $polygons_ids['polygons_ids']);//多个多边形
                // print_r($polygons_ids_arr);exit;
                foreach ($polygons_ids_arr as $k => $v) {

                    $tmp_arr = $this->Polygons_dots_model->select(array('polygons_id'=>$v));

                    $range_list = '';
                    foreach ($tmp_arr as $kk => $vv) {
                        $range_list .= $vv['longtitude'].';'.$vv['latitude'].',';
                    }
                    $range_list = rtrim($range_list,',');  
                    $polygons_data = $this->Polygons_model->get_one(array('id'=>$v),'height_list,flip_switch');
                    $polygons_data['lat_long'] =  $range_list;
                    $data_list[$key]['one_range_list'][$k] = $polygons_data;  //经纬度

                }
            }
            // print_r($data_list);exit;
            $xmlpatch = DATA_EXPORT_XML_PATH.'publisher_config.xml';
            $doc = new DOMDocument('1.0','utf-8');   
            $flag = false;
            if(file_exists($xmlpatch)) {   
            //备份以前的xml版本 2017_12_1_16_48
                $flag = true;
            }
            $doc -> formatOutput = true;
            $publish = $doc -> createElement('publish');//新建节点
            // $publish = $this->create_config_xml($doc,$publish,$data_config);

            $users = $doc->createElement('users');
            foreach ($data_list as $key => $value) {
                $user = $doc -> createElement('user');
                $users = $this->create_only_xml($doc,$users,$user,$value);
            }
            $publish->appendChild($users);
            $doc->appendChild($publish);
            $xml_str =  $doc->saveXML();

            if($this->input->is_ajax_request()){
                create_dir(DATA_EXPORT_XML_PATH);
                $update_xml_file = 'publisher_config_'.date('Y_m_d_H_i',time()).'.xml';
                $kind_id = $this->Xml_basic_config_model->get_one(array('name'=>'数据输出配置文件','is_del'=>0),'id');
                if(!$kind_id){
                    exit(json_encode(array('status'=>false,'tips'=>'请先进行数据输出配置文件设置')));
                }
                $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'publisher_config.xml\'','id');
                $res = $this->All_xml_model->xml_produce($xml_id_arr,$update_xml_file,'publisher_config.xml',$kind_id['id'],DATA_EXPORT_XML_PATH,'数据输出配置文件');
                $operation_data= $this->operation_data;
                $operation_data['dateline'] = time();
                if($flag){
                    $operation_data['operate_explain'] = '生成新的数据输出配置文件并将原有的配置文件修改为'.$update_xml_file;
                }else{
                    $operation_data['operate_explain'] = '生成新的数据输出配置文件';
                }
                if($res){
                    if($flag){
                        rename($xmlpatch, DATA_EXPORT_XML_PATH.$update_xml_file);
                    }
                    $doc->save($xmlpatch);
                    $operation_data['is_success'] = 1;
                    $operation_data['status_explain'] = '信息新增成功';
                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>true,'tips'=>'文件生成成功')));
                }else {
                    $operation_data['is_success'] = 0;
                    $operation_data['status_explain'] = '信息新增失败';
                    @$this->operationLogs($operation_data);
                    exit(json_encode(array('status'=>false,'tips'=>'文件生成失败')));
                }
            }else{
                $this->view('produce_xml',array('xml_data'=>htmlentities($xml_str),'require_js'=>true));
            }

    }
    //生成输入数据的基础文件
    private function create_config_xml($doc,$publish,$data_config){
            $stationConfigFile = $doc -> createElement('stationConfigFile');
            $stationConfigFile_text = $doc->createTextNode($data_config['stationConfigFile']);
            $stationConfigFile->appendChild($stationConfigFile_text);

            $asterixFile = $doc -> createElement('asterixFile');
            $asterixFile_text = $doc->createTextNode($data_config['asterixFile']);
            $asterixFile->appendChild($asterixFile_text);

            $log = $doc -> createElement('log');
             $path = $doc -> createElement('path');
             $path_text = $doc->createTextNode($data_config['log_path']);
             $path->appendChild($path_text);

             $level = $doc -> createElement('level');
             $level_text = $doc->createTextNode($data_config['log_level']);
             $level->appendChild($level_text);
            $log->appendChild($path);
            $log->appendChild($level);

            $monitor = $doc -> createElement('monitor');
             $interval = $doc -> createElement('interval');
             $interval_text = $doc->createTextNode($data_config['interval']);
             $interval->appendChild($interval_text);

             $missCnt = $doc -> createElement('missCnt');
             $missCnt_text = $doc->createTextNode($data_config['miss_count']);
             $missCnt->appendChild($missCnt_text);

             $sendStatus = $doc -> createElement('sendStatus');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['send_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['send_port']);
                 $port->appendChild($port_text);
             $sendStatus->appendChild($ip);
             $sendStatus->appendChild($port);

             $sendHeartbeat = $doc -> createElement('sendHeartbeat');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['send_heart_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['send_heart_port']);
                 $port->appendChild($port_text);
             $sendHeartbeat->appendChild($ip);
             $sendHeartbeat->appendChild($port);

              $recvCmd = $doc -> createElement('recvCmd');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['receive_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['receive_ip_port']);
                 $port->appendChild($port_text);
             $recvCmd->appendChild($ip);
             $recvCmd->appendChild($port);


            $monitor->appendChild($interval);
            $monitor->appendChild($missCnt);
            $monitor->appendChild($sendStatus);
            $monitor->appendChild($sendHeartbeat);
            $monitor->appendChild($recvCmd);

            $raw = $doc -> createElement('raw');
             $processThreadCnt = $doc -> createElement('processThreadCnt');
             $processThreadCnt_text = $doc->createTextNode($data_config['raw_process_thread_cnt']);
             $processThreadCnt->appendChild($processThreadCnt_text);

             $toggleAddr10Ms = $doc -> createElement('toggleAddr10Ms');
             $toggleAddr10Ms_text = $doc->createTextNode($data_config['raw_toggle_addr']);
             $toggleAddr10Ms->appendChild($toggleAddr10Ms_text);

             $recvAddr = $doc -> createElement('recvAddr');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['raw_receive_addr_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['raw_receive_addr_ip_port']);
                 $port->appendChild($port_text);
             $recvAddr->appendChild($ip);
             $recvAddr->appendChild($port);
             
             $recvAddr2 = $doc -> createElement('recvAddr2');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['raw_receive_addr_ip_2']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['raw_receive_addr_ip_port_2']);
                 $port->appendChild($port_text);
             $recvAddr2->appendChild($ip);
             $recvAddr2->appendChild($port);
             
            $raw->appendChild($processThreadCnt);
            $raw->appendChild($toggleAddr10Ms);
            $raw->appendChild($recvAddr);
            $raw->appendChild($recvAddr2);

            $fusion = $doc -> createElement('fusion');
             $processThreadCnt = $doc -> createElement('processThreadCnt');
             $processThreadCnt_text = $doc->createTextNode($data_config['fusion_process_thread_cnt']);
             $processThreadCnt->appendChild($processThreadCnt_text);

             $toggleAddr10Ms = $doc -> createElement('toggleAddr10Ms');
             $toggleAddr10Ms_text = $doc->createTextNode($data_config['fusion_toggle_addr']);
             $toggleAddr10Ms->appendChild($toggleAddr10Ms_text);

             $recvAddr = $doc -> createElement('recvAddr');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['fusion_receive_addr_ip']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['fusion_receive_addr_ip_port']);
                 $port->appendChild($port_text);
             $recvAddr->appendChild($ip);
             $recvAddr->appendChild($port);
             
            $recvAddr2 = $doc -> createElement('recvAddr2');
                 $ip = $doc -> createElement('ip');
                 $ip_text = $doc->createTextNode($data_config['fusion_receive_addr_ip_2']);
                 $ip->appendChild($ip_text);
                 $port = $doc -> createElement('port');
                 $port_text = $doc->createTextNode($data_config['fusion_receive_addr_ip_port_2']);
                 $port->appendChild($port_text);
             $recvAddr2->appendChild($ip);
             $recvAddr2->appendChild($port);
             
            $fusion->appendChild($processThreadCnt);
            $fusion->appendChild($toggleAddr10Ms);
            $fusion->appendChild($recvAddr);
            $fusion->appendChild($recvAddr2);
            
            $publish->appendChild($stationConfigFile);
            $publish->appendChild($asterixFile);
            $publish->appendChild($log);
            $publish->appendChild($monitor);
            $publish->appendChild($raw);
            $publish->appendChild($fusion);
            return $publish;
        }

         //生成基站的_target_xml文件
    private function create_only_xml($doc,$users,$user,$value){
            $type = $doc -> createElement('type');
            $type_text = $doc->createTextNode($value['type']);
            $type->appendChild($type_text);

            $name = $doc -> createElement('name');
            $name_text = $doc->createTextNode($value['name']);
            $name->appendChild($name_text);

            $userId = $doc -> createElement('userId');
            $userId_text = $doc->createTextNode($value['user_id']);
            $userId->appendChild($userId_text);

            $duration = $doc -> createElement('duration');
                $switch = $doc -> createElement('switch');
                $switch_text = $doc->createTextNode($value['duration_switch']);
                $switch->appendChild($switch_text);
                $val = $doc -> createElement('val');
                $val_text = $doc->createTextNode($value['duration_val']);
                $val->appendChild($val_text);
            $duration->appendChild($switch);
            $duration->appendChild($val);

            $delay = $doc -> createElement('delay');
                $switch = $doc -> createElement('switch');
                $switch_text = $doc->createTextNode($value['delay_switch']);
                $switch->appendChild($switch_text);
                $val = $doc -> createElement('val');
                $val_text = $doc->createTextNode($value['delay_val']);
                $val->appendChild($val_text);
            $delay->appendChild($switch);
            $delay->appendChild($val);

            $selectItem = $doc -> createElement('selectItem');
                $switch = $doc -> createElement('switch');
                // $switch_text = $doc->createTextNode($value['select_item_switch']);
                $switch_text = $doc->createTextNode(1);
                $switch->appendChild($switch_text);

                $version = $doc -> createElement('version');
                $version_text = $doc->createTextNode($value['select_item_version']);
                $version->appendChild($version_text);
                $before_str = substr($value['select_item_val'], 0,strlen($value['select_item_val'])-3);
                $after_str = substr($value['select_item_val'], -3);
                $the_str = '0,0,0,0,0,';
                $new_str = $before_str.$the_str.$after_str;
                $item = $doc -> createElement('item');
                $item_text = $doc->createTextNode($new_str);
                $item->appendChild($item_text);
            $selectItem->appendChild($switch);
            $selectItem->appendChild($version);
            $selectItem->appendChild($item);

            $send = $doc -> createElement('send');
                $type1 = $doc -> createElement('type');
                $type1_text = $doc->createTextNode($value['cast_type']);
                $type1->appendChild($type1_text);

                $group = $doc -> createElement('group');
                $group_text = $doc->createTextNode($value['cast_type_ip']);
                $group->appendChild($group_text);
                if($value['cast_type'] == 2){
                    $ip = $doc -> createElement('ip');
                    $ip_text = $doc->createTextNode($value['eth_num']);
                    $ip->appendChild($ip_text);
                }else{
                    $ip = $doc -> createElement('ip');
                    $ip_text = $doc->createTextNode($value['send_a_ip']);
                    $ip->appendChild($ip_text);
                }
                $port = $doc -> createElement('port');
                $port_text = $doc->createTextNode($value['send_a_port']);
                $port->appendChild($port_text);
            $send->appendChild($type1);
            $send->appendChild($group);
            $send->appendChild($ip);
            $send->appendChild($port);

            /*$send2 = $doc -> createElement('send2');
                $type2 = $doc -> createElement('type');
                $type2_text = $doc->createTextNode($value['cast_type_b']);
                $type2->appendChild($type2_text);
                $group = $doc -> createElement('group');
                $group_text = $doc->createTextNode($value['cast_type_ip_b']);
                $group->appendChild($group_text);
                $ip = $doc -> createElement('ip');
                $ip_text = $doc->createTextNode($value['send_b_ip']);
                $ip->appendChild($ip_text);
                $port = $doc -> createElement('port');
                $port_text = $doc->createTextNode($value['send_b_port']);
                $port->appendChild($port_text);
            $send2->appendChild($type2);
            $send2->appendChild($group);
            $send2->appendChild($ip);
            $send2->appendChild($port);*/
            if($value['type'] == 0){
                $faker_ctrl = $doc -> createElement('faker_ctrl');
                    $range = $doc -> createElement('range');
                    $range_text = $doc->createTextNode($value['faker_range']);
                    $range->appendChild($range_text);
                    $radar = $doc -> createElement('radar');
                    $radar_text = $doc->createTextNode($value['faker_radar']);
                    $radar->appendChild($radar_text);
                    $tdoa = $doc -> createElement('tdoa');
                    $tdoa_text = $doc->createTextNode($value['faker_tdoa']);
                    $tdoa->appendChild($tdoa_text);
                    $plan = $doc -> createElement('plan');
                    $plan_text = $doc->createTextNode($value['faker_plan']);
                    $plan->appendChild($plan_text);
                $faker_ctrl->appendChild($range);
                $faker_ctrl->appendChild($radar);
                $faker_ctrl->appendChild($tdoa);
                $faker_ctrl->appendChild($plan);
                $is_output_re =  $doc -> createElement('is_output_re');
                $is_output_re_text = $doc->createTextNode($value['is_output']);
                $is_output_re->appendChild($is_output_re_text);
            }else{
                $fromType = $doc -> createElement('fromType');
                $fromType_text = $doc->createTextNode($value['from_type']);
                $fromType->appendChild($fromType_text);
            }
            $filter = $doc -> createElement('filter');
                $stationId = $doc -> createElement('stationId');
                    $switch = $doc -> createElement('switch');
                    $switch_text = $doc->createTextNode($value['station_switch']);
                    $switch->appendChild($switch_text);
                    $list = $doc -> createElement('list');
                    
                    $station_arr = explode(',',$value['station_list']);
                    $station_lists = $this->Station_model->select('is_del=0','station_id');
                    $str="";
                    foreach($station_lists as $key=>$val)
                    {
                        foreach($station_arr as $k=>$v)
                        {
                            if($v == $val['station_id'])
                                $str .= $key.',';                           
                        }                       
                    }
                    
                    //$list_text = $doc->createTextNode($value['station_list']);
                    $list_text = $doc->createTextNode(rtrim($str, ','));
                    $list->appendChild($list_text);
                    $flip = $doc -> createElement('flip');
                    $flip_text = $doc->createTextNode($value['station_flip']);
                    $flip->appendChild($flip_text);
                $stationId->appendChild($switch);
                $stationId->appendChild($list);
                $stationId->appendChild($flip);

                $targetAddress = $doc -> createElement('targetAddress');
                    $switch = $doc -> createElement('switch');
                    $switch_text = $doc->createTextNode($value['target_add_switch']);
                    $switch->appendChild($switch_text);
                    $list = $doc -> createElement('list');
                    $list_text = $doc->createTextNode($value['target_add_list']);
                    $list->appendChild($list_text);
                    $flip = $doc -> createElement('flip');
                    $flip_text = $doc->createTextNode($value['target_add_flip']);
                    $flip->appendChild($flip_text);
                $targetAddress->appendChild($switch);
                $targetAddress->appendChild($list);
                $targetAddress->appendChild($flip);

                $company = $doc -> createElement('company');
                    $switch = $doc -> createElement('switch');
                    $switch_text = $doc->createTextNode($value['company_switch']);
                    $switch->appendChild($switch_text);
                    $list = $doc -> createElement('list');
                    $list_text = $doc->createTextNode($value['company_list']);
                    $list->appendChild($list_text);
                    $flip = $doc -> createElement('flip');
                    $flip_text = $doc->createTextNode($value['company_flip']);
                    $flip->appendChild($flip_text);
                $company->appendChild($switch);
                $company->appendChild($list);
                $company->appendChild($flip);

                $range = $doc -> createElement('range');
                    $switch = $doc -> createElement('switch');
                    $switch_text = $doc->createTextNode($value['range_switch']);
                    $switch->appendChild($switch_text);
                    $aeras = $doc -> createElement('aeras');
                    $aeras = $this->range_data($aeras,$doc,$value['one_range_list']);
                    
                $range->appendChild($switch);
                $range->appendChild($aeras);
            $filter->appendChild($stationId);
            $filter->appendChild($targetAddress);
            $filter->appendChild($company);
            $filter->appendChild($range);
            // $filter->appendChild($height);

            $user->appendChild($type);
            $user->appendChild($name);
            $user->appendChild($userId);
            $user->appendChild($duration);
            $user->appendChild($delay);
            $user->appendChild($selectItem);
            $user->appendChild($send);
            // $user->appendChild($send2);
            if($value['type'] == 0){
                $user->appendChild($faker_ctrl);
                $user->appendChild($is_output_re);
                
            }else{
                $user->appendChild($fromType);
            }
            $user->appendChild($filter);
            $users->appendChild($user);
            return $users;
        }
    //range项的数据    
    private function range_data($aeras,$doc,$data){
            foreach ($data as $k => $v) {
                $aera = $doc->createElement('aera');

                    $point = $doc -> createElement('point');
                    $point_text = $doc->createTextNode($v['lat_long']);
                    $point->appendChild($point_text);
                    $height = $doc -> createElement('height');
                    $height_text = $doc->createTextNode($v['height_list']);
                    $height->appendChild($height_text);
                    $flip = $doc -> createElement('flip');
                    $flip_text = $doc->createTextNode($v['flip_switch']);
                    $flip->appendChild($flip_text);
                $aera->appendChild($point);
                $aera->appendChild($height);
                $aera->appendChild($flip);
                $aeras->appendChild($aera);
            }
            return $aeras;
    }

    //构造版本输出项的数组    
    private function cat_version_data(){
        $arr = array(
            '2.1'=>array(
                '1021/010-Data Source Identification',
                '1021/040-Target Report Descriptor',
                '1021/161-Track Number',
                '1021/015-Service Identification',
                '1021/071-Time of Applicability for Position',
                '1021/130-Position in WGS-84 Co-ordinates',
                '1021/131-High-Resolution Position in WGS-84 Co-ordinates',
                '1021/072-Time of Applicability for Velocity',
                '1021/150-Air Speed',
                '1021/151-True Air Speed',
                '1021/080-Target Address',
                '1021/073-Time of Message Reception for Position',
                '1021/074-Time of Message Reception of Position-High Precision',
                '1021/075-Time of Message Reception for Velocity',
                '1021/076-Time of Message Reception of Velocity-High Precision',
                '1021/140-Geometric Height',
                '1021/090-Quality Indicators',
                '1021/210-MOPS Version',
                '1021/070-Mode 3/A Code in Octal Representation',
                '1021/230-Roll Angle',
                '1021/145-Flight Level',
                '1021/152-Magnetic Heading',
                '1021/200-Target Status',
                '1021/155-Barometric Vertical Rate',
                '1021/157-Geometric Vertical Rate',
                '1021/160-Ground Vector',
                '1021/165-Track Angle Rate',
                '1021/077-Time of ASTERIX Report Transmission',
                '1021/170-Target Identification',
                '1021/020-Emitter Category',
                '1021/220-Met Information',
                '1021/146-Intermediate State Selected Altitude',
                '1021/148-Final State Selected Altitude',
                '1021/110-Trajectory Intent',
                '1021/116-Service Management',
                '1021/008-Aircraft Operational Status',
                '1021/271-Surface Capabilities and Characteristics',
                '1021/132-Message Amplitude',
                '1021/250-Mode S MB Data',
                '1021/260-ACAS Resolution Advisory Report',
                '1021/400-Receiver ID',
                '1021/295-Data Ages',
                'Reserved Expansion Field',
                'Special Purpose Field'
            ),
            '1.5' =>array(
                '1021/010-Data Source Identification',
                '1021/040-Target Report Descriptor',
                '1021/161-Track Number',
                '1021/015-Service Identification',
                '1021/071-Time of Applicability for Position',
                '1021/130-Position in WGS-84 Co-ordinates',
                '1021/131-High-Resolution Position in WGS-84 Co-ordinates',
                '1021/072-Time of Applicability for Velocity',
                '1021/150-Air Speed',
                '1021/151-True Air Speed',
                '1021/080-Target Address',
                '1021/073-Time of Message Reception for Position',
                '1021/074-Time of Message Reception of Position-High Precision',
                '1021/075-Time of Message Reception for Velocity',
                '1021/076-Time of Message Reception of Velocity-High Precision',
                '1021/140-Geometric Height',
                '1021/090-Quality Indicators',
                '1021/210-MOPS Version',
                '1021/070-Mode 3/A Code in Octal Representation',
                '1021/230-Roll Angle',
                '1021/145-Flight Level',
                '1021/152-Magnetic Heading',
                '1021/200-Target Status',
                '1021/155-Barometric Vertical Rate',
                '1021/157-Geometric Vertical Rate',
                '1021/160-Ground Vector',
                '1021/165-Track Angle Rate',
                '1021/077-Time of ASTERIX Report Transmission',
                '1021/170-Target Identification',
                '1021/020-Emitter Category',
                '1021/220-Met Information',
                '1021/146-Intermediate State Selected Altitude',
                '1021/148-Final State Selected Altitude',
                '1021/110-Trajectory Intent',
                '1021/016-Service Management',
                '1021/008-Aircraft Operational Status',
                '1021/271-Surface Capabilities and Characteristics',
                '1021/132-Message Amplitude',
                '1021/250-Mode S MB Data',
                '1021/260-ACAS Resolution Advisory Report',
                '1021/400-Receiver ID',
                '1021/295-Data Ages',
                'Reserved Expansion Field',
                'Special Purpose Field'
            ),
            '0.26' =>array(
                '1021/010-Data Source Identification',
                '1021/040-Target Report Descriptor',
                '1021/030-Time of Day',
                '1021/130-Position in WGS-84 Co-ordinates',
                '1021/080-Target Address',
                '1021/140-Geometric Height',
                '1021/090-Figure of Merit',
                '1021/210-Link Technology Indicator',
                '1021/230-Roll Angle',
                '1021/145-Flight Level',
                '1021/150-Air Speed',
                '1021/151-True Air Speed',
                '1021/152-Magnetic Heading',
                '1021/155-Barometric Vertical Rate',
                '1021/157-Geometric Vertical Rate',
                '1021/160-Ground Vector',
                '1021/165-Rate Of Turn',
                '1021/170-Target Identification',
                '1021/095-Velocity Accuracy',
                '1021/032-Time of Day Accuracy',
                '1021/200-TStat',
                '1021/020-Emitter Category',
                '1021/220-Met Information',
                '1021/146-Intermediate State Selected Altitude',
                '1021/148-Final State Selected Altitude',
                '1021/110-Trajectory Intent',
                '1021/070-Mode 3/A Code in Octal Representation',
                '1021/131-Signal Amplitude',
                 'Reserved Expansion Field',
                'Special Purpose Field'
                
            )
        );
        return $arr;
    }
}
