<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class UsingLogs extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Operation_logs_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  concat(username,operate_explain,status_explain) like '%{$keyword}%'";
        }

        $where = implode('and',$where_arr);
        $data_list = $this->Operation_logs_model->listinfo($where,'*','id desc' , $page_no, $this->Operation_logs_model->page_size,'',$this->Operation_logs_model->page_size,page_list_url('adminpanel/usingLogs/lists',true));
        if($data_list){
            foreach ($data_list as $key => $value) {
                if($value['info_url']){
                    $value['info_url'] = '/adminpanel/'.$value['info_url'];
                    $data_list[$key]['info_url'] = '<a href="'.$value['info_url'].'" class="green_a">地址详情</a>';

                }
                if($value['operate_info']){
                    $data_list[$key]['operate_info'] = json_decode($value['operate_info'],true);
                   
                }
            }
        }
        // exit;
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Operation_logs_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }


}
