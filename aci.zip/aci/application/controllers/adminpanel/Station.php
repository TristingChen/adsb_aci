<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Station extends Admin_Controller {
    function __construct()
    {
        date_default_timezone_set("UTC");
        parent::__construct();
        $this->load->model(array('Station_model','Eth_manage_model','Common_config_model','Rules_model','Station_config_model','App_model','Raders_kind_model'));
        // $this->load->model(array('Exchange_DstUCast_model','Exchange_DstMCast_model','Exchange_DstBCast_model'));
        $this->load->model(array('Process_input_model','Publish_recvGroup_model','Record_recvMCast_model'));
        $this->load->model(array('All_xml_model','Raders_model','Raders_config_model','Hardware_model','Xml_basic_config_model','Raders_resend_model','Station_warning_logs_model'));
        $this->load->helper(array('member','auto_codeIgniter','string','socket'));
    }

    function lists($page_no=1,$network=1)
    {
        $page_no = max(intval($page_no),1);
        $where = 'is_del = 0';
        // $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where .= " and concat(station_name,station_ip_A,station_ip_B) like '%{$keyword}%'";
        }
        // $tmp = implode(" and ",$where_arr);
        //查找最新生成的xml文件。
        $fresh_xml_data = $this->All_xml_model->get_one(array('kind'=>1,'is_old'=>0));
        $data_list = $this->Station_model->tables_listinfo($where,'t_sys_station.*,enable_A,enable_B,data_version_A,data_version_B',$orderby , $page_no, $this->Station_model->page_size,'',$this->Station_model->page_size,page_list_url('adminpanel/station/lists',true));

        $this->view('lists',array('data_list'=>$data_list,'network'=>intval($network),'page_no'=>$page_no,'pages'=>$this->Station_model->pages,'keyword'=>$keyword,'fresh_xml_data'=>$fresh_xml_data,'require_js'=>true));
    }

    /**
     * 新增基站
     */
    function add($network=0)
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['station_name'] = isset($_POST["station_name"])?trim(safe_replace($_POST["station_name"])):exit(json_encode(array('status'=>false,'tips'=>'基站名称不能为空')));
            if($_arr['station_name']=='')exit(json_encode(array('status'=>false,'tips'=>'基站名称名称不能为空')));
            //重名判断
            $jurge_name = $this->Station_model->get_one(array('station_name'=>$_arr['station_name']));
            if($jurge_name){
                exit(json_encode(array('status'=>false,'tips'=>'已有同名基站名存在，请更换名称')));
            }
            /* $_arr['data_version'] = isset($_POST["data_version"])?trim(safe_replace($_POST["data_version"])):exit(json_encode(array('status'=>false,'tips'=>'CAT021数据版本不能为空')));
             if($_arr['data_version']=='')exit(json_encode(array('status'=>false,'tips'=>'CAT021数据版本不能为空')));*/

            $_arr["station_height"] = isset($_POST["station_height"])?trim(safe_replace($_POST["station_height"])):"";
            $_arr["station_status"] = isset($_POST["station_status"])?trim(safe_replace($_POST["station_status"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            if($_arr["station_status"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            $_arr["in_work_option"] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            if($_arr["in_work_option"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            $_arr["longtitude"] = isset($_POST["longtitude"])?trim(safe_replace($_POST["longtitude"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            if($_arr["longtitude"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            $_arr["latitude"] = isset($_POST["latitude"])?trim(safe_replace($_POST["latitude"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            if($_arr["latitude"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站纬度')));
            $_arr["have_beacon"] = isset($_POST["have_beacon"])?trim(safe_replace($_POST["have_beacon"])):exit(json_encode(array('status'=>false,'tips'=>'请输入是否配置信标机')));
            if($_arr["have_beacon"]=='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否配置信标机')));
            $_arr["beacon_send_cycle"] = isset($_POST["beacon_send_cycle"])?trim(safe_replace($_POST["beacon_send_cycle"])):exit(json_encode(array('status'=>false,'tips'=>'请输入信标机发送周期')));
            if($_arr["beacon_send_cycle"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入信标机发送周期')));

            $_arr["receive_range"] = isset($_POST["receive_range"])?trim(safe_replace($_POST["receive_range"])):'';
            if($_arr["receive_range"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入数据接收范围')));

            $_arr["is_station"] = isset($_POST["is_station"])?trim(safe_replace($_POST["is_station"])):'';
            if($_arr["is_station"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否发送数据')));

            $_arr["is_monitor"] = isset($_POST["is_monitor"])?trim(safe_replace($_POST["is_monitor"])):'';
            if($_arr["is_monitor"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否监控')));
            if($_arr["is_monitor"] == 0){
                $_arr['station_img'] = 'station2.png';
            }else{
                $_arr['station_img'] = 'station.png';
            }
            /*
            $_arr["tdoa_check"] = isset($_POST["tdoa_check"])?trim(safe_replace($_POST["tdoa_check"])):'';
            if($_arr["tdoa_check"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否tdoa验证')));
            $_arr["rader_check"] = isset($_POST["rader_check"])?trim(safe_replace($_POST["rader_check"])):'';
            if($_arr["rader_check"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否雷达验证')));
            $_arr["is_send"] = isset($_POST["is_send"])?trim(safe_replace($_POST["is_send"])):'';
            if($_arr["is_send"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否发送')));
            */

            $rader_ids = $this->input->post('rader_ids');
            if($rader_ids){
                $_arr["rader_ids"] = implode(',', $rader_ids);
            }else{
                $_arr["rader_ids"] = '';
            }
            $_arr["update_route"] = isset($_POST["update_route"])?trim(safe_replace($_POST["update_route"])):'';
            if($_arr["update_route"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入cat021推送周期')));
            $_arr["cat023_route"] = isset($_POST["cat023_route"])?trim(safe_replace($_POST["cat023_route"])):'';
            if($_arr["cat023_route"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入cat021推送周期')));
            $_arr["cat247_route"] = isset($_POST["cat247_route"])?trim(safe_replace($_POST["cat247_route"])):'';
            if($_arr["cat247_route"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入cat021推送周期')));
            $this->db->trans_start();
            $new_station_id = $this->Station_model->insert($_arr);
            $_config_arr["cast_type_A"] = isset($_POST["cast_type_A"])?trim(safe_replace($_POST["cast_type_A"])):"";
            $_config_arr["send_ip_A"] = isset($_POST["send_ip_A"])?trim(safe_replace($_POST["send_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_config_arr["send_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_config_arr["channel_ip_A"] = isset($_POST["channel_ip_A"])?trim(safe_replace($_POST["channel_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            if($_config_arr["channel_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            $_config_arr["send_port_A"] = isset($_POST["send_port_A"])?trim(safe_replace($_POST["send_port_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_config_arr["send_port_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_config_arr["exchange_eth_num_A"] = isset($_POST["exchange_eth_num_A"])?trim(safe_replace($_POST["exchange_eth_num_A"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            if($_config_arr["exchange_eth_num_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            /*  $channel_A = isset($_POST["channel_status_A"])?trim(safe_replace($_POST["channel_status_A"])):1;
              $_config_arr["channel_status_A"] = ($channel_A == 1)?"1":"2";*/
            $_config_arr["enable_A"] =  isset($_POST['enable_A'])?$_POST['enable_A']:'';
            if($_config_arr["enable_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择通道')));
            $_config_arr["track_upper_limit_A"] = isset($_POST["track_upper_limit_A"])?trim(safe_replace($_POST["track_upper_limit_A"])):FALSE;
            if($_config_arr["track_upper_limit_A"] === FALSE)exit(json_encode(array('status'=>false,'tips'=>'请A路输入航迹目标接收上限')));
            $_config_arr["data_upper_limit_A"] = isset($_POST["data_upper_limit_A"])?trim(safe_replace($_POST["data_upper_limit_A"])):FALSE;
            if($_config_arr["data_upper_limit_A"] === FALSE)exit(json_encode(array('status'=>false,'tips'=>'请输入A路数据帧接收上限')));


            $_config_arr["cast_type_B"] = isset($_POST["cast_type_B"])?trim(safe_replace($_POST["cast_type_B"])):"";
            $_config_arr["send_ip_B"] = isset($_POST["send_ip_B"])?trim(safe_replace($_POST["send_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_config_arr["send_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_config_arr["channel_ip_B"] = isset($_POST["channel_ip_B"])?trim(safe_replace($_POST["channel_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            if($_config_arr["channel_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            $_config_arr["send_port_B"] = isset($_POST["send_port_B"])?trim(safe_replace($_POST["send_port_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_config_arr["send_port_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_config_arr["exchange_eth_num_B"] = isset($_POST["exchange_eth_num_B"])?trim(safe_replace($_POST["exchange_eth_num_B"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            if($_config_arr["exchange_eth_num_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            /*$channel_B = isset($_POST["channel_status_B"])?trim(safe_replace($_POST["channel_status_B"])):1;
            $_config_arr["channel_status_B"] = ($channel_B == 1)?"1":"2";*/
            $_config_arr["enable_B"] =  isset($_POST['enable_B'])?$_POST['enable_B']:'';
            if($_config_arr["enable_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择B通道')));
            $_config_arr["track_upper_limit_B"] = isset($_POST["track_upper_limit_B"])?trim(safe_replace($_POST["track_upper_limit_B"])):'';
            if($_config_arr["track_upper_limit_B"] === '')exit(json_encode(array('status'=>false,'tips'=>'请B路输入航迹目标接收上限')));
            $_config_arr["data_upper_limit_B"] = isset($_POST["data_upper_limit_B"])?trim(safe_replace($_POST["data_upper_limit_B"])):'';
            if($_config_arr["data_upper_limit_B"] === '')exit(json_encode(array('status'=>false,'tips'=>'请输入B路数据帧接收上限')));
            $_config_arr['sac_code_A'] = isset($_POST["sac_code_A"])?trim(safe_replace($_POST["sac_code_A"])):exit(json_encode(array('status'=>false,'tips'=>'SAC码不能为空')));
            if($_config_arr['sac_code_A']=='')exit(json_encode(array('status'=>false,'tips'=>'通道A的sac码不能为空')));
            $_config_arr['sic_code_A'] = isset($_POST["sic_code_A"])?trim(safe_replace($_POST["sic_code_A"])):exit(json_encode(array('status'=>false,'tips'=>'SIC码不能为空')));
            if($_config_arr['sic_code_A']=='')exit(json_encode(array('status'=>false,'tips'=>'通道A的sic码不能为空')));

            $_config_arr['sac_code_B'] = isset($_POST["sac_code_B"])?trim(safe_replace($_POST["sac_code_B"])):exit(json_encode(array('status'=>false,'tips'=>'SAC码不能为空')));
            if($_config_arr['sac_code_B']=='')exit(json_encode(array('status'=>false,'tips'=>'通道B的sac码不能为空')));
            $_config_arr['sic_code_B'] = isset($_POST["sic_code_B"])?trim(safe_replace($_POST["sic_code_B"])):exit(json_encode(array('status'=>false,'tips'=>'SIC码不能为空')));
            if($_config_arr['sic_code_B']=='')exit(json_encode(array('status'=>false,'tips'=>'通道B的sic码不能为空')));

            $_config_arr['data_version_A'] = isset($_POST["data_version_A"])?trim(safe_replace($_POST["data_version_A"])):exit(json_encode(array('status'=>false,'tips'=>'A通道数据版本不得为空')));
            if($_config_arr['data_version_A']=='')exit(json_encode(array('status'=>false,'tips'=>'A通道数据版本不得为空')));
            $_config_arr['data_version_B'] = isset($_POST["data_version_B"])?trim(safe_replace($_POST["data_version_B"])):exit(json_encode(array('status'=>false,'tips'=>'B通道数据版本不得为空')));
            if($_config_arr['data_version_B']=='')exit(json_encode(array('status'=>false,'tips'=>'B通道数据版本不得为空')));

            $_config_arr['station_id'] = $new_station_id;
            $result = $this->Station_config_model->insert($_config_arr);
            $this->db->trans_complete();
            $operation_data = $this->operation_data;
            $operation_data['operate_explain'] = '新增名称为'.$_arr['station_name'].'的基站';
            $operation_data['dateline'] = time();
            if($this->db->trans_status() !== FALSE)
            {
                $this->Station_model->_cache_station();

                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息新增成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$result)));
            }else
            {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息新增失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $all_rader_list = $this->Raders_model->select('is_del = 0');
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'station_info'=>$this->Station_model->default_info(),'station_config_info'=>$this->Station_config_model->default_info(),'all_rader_list'=>$all_rader_list));
        }

    }

    /**
     * 通过应服务器网口序号获取网口ip
     * @param $app_name 应用名称
     * @param $eth_num 网口编号
     * @return mixed
     */
    function get_eth_ip($app_name,$eth_num)
    {
        $result = $this->App_model->get_one(array('app_name'=>"".$app_name."")); //获取应用所在服务器
        $hardware_id = $result['hardware_id'];
        $ethInfo =$this->Eth_manage_model->get_one(array('hardware_id'=>$hardware_id,'eth_num'=>"".$eth_num."")); //获取服务器对应网口IP
        $eth_ip = $ethInfo['eth_ip'];
        return $eth_ip;
    }




    /*
        function insert_publish_recv_groupaddr($station_data, $station_id,$network_type,$channel)
        {
            $group_addr = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
            $_arr['GroupAddr'] = $group_addr['value'].":".($channel=="A")?intval($station_data['send_port_A']) + 1000:intval($station_data['send_port_B']) +2000;
            $_arr['note'] = $station_data['station_name'].$channel;
            $_arr['EthNum'] = "eth1";
            $appName = "PUBLISH-A";
            $_arr['interface'] = $this->get_eth_ip($appName,$_arr['EthNum']);
            $_arr['StnId'] = $station_id;
            $_arr['channel'] = $channel;
            $_arr['NTId'] = $network_type;
            $this->Publish_recvGroup_model->insert($_arr);
        }*/

    /**
     * 新增录制模块组播接收配置
     * @param $station_data
     * @param $station_id
     * @param $network_type
     */
    /*    function insert_record_recvmacst($station_data,$station_id,$network_type,$channel)
        {
            $RecvMCastIp = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
            $_arr['RecvMCastIp'] = $RecvMCastIp['value'];
            $_arr['RecvMCastEth'] = "eth0";
            $appName = "RECORD-A";
            $_arr['RecvMCastRoute'] = $this->get_eth_ip($appName,$_arr['RecvMCastEth']);
            $_arr['RecvMCastPort'] = ($channel == "A")?$station_data["send_port_A"]+1000:$station_data["send_port_B"]+2000;
            $_arr['StnId'] = $station_id;
            $_arr['channel'] = $channel;
            $_arr['NTId'] = $network_type;
            $this->Record_recvMCast_model->insert($_arr);
        }*/

    /**
     * 修改基站信息时自动修改基站对应的交换模块数据接收配置信息
     * @param $cast_type 数据接收方式
     * @param $cast_ip 数据接收IP
     * @param $cast_port 数据接收端口
     * @param $eth_Num 服务器网口序号
     * @param $note 备注
     * @param $channel 数据接收通道
     * @param $station_id 基站ID
     * @param $network_type 所属网络结构
     */
    function update_recv_cast($cast_type,$cast_ip,$cast_port,$eth_Num,$note,$channel,$station_id,$network_type)
    {
        $_arr["SrcId"] = $this->get_send_cast_count($cast_type,$network_type);  //1、单播 2、组播 3、广播
        $_arr["Note"] = $note;
        $_arr["RecvCastIp"] = $cast_ip;
        $_arr["RecvCastPort"] = $cast_port;
        $appName = ($network_type == 1)?"EXCHANGE-A":"EXCHANGE-B";
        if($cast_type == 2){
            $_arr["RecvMCastInterface"] = $this->get_eth_ip($appName,$eth_Num);
        }
        $_arr["StnId"] = $station_id;
        $_arr["EthNum"] = $eth_Num;
        $_arr['NTId'] = $network_type;
        switch ($cast_type){
            case 1:
                $this->Exchange_RecvUCast_model->update($_arr,array('StnId'=>$station_id,'channel'=>$channel,'NTId'=>$network_type));
                break;
            case 2:
                $this->Exchange_RecvMCast_model->update($_arr,array('StnId'=>$station_id,'channel'=>$channel,'NTId'=>$network_type));
                break;
            case 3:
                $this->Exchange_RecvBCast_model->update($_arr,array('StnId'=>$station_id,'channel'=>$channel,'NTId'=>$network_type));
                break;
            default:
                exit();
        }
    }

    /**
     * 修改基站数据时自动修改系统内部组播数据发送配置
     * @param $cast_type 默认数据发送方式为组播
     * @param $cast_ip 组播发送IP
     * @param $cast_port 组播发送端口
     * @param $eth_num 组播数据输出网口序号
     * @param $note 备注
     * @param $station_id 基站ID
     * @param $network_type 所属网络结构
     */
    function update_exchange_dst_mcast($cast_type,$cast_ip,$cast_port,$eth_num,$note,$station_id,$network_type)
    {
        $_arr["SrcId"] = $this->get_send_cast_count($cast_type,$network_type);  //$cast_type=1、单播 2、组播 3、广播
        $_arr["Note"] = $note;
        $_arr["RecvCastIp"] = $cast_ip;
        $_arr["RecvCastPort"] = $cast_port;
        $appName = ($network_type == 1)?"EXCHANGE-A":"EXCHANGE-B";
        if($cast_type == 2){
            $_arr["RecvMCastInterface"] = $this->get_eth_ip($appName,$eth_num);
        }
        $_arr["StnId"] = $station_id;
        $_arr["EthId"] = $eth_num;
        $_arr['NTId'] = $network_type;

        $this->Exchange_Dst->get_one(array('station_id'=>$station_id));
    }

    function update_process_input($station_data,$network_type,$station_id)
    {
        $data_info =$this->Process_input_model->get_one(array('station_id'=>$station_id,'NTId'=>$network_type));
        if($data_info){
            $count = $this->Process_input_model->count(array('$NTId'=>$network_type));
            $_arr['number'] = $count;
            $_arr['version'] = $station_data['data_version'];
            $_arr['sac'] = $station_data['sac_code'];
            $_arr['sic'] = $station_data['sic_code'];
            $_arr['stationName'] = $station_data['station_name'];
            $_arr['latitudeDegree'] = $station_data["station_lat_degree"];
            $_arr['latitudeMinute'] = $station_data["station_lat_minute"];
            $_arr['latitudeSecond'] = $station_data["station_lat_second"];
            $_arr['longitudeDegree'] = $station_data['station_lng_degree'];
            $_arr['longitudeMinute'] = $station_data['station_lng_minute'];
            $_arr['longitudeSecond'] = $station_data['station_lng_second'];
            $_arr['height'] = $station_data['station_height'];
            $_arr['groupAddressA'] = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
            $_arr['inPortA'] = intval($station_data['send_port_A']) + 1000;
            $_arr['ChannelAStatus'] = $station_data['channel_status_A'];
            $_arr['groupAddressB'] = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
            $_arr['inPortB'] = intval($station_data['send_port_B']) + 2000;
            $_arr['ChannelBStatus'] = $station_data['channel_status_B'];
            $_arr['filterCrc'] = false;
            $_arr['filterErrorPacket'] = true;
            $_arr['filterEnabled'] = false;
            $_arr['filterSacSic'] = true;
            $_arr['enabled'] = true;
            $_arr['StnId'] = $station_id;
            $_arr['NTId'] = $network_type;

            $this->Process_input_model->update($_arr,array('station_id'=>$station_id,'NTId'=>$network_type));
        }

    }

    /**
     * @param $station_data
     * @param $station_id
     * @param $network_type
     * @param $channel
     */
    function update_publish_recv_groupaddr($station_data, $station_id,$network_type,$channel)
    {
        $data_info =$this->Publish_recvMCast_model->get_one(array('station_id'=>$station_id,'NTId'=>$network_type,'channel'=>$channel));
        if($data_info)
        {
            $group_addr = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
            $_arr['GroupAddr'] = $group_addr['GroupAddr'].":".($channel=="A")?intval($station_data['send_port_A']) + 1000:intval($station_data['send_port_B']) +2000;
            $_arr['note'] = $station_data['station_name'].$channel;
            $_arr['EthNum'] = "eth1";
            $appName = "PUBLISH-A";
            $_arr['interface'] = $this->get_eth_ip($appName,$_arr['EthNum']);
            $_arr['StnId'] = $station_id;
            $_arr['channel'] = $channel;
            $_arr['NTId'] = $network_type;

            $this->Publish_recvMCast_model->update($_arr,array('station_id'=>$station_id,'NTId'=>$network_type,'channel'=>$channel));
        }
    }

    /**
     * @param $station_data
     * @param $station_id
     * @param $network_type
     * @param $channel
     */
    function update_record_recvmacst($station_data, $station_id,$network_type,$channel)
    {
        $data_info =$this->Record_recvMCast_model->get_one(array('station_id'=>$station_id,'NTId'=>$network_type,'channel'=>$channel));
        if($data_info)
        {
            $_arr['RecvMCastIp'] = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
            $_arr['RecvMCastEth'] = "eth0";
            $appName = "RECORD-A";
            $_arr['RecvMCastRoute'] = $this->get_eth_ip($appName,$_arr['RecvMCastEth']);
            $_arr['RecvMCastPort'] = ($channel == "A")?$station_data["send_port_A"]+1000:$station_data["send_port_B"]+2000;
            $_arr['StnId'] = $station_id;
            $_arr['channel'] = $channel;
            $_arr['NTId'] = $network_type;
            $this->Record_recvMCast_model->update($_arr,array('station_id'=>$station_id,'NTId'=>$network_type,'channel'=>$channel));
        }
    }

    /**
     * 修改基站信息
     * @param $id
     * @param $network 所属网络结构
     */
    function edit($id)
    {
        $id = intval($id);
        // print_r(getcache('cache_all_station'));exit;
        $station_info =$this->Station_model->get_one(array('station_id'=>$id));
        $station_config_info =$this->Station_config_model->get_one(array('station_id'=>$id));
        if(!$station_info||!$station_config_info)$this->showmessage('基站信息不存在或不完整');
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            // print_r($this->input->post());exit;
            $_arr['station_name'] = isset($_POST["station_name"])?trim(safe_replace($_POST["station_name"])):exit(json_encode(array('status'=>false,'tips'=>'基站名称不能为空')));
            if($_arr['station_name']=='')exit(json_encode(array('status'=>false,'tips'=>'基站名称名称不能为空')));
            $jurge_name = $this->Station_model->get_one('station_name =\''.$_arr['station_name'].'\' and station_id !='.$id);
            if($jurge_name){
                exit(json_encode(array('status'=>false,'tips'=>'已有同名基站名存在，请更换名称')));
            }

            $_arr["station_height"] = isset($_POST["station_height"])?trim(safe_replace($_POST["station_height"])):"";
            $_arr["station_status"] = isset($_POST["station_status"])?trim(safe_replace($_POST["station_status"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            if($_arr["station_status"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            $_arr["in_work_option"] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            if($_arr["in_work_option"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            $_arr["longtitude"] = isset($_POST["longtitude"])?trim(safe_replace($_POST["longtitude"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            if($_arr["longtitude"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            $_arr["latitude"] = isset($_POST["latitude"])?trim(safe_replace($_POST["latitude"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            if($_arr["latitude"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站纬度')));
            $_arr["have_beacon"] = isset($_POST["have_beacon"])?trim(safe_replace($_POST["have_beacon"])):exit(json_encode(array('status'=>false,'tips'=>'请输入是否配置信标机')));
            if($_arr["have_beacon"]=='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否配置信标机')));
            $_arr["beacon_send_cycle"] = isset($_POST["beacon_send_cycle"])?trim(safe_replace($_POST["beacon_send_cycle"])):exit(json_encode(array('status'=>false,'tips'=>'请输入信标机发送周期')));
            if($_arr["beacon_send_cycle"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入信标机发送周期')));

            $_arr["receive_range"] = isset($_POST["receive_range"])?trim(safe_replace($_POST["receive_range"])):'';
            if($_arr["receive_range"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入数据接收范围')));
            $_arr["is_station"] = isset($_POST["is_station"])?trim(safe_replace($_POST["is_station"])):'';
            if($_arr["is_station"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否数据站')));
            $_arr["is_monitor"] = isset($_POST["is_monitor"])?trim(safe_replace($_POST["is_monitor"])):'';
            if($_arr["is_monitor"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否监控')));
            if($_arr["is_monitor"] == 0){
                $_arr['station_img'] = 'station2.png';
            }else{
                $_arr['station_img'] = 'station.png';
            }
            /*
            $_arr["tdoa_check"] = isset($_POST["tdoa_check"])?trim(safe_replace($_POST["tdoa_check"])):'';
            if($_arr["tdoa_check"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否tdoa验证')));
            $_arr["rader_check"] = isset($_POST["rader_check"])?trim(safe_replace($_POST["rader_check"])):'';
            if($_arr["rader_check"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否雷达验证')));

            $_arr["update_route"] = isset($_POST["update_route"])?trim(safe_replace($_POST["update_route"])):'';
            if($_arr["update_route"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否发送')));
            */
            $rader_ids = $this->input->post('rader_ids');
            if($rader_ids){
                $_arr["rader_ids"] = implode(',', $rader_ids);
            }else{
                $_arr["rader_ids"] = '';

            }
            $_arr["update_route"] = isset($_POST["update_route"])?trim(safe_replace($_POST["update_route"])):'';
            if($_arr["update_route"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入cat021推送周期')));
            $_arr["cat023_route"] = isset($_POST["cat023_route"])?trim(safe_replace($_POST["cat023_route"])):'';
            if($_arr["cat023_route"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入cat021推送周期')));
            $_arr["cat247_route"] = isset($_POST["cat247_route"])?trim(safe_replace($_POST["cat247_route"])):'';
            if($_arr["cat247_route"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入cat021推送周期')));
            $this->db->trans_start();
            $status = $this->Station_model->update($_arr,array('station_id'=>$id));

            $_config_arr["cast_type_A"] = isset($_POST["cast_type_A"])?trim(safe_replace($_POST["cast_type_A"])):"";
            $_config_arr["send_ip_A"] = isset($_POST["send_ip_A"])?trim(safe_replace($_POST["send_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_config_arr["send_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_config_arr["channel_ip_A"] = isset($_POST["channel_ip_A"])?trim(safe_replace($_POST["channel_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            if($_config_arr["channel_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            $_config_arr["send_port_A"] = isset($_POST["send_port_A"])?trim(safe_replace($_POST["send_port_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_config_arr["send_port_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_config_arr["exchange_eth_num_A"] = isset($_POST["exchange_eth_num_A"])?trim(safe_replace($_POST["exchange_eth_num_A"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            if($_config_arr["exchange_eth_num_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            /*  $channel_A = isset($_POST["channel_status_A"])?trim(safe_replace($_POST["channel_status_A"])):1;
              $_config_arr["channel_status_A"] = ($channel_A == 1)?"1":"2";*/
            $_config_arr["enable_A"] =  isset($_POST['enable_A'])?$_POST['enable_A']:'';
            if($_config_arr["enable_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择通道')));
            $_config_arr["track_upper_limit_A"] = isset($_POST["track_upper_limit_A"])?trim(safe_replace($_POST["track_upper_limit_A"])):FALSE;
            if($_config_arr["track_upper_limit_A"] === FALSE)exit(json_encode(array('status'=>false,'tips'=>'请A路输入航迹目标接收上限')));
            $_config_arr["data_upper_limit_A"] = isset($_POST["data_upper_limit_A"])?trim(safe_replace($_POST["data_upper_limit_A"])):FALSE;
            if($_config_arr["data_upper_limit_A"] === FALSE)exit(json_encode(array('status'=>false,'tips'=>'请输入A路数据帧接收上限')));

            $_config_arr["cast_type_B"] = isset($_POST["cast_type_B"])?trim(safe_replace($_POST["cast_type_B"])):"";
            $_config_arr["send_ip_B"] = isset($_POST["send_ip_B"])?trim(safe_replace($_POST["send_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_config_arr["send_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_config_arr["channel_ip_B"] = isset($_POST["channel_ip_B"])?trim(safe_replace($_POST["channel_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            if($_config_arr["channel_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站通道IP不能为空')));
            $_config_arr["send_port_B"] = isset($_POST["send_port_B"])?trim(safe_replace($_POST["send_port_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_config_arr["send_port_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_config_arr["exchange_eth_num_B"] = isset($_POST["exchange_eth_num_B"])?trim(safe_replace($_POST["exchange_eth_num_B"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            if($_config_arr["exchange_eth_num_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            /*$channel_B = isset($_POST["channel_status_B"])?trim(safe_replace($_POST["channel_status_B"])):1;
            $_config_arr["channel_status_B"] = ($channel_B == 1)?"1":"2";*/
            $_config_arr["enable_B"] =  isset($_POST['enable_B'])?$_POST['enable_B']:'';
            if($_config_arr["enable_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择B通道')));
            $_config_arr["track_upper_limit_B"] = isset($_POST["track_upper_limit_B"])?trim(safe_replace($_POST["track_upper_limit_B"])):'';
            if($_config_arr["track_upper_limit_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请B路输入航迹目标接收上限')));
            $_config_arr["data_upper_limit_B"] = isset($_POST["data_upper_limit_B"])?trim(safe_replace($_POST["data_upper_limit_B"])):'';
            if($_config_arr["data_upper_limit_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入B路数据帧接收上限')));

            $_config_arr['sac_code_A'] = isset($_POST["sac_code_A"])?trim(safe_replace($_POST["sac_code_A"])):exit(json_encode(array('status'=>false,'tips'=>'SAC码不能为空')));
            if($_config_arr['sac_code_A']=='')exit(json_encode(array('status'=>false,'tips'=>'通道A的sac码不能为空')));
            $_config_arr['sic_code_A'] = isset($_POST["sic_code_A"])?trim(safe_replace($_POST["sic_code_A"])):exit(json_encode(array('status'=>false,'tips'=>'SIC码不能为空')));
            if($_config_arr['sic_code_A']=='')exit(json_encode(array('status'=>false,'tips'=>'通道A的sic码不能为空')));

            $_config_arr['sac_code_B'] = isset($_POST["sac_code_B"])?trim(safe_replace($_POST["sac_code_B"])):exit(json_encode(array('status'=>false,'tips'=>'SAC码不能为空')));
            if($_config_arr['sac_code_B']=='')exit(json_encode(array('status'=>false,'tips'=>'通道B的sac码不能为空')));
            $_config_arr['sic_code_B'] = isset($_POST["sic_code_B"])?trim(safe_replace($_POST["sic_code_B"])):exit(json_encode(array('status'=>false,'tips'=>'SIC码不能为空')));
            if($_config_arr['sic_code_B']=='')exit(json_encode(array('status'=>false,'tips'=>'通道B的sic码不能为空')));

            $_config_arr['data_version_A'] = isset($_POST["data_version_A"])?trim(safe_replace($_POST["data_version_A"])):exit(json_encode(array('status'=>false,'tips'=>'A通道数据版本不得为空')));
            if($_config_arr['data_version_A']=='')exit(json_encode(array('status'=>false,'tips'=>'A通道数据版本不得为空')));
            $_config_arr['data_version_B'] = isset($_POST["data_version_B"])?trim(safe_replace($_POST["data_version_B"])):exit(json_encode(array('status'=>false,'tips'=>'B通道数据版本不得为空')));
            if($_config_arr['data_version_B']=='')exit(json_encode(array('status'=>false,'tips'=>'B通道数据版本不得为空')));
            $status = $this->Station_config_model->update($_config_arr,array('station_id'=>$id));
            // print_r($old_merge_station);exit;
            // print_r($old_merge_station);
            // print_r($new_merge_station);
            // print_r($before_change_data);exit;

            $this->db->trans_complete();
            $old_merge_station = array_merge($station_info,$station_config_info);
            $operation_data = $this->operation_data;
            $operation_data['operate_explain'] = '修改基站'.$_arr['station_name'].'信息';
            $operation_data['dateline'] = time();
            if($this->db->trans_status() !== FALSE)
            {
                $this->Station_model->_cache_station();
                $new_station_info =$this->Station_model->get_one(array('station_id'=>$id));
                $new_station_config_info =$this->Station_config_model->get_one(array('station_id'=>$id));
                $new_merge_station = array_merge($new_station_info,$new_station_config_info);
                $before_change_data = array_diff_assoc($old_merge_station, $new_merge_station);
                $operate_info = array();
                $i = 0;
                foreach ($before_change_data as $key => $value) {
                    $operation_info[$i]['key'] = $key;
                    $operation_info[$i]['old_val'] = $value;
                    $operation_info[$i]['new_val'] = $new_merge_station[$key];
                    $i++;
                }
                if(!empty($operation_info)){
                    $operation_data['operate_info'] = json_encode($operation_info);
                }
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息修改成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息修改失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            $all_rader_list = $this->Raders_model->select('is_del = 0');
            $station_info['rader_ids'] = explode(',', $station_info['rader_ids']);
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'station_info'=>$station_info,'station_config_info'=>$station_config_info,'all_rader_list'=>$all_rader_list));
        }
    }

    function info($id)
    {
        $id = intval($id);
        // print_r(getcache('cache_all_station'));exit;
        $station_info =$this->Station_model->get_one(array('station_id'=>$id));
        $station_config_info =$this->Station_config_model->get_one(array('station_id'=>$id));
        if(!$station_info||!$station_config_info)$this->showmessage('基站信息不存在或不完整');
        //如果是AJAX请求

        $all_rader_list = $this->Raders_model->select('is_del = 0');
        $station_info['rader_ids'] = explode(',', $station_info['rader_ids']);
        $this->view('info',array('require_js'=>true,'is_edit'=>true,'station_info'=>$station_info,'station_config_info'=>$station_config_info,'all_rader_list'=>$all_rader_list));
    }

    function delete($station_id,$network_type)
    {
        $the_station_info = $this->Station_model->get_one(array('station_id'=>$station_id));
        if(!$the_station_info){
            $this->showmessage('参数错误');
        }
        $status = $this->Station_model->update(array('is_del'=>1),array('station_id'=>$station_id));
        $operation_data = $this->operation_data;
        $operation_data['operate_explain'] = '删除'.$the_station_info['station_name'].'应用程序';
        $operation_data['info_url'] = 'station/info/'.$station_id;
        $operation_data['dateline'] = time();
        if($status)
        {
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '删除成功';
            @$this->operationLogs($operation_data);

            $this->Station_model->_cache_station();
            $this->showmessage('删除成功');
        }else{
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '删除失败';
            @$this->operationLogs($operation_data);
            $this->showmessage('删除失败');
        }
    }

    function check_station_name($station_name='')
    {
        if(isset($_POST['station_name'])&&$station_name==''){
            $username = trim(safe_replace($_POST['station_name']));
            $c = $this->Station_model->count(array('station_name'=>$username));
            echo  $c>0?'{"valid":false}':'{"valid":true}';
        }else{
            $station_name = trim(safe_replace($station_name));
            $c = $this->Station_model->count(array('station_name'=>$station_name));
            return $c>0?true:false;
        }
    }

    //数据站的读取与检查
    private function xml_read_jurge($station_num_file,$data){
        $station_num_data = array();
        if(file_exists($station_num_file)){
            // var_dump(time()-filemtime($station_num_file));exit;
            if(time()-filemtime($station_num_file)>30){
                $station_num_data['alarm_status'] = 1;
            }else{
                $fh = fopen($station_num_file, 'r');
                $line_arr = lline_tail($fh);
                $a_error = 0;
                $b_error = 0;
                foreach ($line_arr as $key => $value) {
                    $line_arr[$key] = trim(strip_tags($value));
                }
                $line_arr = array_values(array_filter($line_arr));
                if($line_arr[17] == 'Master'){
                    $station_num_data['current_work_pass'] =  1;
                }else{
                    $station_num_data['current_work_pass'] =  2;
                }
                if(in_array('ERROR', $line_arr) || in_array('bad', $line_arr)){
                    $station_num_data['alarm_status'] = 1;
                    $station_num_data['station_img'] = 'station2.png';
                }else{
                    $station_num_data['alarm_status'] = 0;
                    $station_num_data['station_img'] = 'station1.png';

                }
                setcache('station_line_arr',$line_arr);
            }
        }else{
            $station_num_data['alarm_status'] = 1;
            $station_num_data['station_img'] = 'station2.png';

        }

        if($station_num_data['alarm_status'] != $data['alarm_status']){
            $res = $this->Station_model->update($station_num_data,array('station_id'=>$data['station_id']));


            // echo $this->Station_model->last_query();exit;
        }
        // return $station_num_data;

    }


    //lists表改变 当前通道值
    public function change_current_path($station_id){
        $kind_value = (string)$this->input->post('value');
        $kind = $this->input->post('kind');
        $key_name = (string)$this->input->post('key_name');
        if(!$station_id){
            exit(json_encode(array('status'=>false,'tips'=>'参数传递错误')));
        }
        $the_station_info = $this->Station_model->get_one(array('station_id'=>$station_id));
        if(!$the_station_info){
            exit(json_encode(array('status'=>false,'tips'=>'基站信息不存在')));
        }
        $operation_data = $this->operation_data;
        $update_data = array();
        if($kind == 0){
            if($kind_value == 'A'){
                $text_a = 'B';
                // $update_data['current_work_pass'] = 2;
            }else{
                $text_a = 'A';
                // $update_data['current_work_pass'] = 1;

            }
            $operation_data['operate_explain'] = '切换'.$the_station_info['station_name'].'通道当前通道为'.$text_a;

        }else{
            if(strpos($kind_value, '开启') !== false){
                $switch = 'OFF';
                if($key_name == 'A'){
                    $text_a = '将'.$the_station_info['station_name'].'A通道进行关闭操作';
                    $update_data['enable_A'] = 0;

                }else{
                    $text_a = '将'.$the_station_info['station_name'].'B通道进行关闭操作';
                    $update_data['enable_B'] = 0;

                }
            }else{
                $switch = 'ON';
                if($key_name == 'A'){
                    $text_a = '将'.$the_station_info['station_name'].'A通道进行开启操作';
                    $update_data['enable_A'] = 1;

                }else{
                    $text_a = '将'.$the_station_info['station_name'].'B通道进行开启操作';
                    $update_data['enable_B'] = 1;

                }
            }
            $operation_data['operate_explain'] = $text_a;
        }

        try{
            //进行两个通道状态的判断
            // var_dump($update_data);exit;
            if(!empty($update_data)){
                $update_station = $this->Station_config_model->update($update_data,array('station_id'=>$station_id));
                if(!$update_station){
                    throw new Exception('更新基站的通道关闭状态失败');
                }else{
                    if($kind != 0){
                        //进行操作时间的缓存读取  30秒后再进行操作状态的判断
                        setcache('switch_station_'.$station_id,1,30);
                    }
                }
            }
            $hardware_id_arr = $this->Hardware_model->select('`hardware_other_name` = \'BDCD-A\' or `hardware_other_name` = \'BDCD-B\'','hardware_other_name');
            if(!$hardware_id_arr){
                throw new Exception("数据解析服务器信息不存在");
            }
            foreach ($hardware_id_arr as $key => $value) {

                $all_station_arr = $this->Station_model->select('is_del = 0','station_id');
                $station_orser = 0;
                foreach ($all_station_arr as $key => $v) {
                    if($station_id == $v['station_id'])
                    {
                        $station_orser = $key;
                        break;
                    }
                }
                if($kind == 0){
                    $msg = '<MSG TYPE="7" MODULENAME="'.$value['hardware_other_name'].'" APPNAME="decoder" STATIONID="'.$station_orser.'" MASTERCHANNELCHANGED="'.$text_a.'" CHANGEDTYPE="1" SENDTIME="'.date('Y-m-d H:i:s').'" />';
                }else{

                    $msg = '<MSG TYPE="23" MODULENAME="'.$value['hardware_other_name'].'" APPNAME="decoder" STATIONID="'.$station_orser.'" CHANNEL="'.$key_name.'" SWITCH="'.$switch.'"  SENDTIME="'.date('Y-m-d H:i:s').'" />';
                }
                // var_dump($msg);exit;
                $res = send_udp(SYSTEMSENDIP, SYSTEMSENDPORT,$msg,0);
                if($res != 1){
                    throw new Exception("发送socket消息失败");
                    break;
                }

            }
        }catch(Exception $e){
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = $e->getMessage();
            @$this->operationLogs($operation_data);
            exit(json_encode(array('status'=>false,'tips'=>$e->getMessage())));

        }
        $operation_data['is_success'] = 1;
        $operation_data['status_explain'] = '操作成功';
        @$this->operationLogs($operation_data);
        $this->Station_model->_cache_station();
        exit(json_encode(array('status'=>true,'tips'=>'操作成功')));
    }

    public function one_station_num_detail($station_id){
        //新页面的开发
        $data_info = getcache('station_line_arr');
        $table_data = $this->Station_model->get_one(array('station_id'=>$station_id));
        $this->view('one_station_num_detail',array('require_js'=>true,'table_data'=>$table_data,'data_info'=>$data_info));

    }

    //基站监控
    function produce_xml(){
        $data_list = $this->Station_model->tables_select('is_del = 0','station_status,station_name,sac_code_A,sic_code_A,sac_code_B,sic_code_B,longtitude,latitude,station_height,sendcycle,is_station,have_beacon,beacon_send_cycle,receive_range,in_work_option,enable_A,data_version_A as data_version_a,channel_ip_A,send_ip_A,send_port_A,exchange_eth_num_A,cast_type_A,data_upper_limit_A,track_upper_limit_A,enable_B,data_version_B as data_version_b,channel_ip_B,send_ip_B,send_port_B,exchange_eth_num_B,cast_type_B,data_upper_limit_B,track_upper_limit_B,rader_ids');
        $xmlpatch = STATION_XML_PATH.'station.xml';
        // var_dump($xmlpatch);exit;
        $doc = new DOMDocument('1.0','utf-8');
        $flag = false;
        if(file_exists($xmlpatch)) {

            $flag = true;
        }
        // print_r($data_list);exit;
        $doc -> formatOutput = true;
        $ADSB_RECV = $doc -> createElement('ADSB_RECV');//新建节点
        foreach ($data_list as $key => $value) {
            $station = $doc->createElement('Station');
            $ADSB_RECV->appendChild($station);
            $this->create_xml($doc,$station,$key,$value);
        }
        $doc->appendChild($ADSB_RECV);
        $xml_str =  $doc->saveXML();
        // $xml_res = $doc->save($xmlpatch);
        if($this->input->is_ajax_request()){
            // var_dump($flag);exit;
            create_dir(STATION_XML_PATH);
            $update_xml_file = 'station_'.date('Y_m_d_H_i',time()).'.xml';
            $kind_id = $this->Xml_basic_config_model->get_one(array('name'=>'基站配置文件','is_del'=>0),'id');
            if(!$kind_id){
                exit(json_encode(array('status'=>false,'tips'=>'请先进行基站配置文件服务器的配置')));
            }
            $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'station.xml\'','id');
            $res = $this->All_xml_model->xml_produce($xml_id_arr,$update_xml_file,'station.xml',$kind_id['id'],STATION_XML_PATH,'基站配置文件');
            $operation_data= $this->operation_data;
            $operation_data['dateline'] = time();
            if($flag){
                $operation_data['operate_explain'] = '生成新的基站配置文件并将原有的配置文件修改为'.$update_xml_file;
            }else{
                $operation_data['operate_explain'] = '生成新的基站配置文件';
            }
            if($res){
                if($flag){
                    rename($xmlpatch, STATION_XML_PATH.$update_xml_file);
                }
                $doc->save($xmlpatch);
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息新增成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'文件生成成功')));
            }else {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息新增失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'文件生成失败')));
            }
        }else{
            $this->view('produce_xml',array('xml_data'=>htmlentities($xml_str),'require_js'=>true));
        }

    }

    public function one_station_detail($id){
        $station_id = intval($id);
        $new_data_list = $this->make_one_station_data($station_id);
        $cat_switch_check = $this->check_button_priv('cat_switch');
        $change_current_path_check = $this->check_button_priv('change_current_path');
        $change_switch_status_check = $this->check_button_priv('change_switch_status');

        $this->view('one_station_detail',array('require_js'=>true,'one_data_list'=>$new_data_list,'cat_switch_check'=>$cat_switch_check,'change_current_path_check'=>$change_current_path_check,'change_switch_status_check'=>$change_switch_status_check));
    }
    //雷达的详情
    public function one_rader_detail($id){
        $station_id = intval($id);
        $one_rader_info = $this->Raders_model->get_one(array('id'=>$id));
        if($one_rader_info['is_monitor'] == 0){
            $this->showmessage('设备为监控');exit;
        }
        $this->view('one_rader_detail',array('require_js'=>true,'one_data_list'=>$one_rader_info));
    }

    public function timing_one_station_detail($id){
        $station_id = intval($id);
        $new_data_list = $this->make_one_station_data($station_id,1);
        echo json_encode($new_data_list);
    }

    public function timing_one_rader_detail($id){
        //进行单个文件信息的读取的数据库更新
        $one_rader_info = $this->Raders_model->get_one(array('id'=>$id));
        if(!$one_rader_info){
            echo json_encode(array());exit;
        }
        $this->Station_model->rader_status();
        $one_rader_info = $this->Raders_model->get_one(array('id'=>$id));
        $one_rader_info['report_time'] = date('Y-m-d H:i:s',$one_rader_info['report_time']);
        echo json_encode($one_rader_info);
    }

    public  function rader_lists($page_no=1)
    {
        $page_no = max(intval($page_no),1);
        $where = '';
        $orderby = $keyword= "";
        $where = 'is_del = 0 ';
        // var_dump($_GET);exit;
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where .= "and concat(name,receive_ip) like '%{$keyword}%'";
        }
        $fresh_xml_data = $this->All_xml_model->get_one(array('kind'=>2,'is_old'=>0),'id');
        $data_list = $this->Raders_model->listinfo($where,'*',$orderby , $page_no, $this->Raders_model->page_size,'',$this->Raders_model->page_size,page_list_url('adminpanel/station/rader_lists',true));
        $this->view('rader_lists',array('data_list'=>$data_list,'page_no'=>$page_no,'pages'=>$this->Raders_model->pages,'keyword'=>$keyword,'fresh_xml_data'=>$fresh_xml_data,'require_js'=>true));
    }
    /**
     * 新增雷达
     */
    public  function rader_add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'雷达名称不能为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达名称名称不能为空')));
            $_arr['switch'] = isset($_POST["switch"])?trim(safe_replace($_POST["switch"])):exit(json_encode(array('status'=>false,'tips'=>'雷达状态不能为空')));
            if($_arr['switch']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达状态不能为空')));
            /*$_arr['receive_ip'] = isset($_POST["receive_ip"])?trim(safe_replace($_POST["receive_ip"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收ip不能为空')));
            if($_arr['receive_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收ip不能为空')));*/

            $_arr['receive_port'] = isset($_POST["receive_port"])?trim(safe_replace($_POST["receive_port"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收端口不能为空')));
            if($_arr['receive_port']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收端口不能为空')));
            $_arr['path_switch_a'] = (int)$this->input->post('path_switch_a');
            $data_cast_type = (int)$this->input->post('data_cast_type'); //通道类型
            $cast_type_ip_a = trim(safe_replace($this->input->post('cast_type_ip_a'))); //组播地址
            $receive_ip =trim(safe_replace($this->input->post('receive_ip')));//接收ip
            $broad_ip_a = trim(safe_replace($this->input->post('broad_ip_a')));//广播地址
            $_arr['data_cast_type'] = $data_cast_type?$data_cast_type:exit(json_encode(array('status'=>false,'tips'=>'通道A数据传输方式不能为空')));
            if($data_cast_type == 2){
                $_arr['cast_type_ip_a'] = $cast_type_ip_a?$cast_type_ip_a:exit(json_encode(array('status'=>false,'tips'=>'雷达通道A组播地址不能为空')));
            }elseif($data_cast_type == 1){
                $_arr['receive_ip'] = $receive_ip?$receive_ip:exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收ip不能为空')));
            }else{
                $_arr['broad_ip_a'] = $broad_ip_a?$broad_ip_a:exit(json_encode(array('status'=>false,'tips'=>'雷达通道A广播地址不能为空')));
            }



            /*  $_arr['receive_ip_b'] = isset($_POST["receive_ip_b"])?trim(safe_replace($_POST["receive_ip_b"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收ip不能为空')));
              if($_arr['receive_ip_b']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收ip不能为空')));*/
            $_arr['receive_port_b'] = isset($_POST["receive_port_b"])?trim(safe_replace($_POST["receive_port_b"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收端口不能为空')));
            if($_arr['receive_port_b']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收端口不能为空')));
            $_arr['path_switch_b'] = (int)$this->input->post('path_switch_b');
            $data_cast_type_b = (int)$this->input->post('data_cast_type_b'); //通道类型
            $cast_type_ip_b = trim(safe_replace($this->input->post('cast_type_ip_b'))); //组播地址
            $receive_ip_b =trim(safe_replace($this->input->post('receive_ip_b')));//接收ip
            $broad_ip_b = trim(safe_replace($this->input->post('broad_ip_b')));//广播地址
            $_arr['data_cast_type_b'] = $data_cast_type_b?$data_cast_type_b:exit(json_encode(array('status'=>false,'tips'=>'通道B数据传输方式不能为空')));
            if($data_cast_type_b == 2){
                $_arr['cast_type_ip_b'] = $cast_type_ip_b?$cast_type_ip_b:exit(json_encode(array('status'=>false,'tips'=>'雷达通道B组播地址不能为空')));
            }elseif($data_cast_type_b == 1){
                $_arr['receive_ip_b'] = $receive_ip_b?$receive_ip_b:exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收ip不能为空')));
            }else{
                $_arr['broad_ip_b'] = $broad_ip_b?$broad_ip_b:exit(json_encode(array('status'=>false,'tips'=>'雷达通道B广播地址不能为空')));
            }

            $_arr['range'] = isset($_POST["range"])?trim(safe_replace($_POST["range"])):exit(json_encode(array('status'=>false,'tips'=>'雷达接收范围不能为空')));
            if($_arr['range']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达接收范围不能为空')));
            $_arr['longtitude'] = isset($_POST["longtitude"])?trim(safe_replace($_POST["longtitude"])):exit(json_encode(array('status'=>false,'tips'=>'雷达经度不能为空')));
            if($_arr['longtitude']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达经度不能为空')));
            $_arr['latitude'] = isset($_POST["latitude"])?trim(safe_replace($_POST["latitude"])):exit(json_encode(array('status'=>false,'tips'=>'雷达纬度不能为空')));
            if($_arr['latitude']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达纬度不能为空')));

            $_arr['rader_kind'] = isset($_POST["rader_kind"])?trim(safe_replace($_POST["rader_kind"])):exit(json_encode(array('status'=>false,'tips'=>'雷达类型不能为空')));
            if($_arr['rader_kind']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达类型不能为空')));

            $_arr['version'] = isset($_POST["version"])?trim(safe_replace($_POST["version"])):exit(json_encode(array('status'=>false,'tips'=>'雷达数据版本不能为空')));
            if($_arr['version']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达数据版本不能为空')));
            $_arr['height'] = isset($_POST["height"])?trim(safe_replace($_POST["height"])):exit(json_encode(array('status'=>false,'tips'=>'雷达高度不能为空')));
            if($_arr['height']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达高度不能为空')));
            $_arr["is_monitor"] = isset($_POST["is_monitor"])?trim(safe_replace($_POST["is_monitor"])):'';
            if($_arr["is_monitor"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否监控')));
            if(!$_arr['path_switch_a'] && !$_arr['path_switch_b']){
                $_arr['is_monitor'] == 0;
            }
            if($_arr["is_monitor"] == 0){
                $_arr['rader_img'] = 'satellite_antenna2.png';
            }else{
                $_arr['rader_img'] = 'satellite_antenna.png';
            }
            $_arr['dateline'] = time();
            $_arr['in_work_option'] = (int)$this->input->post('in_work_option');
            if(!$_arr['in_work_option'])exit(json_encode(array('status'=>false,'tips'=>'请输入通道首选项')));
            $this->db->trans_start();
            $new_id = $this->Raders_model->insert($_arr);
            if(!empty($resend_ip)){
                if(in_array('', $resend_ip)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道A转发地址ip不得有空值')));
                }

            }
            if(!empty($resend_port)){
                if(in_array('', $resend_port)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道A转发地址端口不得有空值')));
                }
            }
            if(!empty($resend_group_ip_a)){
                if(in_array('', $resend_group_ip_a)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道A转发组播地址不得有空值')));
                }

            }


            if(!empty($resend_ip_b)){
                if(in_array('', $resend_ip_b)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道B转发地址ip不得有空值')));
                }

            }
            if(!empty($resend_port_B)){
                if(in_array('', $resend_port_B)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道B转发地址端口不得有空值')));
                }
            }
            if(!empty($resend_group_ip_b)){
                if(in_array('', $resend_group_ip_b)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道B转发组播地址不得有空值')));
                }

            }
            $group_ip_a = array();
            if(!empty($cast_type)){
                foreach($cast_type as $key=>$value){
                    if($value == 2){
                        $tmp_a = each($resend_group_ip_a);
                        $group_ip_a[$key] =  $tmp_a['value'];
                    }
                }
            }
            $group_ip_b = array();
            if(!empty($cast_type_b)){
                foreach($cast_type_b as $key=>$value){
                    if($value == 2){
                        $tmp_b = each($resend_group_ip_b);
                        $group_ip_b[$key] =  $tmp_b['value'];
                    }
                }
            }

            //旧数据删除
            $dots_arr = array();
            if(!empty($resend_ip) && !empty($resend_port)){
                $this->Raders_resend_model->delete('rader_id ='.$id.' and kind= 0');
                foreach ($resend_ip as $key => $value) {
                    $dots_arr[$key]['resend_ip'] = $value;
                    $dots_arr[$key]['resend_port'] = $resend_port[$key];
                    $dots_arr[$key]['cast_type'] = $cast_type[$key];
                    $dots_arr[$key]['rader_id'] = $new_id;
                    $dots_arr[$key]['kind'] = 0;
                    if( $dots_arr[$key]['cast_type'] == 2){
                        $dots_arr[$key]['resend_group_ip'] = $group_ip_a[$key];
                    }else{
                        $dots_arr[$key]['resend_group_ip'] = ' ';
                    }

                }
                //新数据插入
                $this->Raders_resend_model->insert_batch($dots_arr);
            }
            $dots_arr_b = array();
            if(!empty($resend_ip_b) && !empty($resend_port_b)){
                $this->Raders_resend_model->delete('rader_id ='.$id.' and kind= 1');
                foreach ($resend_ip_b as $key => $value) {
                    $dots_arr_b[$key]['resend_ip'] = $value;
                    $dots_arr_b[$key]['resend_port'] = $resend_port_b[$key];
                    $dots_arr_b[$key]['cast_type'] = $cast_type_b[$key];
                    $dots_arr_b[$key]['rader_id'] = $new_id;
                    $dots_arr_b[$key]['kind'] = 1;
                    if($dots_arr_b[$key]['cast_type'] == 2){
                        $dots_arr_b[$key]['resend_group_ip'] = $group_ip_b[$key];
                    }else{
                        $dots_arr_b[$key]['resend_group_ip'] = ' ';
                    }
                }
                //新数据插入
                $this->Raders_resend_model->insert_batch($dots_arr_b);
            }
            //日志
            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '添加新雷达'.$_arr['name'].'';
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '信息添加成功';
            $this->operationLogs($operation_data);
            $this->db->trans_complete();
            if($this->db->trans_status() !== false){
                exit(json_encode(array('status'=>true,'tips'=>'信息添加成功')));
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'信息添加失败')));
            }
        }else
        {
            $raders_kind_info = $this->Raders_kind_model->select();
            if(!$raders_kind_info){
                $this->showmessage('请先进行雷达类型文件配置');exit;
            }
            $this->view('rader_edit',array('is_edit'=>false,'require_js'=>true,'data_info'=>$this->Raders_model->default_info(),'raders_arr'=>array(),'raders_arr_b'=>array(),'raders_kind_info'=>$raders_kind_info));
        }

    }


    /**
     * 雷达编辑
     * @param $id
     * @param $network 所属网络结构
     */
    public  function rader_edit($id)
    {
        $id = intval($id);
        $data_info =$this->Raders_model->get_one(array('id'=>$id));
        $raders_arr = $this->Raders_resend_model->select(array('rader_id'=>$id,'kind'=>0));
        $raders_arr_b = $this->Raders_resend_model->select(array('rader_id'=>$id,'kind'=>1));
        if(!$data_info)$this->showmessage('雷达信息不存在或不完整');
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'雷达名称不能为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达名称名称不能为空')));
            $_arr['switch'] = isset($_POST["switch"])?trim(safe_replace($_POST["switch"])):exit(json_encode(array('status'=>false,'tips'=>'雷达状态不能为空')));
            if($_arr['switch']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达状态不能为空')));
            /*$_arr['receive_ip'] = isset($_POST["receive_ip"])?trim(safe_replace($_POST["receive_ip"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收ip不能为空')));
            if($_arr['receive_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收ip不能为空')));*/

            $_arr['receive_port'] = isset($_POST["receive_port"])?trim(safe_replace($_POST["receive_port"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收端口不能为空')));
            if($_arr['receive_port']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收端口不能为空')));
            $_arr['path_switch_a'] = (int)$this->input->post('path_switch_a');
            $data_cast_type = (int)$this->input->post('data_cast_type'); //通道类型
            $cast_type_ip_a = trim(safe_replace($this->input->post('cast_type_ip_a'))); //组播地址
            $receive_ip =trim(safe_replace($this->input->post('receive_ip')));//接收ip
            $broad_ip_a = trim(safe_replace($this->input->post('broad_ip_a')));//广播地址
            $_arr['data_cast_type'] = $data_cast_type?$data_cast_type:exit(json_encode(array('status'=>false,'tips'=>'通道A数据传输方式不能为空')));
            if($data_cast_type == 2){
                $_arr['cast_type_ip_a'] = $cast_type_ip_a?$cast_type_ip_a:exit(json_encode(array('status'=>false,'tips'=>'雷达通道A组播地址不能为空')));
            }elseif($data_cast_type == 1){
                $_arr['receive_ip'] = $receive_ip?$receive_ip:exit(json_encode(array('status'=>false,'tips'=>'雷达通道A接收ip不能为空')));
            }else{
                $_arr['broad_ip_a'] = $broad_ip_a?$broad_ip_a:exit(json_encode(array('status'=>false,'tips'=>'雷达通道A广播地址不能为空')));
            }
            $_arr['pre_abandon_bype_a'] = (int)$this->input->post('pre_abandon_bype_a');
            $_arr['pre_abandon_bype_b'] = (int)$this->input->post('pre_abandon_bype_b');


            /*  $_arr['receive_ip_b'] = isset($_POST["receive_ip_b"])?trim(safe_replace($_POST["receive_ip_b"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收ip不能为空')));
              if($_arr['receive_ip_b']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收ip不能为空')));*/
            $_arr['receive_port_b'] = isset($_POST["receive_port_b"])?trim(safe_replace($_POST["receive_port_b"])):exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收端口不能为空')));
            if($_arr['receive_port_b']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收端口不能为空')));
            $_arr['path_switch_b'] = (int)$this->input->post('path_switch_b');
            $data_cast_type_b = (int)$this->input->post('data_cast_type_b'); //通道类型
            $cast_type_ip_b = trim(safe_replace($this->input->post('cast_type_ip_b'))); //组播地址
            $receive_ip_b =trim(safe_replace($this->input->post('receive_ip_b')));//接收ip
            $broad_ip_b = trim(safe_replace($this->input->post('broad_ip_b')));//广播地址
            $_arr['data_cast_type_b'] = $data_cast_type_b?$data_cast_type_b:exit(json_encode(array('status'=>false,'tips'=>'通道B数据传输方式不能为空')));
            if($data_cast_type_b == 2){
                $_arr['cast_type_ip_b'] = $cast_type_ip_b?$cast_type_ip_b:exit(json_encode(array('status'=>false,'tips'=>'雷达通道B组播地址不能为空')));
            }elseif($data_cast_type_b == 1){
                $_arr['receive_ip_b'] = $receive_ip_b?$receive_ip_b:exit(json_encode(array('status'=>false,'tips'=>'雷达通道B接收ip不能为空')));
            }else{
                $_arr['broad_ip_b'] = $broad_ip_b?$broad_ip_b:exit(json_encode(array('status'=>false,'tips'=>'雷达通道B广播地址不能为空')));
            }

            $_arr['range'] = isset($_POST["range"])?trim(safe_replace($_POST["range"])):exit(json_encode(array('status'=>false,'tips'=>'雷达接收范围不能为空')));
            if($_arr['range']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达接收范围不能为空')));
            $_arr['longtitude'] = isset($_POST["longtitude"])?trim(safe_replace($_POST["longtitude"])):exit(json_encode(array('status'=>false,'tips'=>'雷达经度不能为空')));
            if($_arr['longtitude']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达经度不能为空')));
            $_arr['latitude'] = isset($_POST["latitude"])?trim(safe_replace($_POST["latitude"])):exit(json_encode(array('status'=>false,'tips'=>'雷达纬度不能为空')));
            if($_arr['latitude']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达纬度不能为空')));

            $_arr['rader_kind'] = isset($_POST["rader_kind"])?trim(safe_replace($_POST["rader_kind"])):exit(json_encode(array('status'=>false,'tips'=>'雷达类型不能为空')));
            if($_arr['rader_kind']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达类型不能为空')));

            $_arr['version'] = isset($_POST["version"])?trim(safe_replace($_POST["version"])):exit(json_encode(array('status'=>false,'tips'=>'雷达数据版本不能为空')));
            if($_arr['version']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达数据版本不能为空')));
            $_arr['height'] = isset($_POST["height"])?trim(safe_replace($_POST["height"])):exit(json_encode(array('status'=>false,'tips'=>'雷达高度不能为空')));
            if($_arr['height']=='')exit(json_encode(array('status'=>false,'tips'=>'雷达高度不能为空')));
            $_arr["is_monitor"] = isset($_POST["is_monitor"])?trim(safe_replace($_POST["is_monitor"])):'';
            if($_arr["is_monitor"] =='')exit(json_encode(array('status'=>false,'tips'=>'请输入是否监控')));
            if(!$_arr['path_switch_a'] && !$_arr['path_switch_b']){
                $_arr['is_monitor'] == 0;
            }
            if($_arr["is_monitor"] == 0){
                $_arr['rader_img'] = 'satellite_antenna2.png';
            }else{
                $_arr['rader_img'] = 'satellite_antenna.png';
            }
            $_arr['dateline'] = time();
            $_arr['in_work_option'] = (int)$this->input->post('in_work_option');
            if(!$_arr['in_work_option'])exit(json_encode(array('status'=>false,'tips'=>'请输入通道首选项')));
            $resend_ip = $this->input->post('resend_ip');
            $resend_port = $this->input->post('resend_port');
            $cast_type = $this->input->post('cast_type');
            $resend_group_ip_a = $this->input->post('resend_group_ip_a');


            $resend_ip_b = $this->input->post('resend_ip_b');
            $resend_port_b = $this->input->post('resend_port_b');
            $cast_type_b = $this->input->post('cast_type_b');
            $resend_group_ip_b = $this->input->post('resend_group_ip_b');
            $this->db->trans_start();
            if(!empty($resend_ip)){
                if(in_array('', $resend_ip)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道A转发地址ip不得有空值')));
                }

            }
            if(!empty($resend_port)){
                if(in_array('', $resend_port)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道A转发地址端口不得有空值')));
                }
            }
            if(!empty($resend_group_ip_a)){
                if(in_array('', $resend_group_ip_a)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道A转发组播地址不得有空值')));
                }

            }


            if(!empty($resend_ip_b)){
                if(in_array('', $resend_ip_b)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道B转发地址ip不得有空值')));
                }

            }
            if(!empty($resend_port_B)){
                if(in_array('', $resend_port_B)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道B转发地址端口不得有空值')));
                }
            }
            if(!empty($resend_group_ip_b)){
                if(in_array('', $resend_group_ip_b)){
                    exit(json_encode(array('status'=>false,'tips'=>'通道B转发组播地址不得有空值')));
                }

            }
            $group_ip_a = array();
            if(!empty($cast_type)){
                foreach($cast_type as $key=>$value){
                    if($value == 2){
                        $tmp_a = each($resend_group_ip_a);
                        $group_ip_a[$key] =  $tmp_a['value'];
                    }
                }
            }

            $group_ip_b = array();
            if(!empty($cast_type_b)){
                foreach($cast_type_b as $key=>$value){
                    if($value == 2){
                        $tmp_b = each($resend_group_ip_b);
                        $group_ip_b[$key] =  $tmp_b['value'];
                    }
                }
            }

            //旧数据删除
            $dots_arr = array();
            if(!empty($resend_ip) && !empty($resend_port)){
                $this->Raders_resend_model->delete('rader_id ='.$id.' and kind= 0');
                foreach ($resend_ip as $key => $value) {
                    $dots_arr[$key]['resend_ip'] = $value;
                    $dots_arr[$key]['resend_port'] = $resend_port[$key];
                    $dots_arr[$key]['cast_type'] = $cast_type[$key];
                    $dots_arr[$key]['rader_id'] = $id;
                    $dots_arr[$key]['kind'] = 0;
                    if( $dots_arr[$key]['cast_type'] == 2){
                        $dots_arr[$key]['resend_group_ip'] = $group_ip_a[$key];
                    }else{
                        $dots_arr[$key]['resend_group_ip'] = ' ';
                    }

                }
                //新数据插入
                $this->Raders_resend_model->insert_batch($dots_arr);
            }
            $dots_arr_b = array();
            if(!empty($resend_ip_b) && !empty($resend_port_b)){
                $this->Raders_resend_model->delete('rader_id ='.$id.' and kind= 1');
                foreach ($resend_ip_b as $key => $value) {
                    $dots_arr_b[$key]['resend_ip'] = $value;
                    $dots_arr_b[$key]['resend_port'] = $resend_port_b[$key];
                    $dots_arr_b[$key]['cast_type'] = $cast_type_b[$key];
                    $dots_arr_b[$key]['rader_id'] = $id;
                    $dots_arr_b[$key]['kind'] = 1;
                    if($dots_arr_b[$key]['cast_type'] == 2){
                        $dots_arr_b[$key]['resend_group_ip'] = $group_ip_b[$key];
                    }else{
                        $dots_arr_b[$key]['resend_group_ip'] = ' ';
                    }
                }
                //新数据插入
                $this->Raders_resend_model->insert_batch($dots_arr_b);
            }
            $this->Raders_model->update($_arr,array('id'=>$id));
            $new_data_info = $this->Raders_model->get_one(array('id'=>$id));
            //日志
            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '进行雷达'.$_arr['name'].'的修改';
            $before_change_data = array_diff_assoc($data_info, $new_data_info);
            $operate_info = array();
            $i = 0;
            foreach ($before_change_data as $key => $value) {
                $operation_info[$i]['key'] = $key;
                $operation_info[$i]['old_val'] = $value;
                $operation_info[$i]['new_val'] = $new_data_info[$key];
                $i++;
            }
            $operation_data['operate_info'] = json_encode($operation_info);
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '信息修改成功';
            $this->operationLogs($operation_data);
            $this->db->trans_complete();
            if($this->db->trans_status() !== false){
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }

        }else
        {

            $raders_kind_info = $this->Raders_kind_model->select();
            if(!$raders_kind_info){
                $this->showmessage('清先进行雷达类型文件配置');
            }

            //版本
            $versions_data = $this->Raders_kind_model->get_one(array('id'=>$data_info['rader_kind']));
            if($versions_data){
                $versions_data_arr = explode(',', $versions_data['versions']);
            }else{
                $versions_data_arr = array();
            }
            $this->view('rader_edit',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info,'raders_arr'=>$raders_arr,'raders_arr_b'=>$raders_arr_b,'raders_kind_info'=>$raders_kind_info,'versions_data_arr'=>$versions_data_arr));
        }
    }

    public  function rader_info($id)
    {
        $id = intval($id);
        $data_info =$this->Raders_model->get_one(array('id'=>$id));
        $raders_arr = $this->Raders_resend_model->select(array('rader_id'=>$id,'kind'=>0));
        $raders_arr_b = $this->Raders_resend_model->select(array('rader_id'=>$id,'kind'=>1));
        if(!$data_info)$this->showmessage('雷达信息不存在或不完整');
        //如果是AJAX请求进行雷达类型文件配置');
        $raders_kind_info = $this->Raders_kind_model->select();
        if(!$raders_kind_info){
            $this->showmessage('清先进行雷达类型文件配置');
        }

        //版本
        $versions_data = $this->Raders_kind_model->get_one(array('id'=>$data_info['rader_kind']));
        if($versions_data){
            $versions_data_arr = explode(',', $versions_data['versions']);
        }else{
            $versions_data_arr = array();
        }
        $this->view('rader_info',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info,'raders_arr'=>$raders_arr,'raders_arr_b'=>$raders_arr_b,'raders_kind_info'=>$raders_kind_info,'versions_data_arr'=>$versions_data_arr));

    }
    /**
     * 雷达基础参数编辑
     * @param $id
     */
    public  function rader_base_set()
    {
        //如果是AJAX请求
        $data_info =$this->Raders_config_model->get_one();
        if(!$data_info){
            $data_info = $this->Raders_config_model->default_info();
        }
        if($this->input->is_ajax_request())
        {
            $_arr['recv_adsb_ip'] = isset($_POST["recv_adsb_ip"])?trim(safe_replace($_POST["recv_adsb_ip"])):exit(json_encode(array('status'=>false,'tips'=>'A网ADS-B数据接收ip不能为空')));
            if($_arr['recv_adsb_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'A网ADS-B数据接收ip不能为空')));
            $_arr['recv_adsb_port'] = isset($_POST["recv_adsb_port"])?trim(safe_replace($_POST["recv_adsb_port"])):exit(json_encode(array('status'=>false,'tips'=>'A网ADS-B数据接收端口不能为空')));
            if($_arr['recv_adsb_port']=='')exit(json_encode(array('status'=>false,'tips'=>'A网ADS-B数据接收端口不能为空')));

            $_arr['recv_adsb_ip_2'] = isset($_POST["recv_adsb_ip_2"])?trim(safe_replace($_POST["recv_adsb_ip_2"])):exit(json_encode(array('status'=>false,'tips'=>'B网ADS-B数据接收ip不能为空')));
            if($_arr['recv_adsb_ip_2']=='')exit(json_encode(array('status'=>false,'tips'=>'B网ADS-B数据接收ip不能为空')));
            $_arr['recv_adsb_port_2'] = isset($_POST["recv_adsb_port_2"])?trim(safe_replace($_POST["recv_adsb_port_2"])):exit(json_encode(array('status'=>false,'tips'=>'B网ADS-B数据接收端口不能为空')));
            if($_arr['recv_adsb_port_2']=='')exit(json_encode(array('status'=>false,'tips'=>'B网ADS-B数据接收端口不能为空')));

            $_arr['category_path'] = isset($_POST["category_path"])?trim(safe_replace($_POST["category_path"])):exit(json_encode(array('status'=>false,'tips'=>'cat配置文件目录不得为空')));
            if($_arr['category_path']=='')exit(json_encode(array('status'=>false,'tips'=>'cat配置文件目录不得为空')));

            $_arr['log_path'] = isset($_POST["log_path"])?trim(safe_replace($_POST["log_path"])):exit(json_encode(array('status'=>false,'tips'=>'日志文件目录不得为空')));
            if($_arr['log_path']=='')exit(json_encode(array('status'=>false,'tips'=>'日志文件目录不得为空')));
            $_arr["log_devel"] = isset($_POST["log_devel"])?trim(safe_replace($_POST["log_devel"])):exit(json_encode(array('status'=>false,'tips'=>'日志等级不得为空')));;
            if($_arr['log_devel']=='')exit(json_encode(array('status'=>false,'tips'=>'日志等级不得为空')));
            $_arr["interval"] = isset($_POST["interval"])?trim(safe_replace($_POST["interval"])):exit(json_encode(array('status'=>false,'tips'=>'请选择发送间隔')));
            if($_arr["interval"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择发送间隔')));
            $_arr["missCnt"] = isset($_POST["missCnt"])?trim(safe_replace($_POST["missCnt"])):exit(json_encode(array('status'=>false,'tips'=>'请输入心跳包丢失时间间隔')));
            if($_arr["missCnt"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入心跳包丢失时间间隔')));
            $_arr["watch_ip"] = isset($_POST["watch_ip"])?trim(safe_replace($_POST["watch_ip"])):exit(json_encode(array('status'=>false,'tips'=>'请输入监控程序ip')));
            if(!$_arr["watch_ip"])exit(json_encode(array('status'=>false,'tips'=>'请输入监控程序ip')));
            $_arr["watch_ip_port"] = isset($_POST["watch_ip_port"])?trim(safe_replace($_POST["watch_ip_port"])):exit(json_encode(array('status'=>false,'tips'=>'请输入监控程序ip端口')));
            if(!$_arr["watch_ip_port"])exit(json_encode(array('status'=>false,'tips'=>'请输入监控程序ip端口')));

            $_arr["send_result_ip"] = isset($_POST["send_result_ip"])?trim(safe_replace($_POST["send_result_ip"])):exit(json_encode(array('status'=>false,'tips'=>'请输入雷达验证结果发送ip')));
            if(!$_arr["send_result_ip"])exit(json_encode(array('status'=>false,'tips'=>'请输入雷达验证结果发送ip')));
            $_arr["send_result_port"] = isset($_POST["send_result_port"])?trim(safe_replace($_POST["send_result_port"])):exit(json_encode(array('status'=>false,'tips'=>'请输入雷达验证结果发送ip端口')));
            if(!$_arr["send_result_port"])exit(json_encode(array('status'=>false,'tips'=>'请输入雷达验证结果发送ip端口')));


            $_arr["recieve_program_ip"] = isset($_POST["recieve_program_ip"])?trim(safe_replace($_POST["recieve_program_ip"])):exit(json_encode(array('status'=>false,'tips'=>'请输入接收程序ip')));
            if(!$_arr["recieve_program_ip"])exit(json_encode(array('status'=>false,'tips'=>'请输入接收程序ip')));

            $_arr["recieve_program_port"] = isset($_POST["recieve_program_port"])?trim(safe_replace($_POST["recieve_program_port"])):exit(json_encode(array('status'=>false,'tips'=>'请输入接收程序端口')));
            if(!$_arr["recieve_program_port"])exit(json_encode(array('status'=>false,'tips'=>'请输入接收程序端口')));
            $_arr["in_height"] = isset($_POST["in_height"])?trim(safe_replace($_POST["in_height"])):exit(json_encode(array('status'=>false,'tips'=>'请输入匹配高度')));
            if(!$_arr["in_height"])exit(json_encode(array('status'=>false,'tips'=>'请输入匹配高度')));

            $_arr["in_speed"] = isset($_POST["in_speed"])?trim(safe_replace($_POST["in_speed"])):exit(json_encode(array('status'=>false,'tips'=>'请输入匹配速度')));
            if(!$_arr["in_speed"])exit(json_encode(array('status'=>false,'tips'=>'请输入匹配速度')));
            $_arr["in_time"] = isset($_POST["in_time"])?trim(safe_replace($_POST["in_time"])):exit(json_encode(array('status'=>false,'tips'=>'请输入匹配速度')));
            if(!$_arr["in_time"])exit(json_encode(array('status'=>false,'tips'=>'请输入匹配时间差')));
            $_arr["in_pos"] = isset($_POST["in_pos"])?trim(safe_replace($_POST["in_pos"])):exit(json_encode(array('status'=>false,'tips'=>'请输入匹配速度')));
            if(!$_arr["in_pos"])exit(json_encode(array('status'=>false,'tips'=>'请输入匹配位置差')));
            $_arr["in_angle"] = isset($_POST["in_angle"])?trim(safe_replace($_POST["in_angle"])):exit(json_encode(array('status'=>false,'tips'=>'请输入匹配角度')));
            if(!$_arr["in_angle"])exit(json_encode(array('status'=>false,'tips'=>'请输入匹配角度')));
            $_arr["in_count"] = isset($_POST["in_count"])?trim(safe_replace($_POST["in_count"])):exit(json_encode(array('status'=>false,'tips'=>'请输入匹配轨迹最大点数')));
            if(!$_arr["in_count"])exit(json_encode(array('status'=>false,'tips'=>'请输入匹配轨迹最大点数')));
            $_arr["min_count"] = isset($_POST["min_count"])?trim(safe_replace($_POST["min_count"])):exit(json_encode(array('status'=>false,'tips'=>'请输入两轨最小点数')));
            if(!$_arr["min_count"])exit(json_encode(array('status'=>false,'tips'=>'请输入两轨最小点数')));
            $_arr["rate"] = isset($_POST["rate"])?trim(safe_replace($_POST["rate"])):exit(json_encode(array('status'=>false,'tips'=>'请输入匹配度')));
            if(!$_arr["rate"])exit(json_encode(array('status'=>false,'tips'=>'请输入匹配度')));
            $_arr["check_duration"] = isset($_POST["check_duration"])?trim(safe_replace($_POST["check_duration"])):exit(json_encode(array('status'=>false,'tips'=>'请输入验证周期')));
            if(!$_arr["check_duration"])exit(json_encode(array('status'=>false,'tips'=>'请输入验证周期')));

            $result = $this->Raders_config_model->update($_arr,array('id'=>1));
            $new_data_info = $this->Raders_config_model->get_one(array('id'=>1));
            $operation_data = $this->operation_data;
            $operation_data['dateline'] = time();
            $operation_data['operate_explain'] = '进行雷达基础配置文件的修改';
            $before_change_data = array_diff_assoc($data_info, $new_data_info);
            $operation_info = array();
            $i = 0;
            foreach ($before_change_data as $key => $value) {
                $operation_info[$i]['key'] = $key;
                $operation_info[$i]['old_val'] = $value;
                $operation_info[$i]['new_val'] = $new_data_info[$key];
                $i++;
            }
            $operation_data['operate_info'] = json_encode($operation_info);
            if($result)
            {
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息修改成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$result)));
            }else
            {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息修改失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $this->view('rader_base_set',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info));
        }
    }

    function rader_delete($id)
    {
        $status = $this->Raders_model->update(array('is_del' => 1),array('id'=>$id));
        $data_info = $this->Raders_model->get_one(array('id' => $id));
        if (!$data_info) $this->showmessage('信息不存在');
        $operation_data = $this->operation_data;
        $operation_data['operate_explain'] = '删除'.$data_info['name'].'的雷达数据';
        $operation_data['info_url'] = 'station/rader_info/'.$id;
        $operation_data['dateline'] = time();
        if($status)
        {
            $operation_data['is_success'] = 1;
            $operation_data['status_explain'] = '删除成功';
            @$this->operationLogs($operation_data);
            $this->showmessage('删除成功');
        }else{
            $operation_data['is_success'] = 0;
            $operation_data['status_explain'] = '删除失败';
            @$this->operationLogs($operation_data);
            $this->showmessage('删除失败');
        }
    }

    private function make_one_station_data($id,$ajax_kind = 0){
        $station_id = intval($id);
        /*$one_data_list = $this->Station_model->tables_select('t_sys_station.station_id ='.$station_id,'t_sys_station.station_id,station_name,data_upper_limit_A,data_upper_limit_B,enable_A,enable_B,in_work_option,current_work_pass,alarm_status,channel_status_A,channel_status_B,channel_data_A,channel_data_B,sac_code_A,sic_code_A,sac_code_B,sic_code_B,version_alarm_A,version_alarm_B,data_version_A,data_version_B,channel_bite_A,channel_bite_B,channel_time_A,channel_time_B,channel_A_version,channel_B_version,is_monitor,sound_switch,is_station,cat023_switch,cat247_switch,cat023_route,cat247_route,channel_ip_A,send_port_A,channel_ip_B,send_port_B');*/
        if(getcache('cache_all_station')){
            $all_station_cache = getcache('cache_all_station');
        }else{
            $all_station_cache = $this->Station_model->_cache_station();
        }
        $one_data_list = array();
        foreach ($all_station_cache as $key => $value) {
            if($value['station_id'] == $station_id){
                $one_data_list = $value;
                break;
            }
        }
        if(!$one_data_list){
            if(!$ajax_kind){
                $this->showmessage('应用详情不存在');exit;
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'应用详情不存在')));
            }
        }


        if($one_data_list['is_monitor'] == 0){
            if(!$ajax_kind){
                $this->showmessage('设备未监控');exit;
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'设备已修改为未监控状态')));
            }
        }
        //查找station_id的位置
        $all_datas = $this->Station_model->tables_select('is_del = 0','t_sys_station.station_id');
        $the_key = 0;
        foreach ($all_datas as $key => $value) {
            if($value['station_id'] == $station_id){
                $the_key = $key;
            }
        }
        // $this->one_stations_status($one_data_list,$the_key);
        $one_data_list =  $this->Station_model->one_stations_status($one_data_list,$the_key,count($all_station_cache)+2);
        /*$all_station_cache = $this->Station_model->_cache_station();
        $one_data_list = array();
        foreach ($all_station_cache as $key => $value) {
            if($value['station_id'] == $station_id){
                $one_data_list = $value;
                break;
            }
        }*/
        $sac_path_a = $one_data_list['sac_code_A'].'_'. $one_data_list['sic_code_A'];
        $new_data_list = array();
        $new_data_list[0]['station_id'] = $one_data_list['station_id'];
        $new_data_list[0]['station_name'] = $one_data_list['station_name'];
        $new_data_list[0]['channel_time'] = date('Y-m-d H:i:s',$one_data_list['channel_time_A']);
        // $new_data_list[0]['data_upper_limit'] = $one_data_list['data_upper_limit_A'];
        $new_data_list[0]['data_upper_limit'] = jurge_station_limit(false,$one_data_list['channel_time_A'],$station_id);
        $new_data_list[0]['channel_data'] = $one_data_list['channel_data_A'];
        $new_data_list[0]['channel_bite'] = $one_data_list['channel_bite_A'];
        $tmp_a = '';
        if($one_data_list['enable_A'] == 0){
            $tmp_a = '手工关闭';
        }elseif($one_data_list['enable_A'] == 1){
            $tmp_a = '手工开启';
        }elseif($one_data_list['enable_A'] == 2){
            $tmp_a = '自动关闭';
        }else{
            $tmp_a = '自动开启';
        }
        $new_data_list[0]['enable'] = $tmp_a;
        $new_data_list[0]['in_work_option'] = ($one_data_list['in_work_option']==1)?"A":(($one_data_list['in_work_option']==2)?'B':'AUTO');
        $new_data_list[0]['current_work_pass'] = $one_data_list['current_work_pass'] == 1?"A":'B';
        $new_data_list[0]['channel_status'] = $one_data_list['channel_status_A'];
        $new_data_list[0]['channel_version'] = $one_data_list['channel_A_version'];

        $new_data_list[0]['version_alarm'] = $one_data_list['version_alarm_A'];
        $new_data_list[0]['sound_switch'] = $one_data_list['sound_switch'];
        $new_data_list[0]['alarm_status'] = $one_data_list['alarm_status'];
        $new_data_list[0]['cat023_switch'] = $one_data_list['cat023_switch'];
        $new_data_list[0]['cat247_switch'] = $one_data_list['cat247_switch'];
        $new_data_list[0]['cat023_status'] = $one_data_list['cat023_status_A'];
        $new_data_list[0]['send_ip'] = $one_data_list['send_ip_A'];
        $new_data_list[0]['send_port'] = $one_data_list['send_port_A'];
        $cat023_status_A_file = getcache('cat023_status_A_file');
        $cat023_status_B_file = getcache('cat023_status_B_file');
        if($cat023_status_A_file){
            $new_data_list[0]['a_data_file'] = $cat023_status_A_file;
        }else{
            $new_data_list[0]['a_data_file'] = '无信息';

        }
        $new_data_list[1]['station_id'] = $one_data_list['station_id'];
        $new_data_list[1]['station_name'] = $one_data_list['station_name'];
        $new_data_list[1]['channel_time'] = date('Y-m-d H:i:s',$one_data_list['channel_time_B']);
        // $new_data_list[1]['data_upper_limit'] = $one_data_list['data_upper_limit_B'];
        $new_data_list[1]['data_upper_limit'] = jurge_station_limit(false,$one_data_list['channel_time_B'],$station_id);
        $new_data_list[1]['channel_data'] = $one_data_list['channel_data_B'];
        $new_data_list[1]['channel_bite'] = $one_data_list['channel_bite_B'];
        $tmp_b = '';
        if($one_data_list['enable_B'] == 0){
            $tmp_b = '手工关闭';
        }elseif($one_data_list['enable_B'] == 1){
            $tmp_b = '手工开启';
        }elseif($one_data_list['enable_B'] == 2){
            $tmp_b = '自动关闭';
        }else{
            $tmp_b = '自动开启';
        }
        $new_data_list[1]['enable'] = $tmp_b;
        $new_data_list[1]['in_work_option'] = ($one_data_list['in_work_option']==1)?"A":(($one_data_list['in_work_option']==2)?'B':'AUTO');
        $new_data_list[1]['current_work_pass'] = $one_data_list['current_work_pass'] == 1?"A":'B';
        $new_data_list[1]['channel_status'] = $one_data_list['channel_status_B'];
        $new_data_list[1]['channel_version'] = $one_data_list['channel_B_version'];

        $new_data_list[1]['version_alarm'] = $one_data_list['version_alarm_B'];
        $new_data_list[1]['sound_switch'] = $one_data_list['sound_switch'];
        $new_data_list[1]['alarm_status'] = $one_data_list['alarm_status'];
        $new_data_list[1]['cat023_switch'] = $one_data_list['cat023_switch'];
        $new_data_list[1]['cat247_switch'] = $one_data_list['cat247_switch'];
        $new_data_list[1]['cat023_status'] = $one_data_list['cat023_status_B'];
        $new_data_list[1]['send_ip'] = $one_data_list['send_ip_B'];
        $new_data_list[1]['send_port'] = $one_data_list['send_port_B'];

        if($cat023_status_B_file){
            $new_data_list[1]['a_data_file'] = $cat023_status_B_file;
        }else{
            $new_data_list[1]['a_data_file'] = '无信息';

        }
        return $new_data_list;

    }

    //生成基站的xml文件
    private function create_xml($doc,$station,$key,$value){
        $stationId = $doc -> createElement('stationId');
        $stationId_text = $doc->createTextNode($key);
        $stationId->appendChild($stationId_text);

        $enabled = $doc -> createElement('enabled');
        $enabled_text = $doc->createTextNode($value['station_status']);
        $enabled->appendChild($enabled_text);

        $name = $doc -> createElement('name');
        $name_text = $doc->createTextNode($value['station_name']);
        $name->appendChild($name_text);

        /* $sac = $doc -> createElement('sac');
         $sac_text = $doc->createTextNode($value['sac_code']);
         $sac->appendChild($sac_text);

         $sic = $doc -> createElement('sic');
         $sic_text = $doc->createTextNode($value['sic_code']);
         $sic->appendChild($sic_text);*/

        $longitude = $doc -> createElement('longitude');
        $longitude_text = $doc->createTextNode($value['longtitude']);
        $longitude->appendChild($longitude_text);

        $latitude = $doc -> createElement('latitude');
        $latitude_text = $doc->createTextNode($value['latitude']);
        $latitude->appendChild($latitude_text);

        $height = $doc -> createElement('height');
        $height_text = $doc->createTextNode($value['station_height']);
        $height->appendChild($height_text);

        $sendCycle = $doc -> createElement('sendCycle');
        $sendCycle_text = $doc->createTextNode($value['sendcycle']);
        $sendCycle->appendChild($sendCycle_text);

        $dataStation = $doc -> createElement('dataStation');
        $dataStation_text = $doc->createTextNode($value['is_station']);
        $dataStation->appendChild($dataStation_text);

        $beacon = $doc -> createElement('beacon');
        $beacon_text = $doc->createTextNode($value['have_beacon']);
        $beacon->appendChild($beacon_text);

        $beaconSendCycle = $doc -> createElement('beaconSendCycle');
        $beaconSendCycle_text = $doc->createTextNode($value['beacon_send_cycle']);
        $beaconSendCycle->appendChild($beaconSendCycle_text);

        $relationRadar = $doc -> createElement('relationRadar');
        $radar_source_id = " ";
        $radar_lists = $this->Raders_model->select('is_del = 0','id');
        $value['rader_ids'] = explode(',', $value['rader_ids']);
        foreach($radar_lists as $k=>$val)
        {
            if(in_array($val["id"], $value['rader_ids']))
            {
                $radar_source_id .= $k.',';
            }
        }
        $radar_source_id = rtrim($radar_source_id,',');
        $relationRadar_text = $doc->createTextNode($radar_source_id);
        $relationRadar->appendChild($relationRadar_text);

        $receiveRange = $doc -> createElement('receiveRange');
        $receiveRange_text = $doc->createTextNode($value['receive_range']);
        $receiveRange->appendChild($receiveRange_text);

        $masterChannel = $doc -> createElement('masterChannel');
        $masterChannel_text = $doc->createTextNode($value['in_work_option']);
        $masterChannel->appendChild($masterChannel_text);

        $channelA = $doc -> createElement('channelA');
        $enabled_a = $doc -> createElement('enabled');
        if($value['enable_A'] == 0 || $value['enable_A'] == 2){
            $enabled_A = 0;
        }else{
            $enabled_A = 1;
        }
        $enabled_A = 1;
        $enabled_a_text = $doc->createTextNode($enabled_A);
        $enabled_a->appendChild($enabled_a_text);

        $sac = $doc -> createElement('sac');
        $sac_text = $doc->createTextNode($value['sac_code_A']);
        $sac->appendChild($sac_text);

        $sic = $doc -> createElement('sic');
        $sic_text = $doc->createTextNode($value['sic_code_A']);
        $sic->appendChild($sic_text);

        $dataVersion = $doc -> createElement('dataVersion');
        $dataVersion_text = $doc->createTextNode($value['data_version_a']);
        $dataVersion->appendChild($dataVersion_text);

        $channelIp = $doc -> createElement('channelIp');
        $channelIp_text = $doc->createTextNode($value['channel_ip_A']);
        $channelIp->appendChild($channelIp_text);

        $channelSendDataIp = $doc -> createElement('channelSendDataIp');
        $channelSendDataIp_text = $doc->createTextNode($value['send_ip_A']);
        $channelSendDataIp->appendChild($channelSendDataIp_text);

        $channelSendDataPort = $doc -> createElement('channelSendDataPort');
        $channelSendDataPort_text = $doc->createTextNode($value['send_port_A']);
        $channelSendDataPort->appendChild($channelSendDataPort_text);

        $interfaceIp = $doc -> createElement('interfaceIp');
        $interfaceIp_text = $doc->createTextNode($value['exchange_eth_num_A']);
        $interfaceIp->appendChild($interfaceIp_text);

        $receiveDataCast = $doc -> createElement('receiveDataCast');
        $receiveDataCast_text = $doc->createTextNode($value['cast_type_A']);
        $receiveDataCast->appendChild($receiveDataCast_text);

        $dataUpperLimit = $doc -> createElement('dataUpperLimit');
        $dataUpperLimit_text = $doc->createTextNode($value['data_upper_limit_A']);
        $dataUpperLimit->appendChild($dataUpperLimit_text);

        $trackUpperLimit = $doc -> createElement('trackUpperLimit');
        $trackUpperLimit_text = $doc->createTextNode($value['track_upper_limit_A']);
        $trackUpperLimit->appendChild($trackUpperLimit_text);

        $channelA->appendChild($enabled_a);
        $channelA->appendChild($sac);
        $channelA->appendChild($sic);

        $channelA->appendChild($dataVersion);
        $channelA->appendChild($channelIp);
        $channelA->appendChild($channelSendDataIp);
        $channelA->appendChild($channelSendDataPort);
        $channelA->appendChild($interfaceIp);
        $channelA->appendChild($receiveDataCast);
        $channelA->appendChild($dataUpperLimit);
        $channelA->appendChild($trackUpperLimit);


        $channelB = $doc -> createElement('channelB');
        $enabled_b = $doc -> createElement('enabled');
        if($value['enable_B'] == 0 || $value['enable_B'] == 2){
            $enable_B = 0;
        }else{
            $enable_B = 1;
        }
        $enabled_b_text = $doc->createTextNode($enable_B);
        $enabled_b->appendChild($enabled_b_text);

        $sac = $doc -> createElement('sac');
        $sac_text = $doc->createTextNode($value['sac_code_B']);
        $sac->appendChild($sac_text);

        $sic = $doc -> createElement('sic');
        $sic_text = $doc->createTextNode($value['sic_code_B']);
        $sic->appendChild($sic_text);

        $dataVersion = $doc -> createElement('dataVersion');
        $dataVersion_text = $doc->createTextNode($value['data_version_b']);
        $dataVersion->appendChild($dataVersion_text);

        $channelIp = $doc -> createElement('channelIp');
        $channelIp_text = $doc->createTextNode($value['channel_ip_B']);
        $channelIp->appendChild($channelIp_text);

        $channelSendDataIp = $doc -> createElement('channelSendDataIp');
        $channelSendDataIp_text = $doc->createTextNode($value['send_ip_B']);
        $channelSendDataIp->appendChild($channelSendDataIp_text);

        $channelSendDataPort = $doc -> createElement('channelSendDataPort');
        $channelSendDataPort_text = $doc->createTextNode($value['send_port_B']);
        $channelSendDataPort->appendChild($channelSendDataPort_text);

        $interfaceIp = $doc -> createElement('interfaceIp');
        $interfaceIp_text = $doc->createTextNode($value['exchange_eth_num_B']);
        $interfaceIp->appendChild($interfaceIp_text);

        $receiveDataCast = $doc -> createElement('receiveDataCast');
        $receiveDataCast_text = $doc->createTextNode($value['cast_type_B']);
        $receiveDataCast->appendChild($receiveDataCast_text);

        $dataUpperLimit = $doc -> createElement('dataUpperLimit');
        $dataUpperLimit_text = $doc->createTextNode($value['data_upper_limit_B']);
        $dataUpperLimit->appendChild($dataUpperLimit_text);

        $trackUpperLimit = $doc -> createElement('trackUpperLimit');
        $trackUpperLimit_text = $doc->createTextNode($value['track_upper_limit_B']);
        $trackUpperLimit->appendChild($trackUpperLimit_text);
        $channelB->appendChild($enabled_b);
        $channelB->appendChild($sac);
        $channelB->appendChild($sic);

        $channelB->appendChild($dataVersion);
        $channelB->appendChild($channelIp);
        $channelB->appendChild($channelSendDataIp);
        $channelB->appendChild($channelSendDataPort);
        $channelB->appendChild($interfaceIp);
        $channelB->appendChild($receiveDataCast);
        $channelB->appendChild($dataUpperLimit);
        $channelB->appendChild($trackUpperLimit);

        $station->appendChild($stationId);
        $station->appendChild($enabled);
        $station->appendChild($name);
        /*$station->appendChild($sac);
        $station->appendChild($sic);*/
        $station->appendChild($longitude);
        $station->appendChild($latitude);
        $station->appendChild($height);
        $station->appendChild($sendCycle);
        $station->appendChild($dataStation);
        $station->appendChild($beacon);
        $station->appendChild($beaconSendCycle);
        $station->appendChild($relationRadar);
        $station->appendChild($receiveRange);
        $station->appendChild($masterChannel);
        $station->appendChild($channelA);
        $station->appendChild($channelB);

        return $station;
    }

    //雷达xml
    function rader_produce_xml(){
        $raders_base = $this->Raders_config_model->get_one();
        // $data_list = $this->Raders_model->select('is_del!=1');
        $rader_kind_arr = $this->Raders_model->select('is_del=0','rader_kind','','','rader_kind');
        if(!$raders_base || empty($raders_base)){
            $this->showmessage('请先进行雷达基础参数配置');exit;
        }
        if(!$rader_kind_arr || empty($rader_kind_arr)){
            $this->showmessage('请先添加雷达基站');exit;
        }
        $data_list = array();
        foreach ($rader_kind_arr as $key => $value) {
            $data_list[$value['rader_kind']] = $this->Raders_model->select('is_del=0 and rader_kind ='.$value['rader_kind']);
        }
        $xmlpatch = RADER_XML_PATH.'varifier_config.xml';
        $doc = new DOMDocument('1.0','utf-8');
        $flag = false;
        if(file_exists($xmlpatch)) {
            //备份以前的xml版本 2017_12_1_16_48
            $flag = true;
        }
        $doc -> formatOutput = true;
        $varify = $doc -> createElement('varify');//新建节点
        //基础属性xml配置
        // $varify = $this->create_base_xml($doc,$varify,$raders_base);
        $data_list = $this->Raders_model->select('is_del=0');
        foreach ($data_list as $key => $value) {
            $resend_data_a = $this->Raders_resend_model->select(array('rader_id'=>$value['id'],'kind'=>0));
            if($resend_data_a){
                $data_list[$key]['rader_resend_a'] = $resend_data_a;
            }else{
                $data_list[$key]['rader_resend_a'] = array();
            }
            $resend_data_b = $this->Raders_resend_model->select(array('rader_id'=>$value['id'],'kind'=>1));
            if($resend_data_b){
                $data_list[$key]['rader_resend_b'] = $resend_data_b;
            }else{
                $data_list[$key]['rader_resend_b'] = array();
            }
        }
        // print_r($data_list);exit;
        $radarStation = $doc -> createElement('radarStation');
        foreach ($data_list as $key => $value) {
            $station = $doc -> createElement('station');
            //$radarStation->setAttribute('catid',$value['rader_kind']);
            $station = $this->create_target_xml($doc,$station,$key,$value);
            $radarStation->appendChild($station);
        }
        $varify->appendChild($radarStation);
        $doc->appendChild($varify);
        $xml_str =  $doc->saveXML();
        if($this->input->is_ajax_request()){

            create_dir(RADER_XML_PATH);
            $update_xml_file = 'varifier_config_'.date('Y_m_d_H_i',time()).'.xml';
            $kind_id = $this->Xml_basic_config_model->get_one(array('name'=>'雷达配置文件','is_del'=>0),'id');
            if(!$kind_id){
                exit(json_encode(array('status'=>false,'tips'=>'请先进行雷达配置文件服务器的配置')));
            }
            $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'varifier_config.xml\'','id');
            $res = $this->All_xml_model->xml_produce($xml_id_arr,$update_xml_file,'varifier_config.xml',$kind_id['id'],RADER_XML_PATH,'雷达配置文件');
            $operation_data= $this->operation_data;
            $operation_data['dateline'] = time();
            if($flag){
                $operation_data['operate_explain'] = '生成新的雷达配置文件并将原有的配置文件修改为'.$update_xml_file;
            }else{
                $operation_data['operate_explain'] = '生成新的雷达配置文件';
            }
            if($res){
                if($flag){
                    rename($xmlpatch, RADER_XML_PATH.$update_xml_file);
                }
                $doc->save($xmlpatch);
                $operation_data['is_success'] = 1;
                $operation_data['status_explain'] = '信息新增成功';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>true,'tips'=>'文件生成成功')));
            }else {
                $operation_data['is_success'] = 0;
                $operation_data['status_explain'] = '信息新增失败';
                @$this->operationLogs($operation_data);
                exit(json_encode(array('status'=>false,'tips'=>'文件生成失败')));
            }

        }else{
            $this->view('rader_produce_xml',array('xml_data'=>htmlentities($xml_str),'require_js'=>true));
        }

    }

    //生成基站的_target_xml文件
    private function create_base_xml($doc,$varify,$data_list){
        $categoryPath = $doc -> createElement('categoryPath');
        $categoryPath_text = $doc->createTextNode($data_list['category_path']);
        $categoryPath->appendChild($categoryPath_text);


        $adsbStationFile = $doc -> createElement('adsbStationFile');
        $adsbStationFile_text = $doc->createTextNode($data_list['adsbStationFile']);
        $adsbStationFile->appendChild($adsbStationFile_text);



        $recvAdsb = $doc -> createElement('recvAdsb');
        $recv_adsb_ip = $doc -> createElement('ip');
        $recv_adsb_ip_text = $doc->createTextNode($data_list['recv_adsb_ip']);
        $recv_adsb_ip->appendChild($recv_adsb_ip_text);

        $recv_adsb_port = $doc -> createElement('port');
        $recv_adsb_port_text = $doc->createTextNode($data_list['recv_adsb_port']);
        $recv_adsb_port->appendChild($recv_adsb_port_text);

        $recvAdsb->appendChild($recv_adsb_ip);
        $recvAdsb->appendChild($recv_adsb_port);

        $recvAdsb2 = $doc -> createElement('recvAdsb2');

        $recv_adsb_ip_2 = $doc -> createElement('ip');
        $recv_adsb_ip_2_text = $doc->createTextNode($data_list['recv_adsb_ip_2']);
        $recv_adsb_ip_2->appendChild($recv_adsb_ip_2_text);

        $port2 = $doc -> createElement('port');
        $port_text_2 = $doc->createTextNode($data_list['recv_adsb_port_2']);
        $port2->appendChild($port_text_2);

        $recvAdsb2->appendChild($recv_adsb_ip_2);
        $recvAdsb2->appendChild($port2);

        $categoryPath = $doc -> createElement('categoryPath');
        $categoryPath_text = $doc->createTextNode($data_list['category_path']);
        $categoryPath->appendChild($categoryPath_text);

        $log = $doc -> createElement('log');
        $path = $doc -> createElement('path');
        $path_text = $doc->createTextNode($data_list['log_path']);
        $path->appendChild($path_text);

        $level = $doc -> createElement('level');
        $level_text = $doc->createTextNode($data_list['log_devel']);
        $level->appendChild($level_text);

        $log->appendChild($path);
        $log->appendChild($level);

        $monitor = $doc -> createElement('monitor');

        $interval = $doc -> createElement('interval');
        $interval_text = $doc->createTextNode($data_list['interval']);
        $interval->appendChild($interval_text);

        $missCnt = $doc -> createElement('missCnt');
        $missCnt_text = $doc->createTextNode($data_list['missCnt']);
        $missCnt->appendChild($missCnt_text);

        $sendStatus = $doc -> createElement('sendStatus');

        $send_status_ip = $doc -> createElement('ip');
        $send_status_ip_text = $doc->createTextNode($data_list['watch_ip']);
        $send_status_ip->appendChild($send_status_ip_text);
        $send_status_port = $doc -> createElement('port');
        $send_status_port_text = $doc->createTextNode($data_list['watch_ip_port']);
        $send_status_port->appendChild($send_status_port_text);
        $sendStatus->appendChild($send_status_ip);
        $sendStatus->appendChild($send_status_port);

        $sendHeartbeat = $doc -> createElement('sendHeartbeat');

        $ip = $doc -> createElement('ip');
        $ip_text = $doc->createTextNode($data_list['send_heartbeat_ip']);
        $ip->appendChild($ip_text);

        $port = $doc -> createElement('port');
        $port_text = $doc->createTextNode($data_list['send_heartbeat_port']);
        $port->appendChild($port_text);
        $sendHeartbeat->appendChild($ip);
        $sendHeartbeat->appendChild($port);

        $recvCmd = $doc -> createElement('recvCmd');

        $ip = $doc -> createElement('ip');
        $ip_text = $doc->createTextNode($data_list['recieve_program_ip']);
        $ip->appendChild($ip_text);

        $port = $doc -> createElement('port');
        $port_text = $doc->createTextNode($data_list['recieve_program_port']);
        $port->appendChild($port_text);
        $recvCmd->appendChild($ip);
        $recvCmd->appendChild($port);

        $monitor->appendChild($interval);
        $monitor->appendChild($missCnt);
        $monitor->appendChild($sendStatus);
        $monitor->appendChild($sendHeartbeat);
        $monitor->appendChild($recvCmd);

        $matchParam = $doc -> createElement('matchParam');

        $inHeight = $doc -> createElement('inHeight');
        $inHeight_text = $doc->createTextNode($data_list['in_height']);
        $inHeight->appendChild($inHeight_text);
        $inSpeed = $doc -> createElement('inSpeed');
        $inSpeed_text = $doc->createTextNode($data_list['in_speed']);
        $inSpeed->appendChild($inSpeed_text);

        $inTime = $doc -> createElement('inTime');
        $inTime_text = $doc->createTextNode($data_list['in_time']);
        $inTime->appendChild($inTime_text);

        $inPos = $doc -> createElement('inPos');
        $inPos_text = $doc->createTextNode($data_list['in_pos']);
        $inPos->appendChild($inPos_text);

        $inAngle = $doc -> createElement('inAngle');
        $inAngle_text = $doc->createTextNode($data_list['in_angle']);
        $inAngle->appendChild($inAngle_text);

        $inCount = $doc -> createElement('inCount');
        $inCount_text = $doc->createTextNode($data_list['in_count']);
        $inCount->appendChild($inCount_text);

        $minCount = $doc -> createElement('minCount');
        $minCount_text = $doc->createTextNode($data_list['min_count']);
        $minCount->appendChild($minCount_text);

        $rate = $doc -> createElement('rate');
        $rate_text = $doc->createTextNode($data_list['rate']);
        $rate->appendChild($rate_text);

        $matchParam->appendChild($inHeight);
        $matchParam->appendChild($inSpeed);
        $matchParam->appendChild($inTime);
        $matchParam->appendChild($inPos);
        $matchParam->appendChild($inAngle);
        $matchParam->appendChild($inCount);
        $matchParam->appendChild($minCount);
        $matchParam->appendChild($rate);

        $chkDurSec = $doc -> createElement('chkDurSec');
        $chkDurSec_text = $doc->createTextNode($data_list['check_duration']);
        $chkDurSec->appendChild($chkDurSec_text);

        $sendResult = $doc -> createElement('sendResult');
        $send_result_type = $doc -> createElement('type');
        $send_result_type_text = $doc->createTextNode($data_list['send_result_type']);
        $send_result_type->appendChild($send_result_type_text);

        $send_result_ip = $doc -> createElement('ip');
        $send_result_ip_text = $doc->createTextNode($data_list['send_result_ip']);
        $send_result_ip->appendChild($send_result_ip_text);

        $send_result_port = $doc -> createElement('port');
        $send_result_port_text = $doc->createTextNode($data_list['send_result_port']);
        $send_result_port->appendChild($send_result_port_text);

        $sendResult->appendChild($send_result_type);
        $sendResult->appendChild($send_result_ip);
        $sendResult->appendChild($send_result_port);


        $recordResultDir = $doc -> createElement('recordResultDir');
        $recordResultDir_text = $doc->createTextNode($data_list['record_path']);
        $recordResultDir->appendChild($recordResultDir_text);

        $varify->appendChild($categoryPath);
        $varify->appendChild($adsbStationFile);
        $varify->appendChild($log);
        $varify->appendChild($monitor);
        //$varify->appendChild($recvCmd);
        $varify->appendChild($matchParam);
        $varify->appendChild($chkDurSec);
        $varify->appendChild($sendResult);
        $varify->appendChild($recvAdsb);
        $varify->appendChild($recvAdsb2);
        //$varify->appendChild($recordResultDir);
        return $varify;
    }

    //生成基站的_target_xml文件
    private function create_target_xml($doc,$station,$key,$v){
        // $station = $doc -> createElement('station');
        $switch = $doc -> createElement('switch');
        $switch_text = $doc->createTextNode($v['switch']);
        $switch->appendChild($switch_text);
        $sourceId = $doc -> createElement('sourceId');
        $sourceId_text = $doc->createTextNode($key);
        $sourceId->appendChild($sourceId_text);

        $catId = $doc -> createElement('catid');
        $catId_text = $doc->createTextNode($v['rader_kind']);
        $catId->appendChild($catId_text);

        $version = $doc -> createElement('version');
        $version_text = $doc->createTextNode($v['version']);
        $version->appendChild($version_text);

        $name = $doc -> createElement('name');
        $name_text = $doc->createTextNode($v['name']);
        $name->appendChild($name_text);

        $masterChannel = $doc -> createElement('masterChannel');
        $masterChannel_text = $doc->createTextNode($v['in_work_option']);
        $masterChannel->appendChild($masterChannel_text);

        $lat = $doc -> createElement('lat');
        $lat_text = $doc->createTextNode($v['latitude']);
        $lat->appendChild($lat_text);
        $lon = $doc -> createElement('lon');
        $lon_text = $doc->createTextNode($v['longtitude']);
        $lon->appendChild($lon_text);
        $range = $doc -> createElement('range');
        $range_text = $doc->createTextNode($v['range']);
        $range->appendChild($range_text);
        $height = $doc -> createElement('height');
        $height_text = $doc->createTextNode($v['height']);
        $height->appendChild($height_text);

        $channel_a = $doc->createElement('channel_a');

        $recvAddr = $doc -> createElement('recvAddr');
        $type_a = $doc -> createElement('type');
        $type_a_text = $doc->createTextNode($v['data_cast_type']);
        $type_a->appendChild($type_a_text);


        $ip = $doc -> createElement('ip');
        if($v['data_cast_type'] == 1){
            $ip_text = $doc->createTextNode($v['receive_ip']);

        }elseif($v['data_cast_type'] == 3){
            $ip_text = $doc->createTextNode($v['broad_ip_a']);
        }
        $ip->appendChild($ip_text);

        $port = $doc -> createElement('port');
        $port_text = $doc->createTextNode($v['receive_port']);
        $port->appendChild($port_text);

        $group_a = $doc -> createElement('group');
        if($v['data_cast_type'] == 2){
            $group_a_text = $doc->createTextNode($v['cast_type_ip_a']);
        }else{
            $group_a_text = $doc->createTextNode(' ');
        }
        $group_a->appendChild($group_a_text);

        $pre_abandon_bype = $doc -> createElement('pre_abandon_bype');
        $pre_abandon_bype_text = $doc->createTextNode($v['pre_abandon_bype_a']);
        $pre_abandon_bype->appendChild($pre_abandon_bype_text);

        $recvAddr->appendChild($type_a);
        $recvAddr->appendChild($ip);
        $recvAddr->appendChild($port);
        $recvAddr->appendChild($group_a);
        $recvAddr->appendChild($pre_abandon_bype);
        if(!empty($v['rader_resend_a'])){
            $reSends = $doc -> createElement('reSends');
            foreach ($v['rader_resend_a'] as $kk => $vv) {
                $addr = $doc -> createElement('addr');
                $ip = $doc -> createElement('ip');
                $ip_text = $doc->createTextNode($vv['resend_ip']);
                $ip->appendChild($ip_text);
                $port = $doc -> createElement('port');
                $port_text = $doc->createTextNode($vv['resend_port']);
                $port->appendChild($port_text);
                $type = $doc -> createElement('type');
                $type_text = $doc->createTextNode($vv['cast_type']);
                $type->appendChild($type_text);
                $group_a = $doc -> createElement('group');
                if($vv['cast_type'] == 2){
                    $group_a_text = $doc->createTextNode($vv['resend_group_ip']);
                }else{
                    $group_a_text = $doc->createTextNode(' ');
                }
                $group_a->appendChild($group_a_text);
                $addr->appendChild($ip);
                $addr->appendChild($port);
                $addr->appendChild($type);
                $addr->appendChild($group_a);
                $reSends->appendChild($addr);
            }
        }
        $channel_a->appendChild($recvAddr);
        if(!empty($v['rader_resend_a'])){
            $channel_a->appendChild($reSends);
        }

        $channel_b = $doc->createElement('channel_b');
        $recvAddr_b = $doc -> createElement('recvAddr');
        $type_b = $doc -> createElement('type');
        $type_b_text = $doc->createTextNode($v['data_cast_type_b']);
        $type_b->appendChild($type_b_text);
        $ip = $doc -> createElement('ip');
        if($v['data_cast_type'] == 1){
            $ip_text = $doc->createTextNode($v['receive_ip_b']);

        }elseif($v['data_cast_type'] == 3){
            $ip_text = $doc->createTextNode($v['broad_ip_b']);
        }
        $ip->appendChild($ip_text);
        $port = $doc -> createElement('port');
        $port_text = $doc->createTextNode($v['receive_port_b']);
        $port->appendChild($port_text);
        $group_b = $doc -> createElement('group');
        if($v['data_cast_type'] == 2){
            $group_b_text = $doc->createTextNode($v['cast_type_ip_b']);
        }else{
            $group_b_text = $doc->createTextNode(' ');
        }
        $group_b->appendChild($group_b_text);
        $pre_abandon_bype = $doc -> createElement('pre_abandon_bype');
        $pre_abandon_bype_text = $doc->createTextNode($v['pre_abandon_bype_b']);
        $pre_abandon_bype->appendChild($pre_abandon_bype_text);

        $recvAddr_b->appendChild($type_b);
        $recvAddr_b->appendChild($ip);
        $recvAddr_b->appendChild($port);
        $recvAddr_b->appendChild($group_b);
        $recvAddr_b->appendChild($pre_abandon_bype);

        if(!empty($v['rader_resend_b'])){
            $reSends = $doc -> createElement('reSends');
            foreach ($v['rader_resend_b'] as $kk => $vv) {
                $addr = $doc -> createElement('addr');

                $ip = $doc -> createElement('ip');
                $ip_text = $doc->createTextNode($vv['resend_ip']);
                $ip->appendChild($ip_text);
                $port = $doc -> createElement('port');
                $port_text = $doc->createTextNode($vv['resend_port']);
                $port->appendChild($port_text);
                $type = $doc -> createElement('type');
                $type_text = $doc->createTextNode($vv['cast_type']);
                $type->appendChild($type_text);
                $group_b = $doc -> createElement('group');
                if($vv['cast_type'] == 2){
                    $group_b_text = $doc->createTextNode($vv['resend_group_ip']);
                }else{
                    $group_b_text = $doc->createTextNode(' ');
                }
                $group_b->appendChild($group_b_text);
                $addr->appendChild($ip);
                $addr->appendChild($port);
                $addr->appendChild($type);
                $addr->appendChild($group_b);
                $reSends->appendChild($addr);
            }
        }
        $channel_b->appendChild($recvAddr_b);
        if(!empty($v['rader_resend_b'])){
            $channel_b->appendChild($reSends);
        }

        $station->appendChild($switch);
        $station->appendChild($sourceId);
        $station->appendChild($catId);
        $station->appendChild($version);
        $station->appendChild($name);
        $station->appendChild($masterChannel);
        $station->appendChild($lat);
        $station->appendChild($lon);
        $station->appendChild($range);
        $station->appendChild($height);
        $station->appendChild($channel_a);
        $station->appendChild($channel_b);
        // $radarStation->appendChild($station);

        return $station;
    }


    //预告警声音关闭
    public function cat_switch($id,$val,$kind){
        if($kind == 1){
            $cat_name = 'cat023_switch';
        }elseif($kind == 2){
            $cat_name = 'cat247_switch';

        }
        $res = $this->Station_model->update(array($cat_name=>$val),array('station_id'=>$id));
        if($res){
            $this->Station_model->_cache_station();
            echo json_encode(array('status'=>true,'tips'=>'操作成功'));exit;
        }else{
            echo json_encode(array('status'=>false,'tips'=>'操作失败'));
        }
        // echo json_encode(array('status'=>false,'tips'=>'操作失败'));
    }
}