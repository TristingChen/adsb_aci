<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class AreaManage extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Area_model','Polygons_model'));
        $this->load->helper(array('member','auto_codeIgniter','string'));
    }

    function  lists($page_no=0)
    {   
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "  name like '%{$keyword}%'";
        }
        $where = implode('and',$where_arr);
        $data_list = $this->Area_model->listinfo($where,'*',$orderby , $page_no, $this->Area_model->page_size,'',$this->Area_model->page_size,page_list_url('adminpanel/bypassManage/lists',true));
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Area_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'区域名不得为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'区域名不得为空')));
            /* $_arr['height'] = isset($_POST["height"])?trim(safe_replace($_POST["height"])):exit(json_encode(array('status'=>false,'tips'=>'高度不得为空')));
            if($_arr['height']=='')exit(json_encode(array('status'=>false,'tips'=>'高度不得为空')));*/
            if(@$_POST["polygons_ids"]){
                    $_arr['polygons_ids'] = implode(',', $_POST["polygons_ids"]);
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'请选择多边形')));
            }
          
            $_arr['dateline'] = time();
            $new_id = $this->Area_model->insert($_arr);
            if($new_id)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $polygons_data = $this->Polygons_model->select();
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_info'=>$this->Area_model->default_info(),'polygons_data'=>$polygons_data));
        }
    }

    function edit($id=0)
    {
        $id = intval($id);
        $data_info =$this->Area_model->get_one(array('id'=>$id));
        if($this->input->is_ajax_request())
        {
             //接收POST参数
             $_arr['name'] = isset($_POST["name"])?trim(safe_replace($_POST["name"])):exit(json_encode(array('status'=>false,'tips'=>'区域名不得为空')));
            if($_arr['name']=='')exit(json_encode(array('status'=>false,'tips'=>'区域名不得为空')));
             /*$_arr['height'] = isset($_POST["height"])?trim(safe_replace($_POST["height"])):exit(json_encode(array('status'=>false,'tips'=>'高度不得为空')));
            if($_arr['height']=='')exit(json_encode(array('status'=>false,'tips'=>'高度不得为空')));*/
            if(@$_POST["polygons_ids"]){
                    $_arr['polygons_ids'] = implode(',', $_POST["polygons_ids"]);
            }else{
                exit(json_encode(array('status'=>false,'tips'=>'请选择多边形')));
            }
            $_arr['dateline'] = time();
            $status = $this->Area_model->update($_arr,array('id'=>$id));
            if($status)
            {
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $polygons_data = $this->Polygons_model->select();
            $data_info['polygons_ids'] = explode(',', $data_info['polygons_ids']);
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info,'polygons_data'=>$polygons_data,'id'=>$id));
        }
    }

         //删除
     function delete($id){
        $id = intval($id);
        $del_res = $this->Area_model->delete('id='.$id);
        if($del_res){
              $this->showmessage('删除成功');
        }else{
              $this->showmessage('删除失败');
        }
     }


}
