<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Station extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Station_model','Eth_manage_model','Recv_data_model','Send_data_model','Common_config_model','Rules_model'));
    }

    function lists($page_no=1)
    {
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "concat(station_name,sic,sac,station_ip_A,station_ip_B) like '%{$keyword}%'";
        }
        $where = implode(" and ",$where_arr);
        $data_list = $this->Station_model->listinfo($where,'*',$orderby , $page_no, $this->Station_model->page_size,'',$this->Station_model->page_size,page_list_url('adminpanel/station/list',true));
        foreach($data_list as $k=>$v){
            $data_list[$k]["station_lng"] = $data_list[$k]["station_lng_degree"]."°".$data_list[$k]["station_lng_minute"]."′".$data_list[$k]["station_lng_second"].'″';
            $data_list[$k]["station_lat"] = $data_list[$k]["station_lat_degree"]."°".$data_list[$k]["station_lat_minute"]."′".$data_list[$k]["station_lat_second"].'″';
        }

        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Station_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    /**
     * 新增基站
     */
    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['station_name'] = isset($_POST["station_name"])?trim(safe_replace($_POST["station_name"])):exit(json_encode(array('status'=>false,'tips'=>'基站名称不能为空')));
            if($_arr['station_name']=='')exit(json_encode(array('status'=>false,'tips'=>'基站名称名称不能为空')));
            $_arr['data_version'] = isset($_POST["data_version"])?trim(safe_replace($_POST["data_version"])):exit(json_encode(array('status'=>false,'tips'=>'数据版本不能为空')));
            if($_arr['data_version']=='')exit(json_encode(array('status'=>false,'tips'=>'网口编号不能为空')));
            $_arr['sac_code'] = isset($_POST["sac_code"])?trim(safe_replace($_POST["sac_code"])):exit(json_encode(array('status'=>false,'tips'=>'SAC码不能为空')));
            if($_arr['sac_code']=='')exit(json_encode(array('status'=>false,'tips'=>'sac码不能为空')));
            $_arr['sic_code'] = isset($_POST["sic_code"])?trim(safe_replace($_POST["sic_code"])):exit(json_encode(array('status'=>false,'tips'=>'SIC码不能为空')));
            if($_arr['sic_code']=='')exit(json_encode(array('status'=>false,'tips'=>'sic码不能为空')));
            $_arr["station_height"] = isset($_POST["station_height"])?trim(safe_replace($_POST["station_height"])):"";
            $_arr["station_status"] = isset($_POST["station_status"])?trim(safe_replace($_POST["station_status"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            if($_arr["station_status"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            $_arr["in_work_option"] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            if($_arr["in_work_option"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            $_arr["station_lng_degree"] = isset($_POST["station_lng_degree"])?trim(safe_replace($_POST["station_lng_degree"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            if($_arr["station_lng_degree"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            $_arr["station_lng_minute"] = isset($_POST["station_lng_minute"])?trim(safe_replace($_POST["station_lng_minute"])):"";
            $_arr["station_lng_second"] = isset($_POST["station_lng_second"])?trim(safe_replace($_POST["station_lng_second"])):"";
            $_arr["station_lat_degree"] = isset($_POST["station_lat_degree"])?trim(safe_replace($_POST["station_lat_degree"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站纬度')));
            if($_arr["station_lat_degree"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站纬度')));
            $_arr["station_lat_minute"] = isset($_POST["station_lat_minute"])?trim(safe_replace($_POST["station_lat_minute"])):"";
            $_arr["station_lat_second"] = isset($_POST["station_lat_second"])?trim(safe_replace($_POST["station_lat_second"])):"";
            $_arr["station_ip_A"] = isset($_POST["station_ip_A"])?trim(safe_replace($_POST["station_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站A网IP')));
            if($_arr["station_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站A网IP')));
            $_arr["station_ip_B"] = isset($_POST["station_ip_B"])?trim(safe_replace($_POST["station_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站B网IP')));
            if($_arr["station_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站B网IP')));
            $_arr["cast_type_A"] = isset($_POST["cast_type_A"])?trim(safe_replace($_POST["cast_type_A"])):"";
            $_arr["send_ip_A"] = isset($_POST["send_ip_A"])?trim(safe_replace($_POST["send_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_arr["send_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_arr["send_port_A"] = isset($_POST["send_port_A"])?trim(safe_replace($_POST["send_port_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_arr["send_port_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_arr["exchange_eth_id_A"] = isset($_POST["exchange_eth_id_A"])?trim(safe_replace($_POST["exchange_eth_id_A"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            if($_arr["exchange_eth_id_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            $channel_A = isset($_POST["channel_status_A"])?trim(safe_replace($_POST["channel_status_A"])):"";
            $_arr["channel_status_A"] = ($channel_A == 1)?"ATTACH":"DETACH";
            $_arr["cast_type_B"] = isset($_POST["cast_type_B"])?trim(safe_replace($_POST["cast_type_B"])):"";
            $_arr["send_ip_B"] = isset($_POST["send_ip_B"])?trim(safe_replace($_POST["send_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_arr["send_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_arr["send_port_B"] = isset($_POST["send_port_B"])?trim(safe_replace($_POST["send_port_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_arr["send_port_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_arr["exchange_eth_id_B"] = isset($_POST["exchange_eth_id_B"])?trim(safe_replace($_POST["exchange_eth_id_B"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            if($_arr["exchange_eth_id_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            $channel_B = isset($_POST["channel_status_B"])?trim(safe_replace($_POST["channel_status_B"])):"";
            $_arr["channel_status_B"] = ($channel_B == 1)?"ATTACH":"DETACH";

            $new_id = $this->Station_model->insert($_arr);


            if($new_id)
            {
                $this->insert_recv_data($_arr,1,$new_id);    //新增交换模块A网数据接收
                $this->insert_recv_data($_arr,2,$new_id);    //新增交换模块B网数据接收
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_info'=>$this->Station_model->default_info()));
        }

    }

    /**
     * 新增交换模块接收基站数据
     * @param $_data 基站数据
     * @param $network_type 所属网络 1、A网 2、B网
     * @param $station_id 基站ID
     */
    function insert_recv_data($_data,$network_type,$station_id)
    {
        $network_type_name = (intval($network_type) == 1)?"A":"B";
        $srcid_1 = $this->insert_send_data($_data,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&".$network_type_name,$station_id,1); //新增交换模块发送到A或者B网数据
        $srcid_2 = $this->insert_send_data($_data,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&S",$station_id,1); //新增交换模块发送到S网数据
        $src_str_a = $srcid_1.";".$srcid_2.";";
        $_recv_arr_a["recv_type"] = $_data["cast_type_A"];
        switch ($_recv_arr_a["recv_type"]){
            case 1:
                $_recv_arr_a["recv_num"] = 10000 + $this->get_recv_cast_count(1,$network_type);
                break;
            case 2:
                $_recv_arr_a["recv_num"] = 20000 + $this->get_recv_cast_count(2,$network_type);
                break;
            case 3:
                $_recv_arr_a["recv_num"] = 30000 + $this->get_recv_cast_count(3,$network_type);
                break;
            default;
        }
        $_recv_arr_a["recv_ip"] = $_data["send_ip_A"];
        $_recv_arr_a["recv_port"] = $_data["send_port_A"];
        $eth_id_a = $_data["exchange_eth_id_A"];
        $eth_ip_a =$this->get_eth_ip($eth_id_a);
        $_recv_arr_a["recv_interface"] = $eth_ip_a;
        $_recv_arr_a["send_ids"] = $src_str_a;
        $_recv_arr_a["network_type"] = $network_type;
        $_recv_arr_a["station_id"] = $station_id;
        $_recv_arr_a["channel"] = "A";
        $_recv_arr_a['station_name'] = $_data['station_name']."_A";
        $new_id_a = $this->Recv_data_model->insert($_recv_arr_a);

        $srcid_3 = $this->insert_send_data($_data,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&".$network_type_name,$station_id,2);
        $srcid_4 = $this->insert_send_data($_data,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&S",$station_id,2);
        $src_str_b = $srcid_3.";".$srcid_4.";";
        $_recv_arr_b["recv_type"] = $_data["cast_type_B"];
        switch ($_recv_arr_b["recv_type"]){
            case 1:
                $_recv_arr_b["recv_num"] = 10000 + $this->get_recv_cast_count(1,$network_type);
                break;
            case 2:
                $_recv_arr_b["recv_num"] = 20000 + $this->get_recv_cast_count(2,$network_type);
                break;
            case 3:
                $_recv_arr_b["recv_num"] = 30000 + $this->get_recv_cast_count(3,$network_type);
                break;
            default;
        }
        $_recv_arr_b["recv_ip"] = $_data["send_ip_B"];
        $_recv_arr_b["recv_port"] = $_data["send_port_B"];
        $eth_id_b = $_data["exchange_eth_id_B"];
        $eth_ip_b =$this->get_eth_ip($eth_id_b);
        $_recv_arr_b["recv_interface"] = $eth_ip_b;
        $_recv_arr_b["send_ids"] = $src_str_b;
        $_recv_arr_b["network_type"] = $network_type;
        $_recv_arr_b["station_id"] = $station_id;
        $_recv_arr_b["channel"] = "B";
        $_recv_arr_b['station_name'] = $_data['station_name']."_B";
        $new_id_b = $this->Recv_data_model->insert($_recv_arr_b);
    }

    function get_recv_cast_count($recv_cast_type,$network_type)
    {
        $count = $this->Recv_data_model->count(array('recv_type'=>$recv_cast_type,'network_type'=>$network_type));
        return $count;
    }

    function get_send_cast_coun($send_cast_type,$network_type)
    {
        $count = $this->Send_data_model->count(array('send_type'=>$send_cast_type,'network_type'=>$network_type));
        return $count;
    }

    function get_eth_ip($eth_id)
    {
        $id = intval($eth_id);
        $ethInfo =$this->Eth_manage_model->get_one(array('eth_id'=>$id));
        $eth_ip = $ethInfo["eth_ip"];
        return $eth_ip;
    }

    /**
     * 新增数据站内部模块数据发送
     * @param $_data 基站数据
     * @param $cast_type UDP数据包发送类型 1、单播 2、组播 3、广播，默认为组播发送
     * @param $network_type 所属网络 1、A网 2、B网
     * @param $rule 内部数据转发规则，指定各个模块服务器接收发送数据网口
     * @param $station_id 基站ID
     * @param $channel 通道
     * @return int
     */
    function insert_send_data($_data,$cast_type,$network_type,$rule,$station_id,$channel)
    {
        $MCastIp = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
        $_arr_send["send_ip"] = $MCastIp["value"];
        $send_num = 0;
        $count = $this->get_send_cast_coun($cast_type,$network_type);
        switch ($cast_type){
            case 1:
                $send_num = 40000 + $count;
                break;
            case 2:
                $send_num = 50000 + $count;
                break;
            case 3:
                $send_num = 60000 + $count;
                break;
            default;
        }
        $_arr_send["send_num"] = $send_num;
        $ruleInfo =$this->Rules_model->get_one(array('rules'=>$rule));
        $eth_id = $ruleInfo["eth_id"];

        $_arr_send["send_interface"] = $this->get_eth_ip($eth_id);
        if($channel == 1){
            $_arr_send["send_port"] = $_data["send_port_A"] + 1000;
        }else{
            $_arr_send["send_port"] = $_data["send_port_B"] + 2000;
        }
        $_arr_send["note"] = $rule;
        $TTL = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "TTL"');
        $_arr_send["ttl"] = $TTL["value"];
        $IsLoop = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "IsLoop"');
        $_arr_send["is_loop"] = $IsLoop["value"];
        $_arr_send["network_type"] = $network_type;
        $_arr_send["send_type"] = $cast_type;
        $_arr_send["station_id"] = $station_id;
        $new_id = $this->Send_data_model->insert($_arr_send);
        return $send_num;
    }

    /**
     * 修改数据站接受基站数据
     * @param $_data
     * @param $station_id
     * @param $network_type
     */
    function update_recv_data($_data,$station_id,$network_type)
    {
        $network_type_name = (intval($network_type) == 1)?"A":"B";
        $this->update_send_data($_data,$station_id,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&".$network_type_name,1); //修改交换模块发送到A或者B网数据
        $this->update_send_data($_data,$station_id,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&S",1); //修改交换模块发送到S网数据
        $_recv_arr_a["recv_type"] = $_data["cast_type_A"];
        switch ($_recv_arr_a["recv_type"]){
            case 1:
                $_recv_arr_a["recv_num"] = 10000 + $this->get_recv_cast_count(1,$network_type);
                break;
            case 2:
                $_recv_arr_a["recv_num"] = 20000 + $this->get_recv_cast_count(2,$network_type);
                break;
            case 3:
                $_recv_arr_a["recv_num"] = 30000 + $this->get_recv_cast_count(3,$network_type);
                break;
            default;
        }
        $_recv_arr_a["recv_ip"] = $_data["send_ip_A"];
        $_recv_arr_a["recv_port"] = $_data["send_port_A"];
        $eth_id_a = $_data["exchange_eth_id_A"];
        $eth_ip_a =$this->get_eth_ip($eth_id_a);
        $_recv_arr_a["recv_interface"] = $eth_ip_a;
        $_recv_arr_a["network_type"] = $network_type;
        $_recv_arr_a['note'] = $_data["station_name"]."_A";
        $status = $this->Recv_data_model->update($_recv_arr_a,array('station_id'=>$station_id,'channel = "A"',"network_type"=>$network_type));

        $this->update_send_data($_data,$station_id,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&".$network_type_name,2);
        $this->update_send_data($_data,$station_id,2,$network_type,"EXCHANGE-".$network_type_name."_".$network_type_name."&S",2);
        $_recv_arr_b["recv_type"] = $_data["cast_type_B"];
        switch ($_recv_arr_b["recv_type"]){
            case 1:
                $_recv_arr_b["recv_num"] = 10000 + $this->get_recv_cast_count(1,$network_type);
                break;
            case 2:
                $_recv_arr_b["recv_num"] = 20000 + $this->get_recv_cast_count(2,$network_type);
                break;
            case 3:
                $_recv_arr_b["recv_num"] = 30000 + $this->get_recv_cast_count(3,$network_type);
                break;
            default;
        }
        $_recv_arr_b["recv_ip"] = $_data["send_ip_B"];
        $_recv_arr_b["recv_port"] = $_data["send_port_B"];
        $eth_id_b = $_data["exchange_eth_id_B"];
        $eth_ip_b =$this->get_eth_ip($eth_id_b);
        $_recv_arr_b["recv_interface"] = $eth_ip_b;
        $_recv_arr_b["network_type"] = $network_type;
        $_recv_arr_b["station_id"] = $station_id;
        $_recv_arr_b['note'] = $_data["station_name"]."_B";
        $status = $this->Recv_data_model->update($_recv_arr_a,array('station_id'=>$station_id,'channel'=>"B","network_type"=>$network_type));
    }

    /**
     * 修改数据站内部数据发送
     * @param $_data 基站数据
     * @param $station_id 基站id
     * @param $cast_type UDP发送方式
     * @param $network_type 所属网 1、A网  2、B网
     * @param $rule 指定数据站内部数据发送网口
     * @param $channel 通道 1、A  2、B
     */
    function update_send_data($_data,$station_id,$cast_type,$network_type,$rule,$channel)
    {
        $MCastIp = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "MCastIp"');
        $_arr_send["send_ip"] = $MCastIp["value"];
        $send_num = 0;
        $count = $this->get_send_cast_coun($cast_type,$network_type);
        switch ($cast_type){
            case 1:
                $send_num = 40000 + $count;
                break;
            case 2:
                $send_num = 50000 + $count;
                break;
            case 3:
                $send_num = 60000 + $count;
                break;
            default;
        }
        $_arr_send["send_num"] = $send_num;
        $ruleInfo =$this->Rules_model->get_one(array('rules'=>$rule));
        $eth_id = $ruleInfo["eth_id"];

        $_arr_send["send_interface"] = $this->get_eth_ip($eth_id);
        if($channel == 1){
            $_arr_send["send_port"] = $_data["send_port_A"] + 1000;
        }else{
            $_arr_send["send_port"] = $_data["send_port_B"] + 2000;
        }
        $_arr_send["note"] = $rule;
        $TTL = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "TTL"');
        $_arr_send["ttl"] = $TTL["value"];
        $IsLoop = $this->Common_config_model->get_one('network_type = '.$network_type.' and code = "IsLoop"');
        $_arr_send["is_loop"] = $IsLoop["value"];
        $_arr_send["network_type"] = $network_type;
        $_arr_send["send_type"] = $cast_type;
        $_arr_send["station_id"] = $station_id;
        $this->Send_data_model->update($_arr_send,array('station_id'=>$station_id,"network_type"=>$network_type,'note'=>'"'.$rule.'"'));
    }

    function delete_recv_data($station_id)
    {
        $data_info =$this->Recv_data_model->get_one(array('station_id'=>$station_id));
        if($data_info){
            $status = $this->Recv_data_model->delete(array('station_id'=>$station_id));
        }
    }

    function delete_send_data($station_id)
    {
        $data_info =$this->Send_data_model->get_one(array('station_id'=>$station_id));
        if($data_info){
            $status = $this->Send_data_model->delete(array('station_id'=>$station_id));
        }
    }

    function edit($id)
    {
        $id = intval($id);
        $data_info =$this->Station_model->get_one(array('station_id'=>$id));
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['station_name'] = isset($_POST["station_name"])?trim(safe_replace($_POST["station_name"])):exit(json_encode(array('status'=>false,'tips'=>'基站名称不能为空')));
            if($_arr['station_name']=='')exit(json_encode(array('status'=>false,'tips'=>'基站名称名称不能为空')));
            $_arr['data_version'] = isset($_POST["data_version"])?trim(safe_replace($_POST["data_version"])):exit(json_encode(array('status'=>false,'tips'=>'数据版本不能为空')));
            if($_arr['data_version']=='')exit(json_encode(array('status'=>false,'tips'=>'网口编号不能为空')));
            $_arr['sac_code'] = isset($_POST["sac_code"])?trim(safe_replace($_POST["sac_code"])):exit(json_encode(array('status'=>false,'tips'=>'SAC码不能为空')));
            if($_arr['sac_code']=='')exit(json_encode(array('status'=>false,'tips'=>'sac码不能为空')));
            $_arr['sic_code'] = isset($_POST["sic_code"])?trim(safe_replace($_POST["sic_code"])):exit(json_encode(array('status'=>false,'tips'=>'SIC码不能为空')));
            if($_arr['sic_code']=='')exit(json_encode(array('status'=>false,'tips'=>'sic码不能为空')));
            $_arr["station_height"] = isset($_POST["station_height"])?trim(safe_replace($_POST["station_height"])):"";
            $_arr["station_status"] = isset($_POST["station_status"])?trim(safe_replace($_POST["station_status"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            if($_arr["station_status"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站状态')));
            $_arr["in_work_option"] = isset($_POST["in_work_option"])?trim(safe_replace($_POST["in_work_option"])):exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            if($_arr["in_work_option"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择基站通道')));
            $_arr["station_lng_degree"] = isset($_POST["station_lng_degree"])?trim(safe_replace($_POST["station_lng_degree"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            if($_arr["station_lng_degree"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站经度')));
            $_arr["station_lng_minute"] = isset($_POST["station_lng_minute"])?trim(safe_replace($_POST["station_lng_minute"])):"";
            $_arr["station_lng_second"] = isset($_POST["station_lng_second"])?trim(safe_replace($_POST["station_lng_second"])):"";
            $_arr["station_lat_degree"] = isset($_POST["station_lat_degree"])?trim(safe_replace($_POST["station_lat_degree"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站纬度')));
            if($_arr["station_lat_degree"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站纬度')));
            $_arr["station_lat_minute"] = isset($_POST["station_lat_minute"])?trim(safe_replace($_POST["station_lat_minute"])):"";
            $_arr["station_lat_second"] = isset($_POST["station_lat_second"])?trim(safe_replace($_POST["station_lat_second"])):"";
            $_arr["station_ip_A"] = isset($_POST["station_ip_A"])?trim(safe_replace($_POST["station_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站A网IP')));
            if($_arr["station_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站A网IP')));
            $_arr["station_ip_B"] = isset($_POST["station_ip_B"])?trim(safe_replace($_POST["station_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'请输入基站B网IP')));
            if($_arr["station_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请输入基站B网IP')));
            $_arr["cast_type_A"] = isset($_POST["cast_type_A"])?trim(safe_replace($_POST["cast_type_A"])):"";
            $_arr["send_ip_A"] = isset($_POST["send_ip_A"])?trim(safe_replace($_POST["send_ip_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_arr["send_ip_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_arr["send_port_A"] = isset($_POST["send_port_A"])?trim(safe_replace($_POST["send_port_A"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_arr["send_port_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_arr["exchange_eth_id_A"] = isset($_POST["exchange_eth_id_A"])?trim(safe_replace($_POST["exchange_eth_id_A"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            if($_arr["exchange_eth_id_A"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器A路数据接收网口')));
            $channel_A = isset($_POST["channel_status_A"])?trim(safe_replace($_POST["channel_status_A"])):"";
            $_arr["channel_status_A"] = ($channel_A == 1)?"ATTACH":"DETACH";
            $_arr["cast_type_B"] = isset($_POST["cast_type_B"])?trim(safe_replace($_POST["cast_type_B"])):"";
            $_arr["send_ip_B"] = isset($_POST["send_ip_B"])?trim(safe_replace($_POST["send_ip_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            if($_arr["send_ip_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送IP不能为空')));
            $_arr["send_port_B"] = isset($_POST["send_port_B"])?trim(safe_replace($_POST["send_port_B"])):exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            if($_arr["send_port_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'基站数据发送端口不能为空')));
            $_arr["exchange_eth_id_B"] = isset($_POST["exchange_eth_id_B"])?trim(safe_replace($_POST["exchange_eth_id_B"])):exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            if($_arr["exchange_eth_id_B"] == '')exit(json_encode(array('status'=>false,'tips'=>'请选择交换服务器B路数据接收网口')));
            $channel_B = isset($_POST["channel_status_B"])?trim(safe_replace($_POST["channel_status_B"])):"";
            $_arr["channel_status_B"] = ($channel_B == 1)?"ATTACH":"DETACH";

            $status = $this->Station_model->update($_arr,array('station_id'=>$id));
            if($status)
            {
                $this->update_recv_data($_arr,$id,1);
                $this->update_recv_data($_arr,$id,2);
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info));
        }
    }

    function delete($id)
    {
        $id = intval($id);
        $data_info =$this->Station_model->get_one(array('station_id'=>$id));
        if(!$data_info)$this->showmessage('信息不存在');

        $status = $this->Station_model->delete(array('station_id'=>$id));
        if($status)
        {
            $this->delete_recv_data($id);
            $this->delete_send_data($id);
            $this->showmessage('删除成功');
        }else{
            $this->showmessage('删除失败');
        }
    }

    function check_station_name($station_name='')
    {
        if(isset($_POST['station_name'])&&$station_name==''){
            $username = trim(safe_replace($_POST['station_name']));
            $c = $this->Station_model->count(array('station_name'=>$username));
            echo  $c>0?'{"valid":false}':'{"valid":true}';
        }else{
            $station_name = trim(safe_replace($station_name));
            $c = $this->Station_model->count(array('station_name'=>$station_name));
            return $c>0?true:false;
        }
    }

}