<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-10
 * Time: 上午9:01
 * To change this template use File | Settings | File Templates.
 */
class StationWarningLogs extends Admin_Controller {
    function __construct()
    {
        // date_default_timezone_set("UTC");
        parent::__construct();
        $this->load->model(array('Station_model','Station_warning_logs_model','Station_model'));
    }

    function lists($page_no=1)
    {
         $page_no = max(intval($page_no),1);
        $keyword= "";
        $where = '1= 1';
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['station_id'])?safe_replace(trim($_GET['station_id'])):'';
            if($keyword!="") $where .= " and t_sys_station_warning_logs.station_id=".$keyword;
            $start_time = strtotime($this->input->get('start_time'));
            $end_time = strtotime($this->input->get('end_time'));
            if($start_time){
                $where .= " and t_sys_station_warning_logs.dateline >=".$start_time;
            }
            if($end_time){
                $where .= " and t_sys_station_warning_logs.dateline <=".$end_time;
            }
        }
        // var_dump($where);exit;
        $data_list = $this->Station_warning_logs_model->tables_listinfo($where,'t_sys_station.station_name,t_sys_station_warning_logs.*','t_sys_station_warning_logs.dateline desc' , $page_no, $this->Station_warning_logs_model->page_size,'',$this->Station_warning_logs_model->page_size,page_list_url('adminpanel/stationWarningLogs/lists',true));
        $station_list = $this->Station_model->select('is_del = 0','station_id,station_name');
        $this->view('lists',array('require_js'=>true,'data_list'=>$data_list,'pages' =>$this->Station_warning_logs_model->pages,'station_list'=>$station_list));   
    }



}