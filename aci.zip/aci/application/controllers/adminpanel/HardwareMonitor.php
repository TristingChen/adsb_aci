<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-16
 * Time: 下午2:54
 * To change this template use File | Settings | File Templates.
 */
class HardwareMonitor extends Admin_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Hardware_model','Hardware_type_model','Hardware_eth_model'));
        $this->load->helper(array('member','auto_codeIgniter','string','snmp'));
    }

    function  index()
    {
        $this->view('index',array('require_js'=>true));
    }

    function lists($page_no=1)
    {
        $page_no = max(intval($page_no),1);
        $where_arr = array();
        $orderby = $keyword= "";
        if (isset($_GET['dosubmit'])) {
            $keyword =isset($_GET['keyword'])?safe_replace(trim($_GET['keyword'])):'';
            if($keyword!="") $where_arr[] = "concat(hardware_type_id,hardware_name,position,factory) like '%{$keyword}%'";
        }
        $where = implode(" and ",$where_arr);
        $data_list = $this->Hardware_model->listinfo($where,'*',$orderby , $page_no, $this->Hardware_model->page_size,'',$this->Hardware_model->page_size,page_list_url('adminpanel/hardwareMonitor/lists',true));
        $this->_cache_hardware();
        $this->view('lists',array('data_list'=>$data_list,'pages'=>$this->Hardware_model->pages,'keyword'=>$keyword,'require_js'=>true));
    }

    function run_info()
    {
        $data_list = monitor_list();

        $this->view('run_info',array('data_list'=>$data_list,'require_js'=>true));
    }

    /**
     * 新增数据
     * @param AJAX POST
     * @return void
     */
    function add()
    {
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            //接收POST参数
            $_arr['hardware_name'] = isset($_POST["hardware_name"])?trim(safe_replace($_POST["hardware_name"])):exit(json_encode(array('status'=>false,'tips'=>'设备名称不能为空')));
            if($_arr['hardware_name']=='')exit(json_encode(array('status'=>false,'tips'=>'设备名称不能为空')));
            $_arr['hardware_other_name'] = isset($_POST["hardware_other_name"])?trim(safe_replace($_POST["hardware_other_name"])):exit(json_encode(array('status'=>false,'tips'=>'设备别名不能为空')));
            if($_arr['hardware_other_name']=='')exit(json_encode(array('status'=>false,'tips'=>'设备别名不能为空')));
            $_arr['hardware_type_id'] = isset($_POST["hardware_type_id"])?trim(safe_replace($_POST["hardware_type_id"])):exit(json_encode(array('status'=>false,'tips'=>'设备类型不能为空')));
            if($_arr['hardware_type_id']=='')exit(json_encode(array('status'=>false,'tips'=>'设备类型不能为空')));
            // $_arr['eth_num'] = isset($_POST["eth_num"])?trim(safe_replace($_POST["eth_num"])):'';
            $_arr['cpu_num'] = isset($_POST["cpu_num"])?trim(safe_replace($_POST["cpu_num"])):'';
            $_arr['disk_size'] = isset($_POST["disk_size"])?trim(safe_replace($_POST["disk_size"])):'';
            $_arr['memory_size'] = isset($_POST["memory_size"])?trim(safe_replace($_POST["memory_size"])):'';
            $_arr['position'] = isset($_POST["position"])?trim(safe_replace($_POST["position"])):'';
            $_arr['factory'] = isset($_POST["factory"])?trim(safe_replace($_POST["factory"])):'';
            $_arr['is_monitor'] = isset($_POST["is_monitor"])?trim(safe_replace($_POST["is_monitor"])):'0';
            /*$_arr['monitor_ip'] = '';
            $_arr['ftp_name'] = '';
            $_arr['ftp_code'] = '';
            $_arr['ftp_dir'] = '';

            if($_arr['is_monitor'] !=0){
                $_arr['monitor_ip'] = isset($_POST["monitor_ip"])?trim(safe_replace($_POST["monitor_ip"])):exit(json_encode(array('status'=>false,'tips'=>'监控IP不能为空')));
                if($_arr['monitor_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'监控IP不能为空')));
                if($_arr['hardware_type_id'] == 2){
                    $_arr['ftp_name'] = isset($_POST["ftp_name"])?trim(safe_replace($_POST["ftp_name"])):exit(json_encode(array('status'=>false,'tips'=>'ftp名称不能为空')));
                    if($_arr['ftp_name']=='')exit(json_encode(array('status'=>false,'tips'=>'ftp名称不能为空')));
                    $_arr['ftp_code'] = isset($_POST["ftp_code"])?trim(safe_replace($_POST["ftp_code"])):exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                    if($_arr['ftp_code']=='')exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                     $ftp_code2 = isset($_POST["ftp_code2"])?trim(safe_replace($_POST["ftp_code2"])):exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                    if($ftp_code2=='')exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                    if($_arr['ftp_code'] != $ftp_code2){
                        exit(json_encode(array('status'=>false,'tips'=>'两次ftp密码不一样')));
                    }
                     $_arr['ftp_code'] = check_encrypt($_arr['ftp_code'],'E',FTP_SIGIN);
                    $_arr['ftp_dir'] = isset($_POST["ftp_dir"])?trim(safe_replace($_POST["ftp_dir"])):exit(json_encode(array('status'=>false,'tips'=>'ftp名称不能为空')));
                    if($_arr['ftp_dir']=='')exit(json_encode(array('status'=>false,'tips'=>'ftp文件路径不能为空'))); 
                }
            }*/
            $new_id = $this->Hardware_model->insert($_arr);
            if($new_id)
            {
                $this->_cache_hardware();
                exit(json_encode(array('status'=>true,'tips'=>'信息新增成功','new_id'=>$new_id)));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息新增失败','new_id'=>0)));
            }
        }else
        {
            $this->view('edit',array('is_edit'=>false,'require_js'=>true,'data_info'=>$this->Hardware_model->default_info()));
        }
    }

    /**
     * 删除单个数据
     * @param int id
     * @return void
     */
    function delete_one($id=0)
    {
        $id = intval($id);
        $data_info =$this->Hardware_model->get_one(array('hardware_id'=>$id));
        if(!$data_info)$this->showmessage('信息不存在');
        $status = $this->Hardware_model->delete(array('hardware_id'=>$id));
        if($status)
        {
            $this->_cache_hardware();
            $this->showmessage('删除成功');exit;
        }else{
            $this->showmessage('删除失败');
        }
    }

    /**
     * 修改数据
     * @param int id
     * @return void
     */
    function edit($id=0)
    {
        $id = intval($id);

        $data_info =$this->Hardware_model->get_one(array('hardware_id'=>$id));
        //如果是AJAX请求
        if($this->input->is_ajax_request())
        {
            if(!$data_info)exit(json_encode(array('status'=>false,'tips'=>'信息不存在')));
            //接收POST参数
            $_arr['hardware_name'] = isset($_POST["hardware_name"])?trim(safe_replace($_POST["hardware_name"])):exit(json_encode(array('status'=>false,'tips'=>'设备名称不能为空')));
            if($_arr['hardware_name']=='')exit(json_encode(array('status'=>false,'tips'=>'设备名称不能为空')));
            $_arr['hardware_other_name'] = isset($_POST["hardware_other_name"])?trim(safe_replace($_POST["hardware_other_name"])):exit(json_encode(array('status'=>false,'tips'=>'设备别名不能为空')));
            if($_arr['hardware_other_name']=='')exit(json_encode(array('status'=>false,'tips'=>'设备别名不能为空')));
            $_arr['hardware_type_id'] = isset($_POST["hardware_type_id"])?trim(safe_replace($_POST["hardware_type_id"])):exit(json_encode(array('status'=>false,'tips'=>'设备类型不能为空')));
            if($_arr['hardware_type_id']=='')exit(json_encode(array('status'=>false,'tips'=>'设备类型不能为空')));
            // $_arr['eth_num'] = isset($_POST["eth_num"])?trim(safe_replace($_POST["eth_num"])):'';
            $_arr['cpu_num'] = isset($_POST["cpu_num"])?trim(safe_replace($_POST["cpu_num"])):'';
            $_arr['disk_size'] = isset($_POST["disk_size"])?trim(safe_replace($_POST["disk_size"])):'';
            $_arr['memory_size'] = isset($_POST["memory_size"])?trim(safe_replace($_POST["memory_size"])):'';
            $_arr['position'] = isset($_POST["position"])?trim(safe_replace($_POST["position"])):'';
            $_arr['factory'] = isset($_POST["factory"])?trim(safe_replace($_POST["factory"])):'';
            $_arr['is_monitor'] = isset($_POST["is_monitor"])?trim(safe_replace($_POST["is_monitor"])):'0';
            /*$_arr['monitor_ip'] = '';
            if($_arr['is_monitor'] !=0){
                $_arr['monitor_ip'] = isset($_POST["monitor_ip"])?trim(safe_replace($_POST["monitor_ip"])):exit(json_encode(array('status'=>false,'tips'=>'监控IP不能为空')));
                if($_arr['monitor_ip']=='')exit(json_encode(array('status'=>false,'tips'=>'监控IP不能为空')));
                 if($_arr['hardware_type_id'] ==2){
                    $_arr['ftp_name'] = isset($_POST["ftp_name"])?trim(safe_replace($_POST["ftp_name"])):exit(json_encode(array('status'=>false,'tips'=>'ftp名称不能为空')));
                    if($_arr['ftp_name']=='')exit(json_encode(array('status'=>false,'tips'=>'ftp名称不能为空')));
                    $_arr['ftp_code'] = isset($_POST["ftp_code"])?trim(safe_replace($_POST["ftp_code"])):exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                    if($_arr['ftp_code']=='')exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                     $ftp_code2 = isset($_POST["ftp_code2"])?trim(safe_replace($_POST["ftp_code2"])):exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                    if($ftp_code2=='')exit(json_encode(array('status'=>false,'tips'=>'ftp密码不能为空')));
                    if($_arr['ftp_code'] != $ftp_code2){
                        exit(json_encode(array('status'=>false,'tips'=>'两次ftp密码不一样')));
                    }
                     $_arr['ftp_code'] = check_encrypt($_arr['ftp_code'],'E',FTP_SIGIN);
                    $_arr['ftp_dir'] = isset($_POST["ftp_dir"])?trim(safe_replace($_POST["ftp_dir"])):exit(json_encode(array('status'=>false,'tips'=>'ftp名称不能为空')));
                    if($_arr['ftp_dir']=='')exit(json_encode(array('status'=>false,'tips'=>'ftp文件路径不能为空'))); 
                }
            }*/
            
            $status = $this->Hardware_model->update($_arr,array('hardware_id'=>$id));
            if($status)
            {
                $this->_cache_hardware();
                exit(json_encode(array('status'=>true,'tips'=>'信息修改成功')));
            }else
            {
                exit(json_encode(array('status'=>false,'tips'=>'信息修改失败')));
            }
        }else
        {
            if(!$data_info)$this->showmessage('信息不存在');
            $this->view('edit',array('require_js'=>true,'is_edit'=>true,'data_info'=>$data_info));
        }
    }

    /**
     * 设备缓存
     */
    private function _cache_hardware() {
        $infos = $this->Hardware_model->tables_select(array('is_hide'=>0), 't_sys_hardware.hardware_id,hardware_name,hardware_type_id,img_dir,canvas_x,canvas_y,is_accetive,to_notes,is_middel_server,hardware_other_name,is_main,kind_group,alarm_status,is_monitor,sound_switch');
        if ($infos) {
            setcache('cache_all_hardware', $infos);
        }else{
            $infos = array();
        }
        return $infos;
    }

    /**
     * 设备类型缓存
     */
    private function _cache_hardware_type() {
        $infos = $this->Hardware_type_model->select('',  '*', '', 'type_id ASC');
        $typeid_arr=array();
        if($infos) {
            foreach($infos as $k=>$v){
                $typeid_arr[$v['type_id']]=$v;
            }
            setcache('cache_hardware_type', $typeid_arr);
        }
        return $typeid_arr;
    }

    /**
     * 设备网口缓存
     */
    private function _cache_hardware_eth() {
        $infos = $this->Hardware_eth_model->select('',  '*', '', 'eth_id ASC');
        $eth_data = array();
        foreach ($infos as $key => $value) {
           $eth_data[$value['hardware_id']][] = $value;
        }
        $data = array();
        foreach ($eth_data as $key => $value) {
            $data[$key]['eth'] = implode(array_column($value,'eth_num'), ',') ;
        }
        return $data;
    }

    /**
     * 获取所有设备
     */
    function all_hardwares(){
        $all_hardwares = getcache("cache_hardware");
        $all_hardware_type = $this->_cache_hardware_type();
        $all_hardwares_eth = $this->_cache_hardware_eth();
        $hardware_arr = array();
        if($all_hardwares){
            foreach($all_hardwares as $k=>$v){
                $hardware_arr[$k]['hardware_id'] = $all_hardwares[$k]['hardware_id'];
                $hardware_arr[$k]['hardware_name'] = $all_hardwares[$k]['hardware_name'];
                $hardware_type_id = $all_hardwares[$k]['hardware_type_id'];
                $hardware_arr[$k]['hardware_type_id'] = $hardware_type_id;
                $hardware_arr[$k]['hardware_img'] = $all_hardware_type[$hardware_type_id]['img_dir'];
                $hardware_arr[$k]['canvas_x'] = $all_hardwares[$k]["canvas_x"];
                $hardware_arr[$k]['canvas_y'] = $all_hardwares[$k]["canvas_y"];
                $hardware_arr[$k]['is_accetive'] = $all_hardwares[$k]["is_accetive"];
                $hardware_arr[$k]['to_notes'] = $all_hardwares[$k]["to_notes"];
                $hardware_arr[$k]['is_middel_server'] = $all_hardwares[$k]["is_middel_server"];
                $hardware_arr[$k]['hardware_alias'] = $all_hardwares[$k]["hardware_alias"];
                //监控网口
                
            }
        }
        setcache('cache_hardware_arr', $hardware_arr);
        echo json_encode($hardware_arr);
    }
   
    public function use_server($use_kind){

        $hardware_id_arr = $this->input->post('hardware_id_arr');
        // var_dump($hardware_id_arr);exit;
        $hardware_id_str = implode(',', $hardware_id_arr);
        $all_hardwares = $this->Hardware_model->select('hardware_id in ('.$hardware_id_str.')','hardware_name');
        $all_hardwares_str = '';
        foreach ($all_hardwares as $key => $value) {
            $all_hardwares_str .= $value['hardware_name'].',';
        }
        $all_hardwares_str = rtrim($all_hardwares_str,',');
        $error_hardware = array();
        if($hardware_id_arr){
            foreach ($hardware_id_arr as $key => $value) {
                $ip_info = $this->Hardware_eth_model->tables_select(array('t_sys_hardware_eth.hardware_id'=>$value,'eth_type'=>0,'net_type'=>0),'eth_ip,hardware_name');
                if($ip_info){
                     $ip_add = $ip_info[0]['eth_ip'];
                    if($use_kind == 1){
                        $msg_str = '关机';
                        exec(POWER_FILE.' '.$ip_add,$a,$status);
                        if($status != 255){
                            $error_hardware[] = $ip_info[0]['hardware_name'];      
                        }
                         
                    }else{
                        $msg_str = '重启';
                        exec(REBOOT_FILE.' '.$ip_add,$a,$status);
                        if($status != 255){
                            $error_hardware[] = $ip_info[0]['hardware_name'];      
                        }
                         
                    }
                     // $flag = true;
                }else{
                    // $flag = false;
                    $error_hardware[] = $ip_info[0]['hardware_name'];      


                }
            }
            // exit;
            $operation_data = $this->operation_data;
            $operation_data['operate_explain'] = '进行'.$all_hardwares_str.'的设备'.$msg_str;
            $operation_data['dateline'] = time();
            if(empty($error_hardware)){
                  $operation_data['is_success'] = 1;
                  $operation_data['status_explain'] = '操作成功';
                  @$this->operationLogs($operation_data);
                  echo json_encode(array('status'=>FALSE,'tips'=>'操作成功'));exit;
            }else {
                  $error_hardware_str = implode(',', $error_hardware);
                  $operation_data['is_success'] = 0;
                  $operation_data['status_explain'] = $error_hardware_str.'设备'.$msg_str.'失败';
                  @$this->operationLogs($operation_data);
                  echo json_encode(array('status'=>FALSE,'tips'=>'操作失败'));exit;
            }
        }else{
            echo json_encode(array('status'=>FALSE,'tips'=>'请选择设备'));exit;
        }
        
    }
}