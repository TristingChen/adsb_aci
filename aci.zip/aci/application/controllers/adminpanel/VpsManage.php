<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 黑名单管理
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
class VpsManage extends Admin_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model(array('Vps_config_model', 'All_xml_model'));
        $this->load->helper(array('member', 'auto_codeIgniter', 'string'));
    }

    function index()
    {
        $data_info = $this->Vps_config_model->get_one();
        if(!$data_info){
            $data_info = $this->Vps_config_model->default_info();
        }
        //查找生成的xml与相应的文件资源
        $xml_info = $this->All_xml_model->get_one('`xml_name`= \'vsp.xml\'');
        $can_upload = false;
        if($xml_info){
            $file_exist = file_exists($xml_info['xml_path'].'vsp.xml');
            if($file_exist){
                $can_upload = true;
            }
        }
        $this->view('index',array('data_info'=>$data_info,'can_upload'=>$can_upload,'xml_info'=>$xml_info,'require_js'=>true));

    }

    function produce_xml(){
        $_arr['is_open_channel_by_self'] = $this->input->post('is_open_channel_by_self');
        if($_arr['is_open_channel_by_self'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'通道数据量熔断后是否自动恢复不得为空')));
        }
        $_arr['tdoa'] = $this->input->post('tdoa');
        if($_arr['tdoa'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'TDOA距离差不得为空')));
        }
        $_arr['delay'] = $this->input->post('delay');
        if($_arr['delay'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'延时不得为空')));
        }
		
        $_arr['nuc'] = $this->input->post('nuc');
        if($_arr['nuc'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'nuc门限值不得为空')));
        }
        $_arr['nac'] = $this->input->post('nac');
        if($_arr['nac'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'nac门限值不得为空')));
        }
        $_arr['nic'] = $this->input->post('nic');
        if($_arr['nic'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'nic门限值不得为空')));
        }
		$_arr['sil'] = $this->input->post('sil');
        if($_arr['sil'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'sil门限值不得为空')));
        }
		$_arr['item_value_keep_time'] = $this->input->post('item_value_keep_time');
        if($_arr['item_value_keep_time'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'重要数据项值保持时间不能为空')));
        }
        /*$_arr['in_height'] = $this->input->post('in_height');
        if($_arr['in_height'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点最大高度差不得为空')));
        }
        $_arr['in_speed'] = $this->input->post('in_speed');
        if($_arr['in_speed'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点最大速度差不得为空')));
        }
        $_arr['in_time'] = $this->input->post('in_time');
        if($_arr['in_time'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点最大时间差不得为空')));
        }
        $_arr['in_pos'] = $this->input->post('in_pos');
        if($_arr['in_pos'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点最大距离差不得为空')));
        }*/
        $_arr['in_angle'] = $this->input->post('in_angle');
        if($_arr['in_angle'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点最大角度差不得为空')));
        }
        $_arr['in_count'] = $this->input->post('in_count');
        if($_arr['in_count'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点航迹最大比较点迹数不得为空')));
        }
        $_arr['rate'] = $this->input->post('rate');
        if($_arr['rate'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点航迹最小匹配度不得为空')));
        }
        $_arr['max_speed'] = $this->input->post('max_speed');
        if($_arr['max_speed'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'航空器最大速度不得为空')));
        }
        $_arr['disappear_time_sec'] = $this->input->post('disappear_time_sec');
        if($_arr['disappear_time_sec'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'航迹两点时间最小丢失点迹数不得为空')));
        }
         $_arr['max_virtual_speed'] = $this->input->post('max_virtual_speed');
        if($_arr['max_virtual_speed'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'最大垂直速度不得为空')));
        }

        $_arr['chk_duration_microsec'] = $this->input->post('chk_duration_microsec');
        if($_arr['chk_duration_microsec'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'质量统计周期不得为空')));
        }
        $_arr['min_track_points'] = $this->input->post('min_track_points');
        if($_arr['min_track_points'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'最少航迹个数不得为空')));
        }
        $_arr['fusion_point_distance'] = $this->input->post('fusion_point_distance');
        if($_arr['fusion_point_distance'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'可视为同一个点的水平距离不得为空')));
        }
        $_arr['fusion_point_height'] = $this->input->post('fusion_point_height');
        if($_arr['fusion_point_height'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'可视为同一个点的垂直距离不得为空')));
        }
        $_arr['low_height'] = $this->input->post('low_height');
        if($_arr['low_height'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'可视为同一个点的垂直距离不得为空')));
        }
        /*$_arr['in_jump_time_sec'] = $this->input->post('in_jump_time_sec');
        if($_arr['in_jump_time_sec'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'两点最大时间差不得为空')));
        }
        $_arr['jump_position_distance'] = $this->input->post('jump_position_distance');
        if($_arr['jump_position_distance'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'航迹两点距离大于以下值判断为位置跳变不得为空')));
        }
        $_arr['jump_height_distance'] = $this->input->post('jump_height_distance');
        if($_arr['jump_height_distance'] === null){
            exit(json_encode(array('status'=>false,'tips'=>'航迹两点高度大于以下值判断为位置跳变不得为空')));
        }*/
        $data_info = $this->Vps_config_model->get_one();
        if(!$data_info){
            $m_status = $this->Vps_config_model->insert($_arr);
        }else{
            $m_status = $this->Vps_config_model->update($_arr,array('id'=>$data_info['id']));
        }
        if(!$m_status){
            echo json_encode(array('status'=>true,'tips'=>'信息保存失败'));
        }
        $xmlpatch = VSP_XML_PATH.'vsp.xml';
        $doc = new DOMDocument('1.0','utf-8');
        $flag = false;
        if(file_exists($xmlpatch)) {
            //备份以前的xml版本 2017_12_1_16_48
            $flag = true;
        }
        $doc -> formatOutput = true;
        $adsb = $doc -> createElement('ADSB_VSP');//新建节点
        $adsb = $this->create_only_xml($doc,$adsb,$_arr);
        $doc->appendChild($adsb);
        create_dir(VSP_XML_PATH);
        if($flag){
            //备份以前的xml版本 2017_12_1_16_48
            //输出以前的内容
            // $xml_str = file_get_contents($xmlpatch);
            $update_xml_file = 'vsp_'.date('Y_m_d_H_i',time()).'.xml';
            $xml_id_arr = $this->All_xml_model->get_one('`xml_name`= \'vsp.xml\'','id');
            $this->All_xml_model->update(array('xml_name'=>$update_xml_file,'is_old'=>1),array('id'=>$xml_id_arr['id']));
            rename($xmlpatch, VSP_XML_PATH.$update_xml_file);
        }
        $xml_save = $doc->save($xmlpatch);
        if($xml_save){ //发送udp
            $insert_data['xml_name'] = 'vsp.xml';
            $insert_data['dateline'] = time();
            $insert_data['kind'] = 9;
            $insert_data['xml_path'] = VSP_XML_PATH;
            $insert_data['config_name'] = '应用参数配置文件';
            $status = $this->All_xml_model->insert($insert_data);
            if($status){
                echo json_encode(array('status'=>true,'tips'=>'操作成功'));
            }else{
                echo json_encode(array('status'=>false,'tips'=>'文件上传失败'));
            }

        }else{
            echo json_encode(array('status'=>false,'tips'=>'xml保存失败'));
        }

    }

    //生成基站的_target_xml文件
    private function create_only_xml($doc,$adsb,$data_list){

        //$BDCD = $doc -> createElement('BDCD');
            //$decoder = $doc -> createElement('decoder');
                $isOpenChannelBySelf = $doc -> createElement('is_open_channel_by_self');
                $isOpenChannelBySelf_text = $doc->createTextNode($data_list['is_open_channel_by_self']);
                $isOpenChannelBySelf->appendChild($isOpenChannelBySelf_text);
            $adsb->appendChild($isOpenChannelBySelf);
        //$BDCD->appendChild($decoder);
        //$ADFV = $doc -> createElement('ADFV');
            //$fuser = $doc -> createElement('fuser');
                //$AlertParameter = $doc -> createElement('AlertParameter');
                    $tdoa = $doc -> createElement('tdoa');
                    $tdoa_text = $doc->createTextNode($data_list['tdoa']);
                    $tdoa->appendChild($tdoa_text);
                    $delay = $doc -> createElement('delay');
                    $delay_text = $doc->createTextNode($data_list['delay']);
                    $delay->appendChild($delay_text);
                $adsb->appendChild($tdoa);
                $adsb->appendChild($delay);
                //$QualityLimit = $doc -> createElement('QualityLimit');
                    $nuc = $doc -> createElement('nuc');
                    $nuc_text = $doc->createTextNode($data_list['nuc']);
                    $nuc->appendChild($nuc_text);
                    $nac = $doc -> createElement('nac');
                    $nac_text = $doc->createTextNode($data_list['nac']);
                    $nac->appendChild($nac_text);
                    $nic = $doc -> createElement('nic');
                    $nic_text = $doc->createTextNode($data_list['nic']);
                    $nic->appendChild($nic_text);
					$sil = $doc -> createElement('sil');
                    $sil_text = $doc->createTextNode($data_list['sil']);
                    $sil->appendChild($sil_text);		
					$item_value_keep_time = $doc -> createElement('item_value_keep_time');
                    $item_value_keep_time_text = $doc->createTextNode($data_list['item_value_keep_time']);
                    $item_value_keep_time->appendChild($item_value_keep_time_text);
                $adsb->appendChild($nuc);
                $adsb->appendChild($nac);
                $adsb->appendChild($nic);
                $adsb->appendChild($sil);
                $adsb->appendChild($item_value_keep_time);
            //$fuser->appendChild($AlertParameter);
            //$fuser->appendChild($QualityLimit);
        //$ADFV->appendChild($fuser);

        //$RDCD = $doc -> createElement('RDCD');
            //$varifier = $doc -> createElement('varifier');
                /*$in_height = $doc -> createElement('in_height');
                $in_height_text = $doc->createTextNode($data_list['in_height']);
                $in_height->appendChild($in_height_text);
                $in_speed = $doc -> createElement('in_speed');
                $in_speed_text = $doc->createTextNode($data_list['in_speed']);
                $in_speed->appendChild($in_speed_text);
                $in_time = $doc -> createElement('in_time');
                $in_time_text = $doc->createTextNode($data_list['in_time']);
                $in_time->appendChild($in_time_text);
                $in_pos = $doc -> createElement('in_pos');
                $in_pos_text = $doc->createTextNode($data_list['in_pos']);
                $in_pos->appendChild($in_pos_text);*/
                $max_virtual_speed = $doc -> createElement('max_virtual_speed');
                $max_virtual_speed_text = $doc->createTextNode($data_list['max_virtual_speed']);
                $max_virtual_speed->appendChild($max_virtual_speed_text);
                $in_angle = $doc -> createElement('in_angle');
                $in_angle_text = $doc->createTextNode($data_list['in_angle']);
                $in_angle->appendChild($in_angle_text);
                $in_count = $doc -> createElement('in_count');
                $in_count_text = $doc->createTextNode($data_list['in_count']);
                $in_count->appendChild($in_count_text);
                $rate = $doc -> createElement('rate');
                $rate_text = $doc->createTextNode($data_list['rate']);
                $rate->appendChild($rate_text);
            /*$adsb->appendChild($in_height);
            $adsb->appendChild($in_speed);
            $adsb->appendChild($in_time);
            $adsb->appendChild($in_pos);*/
            $adsb->appendChild($max_virtual_speed);
            $adsb->appendChild($in_angle);
            $adsb->appendChild($in_count);
            $adsb->appendChild($rate);
        //$RDCD->appendChild($varifier);

        //$CMLR = $doc -> createElement('CMLR');
            //$quality_staticstician = $doc -> createElement('quality_staticstician');
                    $maxSpeed = $doc -> createElement('max_speed');
                    $maxSpeed_text = $doc->createTextNode($data_list['max_speed']);
                    $maxSpeed->appendChild($maxSpeed_text);
                    $disappearTimeSec = $doc -> createElement('disappear_time_sec');
                    $disappearTimeSec_text = $doc->createTextNode($data_list['disappear_time_sec']);
                    $disappearTimeSec->appendChild($disappearTimeSec_text);
                    $chk_duration_microsec = $doc -> createElement('chk_duration_microsec');
                    $chk_duration_microsec_text = $doc->createTextNode($data_list['chk_duration_microsec']);
                    $chk_duration_microsec->appendChild($chk_duration_microsec_text);
                    $min_track_points = $doc -> createElement('min_track_points');
                    $min_track_points_text = $doc->createTextNode($data_list['min_track_points']);
                    $min_track_points->appendChild($min_track_points_text);
                    
                    $fusion_point_distance = $doc -> createElement('fusion_point_distance');
                    $fusion_point_distance_text = $doc->createTextNode($data_list['fusion_point_distance']);
                    $fusion_point_distance->appendChild($fusion_point_distance_text);

                    $fusion_point_height = $doc -> createElement('fusion_point_height');
                    $fusion_point_height_text = $doc->createTextNode($data_list['fusion_point_height']);
                    $fusion_point_height->appendChild($fusion_point_height_text);
                    $low_height = $doc -> createElement('low_height');
                    $low_height_text = $doc->createTextNode($data_list['low_height']);
                    $low_height->appendChild($low_height_text);
            $adsb->appendChild($maxSpeed);
            $adsb->appendChild($disappearTimeSec);
            $adsb->appendChild($chk_duration_microsec);
            $adsb->appendChild($min_track_points);
            $adsb->appendChild($fusion_point_distance);
            $adsb->appendChild($fusion_point_height);
            $adsb->appendChild($low_height);

        //$CMLR->appendChild($varifier);
        //$FPCD = $doc -> createElement('FPCD');
        //$FPCD_text = $doc -> createTextNode('');
        //$FPCD->appendChild($FPCD_text);
        //$ADDP = $doc -> createElement('ADDP');
            //$publisher = $doc -> createElement('publisher');
            //$publisher_text = $doc -> createTextNode('');
            //$publisher->appendChild($publisher_text);
        //$ADDP->appendChild($publisher);
        //$ADRP = $doc -> createElement('ADRP');
            //$record = $doc -> createElement('record');
            //$record_text = $doc -> createTextNode('');
            //$record->appendChild($record_text);
            //$replay = $doc -> createElement('replay');
            //$replay_text = $doc -> createTextNode('');
            //$replay->appendChild($replay_text);
        //$ADRP->appendChild($record);
        //$ADRP->appendChild($replay);

        //$BADP = $doc -> createElement('BADP');
            //$bypasser = $doc -> createElement('bypasser');
            //$bypasser_text = $doc -> createTextNode('');
            //$bypasser->appendChild($bypasser_text);
        //$BADP->appendChild($bypasser);
        //$adsb->appendChild($BDCD);
        //$adsb->appendChild($ADFV);
        //$adsb->appendChild($RDCD);
        //$adsb->appendChild($CMLR);
        //$adsb->appendChild($FPCD);
        //$adsb->appendChild($ADDP);
        //$adsb->appendChild($ADRP);
        //$adsb->appendChild($BADP);
        return $adsb;
    }

}
