<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function send_udp($host, $port, $buff, $waitAckSec=0)
{
    $result = false;
    $buffMassage = htmlspecialchars($buff);

    if ( ! ($sock = @socket_create(AF_INET, SOCK_DGRAM, SOL_UDP))  )
    {

        $errno = socket_last_error();
        $errmsg = socket_strerror($errno);
        log_message("send ".$host." ".$port."".$buffMassage." faile","log");
        return 0;
    }
    else
    {
		socket_set_option($sock,SOL_SOCKET,SO_BROADCAST,1);
        if ( !($result = @socket_sendto($sock, $buff, strlen($buff), 0, $host, $port)))
        {
            $errno = socket_last_error();
            $errmsg = socket_strerror($errno);
            @socket_close($sock);
            log_message('info',"send ".$host." ".$port."".$buffMassage." faile","log");
            return 0;
        }
    }
    return 1;
}

function recv_udp($host, $port)
{
	$buff = "";
	error_reporting(E_ALL | E_STRICT);
	$socket = socket_create(AF_INET,SOCK_DGRAM,SOL_UDP);
	socket_set_option($socket,SOL_SOCKET,SO_RCVTIMEO,array("sec"=>1,"usec"=>0));
	socket_set_option($socket,SOL_SOCKET,SO_REUSEADDR,1);
	if(socket_bind($socket,$host,$port) < 0)
	{
		log_message('info',"bind ".$host." ".$port."faile","log");
		return $buff;
	}
	else
	{
		socket_recvfrom($socket,$buff,500,0,$host,$port);		
	}
	socket_close($socket);
	return $buff;
}
