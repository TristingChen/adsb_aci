<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if(!function_exists('group_options'))
{
    function group_options($defaultValue=''){

        $all_groups = getcache("cache_member_group");

        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_groups as $k=>$v)
            $options[] =array('caption'=>$v['role_name'],'value'=>$v['role_id']);

        $_html="";
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }

        return $_html;
    }
}

if(!function_exists('app_options'))
{
    function app_options($defaultValue=''){

        $all_apps = getcache("cache_app_all");
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_apps as $k=>$v)
            $options[] =array('caption'=>$v['app_name'],'value'=>$v['app_id']);
        $_html="";
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }

        return $_html;
    }
}

if(!function_exists('hardware_options'))
{
    function hardware_options($defaultValue=''){
        $all_hardwares = getcache("cache_hardware");
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_hardwares as $k=>$v)
            $options[] =array('caption'=>$v['hardware_name'],'value'=>$v['hardware_id']);
        $_html="";
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

if(!function_exists('hardware_type_options'))
{
    function hardware_type_options($defaultValue=''){
        $all_types = getcache("cache_hardware_type");
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_types as $k=>$v)
            $options[] =array('caption'=>$v['type_name'],'value'=>$v['type_id']);

        $_html="";
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

if(!function_exists('versions_relation_options'))
{
    function versions_relation_options($data){
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($data as $k=>$v)
            $options[] =array('caption'=>$v['program'],'value'=>$v['id']);

        $_html="";
        foreach($options as $k=>$v)
        {
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

if(!function_exists('versions_old_options'))
{
    function versions_old_options($data){
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($data as $k=>$v)
            $options[] =array('caption'=>$v['version_num'],'value'=>$v['id']);

        $_html="";
        foreach($options as $k=>$v)
        {
                $_html .="<option value=\"{$v['id']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}


if(!function_exists('eth_options'))
{
    function eth_options($defaultValue='',$eth_id){
        $all_eths = getcache("cache_eth");
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_eths as $k=>$v)
            if($defaultValue == $v["hardware_id"]){
                $options[] =array('caption'=>$v['eth_num'],'value'=>$v['eth_id']);
            }
        $_html="";
        foreach($options as $k=>$v)
        {
            if($eth_id == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}


if(!function_exists('line_type_options'))
{
    function line_type_options($defaultValue=''){
        $all_types = getcache("cache_line_type");
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_types as $k=>$v)
            $options[] =array('caption'=>$v['description'],'value'=>$v['line_type_id']);

        $_html="";
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

if(!function_exists('color_options'))
{
    function color_options($defaultValue=''){
        $all_colors = getcache("cache_color");
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_colors as $k=>$v)
            $options[] =array('caption'=>$v['description'],'value'=>$v['color_id']);

        $_html="";
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

/**
 * 生成所有基站的下拉框
 */
if(!function_exists('station_options'))
{
    function station_options($defaultValue=''){
        $all_stations = getcache("cache_station");
		if(count($all_stations) < 1) exit;
        $options[] =array('caption'=>'ronghe','value'=>'0');
        foreach($all_stations as $k=>$v)
            $options[] =array('caption'=>$v['station_name'],'value'=>$v['station_id']);
		$_html="";
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

/**
 * 生成所有服务器下拉框
 */
if(!function_exists('server_options'))
{
    function server_options($defaultValue=''){
        $all_hardwares = getcache("cache_hardware");
        $_html="";
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_hardwares as $k=>$v){
            if($v["hardware_type_id"] == 2){
                $options[] =array('caption'=>$v['hardware_name'],'value'=>$v['hardware_id']);
            }
        }
        foreach($options as $k=>$v)
        {
            if($defaultValue == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

/**
 * 生成主备状态下拉框
 */
if(!function_exists('channel_status_options'))
{
    function channel_status_options($defaultValue=''){
        if($defaultValue == 1){
            $_html ="<option value=1 selected=\"selected\">ATTACH</option>";
            $_html .="<option value=2 >DETACH</option>";
        }else{
            $_html ="<option value=1 >ATTACH</option>";
            $_html .="<option value=2 selected=\"selected\">DETACH</option>";
        }
        return $_html;
    }
}

/**
 * 生成通道状态下拉框
 */
if(!function_exists('enable_status_options'))
{
    function enable_status_options($defaultValue=''){
        if($defaultValue == 1 || $defaultValue == 3){
            $_html ="<option value=1 selected=\"selected\">开启</option>";
            $_html .="<option value=0 >关闭</option>";
        }else{
            $_html ="<option value=0 selected=\"selected\">关闭</option>";
            $_html .="<option value=1 >开启</option>";
        }
        return $_html;
    }
}

/**
 * 生成UDP发送方式下拉框
 */
if(!function_exists('cast_type_options'))
{
    function cast_type_options($defaultValue=''){
        if($defaultValue == 1){
            $_html ="<option value=1 selected=\"selected\">单播</option>";
            $_html .="<option value=2 >组播</option>";
            $_html .="<option value=3 >广播</option>";
        }else if($defaultValue == 2){
            $_html ="<option value=1 >单播</option>";
            $_html .="<option value=2 selected=\"selected\">组播</option>";
            $_html .="<option value=3 >广播</option>";
        }else if($defaultValue == 3){
            $_html ="<option value=1 >单播</option>";
            $_html .="<option value=2 >组播</option>";
            $_html .="<option value=3 selected=\"selected\">广播</option>";
        }
        return $_html;
    }
}


/**
 * 生成所有服务器下拉框
 */
if(!function_exists('exchange_eth_options'))
{
    function exchange_eth_options($defaultValue=0,$eth_id=0){
        $all_colors = getcache("cache_all_eths");
        $_html="";
        $options[] =array('caption'=>'==请选择==','value'=>'');
        foreach($all_colors as $k=>$v){
            if($v["hardware_id"] == $defaultValue){
                $options[] =array('caption'=>$v['eth_num'],'value'=>$v['eth_num']);
            }
        }
        foreach($options as $k=>$v)
        {
            if($eth_id == $v['value'])
                $_html .="<option value=\"{$v['value']}\" selected=\"selected\">{$v['caption']}</option>";
            else
                $_html .="<option value=\"{$v['value']}\" >{$v['caption']}</option>";
        }
        return $_html;
    }
}

if(!function_exists('sex'))
{
    function sex($s){

        $s = intval($s);
        if($s==1) return "男";
        else if($s==2) return "女";
        return "-";
    }
}


if(!function_exists('group_name'))
{
    function group_name($s){
        $all_groups = getcache("cache_member_group");
        return isset($all_groups[$s])?$all_groups[$s]['role_name']:"-";
    }
}

/**
 * 获取所有的缓存应用信息
 */
if(!function_exists('app_name'))
{
    function app_name($s){
        $all_groups = getcache("cache_app_all");
        return isset($all_groups[$s])?$all_groups[$s]['app_name']:"";
    }
}

/**
 * 获取所有缓存的硬件信息
 */
if(!function_exists('hardware_name'))
{
    function hardware_name($s){
        $all_groups = getcache("cache_hardware");
        return isset($all_groups[$s])?$all_groups[$s]['hardware_name']:"-";
    }
}

/**
 * 获取所有缓存的硬件类型
 */
if(!function_exists('hardware_type'))
{
    function hardware_type($s){
        $all_groups = getcache("cache_hardware_type");
        return isset($all_groups[$s])?$all_groups[$s]['type_name']:"-";
    }
}


/**
 * 获取所有缓存的连线信息
 */
if(!function_exists('line_all'))
{
    function line_all(){
        $all_lines = getcache("cache_line");
        $all_eths = getcache("cache_all_eths");
        $all_color = getcache("cache_color");
        foreach($all_lines as $k=>$v){
            $all_lines[$k]["start_eth_num"] = ($v['start_node_eth_id'] != "")? $all_eths[$v['start_node_eth_id']]['eth_num']:"";
            $all_lines[$k]["end_eth_num"] = ($v['end_node_eth_id']!="")?$all_eths[$v['end_node_eth_id']]['eth_num']:"";
            $all_lines[$k]["line_color"] = ($v['line_color_id']!="")?$all_color[$v['line_color_id']]['rgb']:"";
        }
        return json_encode($all_lines);
    }
}

/**
 * 获取所有缓存的连线信息
 */
if(!function_exists('to_end_notes'))
{
    function to_end_notes(){
        $to_end_notes = getcache("cache_hardware_arr");
        return json_encode($to_end_notes);
    }
}

/**
 * 取文件最后$n行
 *@param string $fp 文件句柄
 * @param int $n 最后几行 基站最多512行
 * @return mixed false表示有错误，成功则返回字符串
 */
if(!function_exists('file_last_lines')){

    function file_last_lines($fp,$num=512,$match_word = fasle){
        $pos = -2;  
        $eof = "";  
        $head = false;   //当总行数小于Num时，判断是否到第一行了  
        $lines = array();  
        $one_line_str = '';
        while($num>0){  
            while($eof != "\n"){  
                if(fseek($fp, $pos, SEEK_END)==0){    //fseek成功返回0，失败返回-1  
                    $eof = fgetc($fp);  
                    $pos--;  
                }else{                               //当到达第一行，行首时，设置$pos失败  
                    fseek($fp,0,SEEK_SET);  
                    $head = true;                   //到达文件头部，开关打开  
                    break;  
                }  
                  
            }  
            $tmp_str = fgets($fp);
            if($match_word){
                if(strpos($tmp_str, $match_word) !==FALSE){
                    $one_line_str = $tmp_str;
                    break;
                }
            }
            array_unshift($lines,fgets($fp));  
            if($head){ break; }                 //这一句，只能放上一句后，因为到文件头后，把第一行读取出来再跳出整个循环  
            $eof = "";  
            $num--;  
        }  
        // fclose($fp);  
        if($match_word){
            return $one_line_str;  
        }else{
            return $lines;
        }


    }
}

function lline_tail($fp,$num=512){  
    $pos = -2;  
    $eof = "";  
    $head = false;   //当总行数小于Num时，判断是否到第一行了  
    $lines = array();  
    while($num>0){  
        while($eof != "\n"){  
            if(fseek($fp, $pos, SEEK_END)==0){    //fseek成功返回0，失败返回-1  
                $eof = fgetc($fp);  
                $pos--;  
            }else{                               //当到达第一行，行首时，设置$pos失败  
                fseek($fp,0,SEEK_SET);  
                $head = true;                   //到达文件头部，开关打开  
                break;  
            }  
              
        }  
        $tmp = fgets($fp);
        array_unshift($lines,$tmp);  
        if($head || strpos($tmp, 'begin') !== false){ break; }                 //这一句，只能放上一句后，因为到文件头后，把第一行读取出来再跳出整个循环  
        $eof = "";  
        $num--;  
    }  
    fclose($fp);  
    return $lines;  
} 


function last_line($fp){
    fseek($fp,-1,SEEK_END);
    $s = '';
    while(($c = fgetc($fp)) !== false) 
    {
      if($c == "\n" && $s) break;
      $s = $c . $s;
      fseek($fp, -2, SEEK_CUR);
    }
    fclose($fp);
    return $s;
}

function get_char_value($char,$line)
{
	$arr = explode(';',$line);
	$value = 0;
	foreach($arr as $key=>$v)
	{
		$item = explode('=',$v);
		if($item[0] == $char)
			$value = $item[1];
	}
	return $value;	
}
//读取最后一个json字符串
function file_json_lines($fp,$match_word = fasle){
    $pos = -2;  
    $eof = "";  
    $head = false;   //当总行数小于Num时，判断是否到第一行了  
    $lines = array();  
    $one_line_str = '';
    while(true){  
        while($eof != "\n"){  
            if(fseek($fp, $pos, SEEK_END)==0){    //fseek成功返回0，失败返回-1  
                $eof = fgetc($fp);  
                $pos--;  
            }else{  
                fseek($fp,0,SEEK_SET);                             //当到达第一行，行首时，设置$pos失败  
                $head = true;                   //到达文件头部，开关打开  
                break;   
            }  
              
        }  
        $tmp_str = fgets($fp);
       
        if($match_word == trim($tmp_str)){
            fseek($fp, $pos+1,SEEK_END);
            $one_line_str = fread($fp, abs($pos));
            break;  //这一句，只能放上一句后，因为到文件头后，把第一行读取出来再跳出整个循环  
        } 
        $eof = ""; 
         if($head){ break; }  
       
    }  
    fclose($fp);  
    return $one_line_str;

}
//记录行号
function file_reverse_lines($fp,$num=true,$match_word = fasle){
    $pos = -2;  
    $eof = "";  
    $head = false;   //当总行数小于Num时，判断是否到第一行了  
    $lines = array();  
    $one_line_str = '';
    while($num){  
        while($eof != "\n"){  
            if(fseek($fp, $pos, SEEK_END)==0){    //fseek成功返回0，失败返回-1  
                $eof = fgetc($fp);  
                $pos--;  
            }else{                               //当到达第一行，行首时，设置$pos失败  
                fseek($fp,0,SEEK_SET);  
                $head = true;                   //到达文件头部，开关打开  
                break;  
            }  
              
        }  
        $tmp_str = fgets($fp);
        if($match_word){
            if(strpos($tmp_str, $match_word) !==FALSE){
                $one_line_str = $tmp_str;
                break;
            }
        }
        array_unshift($lines,fgets($fp));  
        if($head){ break; }                 //这一句，只能放上一句后，因为到文件头后，把第一行读取出来再跳出整个循环  
        $eof = "";  
          
    }  
    // fclose($fp);  
    if($match_word){
        return $one_line_str;  
    }else{
        return $lines;
    }

}

//记录字节数
function file_ftell_lines($fp,$match_word = fasle,$old_ftell = fasle){
    $pos = -2;  
    $eof = "";  
    $head = false;   //当总行数小于Num时，判断是否到第一行了  
    $lines = array();  
    $one_line_str = '';
    fseek($fp, -1, SEEK_END);
    $current_tell = ftell($fp);
    
    if($old_ftell){
        while( $current_tell - $old_ftell > 0){  
            while($eof != "\n"){  
                if(fseek($fp, $pos, SEEK_END)==0){    //fseek成功返回0，失败返回-1  
                    $eof = fgetc($fp);  
                    $pos--;  
                }else{                               //当到达第一行，行首时，设置$pos失败  
                    fseek($fp,0,SEEK_SET);  
                    $head = true;                   //到达文件头部，开关打开  
                    break;  
                }  
                  
            }  
            $tmp_str = fgets($fp);
            if($match_word){
                if(strpos($tmp_str, $match_word) !==FALSE){
                    $one_line_str = $tmp_str;
                    break;
                }
            }
            if($head){ break; }                 //这一句，只能放上一句后，因为到文件头后，把第一行读取出来再跳出整个循环  
            $eof = "";  
            $current_tell--;
        }
    }else{
        while(true){  //全文读取
            while($eof != "\n"){  
                if(fseek($fp, $pos, SEEK_END)==0){    //fseek成功返回0，失败返回-1  
                    $eof = fgetc($fp);  
                    $pos--;  
                }else{                               //当到达第一行，行首时，设置$pos失败  
                    fseek($fp,0,SEEK_SET);  
                    $head = true;                   //到达文件头部，开关打开  
                    break;  
                }  
                  
            }  
            $tmp_str = fgets($fp);
            if($match_word){
                if(strpos($tmp_str, $match_word) !==FALSE){
                    $one_line_str = $tmp_str;
                    break;
                }
            }
            if($head){ break; }                 //这一句，只能放上一句后，因为到文件头后，把第一行读取出来再跳出整个循环  
            $eof = "";  
        }  
    }
    $last_ftell = ftell($fp);
    setcache("cache_file_tell.date('Ymd')",$last_ftell);
    fclose($fp);  
    return $one_line_str;

}

//读取最后一个json字符串
function file_jurge_lines($fp,$match_word = fasle){
    $pos = -2;  
    $eof = "";  
    $head = false;   //当总行数小于Num时，判断是否到第一行了  
    $lines = array();  
    $one_line_str = '';
    $flag = false;
    while(true){  
        while($eof != "\n"){  
            if(fseek($fp, $pos, SEEK_END)==0){    //fseek成功返回0，失败返回-1  
                $eof = fgetc($fp);  
                $pos--;  
            }else{  
                fseek($fp,0,SEEK_SET);                             //当到达第一行，行首时，设置$pos失败  
                $head = true;                   //到达文件头部，开关打开  
                break;   
            }  
              
        }  
        $tmp_str = fgets($fp);
       
        if(strpos($tmp_str,$match_word) !== false){
            // fseek($fp, $pos+1,SEEK_END);
            $flag = true;
            // $one_line_str = fread($fp, abs($pos));
            break;  //这一句，只能放上一句后，因为到文件头后，把第一行读取出来再跳出整个循环  
        } 
        $eof = ""; 
         if($head){ break; }  
       
    }  
    fclose($fp);  
    return $flag;

}

function jurge_station_limit($goal_count = false,$file_put_time,$station_id){
    $file_put_time = intval($file_put_time);
    $cache_warning_config = getcache('cache_warning_config_'.$station_id);
    $file_day_time = strtotime(date('Y-m-d 00:00:00',$file_put_time));
    $hour_file_time = intval(date('H',$file_put_time));
    $flag = false;
    $data = 0;
    if($cache_warning_config){
        $time_value1 = (int)$cache_warning_config['time_value1'];
        $end_value1 = (int)$cache_warning_config['end_time_value1'];
        $time_value2 = (int)$cache_warning_config['time_value2'];
        $end_value2 = (int)$cache_warning_config['end_time_value2'];
        $time_value3 = (int)$cache_warning_config['time_value3'];
        $end_value3 = (int)$cache_warning_config['end_time_value3'];
        if($hour_file_time < $time_value1){
            $file_put_time = $file_put_time + 24*60*60;
        }
        $start_time1 = $file_day_time + $time_value1*60*60;
        $end_time1 = $file_day_time + $end_value1*60*60;
        $start_time2 = $file_day_time + $time_value2*60*60;
        $end_time2 = $file_day_time + $end_value2*60*60;
        $start_time3 = $file_day_time + $time_value3*60*60;
        $end_time3 = $file_day_time + $end_value3*60*60;
        // var_dump($start_time3);var_dump($file_put_time);var_dump($end_time3);

        if($start_time1 <= $file_put_time && $file_put_time  <$end_time1){
            if($goal_count !== false){
                    if($goal_count < $cache_warning_config['value1']){
                        $flag = false;
                    }else{
                        $flag =  true;
                    }
            }else{
                   $data = $cache_warning_config['value1'];
            }  
            
        }elseif ($start_time2 <= $file_put_time && $file_put_time < $end_time2) {

            if($goal_count !== false){
                    if($goal_count < $cache_warning_config['value2']){
                        $flag = false;
                    }else{
                        $flag =  true;
                    }
            }else{
                   $data = $cache_warning_config['value2'];
            }  
            
        }elseif ($start_time3 <= $file_put_time && $file_put_time <= $end_time3) {
            if($goal_count !== false){
                    if($goal_count < $cache_warning_config['value3']){
                        $flag = false;
                    }else{
                        $flag =  true;
                    }
            }else{
                   $data = $cache_warning_config['value3'];
            }  
            
        }else {
            //小于第一段时间
            $file_put_time = $file_put_time + 24*60*60;


        }
        if($goal_count !== false){
               return $flag;
        }else{
           return $data;
        }
    }else{
        if($goal_count === false){
             return -1;

        }else{
            return true;

        }
    }
    
}
//判断目录并进行创建
function create_dir($path){
   if(!file_exists($path)){
     create_dir(dirname($path));
     mkdir($path,0777);
   }
}
//curl模拟ftp上传服务器
function curl_ftp_upload($dir,$src,$dest,$remote_host){
    $ch = curl_init();
    $fp = fopen($src,'r');
    curl_setopt($ch, CURLOPT_URL, 'ftp://root:atc4'.$remote_host.'/interpretation'.$dir.'/'.$dest);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 500);
    curl_setopt($ch, CURLOPT_UPLOAD, 1);
    curl_setopt($ch, CURLOPT_INFILE, $fp);
    curl_setopt($ch, CURLOPT_INFILESIZE, filesize($src));
    curl_exec($ch);
    $error_no = curl_errno($ch);
    curl_close($ch);
    if($error_no != 0){
        return 0;
    }else{
        return 1;
    }

}
function aa(){
    echo 'hello';
}

if(!function_exists('aci_restart_a'))
    {
        /**
         * ACI UI A
         * 
         * @param $folder 文件夹
         * @param $controller 控制器名
         * @param $method action方法
         * @param $args GET 要有问号
         * @param $attr 按钮内属性
         * @param $html 按钮内文字内容
         * @return bool
         */
        function aci_restart_a($folder,$controller,$method,$args,$attr,$html,$is_return=false)
        {
            global $CI;
            if($CI->current_role_priv_arr){
                $found=false;
                if($CI->group_id==SUPERADMIN_GROUP_ID)$found= true;
                if(!$found)
                foreach($CI->current_role_priv_arr as $k=>$v){
                    if($v['method']==$method&&$v['controller']==$controller&&$v['folder']==$folder){
                        $found=true;
                        break;
                    }
                }

                if($found){
                    $url = trim($controller)!=""?"href=\"".base_url(sprintf("%s/%s/%s/%s",trim($folder,"/"),$controller,$method,$args))."\"":"#";
                   
                    $url = base_url(sprintf("%s/%s/%s/%s",trim($folder,"/"),$controller,$method,$args));

                    if(!$is_return)
                        echo sprintf("<a href=\"javascript:if(confirm('确定要重读配置文件吗'))window.location.href='%s';\" %s>%s</a>",$url,$attr,$html);
                    else
                        return sprintf("<a href=\"javascript:if(confirm('确定要重读配置文件吗'))window.location.href='%s';\" %s>%s</a>",$url,$attr,$html);
                }
            }else{
                if(!$is_return)
                    echo "";
                else
                    return "";
            }


        }
    }
