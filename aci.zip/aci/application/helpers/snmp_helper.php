<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 获取监控对象
 * @param string $defaultValue
 */
function monitor_list(){
    $hardware_list = getcache("cache_hardware");
    $monitor_info[] = array();
    foreach($hardware_list as $k=>$v){
        if($v['is_monitor']){
            $monitor_info[$k]['hardware_name'] = $v["hardware_name"];
            $monitor_info[$k]['monitor_ip'] = $v['monitor_ip'];
            //$ping_time = ping_time($v['monitor_ip'])[1];
            $ping_time = 0;
            $monitor_info[$k]['ping_time'] = $ping_time;
            $monitor_info[$k]['status'] = ($ping_time > 0)?1:0;;

            //$monitor_info[$k]['sys_up_time'] = snmp_obj($v['monitor_ip'])["sysUptime"];
            $monitor_info[$k]['sys_up_time'] = 0;
        }
    }
    return $monitor_info;
}

function snmp_obj($ip,$string="adsbMonitor")
{
    $oid_list = getcache('cache_snmp_oid');
    $result = array();
    foreach($oid_list as $k=>$v){
        $fun = $v["request_type"];
        $oid = $v["oid_value"];
        if($fun == "GET"){
            $result[$k][$v["remark"]] = snmp_get($ip,$string,$oid);
        }elseif($fun == "WALK"){
            $result[$k][$v["remark"]] = snmp_walk($ip,$string,$oid);
        }
    }
    return $result;
}


/**
 * 获取ping时间
 * @ip
 */
function ping_time($ip)
{
   $ping_cmd = "ping -c 3 -w 5 ".$ip;
    exec($ping_cmd,$info);
    $ping_time_line = end($info);

   // $ping_time = explode("=",$ping_time_line)[1];
   // $ping_time_min = explode("/",$ping_time)[0]/1000.0;
   // $ping_time_avg = explode("/",$ping_time)[1]/1000.0;
   // $ping_time_max = explode("/",$ping_time)[2]/1000.0;
//
   // $result = array();
   // $result['ping_min'] = $ping_time_min;
   // $result['ping_avg'] = $ping_time_avg;
   // $result['ping_max'] = $ping_time_max;

   // return $result;
}

/**
 * snmpget
 * @param $ip
 * @param $string snmp组标识字符
 * @param $oid
 */
function snmp_get($ip,$string,$oid)
{
    $result = snmpget($ip,$string,$oid);
    if($result != "")
        //$result = explode(":",$result)[1];
    return $result;
}

/**
 * @param $ip
 * @param $string snmp组标识字符
 * @param $oid
 */
function snmp_walk($ip,$string,$oid)
{
    $result = snmpwalk($ip,$string,$oid);
    return $result;
}