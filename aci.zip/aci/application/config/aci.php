<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['aci_status'] = array (
    'systemVersion' => '1.2.0',
    'installED' => true,
);
$config['aci_module'] = array (
    'welcome' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2015-10-09 20:10:10',
        'moduleName' => 'welcome',
        'modulePath' => '',
        'moduleCaption' => '首页',
        'description' => '',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => '',
        'system' => true,
        'coder' => '',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => '',
                'controller' => 'welcome',
                'method' => '',
                'caption' => '欢迎界面',
            ),
        ),
    ),
    'adminpanel' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2015-10-09 20:10:10',
        'moduleName' => 'user',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '后台管理中心',
        'description' => '',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/user',
        'system' => true,
        'coder' => '',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'manage',
                'method' => 'index',
                'caption' => '管理中心-首页',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'manage',
                'method' => 'login',
                'caption' => '管理中心-登录',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'manage',
                'method' => 'logout',
                'caption' => '管理中心-注销',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'profile',
                'method' => 'change_pwd',
                'caption' => '管理中心-修改密码',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'manage',
                'method' => 'login',
                'caption' => '管理中心-登录',
            ),
            5 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'manage',
                'method' => 'go',
                'caption' => '管理中心-URL转向',
            ),
            6 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'manage',
                'method' => 'cache',
                'caption' => '管理中心-全局缓存',
            ),
            7 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataCenterInfo',
                'method' => 'add',
                'caption' => '管理中心-系统中心',
            ),
            8 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataCenterInfo',
                'method' => 'lists',
                'caption' => '管理中心-系统中心',
            ),
            9 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataCenterInfo',
                'method' => 'edit',
                'caption' => '管理中心-系统中心',
            ),
			10 => 
			array(
				'folder' => 'adminpanel',
                'controller' => 'systemAlertInfo',
                'method' => 'lists',
                'caption' => '管理中心-系统告警设置',
			),
			11 => 
			array(
				'folder' => 'adminpanel',
                'controller' => 'systemAlertInfo',
                'method' => 'edit',
                'caption' => '管理中心-系统告警设置',
			)
        ),
    ),
    'user' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2015-10-09 20:10:10',
        'moduleName' => 'user',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '用户 / 用户组管理',
        'description' => '',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/user',
        'system' => true,
        'coder' => '',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'index',
                'caption' => '用户管理-列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'check_username',
                'caption' => '用户管理-检测用户名',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'delete',
                'caption' => '用户管理-删除',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'lock',
                'caption' => '用户管理-锁定',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'edit',
                'caption' => '用户管理-编辑',
            ),
            5 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'add',
                'caption' => '用户管理-新增',
            ),
            6 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'upload',
                'caption' => '用户管理-上传图像',
            ),
            7 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'role',
                'method' => 'index',
                'caption' => '用户组管理-列表',
            ),
            8 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'role',
                'method' => 'setting',
                'caption' => '用户组管理-权限设置',
            ),
            9 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'role',
                'method' => 'add',
                'caption' => '用户组管理-新增',
            ),
            10 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'role',
                'method' => 'edit',
                'caption' => '用户组管理-编辑',
            ),
            11 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'role',
                'method' => 'delete_one',
                'caption' => '用户组管理-删除',
            ),
            12 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'user',
                'method' => 'user_window',
                'caption' => '用户-弹窗',
            ),
            13 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'role',
                'method' => 'group_window',
                'caption' => '用户组-弹窗',
            ),
        ),
    ),
    'moduleMenu' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2015-10-09 20:10:10',
        'moduleName' => 'moduleMenu',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '菜单管理',
        'description' => '',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/moduleMenu',
        'system' => true,
        'coder' => '',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'moduleMenu',
                'method' => 'index',
                'caption' => '菜单管理-列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'moduleMenu',
                'method' => 'add',
                'caption' => '菜单管理-新增',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'moduleMenu',
                'method' => 'edit',
                'caption' => '菜单管理-编辑',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'moduleMenu',
                'method' => 'delete',
                'caption' => '菜单管理-删除',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'moduleMenu',
                'method' => 'set_menu',
                'caption' => '菜单管理-设置菜单',
            )
        ),
    ),
    'appMonitor' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-01-06 20:10:10',
        'moduleName' => 'appMonitor',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '应用程序监控',
        'description' => '应用程序运行信息',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/appMonitor',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'index',
                'caption' => '应用监控',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'data_lists',
                'caption' => '应用监控-应用详情',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'data_charts',
                'caption' => '应用监控-运行图表',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'topo',
                'caption' => '应用监控-系统拓扑',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'save_axis',
                'caption' => '应用监控-保存拓扑节点移动坐标',
            ),
            5 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'add_line',
                'caption' => '应用监控-添加连线',
            ),
            6 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'edit_line',
                'caption' => '应用监控-编辑连线',
            ),
            7 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'delete_line_one',
                'caption' => '应用监控-删除连线',
            ),
            8 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'get_node_eths',
                'caption' => '应用监控-获取设备对应网口',
            ),
            9 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_lists',
                'caption' => '应用监控-应用列表',
            ),
            10 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_add',
                'caption' => '应用监控-添加应用',
            ),
            11 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_edit',
                'caption' => '应用监控-编辑应用',
            ),
            12 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_delete',
                'caption' => '应用监控-删除应用',
            ),
            13 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_alert_lists',
                'caption' => '应用监控-应用告警策略列表',
            ),
            14 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_alert_add',
                'caption' => '应用监控-新增应用告警策略',
            ),
            15 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_alert_edit',
                'caption' => '应用监控-编辑应用告警策略',
            ),
            16 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_alert_delete',
                'caption' => '应用监控-删除应用告警策略',
            ),
             17 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'one_hardware_detail',
                'caption' => '应用监控-告警详情显示',
            ),
             18 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'hardware_status',
                'caption' => '应用监控-告警详情显示',
            ),
            19 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'hardware_log',
                'caption' => '应用监控-错误日志',
            ),
            20 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'timing_hardware_detail',
                'caption' => '应用监控-详情定时状态',
            ),
            21 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'shift_main',
                'caption' => '应用监控-主备切换',
            ),
            22 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'change_msg_confirm',
                'caption' => '应用监控-状态改变',
            ),
            23 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'use_server',
                'caption' => '应用监控-关机重启',
            ),
            24 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'hardware_relation',
                'caption' => '应用监控-拓扑关系图',
            ),
            25 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'timing_app_status',
                'caption' => '应用监控-应用定时',
            ),
            26 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'change_msg_confirm',
                'caption' => '应用监控-应用操作',
            ),
			27 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'produce_xml',
                'caption' => '应用监控-生成配置文件',
            ),
            28 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'ping_result',
                'caption' => '应用监控-ping网口',
            ),
            29 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'compare_is_main',
                'caption' => '应用监控-主备切换',
            ),
            30 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'stations_status',
                'caption' => '应用监控-基站的监控',
            ),
            31 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'file_time_check',
                'caption' => '应用监控-cat247解读',
            ),
            32 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'read_data_limit_file',
                'caption' => '应用监控-航迹限制解读',
            ),
            33 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'current_path_jurge',
                'caption' => '应用监控-当前主备状态判断',
            ),
            34 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'xml_read_jurge',
                'caption' => '应用监控-数据站的读取与检查',
            ),
            35 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'read_rader_file',
                'caption' => '应用监控-雷达的告警解读',
            ),
            36 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'all_stations',
                'caption' => '应用监控-雷达与基站数据',
            ),
            37 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'auto_alarm_switch',
                'caption' => '应用监控-设备告警主动切换',
            ),
            38 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'sound_alarm_switch_off',
                'caption' => '应用监控-预告警声音关闭',
            ),
            39 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'app_info',
                'caption' => '应用监控-应用详情',
            ),
            40 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appMonitor',
                'method' => 'one_ntp_detail',
                'caption' => '应用监控-ntp告警详情显示',
            ),
            41 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'api',
                'method' => 'index',
                'caption' => '应用监控-基站api数据接口',
            )
        ),
    ),
    'station' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-06 15:49:10',
        'moduleName' => 'station',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '基站管理',
        'description' => '进行基站信息配置管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/station',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'lists',
                'caption' => '基站管理-列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'add',
                'caption' => '基站管理-新增',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'edit',
                'caption' => '基站管理-编辑',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'delete',
                'caption' => '基站管理-删除',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'monitor',
                'caption' => '基站管理-删除',
            ),
             5 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'watch_list',
                'caption' => '基站监控-列表',
            ),
             6 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'one_station_detail',
                'caption' => '基站监控-基站详情',
            ),
            7 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'rader_lists',
                'caption' => '雷达管理-列表',
            ),
            8 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'rader_add',
                'caption' => '雷达管理-添加',
            ),
            9 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'rader_edit',
                'caption' => '雷达管理-编辑',
            ),
            9 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'rader_produce_xml',
                'caption' => '基站管理-生成xml',
            ),
            10 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'rader_base_set',
                'caption' => '参数管理-雷达基础参数配置',
            ),
            11 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'one_rader_detail',
                'caption' => '基站监控-雷达详情',
            ),
            12 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'one_station_num_detail',
                'caption' => '基站监控-数据站详情',
            ),
            13 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'stations_status',
                'caption' => '基站监控-基站状态',
            ),
            14 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'produce_xml',
                'caption' => '参数管理-生成xml',
            ),
            15 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'change_current_path',
                'caption' => '参数管理-切换当前通道',
            ),
            16 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'timing_one_rader_detail',
                'caption' => '参数管理-雷达实时详情',
            ),
            17 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'timing_one_station_detail',
                'caption' => '参数管理-基站实时详情',
            ),
            18 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'make_one_station_data',
                'caption' => '参数管理-基站数据整合',
            ),
            19 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'info',
                'caption' => '参数管理-基站详情',
            ),
            20 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'rader_info',
                'caption' => '参数管理-雷达详情',
            ),
            21 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'station',
                'method' => 'station_message_send',
                'caption' => '参数管理-基站管理',
            )
        ),
    ),
    'stationLogs' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-10 08:49:10',
        'moduleName' => 'stationLogs',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '基站日志管理',
        'description' => '进行系统日志信息管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/stationLogs',
        'system' => false,
        'coder' => 'chenjialing',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'stationLogs',
                'method' => 'lists',
                'caption' => '日志管理-列表',
            ),
        ),
    ),
    'stationWarningLogs' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-10 08:49:10',
        'moduleName' => 'stationWarningLogs',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '基站告警日志管理',
        'description' => '进行系统日志信息管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/stationWarningLogs',
        'system' => false,
        'coder' => 'chenjialing',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'stationWarningLogs',
                'method' => 'lists',
                'caption' => '日志管理-列表',
            ),
        ),
    ),
    'appLogs' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-10 08:49:10',
        'moduleName' => 'appLogs',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '应用程序日志管理',
        'description' => '进行系统日志信息管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/appLogs',
        'system' => false,
        'coder' => 'chenjialing',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appLogs',
                'method' => 'lists',
                'caption' => '日志管理-列表',
            ),
        ),
    ),

    'usingLogs' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-10 08:49:10',
        'moduleName' => 'usingLogs',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '用户操作日志',
        'description' => '进行用户操作日志信息管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/usingLogs',
        'system' => false,
        'coder' => 'chenjialing',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'usingLogs',
                'method' => 'lists',
                'caption' => '日志管理-用户操作日志',
            ),
        ),
    ),
    'alert' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-13 15:20:10',
        'moduleName' => 'trackAlert',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '数据质量统计分析参数管理',
        'description' => '进行数据质量统计分析参数管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/trackAlert',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'trackAlert',
                'method' => 'choose',
                'caption' => '数据质量统计分析参数管理-设置',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'trackAlert',
                'method' => 'add',
                'caption' => '数据质量统计分析参数管理-新增',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'trackAlert',
                'method' => 'edit',
                'caption' => '数据质量统计分析参数管理-编辑',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'trackAlert',
                'method' => 'delete',
                'caption' => '数据质量统计分析参数管理-删除',
            ),
             4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'trackAlert',
                'method' => 'produce_xml',
                'caption' => '数据质量统计分析参数管理-生成xml',
            )
        ),
    ),
    'hardwareMonitor' =>
    array (
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-13 16:42:10',
        'moduleName' => 'hardwareManage',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '系统设备管理',
        'description' => '系统设备信息管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/hardwareMonitor',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array (
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'index',
                'caption' => '设备管理-概览',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'lists',
                'caption' => '设备管理-列表',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'add',
                'caption' => '设备管理-新增',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'edit',
                'caption' => '设备管理-编辑',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'delete',
                'caption' => '设备管理-删除',
            ),
            5 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'run_info',
                'caption' => '设备管理-运行信息',
            ),
            6 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'all_hardwares',
                'caption' => '设备管理-获取设备信息',
            ),
            7 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'hardwareMonitor',
                'method' => 'use_server',
                'caption' => '设备管理-设备批量重启关机',
            ),
        ),
    ),
    'ethManage' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-02-17 16:42:10',
        'moduleName' => 'ethManage',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '设备网口管理',
        'description' => '系统网口信息管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/ethManage',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'ethManage',
                'method' => 'lists',
                'caption' => '网口管理-网口信息',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'ethManage',
                'method' => 'add',
                'caption' => '网口管理-新增网口',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'ethManage',
                'method' => 'edit',
                'caption' => '网口管理-编辑网口',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'ethManage',
                'method' => 'delete',
                'caption' => '网口管理-删除网口',
            )
        ),
    ),
    'appNode' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-03-27 10:42:10',
        'moduleName' => 'appNode',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '应用节点管理',
        'description' => '应用模块节点管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/appNode',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appNode',
                'method' => 'index',
                'caption' => '节点管理-节点列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appNode',
                'method' => 'add',
                'caption' => '节点管理-新增节点',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appNode',
                'method' => 'edit',
                'caption' => '节点管理-编辑节点',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'appNode',
                'method' => 'delete',
                'caption' => '节点管理-删除节点',
            )
        )
    ),
    'bypassManage' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'BypassManage',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '旁路配置管理',
        'description' => '旁路配置管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/bypassManage',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'bypassManage',
                'method' => 'lists',
                'caption' => '参数管理-旁路信息列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'bypassManage',
                'method' => 'add',
                'caption' => '参数管理-新增旁路配置信息',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'bypassManage',
                'method' => 'edit',
                'caption' => '参数管理-编辑旁路配置信息',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'bypassManage',
                'method' => 'produce_xml',
                'caption' => '参数管理-生成xml',
            ),
             4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'bypassManage',
                'method' => 'change_main_switch',
                'caption' => '参数管理-旁路开关切换',
            )
        )
    ),
    'polygonsManage' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'polygonsManage',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '多边形管理',
        'description' => '多边形管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/polygonsManage',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'polygonsManage',
                'method' => 'lists',
                'caption' => '参数管理-旁路信息列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'polygonsManage',
                'method' => 'add',
                'caption' => '参数管理-新增旁路配置信息',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'polygonsManage',
                'method' => 'edit',
                'caption' => '参数管理-编辑旁路配置信息',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'polygonsManage',
                'method' => 'produce_xml',
                'caption' => '参数管理-生成xml',
            ),

        )
    ),
    'areaManage' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'areaManage',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '区域管理',
        'description' => '区域管理',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/areaManage',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'areaManage',
                'method' => 'lists',
                'caption' => '参数管理-旁路信息列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'areaManage',
                'method' => 'add',
                'caption' => '参数管理-新增旁路配置信息',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'areaManage',
                'method' => 'edit',
                'caption' => '参数管理-编辑旁路配置信息',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'areaManage',
                'method' => 'produce_xml',
                'caption' => '参数管理-生成xml',
            ),

        )
    ),
    'replayerManage' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'replayer',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '输入回放参数配置',
        'description' => '输入回放参数配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/replayerManage',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'replayerManage',
                'method' => 'lists',
                'caption' => '参数管理-回放参数配置',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'replayerManage',
                'method' => 'produce_xml',
                'caption' => '参数管理-输入回放消息处理',
            ),
        )
    ),
    'replayerExportManage' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'replayer',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '输出回放参数配置',
        'description' => '输出回放参数配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/replayerExportManage',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'replayerExportManage',
                'method' => 'lists',
                'caption' => '参数管理-回放参数配置',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'replayerExportManage',
                'method' => 'produce_xml',
                'caption' => '参数管理-输出回放参数配置',
            ),
        )
    ),
    'warningConfig' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'warningConfig',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '告警参数配置',
        'description' => '告警参数配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/warningConfig',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'warningConfig',
                'method' => 'lists',
                'caption' => '参数管理-告警参数配置',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'warningConfig',
                'method' => 'edit',
                'caption' => '参数管理-告警参数编辑',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'warningConfig',
                'method' => 'add',
                'caption' => '参数管理-告警参数添加',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'warningConfig',
                'method' => 'delete',
                'caption' => '参数管理-告警参数删除',
            ),
        )
    ),
    'dataExport' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'dataExport',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '数据输出参数配置',
        'description' => '数据输出参数配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/dataExport',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataExport',
                'method' => 'lists',
                'caption' => '参数管理-旁路信息列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataExport',
                'method' => 'add',
                'caption' => '参数管理-新增旁路配置信息',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataExport',
                'method' => 'edit',
                'caption' => '参数管理-编辑旁路配置信息',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataExport',
                'method' => 'produce_xml',
                'caption' => '参数管理-生成xml',
            ),

        )
    ),
    'recorderConfig' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'recorderConfig',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '录制参数配置',
        'description' => '录制参数配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/recorderConfig',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'recorderConfig',
                'method' => 'lists',
                'caption' => '参数管理-录制参数配置',
            ),
        )
    ),
    'atmbDataDeploy' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-04-26 16:12:10',
        'moduleName' => 'atmbDataDeploy',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '管制用户数据源配置',
        'description' => '管制用户数据源配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/atmbDataDeploy',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'atmbDataDeploy',
                'method' => 'lists',
                'caption' => '管制用户数据源配置-目标列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'atmbDataDeploy',
                'method' => 'add',
                'caption' => '管制用户数据源配置-新增发送目标',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'atmbDataDeploy',
                'method' => 'edit',
                'caption' => '管制用户数据源配置-编辑发送目标',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'atmbDataDeploy',
                'method' => 'delete',
                'caption' => '管制用户数据源配置-删除发送目标',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'atmbDataDeploy',
                'method' => 'recv_data_lists    ',
                'caption' => '管制用户数据源配置-加载数据源',
            )
        )
    ),
    'publishDataDeploy' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-05-10 16:12:10',
        'moduleName' => 'publishDataDeploy',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '发布数据源配置',
        'description' => '对外发布数据源配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/publishDataDeploy',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'lists',
                'caption' => '发布数据源配置-发布列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'add',
                'caption' => '发布数据源配置-新增发送目标',
            ),
            2 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'edit',
                'caption' => '发布数据源配置-编辑发布目标',
            ),
            3 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'delete',
                'caption' => '发布数据源配置-删除发布目标',
            ),
            4 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'recv_data_lists    ',
                'caption' => '发布数据源配置-加载数据源',
            ),
             5 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'station_relation_add    ',
                'caption' => '发布数据源配置-服务器参数文件添加',
            ),
             6 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'back_versions',
                'caption' => '发布数据源配置-文件回退',
            ),
             7 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'upgrade_versions',
                'caption' => '发布数据源配置-文件升级',
            ),
             8 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'publish_file_add',
                'caption' => '发布数据源配置-参数文件发布',
            ),
             9 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'publish_file_info',
                'caption' => '发布数据源配置-参数文件发布',
            ),
             10 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'xml_info_show',
                'caption' => '发布数据源配置-点击选取xml的详情',
            ),
            11 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'goalFileManage',
                'caption' => '参数管理-参数目标服务器配置',
            ),
            12 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'goal_file_add',
                'caption' => '参数管理-参数目标服务器添加',
            ),
            13 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'goal_file_edit',
                'caption' => '参数管理-参数目标服务器编辑',
            ),
            14 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'publishDataDeploy',
                'method' => 'goal_file_delete',
                'caption' => '参数管理-参数目标服务器删除',
            )
        )
    ),
     'versionController' =>
        array(
            'version' => '1',
            'charset' => 'utf-8',
            'lastUpdate' => '2017-11-12 10:12:10',
            'moduleName' => 'versionsCtrl',
            'modulePath' => 'adminpanel',
            'moduleCaption' => '版本控制',
            'description' => '版本控制',
            'fileList' => NULL,
            'works' => true,
            'moduleUrl' => 'adminpanel/versionsCtrl',
            'system' => false,
            'coder' => 'chenjialing',
            'website' => 'http://',
            'moduleDetails' =>
                array(
                    0 =>
                        array (
                            'folder' => 'adminpanel',
                            'controller' => 'versionsCtrl',
                            'method' => 'versions_manage',
                            'caption' => '版本管理',
                        ),
                    1=>
                        array (
                            'folder' => 'adminpanel',
                            'controller' => 'versionsCtrl',
                            'method' => 'edit',
                            'caption' => '版本编辑',
                        ),
                    2=>
                        array (
                            'folder' => 'adminpanel',
                            'controller' => 'versionsCtrl',
                            'method' => 'upgrade_versions',
                            'caption' => '版本更新',
                        ),
                    3=>
                        array (
                            'folder' => 'adminpanel',
                            'controller' => 'versionsCtrl',
                            'method' => 'back_versions',
                            'caption' => '版本回退',
                        )

                )
    ),
	'dataAnalyse' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2017-11-18 14:44:00',
        'moduleName' => 'dataAnalyse',
        'modulePath' => 'adminpanel',
        'moduleCaption' => '数据质量分析',
        'description' => '数据质量分析',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/dataAnalyse',
        'system' => false,
        'coder' => 'chenyong',
        'website' => 'http://',
        'moduleDetails' =>
        array(
            0 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'index',
                'caption' => '数据帧列表',
            ),
            1 =>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'statistics',
                'caption' => '数据统计',
            ),
            3=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'detail',
                'caption' => '查看数据包详细信息',
            ),
            4=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'offline',
                'caption' => '离线分析',
            ),
            5=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'get_buff_detail',
                'caption' => '报文分析详情',
            ),
            6=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'choose_source',
                'caption' => '通道选择',
            ),
            7=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'read_buff_data',
                'caption' => '数据质量实时分析',
            ),
            8=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'send_buff',
                'caption' => '数据分析',
            ),
            9=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'get_ini_statistics_data',
                'caption' => '数据图形数据初始化',
            ),
            10=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'read_statistics_data',
                'caption' => '数据图形数据获取',
            ),
            11=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'echo_offline_data',
                'caption' => '输出离线数据',
            ),
            12=>
            array (
                'folder' => 'adminpanel',
                'controller' => 'dataAnalyse',
                'method' => 'exportExcel',
                'caption' => '导出离线数据',
            )
        )
    ),
    'vpsManage' =>
    array(
        'version' => '1',
        'charset' => 'utf-8',
        'lastUpdate' => '2018-05-15 09:44:00',
        'moduleName' => 'vpsManage',
        'modulePath' => 'adminpanel',
        'moduleCaption' => 'vsp参数配置',
        'description' => 'vsp参数配置',
        'fileList' => NULL,
        'works' => true,
        'moduleUrl' => 'adminpanel/vpsManage',
        'system' => false,
        'coder' => 'cjl',
        'website' => 'http://',
        'moduleDetails' =>
            array(
                0 =>
                    array (
                        'folder' => 'adminpanel',
                        'controller' => 'vpsManage',
                        'method' => 'index',
                        'caption' => '信息列表',
                    ),
                1 =>
                    array (
                        'folder' => 'adminpanel',
                        'controller' => 'vpsManage',
                        'method' => 'produce_xml',
                        'caption' => '保存并上传配置文件',
                    )
            )
    )
);

/* End of file aci.php */
/* Location: ./application/config/aci.php */
