<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-30
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
class Send_data_model extends Base_Model {
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'send_data';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'send_num'=>0,
            'note'=>"",
            'send_type'=>0,
            'send_ip'=>"",
            'send_interface'=>"",
            'send_port'=>0,
            'ttl'=>0,
            'is_loop'=>0
        );
    }
}