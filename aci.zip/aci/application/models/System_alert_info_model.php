<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
class System_alert_info_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'system_alert_info';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'cpu_alert_value'=>80.0,
            'memory_alert_value'=>80.0,
            'disk_alert_value'=>80.0,
            'NIC_recv_min_value'=>0.0,
            'NIC_recv_max_value'=>102400.0, //单位为KB
			'NIC_send_min_value'=>0.0,
			'NIC_send_max_value'=>102400.0  //单位为KB
        );
    }
}