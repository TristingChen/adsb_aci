<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-16
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */
class Operation_logs_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'operation_logs';
        parent::__construct();
    }


        /**
     * 多表联合执行sql查询
     * @param $where        查询条件[例`name`='$name']
     * @param $data         需要查询的字段值[例`name`,`gender`,`birthday`]
     * @param $limit        返回结果范围[例：10或10,10 默认为空]
     * @param $order        排序方式    [默认按数据库默认方式排序]
     * @param $group        分组方式    [默认为空]
     * @param $key          返回数组按键名排序
     * @return array        查询结果集数组
     */
    public function tables_select($where = '', $data = '*', $limit = '', $order = '', $group = '', $key='') {
            
        if (!empty($where))
        {
            $where = $this->db->where($where);
        }
        $data=str_replace("，",",",$data);
        $this->db->select($data);
        if(!empty($limit))
        {
            $limit_arr=explode(",", $limit);
            if(count($limit_arr)==1)
                $this->db->limit($limit);
            else
                $this->db->limit($limit_arr[1],$limit_arr[0]);
        }
        if(!empty($order))$this->db->order_by($order);
        if(!empty($group))$this->db->group_by($group);

        $this->db->from($this->table_name);
        $this->db->join('t_sys_hardware_type', 't_sys_hardware_type.type_id = t_sys_hardware.hardware_type_id','left');
        // $this->db->join('t_sys_app', 't_sys_hardware.hardware_id = t_sys_app.hardware_id','left');
        // $this->db->join('t_sys_hardware_eth', 't_sys_hardware_eth.hardware_id = t_sys_hardware.hardware_id','left');
        $datalist =array();
        $Q = $this->db->get();
        if ($Q->num_rows() > 0)
        {
            foreach ($Q->result_array() as $rs)
            {
                if($key) {
                    $datalist[$rs[$key]] = $rs;
                } else {
                    $datalist[] = $rs;
                }
            }
        }

        $Q->free_result();
        return $datalist;
    }


}