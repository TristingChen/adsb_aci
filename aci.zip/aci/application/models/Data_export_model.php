<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
class Data_export_model extends Base_Model{
    var $page_size = 20;
    public  function __construct(){
        $this->table_name = 'data_export';
        parent::__construct();
    }



    function default_info(){
        return array(
            'id'=>0,
            'to_name'=>"",
            'to_ip'=>"",
            'to_port'=>"",
            'station_ids'=>"",
            'in_work_option'=>"",
            'remark'=>"",
            'cast_type'=>""

        );
    }
}