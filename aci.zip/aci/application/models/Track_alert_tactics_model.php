<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-14
 * Time: 上午9:23
 * To change this template use File | Settings | File Templates.
 */
class Track_alert_tactics_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'track_alert_tactics';
        parent::__construct();
    }

    function default_info(){
        return array(
            'tactics_id'=>0,
            'tactics_name'=>"",
            'unit'=>"",
            'description'=>"",
            'min_value'=>"",
            'max_value'=>"",
            'alert_cycle'=>0
        );
    }
}