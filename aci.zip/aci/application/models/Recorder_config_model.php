<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-14
 * Time: 上午9:23
 * To change this template use File | Settings | File Templates.
 */
class Recorder_config_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'recorder_config';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>'',
            'log_path'=>"",
            'log_level'=>"",
            'interval'=>"",
            'miss_count'=>"",
            'send_ip'=>"",
            'send_port'=>"",
            'send_heart_ip'=>"",
            'send_heart_port'=>"",
            'recv_cmd_ip'=>"",
            'recv_cmd_port'=>"",
            'input_ip_a'=>"",
            'input_ip_a_port'=>"",
            'output_ip_a'=>"",
            'output_ip_a_port'=>"",
            'input_ip_b'=>"",
            'input_ip_b_port'=>"",
            'output_ip_b'=>"",
            'output_ip_b_port'=>"",
            'bufsize'=>"",
            'recorder_a_dir'=>"",
            'recorder_b_dir'=>"",

        );
    }
}