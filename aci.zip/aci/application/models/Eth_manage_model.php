<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-20
 * Time: 上午9:53
 * To change this template use File | Settings | File Templates.
 */
class Eth_manage_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'hardware_eth';
        parent::__construct();
    }

    function default_info(){
        return array(
            'eth_id'=>0,
            'eth_num'=>"",
            'hardware_id'=>0,
            'eth_ip'=>"",
            'speed'=>0,
            'is_enable'=>0,
            'eth_type'=>0,
            'net_type'=>0
        );
    }
}