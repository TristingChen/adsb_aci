<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
class Bypass_config_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'bypass_config';
        parent::__construct();
    }



    function default_info(){
        return array(
            'id'=>0,
            'to_name'=>"",
            'to_ip'=>"",
            'to_port'=>"",
            'station_ids'=>"",
            'in_work_option'=>"",
            'remark'=>"",
            'cast_type'=>"",
            'receive_watch_ip'=>'',
            'receive_watch_port'=>'',
            'receive_ip'=>'',
            'receive_cast_type'=>'',
            'send_watch_ip'=>'',
            'send_watch_port'=>'',
            'send_ip'=>'',
            'send_cast_type'=>1,
            'send_cycle'=>'',
            'program_name'=>'',
            'program_start_dir'=>'',
            'program_log_dir'=>'',
            'program_log_degree'=>'',
            'is_master'=>1,
            'time_out'=>'',
            'main_switch'=>''

        );
    }
}