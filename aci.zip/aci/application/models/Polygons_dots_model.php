<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-16
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */
class Polygons_dots_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'polygons_dots';
        parent::__construct();
    }

     
    function default_info(){
        return array(
            'hardware_id'=>0,
            'hardware_type_id'=>0,
            'hardware_name'=>"",
            'eth_num'=>"",
            'cpu_num'=>"",
            'disk_size'=>"",
            'memory_size'=>"",
            'position'=>"",
            'factory'=>"",
            'is_monitor'=>0,
            'monitor_ip'=>"",
            'ftp_name'=>"",
            'ftp_code'=>"",
            'ftp_dir'=>""

        );
    }
}