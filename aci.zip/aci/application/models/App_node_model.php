<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-27
 * Time: 上午9:18
 * To change this template use File | Settings | File Templates.
 */
class App_node_model extends Base_Model {
    public function __construct() {
        $this->table_name = 'app_node';
        parent::__construct();
    }

    function default_info(){
        return array(
            'node_id'=>0,
            'node_name'=>"",
            "node_description"=>"",
            "node_attribute"=>"",
            "app_id"=>0,
            'parent_id'=>0,
            'list_order'=>0,
            'is_works'=>1,
            'table_name'=>""
        );
    }

}