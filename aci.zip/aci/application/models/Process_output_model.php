<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-30
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
class Process_output_model extends Base_Model {
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'ProcessOutput';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'number'=>0,
            'version'=>0,
            'sac'=>0,
            'sic'=>0,
            'stationName'=>"",
            'latitudeDegree'=>0,
            'latitudeMinute'=>0,
            'latitudeSecond'=>0,
            'longitudeDegree'=>0,
            'longitudeMinute'=>0,
            'longitudeSecond'=>0,
            'height'=>0,
            'groupAddressA'=>"",
            'inPortA'=>0,
            'ChannelAStatus'=>"",
            'groupAddressB'=>"",
            'inPortB'=>0,
            'ChannelBStatus'=>"",
            'filterCrc'=>0,
            'filterErrorPacket'=>0,
            'filterEnabled'=>0,
            'filterSacSic'=>0,
            'enabled'=>0,
            'StnId'=>0,
            'NTId'=>0,
        );
    }
}