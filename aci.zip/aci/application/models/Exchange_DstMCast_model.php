<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-30
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
class Exchange_DstMCast_model extends Base_Model {
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'ExchangeDstMCast';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'DstId'=>0,
            'Note'=>"",
            'DstMCastIp'=>"",
            'DstMCastInterface'=>"",
            'DstMCastPort'=>0,
            'Ttl'=>0,
            'IsLoop'=>0,
            'NTId'=>0,
            'EthNum'=>"",
            'StnId'=>0,
            'usetype'=>0
        );
    }
}