<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 17-2-8
 * Time: 下午1:48
 * To change this template use File | Settings | File Templates.
 */
class Station_grade_model extends Base_Model{
    var $page_size = 5;
    public  function __construct(){
        $this->table_name = 'station_grade';
        parent::__construct();
    }

    function default_info(){
        return array(
            'station_level_id'=>0,
            'station_level_name'=>"",
        );
    }
}