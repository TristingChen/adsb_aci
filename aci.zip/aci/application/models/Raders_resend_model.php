<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 17-2-8
 * Time: 下午1:48
 * To change this template use File | Settings | File Templates.
 */
class Raders_resend_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'raders_resend';
        parent::__construct();
    }
    public function tables_select($where = '', $data = '*', $limit = '', $order = '', $group = '', $key='') {
            
        if (!empty($where))
        {
            $where = $this->db->where($where);
        }
        $data=str_replace("，",",",$data);
        $this->db->select($data);
        if(!empty($limit))
        {
            $limit_arr=explode(",", $limit);
            if(count($limit_arr)==1)
                $this->db->limit($limit);
            else
                $this->db->limit($limit_arr[1],$limit_arr[0]);
        }
        if(!empty($order))$this->db->order_by($order);
        if(!empty($group))$this->db->group_by($group);

        $this->db->from($this->table_name);
        $this->db->join('t_sys_station_config', 't_sys_station.station_id = t_sys_station_config.station_id');
        $Q = $this->db->get();
        if ($Q->num_rows() > 0)
        {
            foreach ($Q->result_array() as $rs)
            {
                if($key) {
                    $datalist[$rs[$key]] = $rs;
                } else {
                    $datalist[] = $rs;
                }
            }
        }

        $Q->free_result();
        return $datalist;
    }
    function default_info(){
        return array(
            'rader_id'=>0,
            'resend_ip'=>"",
            'resend_port'=>"",
            'cast_type'=>"",
            'resend_group_ip'=>"",

        );
    }
}