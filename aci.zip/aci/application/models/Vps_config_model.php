<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
class Vps_config_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'vps_config';
        parent::__construct();
    }



    function default_info(){
        return array(
            'id'=>'',
            'is_open_channel_by_self'=>'',
            'tdoa'=>"",
            'delay'=>"",
            'tdoa_error_rack_send'=>"",
            'radar_error_rack_send'=>"",
            'range_error_rack_send'=>"",
            'in_height'=>"",
            'in_speed'=>"",
            'in_time'=>"",
            'in_pos'=>"",
            'in_angle'=>"",
            'in_count'=>"",
            'rader_rate'=>"",
            'max_speed'=>"",
            'disappear_time_sec'=>"",
            'in_jump_time_sec'=>"",
            'jump_position_distance'=>"",
            'jump_height_distance'=>"",
            'max_virtual_speed'=>0.00,
            'chk_duration_microsec'=>0,
            'min_track_points'=>0,
            'fusion_point_distance'=>0,
            'fusion_point_height'=>0,
            'low_height'=>0
        );
    }
}