<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-5-10
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
class Publish_send_model extends Base_Model {
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'PublishSendModule';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'Name'=>"",
            'SendAddr'=>"",
            'Pri'=>0,
            'Delay'=>0,
            'Freq'=>0,
            'CompanyName'=>"",
            'Sources'=>"",
            'SourcesId'=>"",
            'SendCastTypeId'=>0,
            'NTId'=>0,
            'cast_type'=>0
        );
    }
}