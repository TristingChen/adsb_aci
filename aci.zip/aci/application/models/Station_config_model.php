<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 17-2-8
 * Time: 下午1:48
 * To change this template use File | Settings | File Templates.
 */
class Station_config_model extends Base_Model{
    var $page_size = 5;
    public  function __construct(){
        $this->table_name = 'station_config';
        parent::__construct();
    }

    function default_info(){
        return array(
            'station_id'=>0,
            'send_ip_A'=>"",
            'send_port_A'=>"",
            'exchange_eth_id_A'=>1,
            'cast_type_A'=>1,
            'channel_status_A'=>1,
            'send_ip_B'=>"",
            'send_port_B'=>"",
            'exchange_eth_id_B'=>1,
            'cast_type_B'=>1,
            'channel_status_B'=>1,
            'data_version_A'=>'',
            'data_version_B'=>'',

        );
    }
}