<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 17-2-8
 * Time: 下午1:48
 * To change this template use File | Settings | File Templates.
 */
class Decoder_config_model extends Base_Model{
    var $page_size = 5;
    public  function __construct(){
        $this->table_name = 'decoder_config';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'send_original_note_1'=>"",
            'send_original_ip_1'=>"",
            'send_original_port_1'=>0,
            'send_original_interface_1'=>"",
            'send_original_cast_1'=>0,
            'send_original_type_1'=>0,
            'send_port_B'=>0,
            'send_original_note_2'=>"",
            'send_original_ip_2'=>"",
            'send_original_port_2'=>0,
            'send_original_interface_2'=>"",
            'send_original_cast_2'=>0,
            'send_original_type_2'=>0,
            'send_decoder_note_1'=>"",
            'send_decoder_ip_1'=>"",
            'send_decoder_port_1'=>0,
            'send_decoder_cast_1'=>0,
            'send_decoder_type_1'=>0,
            'send_decoder_note_2'=>"",
            'send_decoder_ip_2'=>"",
            'send_decoder_interface_2'=>"",
            'send_decoder_cast_2'=>0,
            'send_decoder_type_2'=>0,
			'hardware_id'=>0
        );
    }
}