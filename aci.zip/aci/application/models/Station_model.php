<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 17-2-8
 * Time: 下午1:48
 * To change this template use File | Settings | File Templates.
 */
class Station_model extends Base_Model{
    var $page_size = 20;
    private $changing_station_info = array(
        'version_alarm_A'=> 0,
        'version_alarm_B'=> 0,
        'channel_A_version'=>0,
        'channel_B_version'=>0,
        'cat023_status_A'=>0,
        'cat023_status_B'=>0,
        'channel_data_A'=>0,
        'channel_data_B'=>0,
        'channel_bite_A'=>0,
        'channel_bite_B'=>0,
        'channel_time_A'=>0,
        'channel_time_B'=>0,
        'alarm_status'=>0,
        'station_img'=>'station.img',
        'channel_status_A'=>0,
        'channel_status_B'=>0,
        'error_info'=>''
    );

    public  function __construct(){
        $this->table_name = 'station';
        parent::__construct();
    }
    /**
     * 查询多条数据并分页扩展
     * @param $where
     * @param $order
     * @param $page
     * @param $pagesize
     * @return unknown_type
     */
    final public function tables_listinfo($where = '',$data='*', $order = '', $page = 1, $pagesize = 20, $key='', $setpages = 10,$urlrule = '',$array = array()) {
        $this->db->join('t_sys_station_config', 't_sys_station.station_id = t_sys_station_config.station_id');
        $this->number = $this->count($where);

        $page = max(intval($page), 1);
        $offset = $pagesize*($page-1);
        if($offset>$this->number)
        {
            $page=round($this->number/$pagesize);
            $offset = max($pagesize*($page-1),0);
        }


        if($this->number >$pagesize)
            $this->pages = pages($this->number, $page, $pagesize, $urlrule, $array, $setpages);
        else
            $this->pages = "";
        $array = array();
        if ($this->number > 0) {
            return $this->tables_select($where, $data, "$offset, $pagesize", $order, '', $key);
        } else {
            return array();
        }
    }

    public function tables_select($where = '', $data = '*', $limit = '', $order = '', $group = '', $key='') {

        if (!empty($where))
        {
            $where = $this->db->where($where);
        }
        $data=str_replace("，",",",$data);
        $this->db->select($data);
        if(!empty($limit))
        {
            $limit_arr=explode(",", $limit);
            if(count($limit_arr)==1)
                $this->db->limit($limit);
            else
                $this->db->limit($limit_arr[1],$limit_arr[0]);
        }
        if(!empty($order))$this->db->order_by($order);
        if(!empty($group))$this->db->group_by($group);

        $this->db->from($this->table_name);
        $this->db->join('t_sys_station_config', 't_sys_station.station_id = t_sys_station_config.station_id');
        $Q = $this->db->get();
        if ($Q->num_rows() > 0)
        {
            foreach ($Q->result_array() as $rs)
            {
                if($key) {
                    $datalist[$rs[$key]] = $rs;
                } else {
                    $datalist[] = $rs;
                }
            }
        }

        $Q->free_result();
        return $datalist;
    }
    function default_info(){
        return array(
            'station_id'=>0,
            'station_name'=>"",
            'station_ip'=>"",
            'data_version'=>"",
            'sac_code'=>"",
            'sic_code'=>"",
            'station_height'=>"",
            "station_status"=>"",
            'station_lng'=>"",
            'station_lat'=>"",
            'is_station'=>'0',
            'tdoa_check'=>1,
            'rader_check'=>1,
            'is_send'=>1,
            'update_route'=>0,
            'rader_ids'=>0,
            'is_monitor'=>0
        );
    }
    private function httpGet($url){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($curl);
        return $result;
    }


    //实时监控中共用的方法
    function one_stations_status($data_list,$the_key,$line_cout){
        //判断日志服务器的进程状态 并判断当前是属于哪个服务器上面
        if(substr($_SERVER['SERVER_ADDR'],-1,1) == 1){
            //a服务器
            $cmlr_a_path = CMLR_A_FILE_PATH;
            $cmlr_b_path = CMLR_B_FILE_PATH;
        }else{
            //b服务器
            $cmlr_a_path = CMLR_B_FILE_PATH;
            $cmlr_b_path = CMLR_A_FILE_PATH;
        }
        if(file_exists($cmlr_a_path)){
            $cmlr_a_fh = fopen($cmlr_a_path, 'r');
            $cmlr_a_json_str = file_json_lines($cmlr_a_fh,'{');
            if(isset($cmlr_a_json_str['forkArray'][0]['application']['hearbeatTimeOut'])){
                $hearbeat_a = $cmlr_a_json_str['forkArray'][0]['application']['hearbeatTimeOut'];
            }else{
                $hearbeat_a = false;
            }

            $cmlr_b_fh = fopen($cmlr_b_path, 'r');
            $cmlr_b_json_str = file_json_lines($cmlr_b_fh,'{');
            if(isset($cmlr_b_json_str['forkArray'][0]['application']['hearbeatTimeOut'])){
                $hearbeat_b = $cmlr_b_json_str['forkArray'][0]['application']['hearbeatTimeOut'];
            }else{
                $hearbeat_b = false;
            }

            if(!$hearbeat_a && $hearbeat_b ){
                //进行另一个服务器的备用api数据调用
//                return ;
            }
        }else{
            //暂时不理会
        }
        //默认即将要修改的数据
        $changing_station_info = $this->changing_station_info;

        $data_list['new_cat_A'] = $data_list['sac_code_A'].'_'.$data_list['sic_code_A'];
        $data_list['new_cat_B'] = $data_list['sac_code_B'].'_'.$data_list['sic_code_B'];
        $a_cat023_dir = CAT023_PATH.'A/';
        $b_cat023_dir = CAT023_PATH.'B/';
        $a_cat247_dir = CAT247_PATH.'A/';
        $b_cat247_dir = CAT247_PATH.'B/';

        $station_num_file = STATION_NUM_FIEL;
        $alarm_arr=  array();

        $date = date('Y-m-d');
        $data_upper_limit_A_file = STATISTICS_PATH . "0/" . $date . "/" . STATISTICSDATA;  //A同道
        $data_upper_limit_B_file = STATISTICS_PATH . "1/" . $date . "/" . STATISTICSDATA;
        $msg_current_path = SNMP_DEAL_PATH.'BDCD-A/snmpret'.date('Ymd');

        $a_cat023_dir_path = $a_cat023_dir.$data_list['new_cat_A'];
        $b_cat023_dir_path = $b_cat023_dir.$data_list['new_cat_B'];

        $a_cat247_dir_path = $a_cat247_dir.$data_list['new_cat_A'];
        $b_cat247_dir_path = $b_cat247_dir.$data_list['new_cat_B'];
        //进行当前通道判断 以及背景图的主备状态判断
        $alarm_arr['a_file_error'] = 0;
        $alarm_arr['b_file_error'] = 0;
        $alarm_arr['is_station'] = $data_list['is_station'];
        $alarm_arr['station_id'] = $data_list['station_id'];
        $alarm_arr['is_monitor'] = $data_list['is_monitor'];
        $alarm_arr['error_info'] = '';
        $station_wrong =array();

        if($data_list['enable_A'] == 1 || $data_list['enable_A'] == 3){
            if($data_list['cat023_switch']){
                $alarm_arr = $this->file_time_check($a_cat023_dir_path,$alarm_arr,$the_key,'a_file_error','cat023_status_A',$data_list['cat023_route'],$version_check=false,$data_list['data_version_B'],$data_list['station_id'],$data_list['station_name'],$changing_station_info);

            }
            if($data_list['cat247_switch']){
                $alarm_arr = $this->file_time_check($a_cat247_dir_path,$alarm_arr,$the_key,'a_file_error','',$data_list['cat247_route'],$version_check=true,$data_list['data_version_A'],$data_list['station_id'],$data_list['station_name'],$changing_station_info,'version_alarm_A','channel_A_version');
            }
            // print_r($alarm_arr);exit;
            $alarm_arr = $this->read_data_limit_file($data_upper_limit_A_file,$alarm_arr,$the_key,'enable_A','a_file_error',$data_list['station_id'],$data_list['station_name'],$line_cout,$changing_station_info);

        }
        if($data_list['enable_B']==1 || $data_list['enable_B'] == 3){
            if($data_list['cat023_switch']){
                $alarm_arr = $this->file_time_check($b_cat023_dir_path,$alarm_arr,$the_key,'b_file_error','cat023_status_B',$data_list['cat023_route'],$version_check=false,$data_list['data_version_B'],$data_list['station_id'],$data_list['station_name'],$changing_station_info);

            }
            if($data_list['cat247_switch']){
                $alarm_arr = $this->file_time_check($b_cat247_dir_path,$alarm_arr,$the_key,'b_file_error','',$data_list['cat247_route'],$version_check=true,$data_list['data_version_B'],$data_list['station_id'],$data_list['station_name'],$changing_station_info,'version_alarm_B','channel_B_version',$changing_station_info);
            }
            $alarm_arr = $this->read_data_limit_file($data_upper_limit_B_file,$alarm_arr,$the_key,'enable_B','b_file_error',$data_list['station_id'],$data_list['station_name'],$line_cout,$changing_station_info);
        }
        //当前主备状态的判断
        $this->current_path_jurge($the_key,$msg_current_path,$data_list);

        /* }else{
             @$this->xml_read_jurge($station_num_file,$data_list);
         }*/

        //进行数据统计文件的查询
        //获得全部的报警数据  进行背景图的修改  并修改数据库的状态
        //进行主备状态的获取
        $update_data = array();
        if($alarm_arr['is_monitor']){
            if($alarm_arr['a_file_error']>0 || $alarm_arr['b_file_error']>0 ){
//                $update_data['alarm_status'] = 1;
//                $update_data['station_img'] = 'station1.png';
                $changing_station_info['alarm_status'] = 1;
                $changing_station_info['station_img'] = 'station1.png';

            }else{
//                $update_data['alarm_status'] = 0;
//                $update_data['station_img'] = 'station.png';
                $changing_station_info['alarm_status'] = 0;
                $changing_station_info['station_img'] = 'station0.png';
                $update_data['sound_switch'] = 1;
            }
        }else{
//            $update_data['alarm_status'] = 0;
//            $update_data['station_img'] = 'station2.png';
            $changing_station_info['alarm_status'] = 0;
            $changing_station_info['station_img'] = 'station2.png';
        }
        if(!empty($update_data)){
            $this->Station_model->update($update_data,array('station_id'=>$alarm_arr['station_id']));
        }

        if(isset($alarm_arr['channel_data_A'])){
            $changing_station_info['channel_data_A'] =  $alarm_arr['channel_data_A'];
//            $update_con_data['channel_data_A'] = $alarm_arr['channel_data_A'];
        }
        if(isset($alarm_arr['channel_data_B'])){
            $changing_station_info['channel_data_B'] =  $alarm_arr['channel_data_B'];
//            $update_con_data['channel_data_B'] = $alarm_arr['channel_data_B'];
        }
//        $update_con_data['channel_status_A'] = $alarm_arr['a_file_error']?0:1;
//        $update_con_data['channel_status_B'] = $alarm_arr['b_file_error']?0:1;
        $changing_station_info['channel_status_A'] =  $alarm_arr['a_file_error']?0:1;
        $changing_station_info['channel_status_B'] =  $alarm_arr['b_file_error']?0:1;
//        $res = $this->Station_config_model->update($update_con_data,array('station_id'=>$alarm_arr['station_id']));
        $last_station_warning_log = getcache('station_warning_log_cache_'.$data_list['station_id']);
        if($alarm_arr['error_info']){
            if($last_station_warning_log){
                if(strcasecmp($last_station_warning_log, $alarm_arr['error_info']) != 0 ){  //两次告警内容不相同
                    $this->Station_warning_logs_model->insert(array('station_id'=>$data_list['station_id'],'log_content'=>$alarm_arr['error_info'],'dateline'=>time()));
                }
            }else{
                $this->Station_warning_logs_model->insert(array('station_id'=>$data_list['station_id'],'log_content'=>$alarm_arr['error_info'],'dateline'=>time()));
            }
            setcache('station_warning_log_cache_'.$data_list['station_id'],$alarm_arr['error_info']);

        }
        $error_info = $alarm_arr['error_info'] !== ''?$data_list['station_name'].':'.$alarm_arr['error_info']:'';
        $error_info = rtrim($error_info,',');
        $changing_station_info['error_info'] = $error_info;
        $station_data = $this->_cache_station();
        $station_data = array_merge($changing_station_info,$station_data);
        return $station_data;
//        return $alarm_arr['error_info'] != ''?$data_list['station_name'].':'.$alarm_arr['error_info']:'';

    }

    //并进行数据库的修改
    private function file_time_check($file_path,$alarm_arr=array(),$key,$error_key,$cat023_status,$time_route,$version_check=false,$data_version = 0,$station_id = 0,$station_name='',&$changing_station_info,$version_alarm_kind = 'version_alarm_A',$channel_path_version=0){
        if(!isset($alarm_arr[$error_key])){
            $alarm_arr[$error_key] = 0;
        }
        if(!isset($alarm_arr['error_info'])){
            $alarm_arr['error_info']='';
        }
        if($error_key == 'a_file_error'){
            $s_route = 'A通道';
        }else{
            $s_route = 'B通道';
        }
        $error_str = '';
        if($version_check){
            //cat247
            if(file_exists($file_path)){
                $file_time = filemtime($file_path);
                $subtraction_time = time()-$file_time;
                if($subtraction_time > $time_route ){
                    $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                    $alarm_arr['error_info'] .= $s_route.'cat247文件更新时间超时,';
//                    @$this->Station_config_model->update(array($version_alarm_kind=>-1),array('station_id'=>$station_id));
                    $changing_station_info[$version_alarm_kind] = -1;
                }else {
                    # code...
                    $cat247_str = file_get_contents($file_path);
                    $v1_site = strpos($cat247_str,'Main Version Number:');
                    $v2_site = strpos($cat247_str,'Sub Version Number:');
                    $v1_num = trim(substr($cat247_str, $v1_site+21,$v2_site-$v1_site-23));
                    $v2_num = trim(substr($cat247_str,$v2_site+20));
                    if(strval($data_version) != strval($v1_num.'.'.$v2_num)){

                        $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                        $alarm_arr['error_info'] .= $s_route.'cat247信息版本不匹配,';
                        $changing_station_info[$version_alarm_kind] = -1;
                        $changing_station_info[$channel_path_version] = $v1_num.'.'.$v2_num;
//                        $this->Station_config_model->update(array($version_alarm_kind=>1,$channel_path_version=>$v1_num.'.'.$v2_num),array('station_id'=>$station_id));
                    }else{
                        $this->Station_config_model->update(array($version_alarm_kind=>0,$channel_path_version=>$v1_num.'.'.$v2_num),array('station_id'=>$station_id));
                    }
                }

            }else {
                $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                $alarm_arr['error_info'] .= $s_route.'cat247文件不存在,';
                $changing_station_info[$version_alarm_kind] = -1;

//                @$this->Station_config_model->update(array($version_alarm_kind=>-1),array('station_id'=>$station_id));
            }


        }else{
            //cat023的三个数据项
            $file_path1 = $file_path.'_1 ';
            $file_path2 = $file_path.'_2 ';
            $file_path3 = $file_path.'_3 ';
            if(file_exists($file_path1)!=true || file_exists($file_path2)!=true || file_exists($file_path3) != true){
                $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                $alarm_arr['error_info'] .= $s_route.'cat023文件不存在,';
                $changing_station_info[$cat023_status] = -1;

//                @$this->Station_config_model->update(array($cat023_status=>-1),array('station_id'=>$station_id));
                setcache($cat023_status.'_file','<div class="red_status">数据包流失</div>');
            }else{

                $sub_time1 = time()-filemtime($file_path1);
                $sub_time2 = time()-filemtime($file_path2);
                $sub_time3 = time()-filemtime($file_path3);
                if($sub_time1 > $time_route || $sub_time2 > $time_route || $sub_time3 > $time_route){
                    $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                    $alarm_arr['error_info'] .= $s_route.'cat023更新时间超时,';
                    $changing_station_info[$cat023_status] = -1;
//                    @$this->Station_config_model->update(array($cat023_status=>-1),array('station_id'=>$station_id));
                    setcache($cat023_status.'_file','<div class="red_status">数据包流失</div>');
                }else{

                    $cat023_type_1 = $this->cat023_get($file_path1,0,'type1');
                    $cat023_type_2 = $this->cat023_get($file_path2,$cat023_type_1['error_num'],'type2');
                    $cat023_type_3 = $this->cat023_get($file_path3,$cat023_type_2['error_num'],'type3');
                    $a_dl = $cat023_type_1['cat023_str'].$cat023_type_2['cat023_str'].$cat023_type_3['cat023_str'];
                    $error_num = $cat023_type_3['error_num'];
                    setcache($cat023_status.'_file',$a_dl);
                    if($error_num >0){
                        $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                        $alarm_arr['error_info'] .= $s_route.'cat023信息传输数据异常,';
                        $changing_station_info[$cat023_status] = 0;
//                        @$this->Station_config_model->update(array($cat023_status=>0),array('station_id'=>$station_id));
                    }else{
                        $changing_station_info[$cat023_status] = 1;
//                        @$this->Station_config_model->update(array($cat023_status=>1),array('station_id'=>$station_id));
                    }

                }
            }
        }
        return $alarm_arr;
    }
    //cat023文件的获取判断
    private function cat023_get($file_path,$error_num=0,$type=''){
        $handle = fopen($file_path, 'r');
        $a_dl = '<dl>';
        $a_dl .= '<dd><h3>'.$type.'</h3></dd>';
        while (!feof($handle)) {
            $line = fgets($handle);
            if(strpos($line,'not connected') !==false || strpos($line,'invalid') !==false || strpos($line,'Overload in transmission subsystem') !==false || strpos($line,'potential') !==false || strpos($line,'Failed') !==false || strpos($line,'Disabled') !==false || strpos($line,'Degraded') !==false || strpos($line, 'No information') !==false)
            {
                $a_dl .= '<dd class="red_status">'.$line.'</dd>';
                $error_num++;
            }
            else
            {
                $a_dl .= '<dd>'.$line.'</dd>';
            }
        }
        fclose($handle);
        $a_dl .= '</dl>';
        return array('error_num'=>$error_num,'cat023_str'=>$a_dl);
    }
    private function read_data_limit_file($path,$alarm_arr,$key,$kind_key,$error_key,$station_id,$station_name='',$line_cout,&$changing_station_info){
        //1先判断文件存不存  2文件超时与否 3是否是写完 4是否告警
        if(!isset($alarm_arr['error_info'])){
            $alarm_arr['error_info']='';
        }
        if(file_exists($path)){

            if(time()- filemtime($path) > 60){
                //文件超时
                $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                if($kind_key == 'enable_A'){
                    $alarm_arr['channel_data_A'] = 0;
                    $alarm_arr['error_info'] .= 'A通道航迹量信息更新超时,';
                }else{
                    $alarm_arr['channel_data_B'] = 0;
                    $alarm_arr['error_info'] .= 'B通道航迹量信息更新超时,';
                }

            }else{
                $file_open = fopen($path,'r');

                $str_arr = array();
                $one_line = lline_tail($file_open,$line_cout);
                // print_r($key);exit;
                if(count($one_line) == $line_cout) {
                    if(!empty($one_line) && strpos($one_line[0], 'begin') !== false && strpos($one_line[$line_cout-1], 'end') !== false){
                        $tmp_str = '';
                        foreach ($one_line as $kk => $vv) {
                            if(strpos( $vv,'SOURCEID:'.$key.';') !== false){
                                $tmp_str = $vv;
                                break;
                            }
                        }
                        if(empty($tmp_str)){
                            // print_r($one_line);exit;
                            $alarm_arr[$error_key] =   $alarm_arr[$error_key]+1;
                            if($kind_key == 'enable_A'){
                                $alarm_arr['channel_data_A'] = 0;
                                $alarm_arr['error_info'] .= 'A通道航迹量信息没有匹配项,';

                            }else{
                                $alarm_arr['channel_data_B'] = 0;
                                $alarm_arr['error_info'] .= 'B通道航迹量信息没有匹配项,';

                            }
                        }else{
                            $one_line_arr = explode(';', $tmp_str);
                            $count_str = $one_line_arr[2];
                            $goal_count = substr($count_str, 11);
                            $channel_bite_val = substr($one_line_arr[15],5)!=''?substr($one_line_arr[15],5):0;

                            if($kind_key == 'enable_A'){
                                $changing_station_info['channel_bite_A'] = $channel_bite_val;
//                                $this->Station_config_model->update(array('channel_bite_A'=>$channel_bite_val),array('station_id'=>$station_id));
                            }else{
                                $changing_station_info['channel_bite_B'] = $channel_bite_val;
//                                $this->Station_config_model->update(array('channel_bite_B'=>$channel_bite_val),array('station_id'=>$station_id));
                            }
                            if($goal_count == 0){
                                $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                                if($kind_key == 'enable_A'){
                                    $alarm_arr['error_info'] .= 'A通道航迹量信息为0,';
                                    $alarm_arr['channel_data_A'] = 0;
                                }else{
                                    $alarm_arr['error_info'] .= 'B通道航迹量信息为0,';
                                    $alarm_arr['channel_data_B'] = 0;
                                }
                            }else{
                                /* $tmp = $data_upper_limit_kind-$goal_count<0?1:0;
                                 $alarm_arr[$error_key] =  $alarm_arr[$error_key]+$tmp;*/
                                if($kind_key == 'enable_A'){
                                    $alarm_arr['channel_data_A'] = $goal_count;
                                }else{
                                    $alarm_arr['channel_data_B'] = $goal_count;
                                }
                            }
                            $last_line = $one_line[0];
                            $end_time = strtotime(trim(explode(';', $last_line)[1]));
                            // var_dump($station_id);exit;
                            $jurge_goal = jurge_station_limit($goal_count,$end_time,$station_id);
                            if($kind_key == 'enable_A'){
                                $alarm_arr['channel_data_A'] = $goal_count;
                                $changing_station_info['channel_time_A'] = $end_time;
//                                $this->Station_config_model->update(array('channel_time_A'=>$end_time),array('station_id'=>$station_id));

                            }else{
                                $alarm_arr['channel_data_B'] = $goal_count;
                                $changing_station_info['channel_time_B'] = $end_time;
//                                $this->Station_config_model->update(array('channel_time_B'=>$end_time),array('station_id'=>$station_id));
                            }
                            // var_dump($jurge_goal);
                            if($jurge_goal){
                                $alarm_arr[$error_key] = $alarm_arr[$error_key]+0;
                            }else{
                                if($kind_key == 'enable_A'){
                                    $alarm_arr['error_info'] .= 'A通道航迹量小于最小航迹量,';
                                }else{
                                    $alarm_arr['error_info'] .= 'B通道航迹量小于最小航迹量,';
                                }
                                $alarm_arr[$error_key] = $alarm_arr[$error_key]+1;
                            }
                        }
                    }else{
                        $alarm_arr[$error_key] =   $alarm_arr[$error_key]+1;
                        if($kind_key == 'enable_A'){
                            $alarm_arr['channel_data_A'] = 0;
                            $alarm_arr['error_info'] .= 'A通道数据信息获取不完整,';

                        }else{
                            $alarm_arr['error_info'] .= 'B通道数据信息获取不完整,';

                            $alarm_arr['channel_data_B'] = 0;
                        }
                    }

                }else{
                    //数据写入不完全

                }



            }

        }else{
            $alarm_arr[$error_key] =  $alarm_arr[$error_key]+1;
            if($kind_key == 'enable_A'){
                $alarm_arr['channel_data_A'] = 0;
                $alarm_arr['error_info'] .= 'A通道数据信息获取失败,';

            }else{
                $alarm_arr['channel_data_B'] = 0;
                $alarm_arr['error_info'] .= 'B通道数据信息获取失败,';

            }

        }
        return $alarm_arr;
    }

    //主备判断与基站通道关闭状态的判断
    private function current_path_jurge($key,$path,$value){
        if(file_exists($path)){
            $file_time = filemtime($path);
            if(time()-$file_time >60){
                return ;
            }
            if(getcache('station_filemtime_'.$value['station_id'])){
                if($file_time == getcache('station_filemtime_'.$value['station_id'])){
                    return ;
                }
            }
            $fh = fopen($path, 'r');
            $decode_json = file_json_lines($fh,'{');
            $decode_arr = json_decode($decode_json,true);

            if($decode_arr && isset($decode_arr['forkArray'])){
                if(!isset($decode_arr['forkArray'][0]['application']['appItemContent'])){
                    return false;
                }
                $appItemContent = $decode_arr['forkArray'][0]['application']['appItemContent'];
                $appReportTime = $decode_arr['forkArray'][0]['application']['appReportTime'];
                $app_item_arr = explode(';', $appItemContent);
                //判断报告时间有无变化
                // var_dump($appItemContent);exit;

                if(getcache('station_report_time_'.$value['station_id'])){
                    if(getcache('station_report_time_'.$value['station_id']) == $appReportTime ){
                        return ;
                    }
                }
                if(isset($app_item_arr[$key])){
                    setcache('station_filemtime_'.$value['station_id'],$file_time);
                    setcache('station_report_time_'.$value['station_id'],$appReportTime);

                    $main_status = explode(',', $app_item_arr[$key]);
                    $ab_status = $main_status[3];
                    $data_config['enable_A'] = $main_status[1]<0?0:1;
                    $data_config['enable_B'] = $main_status[2]<0?0:1;

                    if($ab_status == 'A'){
                        $data['current_work_pass'] = 1;
                        @$this->Station_model->update($data,array('station_id'=>$value['station_id']));
                    }else{
                        $data['current_work_pass'] = 2;
                        @$this->Station_model->update($data,array('station_id'=>$value['station_id']));

                    }

                    $station_data = @$this->Station_config_model->get_one(array('station_id'=>$value['station_id']));
                    //判断操作过期 再进行通道状态的自动修改
                    if(!getcache('switch_station_'.$value['station_id'])){
                        if($station_data['enable_A'] == 1 || $station_data['enable_A'] == 3)
                        {
                            if($main_status[1] < 0)
                            {
                                $data_config['enable_A'] = 2;
                                @$this->Station_config_model->update($data_config,array('station_id'=>$value['station_id']));
                            }

                        }elseif($station_data['enable_A'] == 2){
                            if($main_status[1] > 0)
                            {
                                $data_config['enable_A'] = 3;
                                @$this->Station_config_model->update($data_config,array('station_id'=>$value['station_id']));
                            }
                        }
                        if($station_data['enable_B'] == 1 || $station_data['enable_B'] == 3)
                        {
                            if($main_status[2] < 0)
                            {
                                $data_config['enable_B'] = 2;
                                @$this->Station_config_model->update($data_config,array('station_id'=>$value['station_id']));
                            }

                        }elseif($station_data['enable_B'] == 2){
                            if($main_status[2] > 0)
                            {
                                $data_config['enable_B'] = 3;
                                @$this->Station_config_model->update($data_config,array('station_id'=>$value['station_id']));
                            }
                        }
                    }
                }



            }else{
                //不管
            }

        }else{
            //不作为
        }
    }

    //雷达实时监控逻辑
    public function rader_status(){
         $rader_data = $this->Raders_model->select('is_del = 0','id,name,switch,rader_alarm,is_monitor,path_switch_a,path_switch_b,path_a_alarm,path_b_alarm,rader_a_bag,rader_b_bag,in_work_option');
        $rader_server = $this->Hardware_model->get_one(array('hardware_other_name'=>'RDCD-A'),'is_main');
        $rader_read_path = 'RDCD-A';
        if($rader_server['is_main'] == 0){
            $rader_read_path = 'RDCD-B';
        }
        $rader_alarm_arr = array();
        $varify_path = RADER_LOG_PATH.$rader_read_path.'/varifier_'.date('Ymd').'.log';
        $read_rader_res = $this->read_rader_file($varify_path);
        if($rader_data){
            foreach ($rader_data as $key => $value) {
                // $rader_alarm_arr[$value['id']] = $value;
                if($value['is_monitor'] == 1){
                    if(isset($read_rader_res[$key])){
                        //判断ab通道开启的状况 改变ab数据量与告警信息
                        if($value['path_switch_a'] && $value['path_switch_b']){
                            if(!in_array(0, $read_rader_res[$key])){
                                $rader_new_alarm = 0;
                                $rader_img = 'satellite_antenna.png';
                                $sound_switch = 1;
                                $path_a_alarm = 0;
                                $path_b_alarm = 0;
                                //改变数据库报警状态

                            }else{
                                $sound_switch = 0;
                                $rader_new_alarm = 1;
                                $rader_img = 'satellite_antenna1.png';
                                if($read_rader_res[$key][0]){
                                    $path_a_alarm = 0;
                                }else{
                                    $path_a_alarm = 1;
                                }
                                if($read_rader_res[$key][1]){
                                    $path_b_alarm = 0;
                                }else{
                                    $path_b_alarm = 1;
                                }
                            }
                        }elseif($value['path_switch_a'] && !$value['path_switch_b']){
                            if($read_rader_res[$key][0] == 0){
                                $rader_new_alarm = 1;
                                $rader_img = 'satellite_antenna1.png';
                                $sound_switch = 0;
                                $path_a_alarm = 1;
                                $path_b_alarm = 0;
                                //改变数据库报警状态
                            }else{
                                $rader_new_alarm = 0;
                                $rader_img = 'satellite_antenna.png';
                                $sound_switch = 1;
                                $path_a_alarm = 0;
                                $path_b_alarm = 0;
                                //改变数据库报警状态
                            }


                        }elseif(!$value['path_switch_a'] && $value['path_switch_b']){
                            if($read_rader_res[$key][1] == 0){
                                $rader_new_alarm = 1;
                                $rader_img = 'satellite_antenna1.png';
                                $sound_switch = 0;
                                $path_a_alarm = 0;
                                $path_b_alarm = 1;
                            }else{
                                $rader_new_alarm = 0;
                                $rader_img = 'satellite_antenna.png';
                                $sound_switch = 1;
                                $path_a_alarm = 0;
                                $path_b_alarm = 0;
                            }
                        }else{
                            $rader_new_alarm = 0;
                            $rader_img = 'satellite_antenna.png';
                            $sound_switch = 1;
                            $path_a_alarm = 0;
                            $path_b_alarm = 0;
                        }
                        $report_time = $read_rader_res[$key][2];
                        $rader_a_bag = $read_rader_res[$key][0];
                        $rader_b_bag = $read_rader_res[$key][1];
                        if($sound_switch){
                            $this->Raders_model->update(array('rader_alarm'=>$rader_new_alarm,'rader_img'=>$rader_img, 'sound_switch'=>1,'report_time'=>$report_time,'rader_a_bag'=>$rader_a_bag,'path_a_alarm'=>$path_a_alarm,'rader_b_bag'=>$rader_b_bag,'path_b_alarm'=>$path_b_alarm),array('id'=>$value['id']));
                        }else{
                            $this->Raders_model->update(array('rader_alarm'=>$rader_new_alarm,'rader_img'=>$rader_img,'report_time'=>$report_time,'rader_a_bag'=>$rader_a_bag,'path_a_alarm'=>$path_a_alarm,'rader_b_bag'=>$rader_b_bag,'path_b_alarm'=>$path_b_alarm),array('id'=>$value['id']));
                        }
                        /*if($value['path_switch_a']){
                            $this->Raders_model->update(array(),array('id'=>$value['id']));
                        }
                        if($value['path_switch_b']){
                            $this->Raders_model->update(array('rader_b_bag'=>$rader_b_bag,'path_b_alarm'=>$path_b_alarm),array('id'=>$value['id']));
                        }*/
                    }else{
                        $this->Raders_model->update(array('rader_alarm'=>1,'rader_img'=>'satellite_antenna1.png','rader_a_bag'=>0,'rader_b_bag'=>0,'path_a_alarm'=>1,'path_b_alarm'=>1,'report_time'=>0),array('id'=>$value['id']));
                    }
                }else{
                    $this->Raders_model->update(array('rader_alarm'=>0,'rader_img'=>'satellite_antenna2.png','rader_a_bag'=>0,'rader_b_bag'=>0,'path_a_alarm'=>0,'path_a_alarm'=>0,'report_time'=>0),array('id'=>$value['id']));
                }

            }
        }

    }
    //读取雷达的告警文件
    private function read_rader_file($path){
        $rader_bag = array();
        if(file_exists($path)){
            // var_dump(time()-filemtime($path));exit;
            if(time()-filemtime($path)>30){
                $rader_bag = array();
            }else{
                $fp = fopen($path, 'r');
                fseek($fp,-1,SEEK_END);

                $s = '';
                while(($c = fgetc($fp)) !== false)
                {
                    if($c == "\n" && $s) break;
                    $s = $c . $s;
                    fseek($fp, -2, SEEK_CUR);
                }
                fclose($fp);
                // var_dump($s);exit;
                if($s != ''){
                    $site = strpos($s, 'ITEMCONTENT');
                    $status = strpos($s, 'STATUS');
                    $the_str = substr($s, $site+15,$status-$site-17);
                    $the_str_arr = array_filter(explode(';', $the_str));

                    $time_sit = strpos($s, 'REPORTTIME');
                    $time_str = substr($s, $time_sit+14,19);
                    if($the_str_arr){
                        foreach ($the_str_arr as $kk => $vv) {
                            //0:0|0;
                            $vv = explode(':', $vv);
                            $patch_ab = explode('|', $vv[1]);
                            $rader_bag[$vv[0]] = array($patch_ab[0],$patch_ab[1],strtotime($time_str));
                        }
                    }else{
                        $rader_bag = array();
                    }
                }else{
                    $rader_bag = array();
                }

            }
        }
        return $rader_bag;
    }

    /**
     * 缓存基站数据
     */
    public function _cache_station()
    {
        $infos = $this->Station_model->tables_select('is_del = 0','t_sys_station.station_id,station_name,data_upper_limit_A,data_upper_limit_B,enable_A,enable_B,in_work_option,current_work_pass,sac_code_A,sic_code_A,sac_code_B,sic_code_B,is_monitor,sound_switch,is_station,cat023_switch,cat247_switch,send_ip_A,send_port_A,send_ip_B,send_port_B,canvas_x,canvas_y,cat247_route,cat023_route,data_version_A,data_version_B');
        if ($infos) {
            setcache('cache_all_station', $infos);
        }else{
            $infos = array();
        }
        return $infos;
    }
}