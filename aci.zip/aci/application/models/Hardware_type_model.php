<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-20
 * Time: 上午8:58
 * To change this template use File | Settings | File Templates.
 */
class Hardware_type_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'hardware_type';
        parent::__construct();
    }

    function default_info(){
        return array(
            'type_id'=>0,
            'type_name'=>"",
            'img_dir'=>""
        );
    }
}