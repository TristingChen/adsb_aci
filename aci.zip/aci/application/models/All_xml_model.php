<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenjialing
 * Date: 17-2-16
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */
class All_xml_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'all_xml';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'xml_name'=>'',
            'kind'=>"",
            'is_publish'=>0,
            'dateline'=>''
        );
    }


    public function xml_produce($xml_id_arr,$update_xml_file,$xml_name,$kind,$xml_path,$config_name){
            $this->db->trans_begin();
            if($xml_id_arr){
                $this->All_xml_model->update(array('xml_name'=>$update_xml_file,'is_old'=>1),array('id'=>$xml_id_arr['id']));
            }
            $insert_data['xml_name'] = $xml_name;
            $insert_data['dateline'] = time();
            $insert_data['kind'] = $kind;
            $insert_data['xml_path'] = $xml_path;
            $insert_data['config_name'] = $config_name;
            $res = $this->All_xml_model->insert($insert_data);
            if($this->db->trans_status() === false){
                $this->db->trans_rollback();
                return false;
            }else {
                $this->db->trans_commit();
                return true;
            }
    }
}