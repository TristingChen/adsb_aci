<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-30
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
class Replay_task_model extends Base_Model {
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'ReplayTask';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'addr'=>"",
            'time_begin'=>"",
            'time_end'=>"",
            'speed'=>0,
            'NTId'=>0,
        );
    }
}