<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-16
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */
class Login_captcha_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'login_captcha';
        parent::__construct();
        $this->load->helper("captcha");
    }

    public function getVcode(){
        $vals = array(
            'word' => rand(10000,100000),//验证码上显示的字符
            'img_path' => SITE_URL.'captcha/',//验证码保存路径
            'img_url' => SITE_URL.'captcha/', //验证码图片url
            // 'font_path' => './path/to/fonts/texb.ttf',//验证码上字体
            'img_width' => '100',
            'img_height' => 25,
            'expiration' => 100,
            'word_length' => 8,
            'font_size' => 16,
            'img_id' => 'Imageid',
            'pool' => '23456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
            'color' => array(
                'background' => array(255,255,255),
                'border' => array(255,255,255),
                'text' => array(0,0,0),
                'grid' => array(255,40,40)
            )
        );

        $cap = create_captcha($vals);
        return $cap;
    }

}