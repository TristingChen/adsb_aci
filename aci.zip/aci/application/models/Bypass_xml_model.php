<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenjialing
 * Date: 17-2-16
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */
class Bypass_xml_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'bypass_xml';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'bypass_xml_name'=>'',
            'dateline'=>"",
        );
    }
}