<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
class Data_export_users_model extends Base_Model{
    var $page_size = 20;
    public  function __construct(){
        $this->table_name = 'data_export_users';
        parent::__construct();
    }



    function default_info(){
        return array(
              'id'=>'',
              'type'=>'',
              'name' =>'', 
              'duration_switch' =>'',
              'duration_val'=>'',
              'delay_switch'=>'',
              'delay_val'=>'', 
              'select_item_switch'=>'',
              'select_item_version'=>'', 
              'select_item_val'=>'', 
              'send_a_ip'=>'', 
              'send_a_port'=>'', 
              'send_b_ip'=>'', 
              'send_b_port'=>'',
              'station_switch'=>'', 
              'station_list'=>'', 
              'station_flip'=>'',
              'target_add_switch'=>'', 
              'target_add_list'=>'',
              'target_add_flip'=>'', 
              'company_switch'=>'',
              'company_list'=>'',
              'company_flip'=>'',
              'range_switch'=>'',
              'range_list'=>'',
              'range_flip'=>'',
              'height_switch'=>'',
              'height_list'=>'',
              'height_flip'=>'',
              'dataline'=>'',
              'cast_type'=>1,
              'cast_type_b'=>'',
              'faker_range'=>1,
            'faker_radar'=>1,
            'faker_tdoa'=>1,
            'faker_plan'=>1,
            'faker_type'=>0,
            'is_output'=>0

        );
    }
}