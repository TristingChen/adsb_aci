<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-1-22
 * Time: 下午4:14
 * To change this template use File | Settings | File Templates.
 */
class App_status_model extends Base_Model{
    var $page_size = 6;
    public  function __construct(){
        $this->table_name = 'app_status';
        parent::__construct();
    }

    function defualt_info(){
        return array(
            'status_id'=>0,
            'data_source'=>"",
            'data_source_ip_port'=>"",
            'app_id'=>0,
            'count'=>0,
            'report_time'=>"",
            'alert_content'=>"",
            'is_receive'=>true
        );
    }
}