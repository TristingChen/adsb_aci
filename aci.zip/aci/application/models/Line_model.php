<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-22
 * Time: 下午5:12
 * To change this template use File | Settings | File Templates.
 */
class Line_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'line';
        parent::__construct();
    }

    function default_info(){
        return array(
            'line_id'=>0,
            'start_node_id'=>"",
            'end_node_id'=>"",
            'line_color_id'=>"",
            'line_type_id'=>"",
            'start_node_eth_id'=>0,
            'end_node_eth_id'=>0
        );
    }
}