<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-2-13
 * Time: 上午10:09
 * To change this template use File | Settings | File Templates.
 */

class Syslog_model extends Syslog_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'SystemEvents';
        parent::__construct();
    }

    function default_info(){
        return array(
            'ID'=>0,
            'CustomerID'=>0,
            'ReceivedAt'=>"",
            'DeviceReportedTime'=>"",
            'Facility'=>0,
            'Priority'=>0,
            'FromHost'=>"",
            'Message'=>"",
            'NTSeverity'=>0,
            'Importance'=>0,
            'EventSource'=>"",
            'EventUser'=>"",
            'EventCategory'=>0,
            'EventID'=>0,
            'EventBinaryData'=>"",
            'MaxAvailable'=>0,
            'CurrUsage'=>0,
            'MinUsage'=>0,
            'MaxUsage'=>0,
            'InfoUnitID'=>0,
            'SysLogTag'=>"",
            'EventLogType'=>"",
            'GenericFileName'=>"",
            'SystemID'=>0
        );
    }
}