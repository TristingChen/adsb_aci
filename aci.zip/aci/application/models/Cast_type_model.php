<?php if( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-31
 * Time: 上午11:17
 * To change this template use File | Settings | File Templates.
 */
class Cast_type_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'cast_type';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'cast_name'=>""
        );
    }
}