<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 17-2-8
 * Time: 下午1:48
 * To change this template use File | Settings | File Templates.
 */
class Raders_kind_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'raders_kind_info';
        parent::__construct();
    }

   
}