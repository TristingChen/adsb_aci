<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-7
 * Time: 下午5:00
 * To change this template use File | Settings | File Templates.
 */
class Snmp_oid_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'snmp_oid';
        parent::__construct();
    }

    function default_info(){
        return array(
            'oid_id'=>0,
            'oid_value'=>"",
            'request_type'=>"",
            'description'=>"",
            'is_cycle'=>0,
            'cycale_time'=>0
        );
    }
}