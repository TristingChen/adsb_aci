<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
class Warning_config_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'station_warning_config';
        parent::__construct();
    }



    function default_info(){
        return array(
            'station_id'=>0,
            'value1'=>"",
            'time_value1'=>"",
            'end_time_value1'=>"",
            'value2'=>"",
            'time_value2'=>"",
            'end_time_value2'=>"",
            'value3'=>"",
            'time_value3'=>"",
            'end_time_value3'=>"",
            'warning_switch'=>1
        );
    }
     /**
     * 查询多条数据并分页扩展
     * @param $where
     * @param $order
     * @param $page
     * @param $pagesize
     * @return unknown_type
     */
    final public function tables_listinfo($where = '',$data='*', $order = '', $page = 1, $pagesize = 20, $key='', $setpages = 10,$urlrule = '',$array = array()) {
        $this->db->join('t_sys_station', 't_sys_station_warning_config.station_id = t_sys_station.station_id');
        $this->number = $this->count($where);
        
        $page = max(intval($page), 1);
        $offset = $pagesize*($page-1);
        if($offset>$this->number)
        {
            $page=round($this->number/$pagesize);
            $offset = max($pagesize*($page-1),0);
        }
    

        if($this->number >$pagesize)
            $this->pages = pages($this->number, $page, $pagesize, $urlrule, $array, $setpages);
        else
            $this->pages = "";
        $array = array();
        if ($this->number > 0) {
            return $this->tables_select($where, $data, "$offset, $pagesize", $order, '', $key);
        } else {
            return array();
        }
    }

    public function tables_select($where = '', $data = '*', $limit = '', $order = '', $group = '', $key='') {
            
        if (!empty($where))
        {
            $where = $this->db->where($where);
        }
        $data=str_replace("，",",",$data);
        $this->db->select($data);
        if(!empty($limit))
        {
            $limit_arr=explode(",", $limit);
            if(count($limit_arr)==1)
                $this->db->limit($limit);
            else
                $this->db->limit($limit_arr[1],$limit_arr[0]);
        }
        if(!empty($order))$this->db->order_by($order);
        if(!empty($group))$this->db->group_by($group);

        $this->db->from($this->table_name);
        $this->db->join('t_sys_station', 't_sys_station_warning_config.station_id = t_sys_station.station_id');
        $Q = $this->db->get();
        if ($Q->num_rows() > 0)
        {
            foreach ($Q->result_array() as $rs)
            {
                if($key) {
                    $datalist[$rs[$key]] = $rs;
                } else {
                    $datalist[] = $rs;
                }
            }
        }

        $Q->free_result();
        return $datalist;
    }

    public function tables_get_one($where = '', $data = '*', $order = '', $group = '') {
        $datainfo= $this->tables_select($where , $data, '1', $order , $group);
        if(count($datainfo)>0)$datainfo=$datainfo[0];
        return $datainfo;
    }
}