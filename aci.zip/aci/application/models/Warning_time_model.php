<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-26
 * Time: 下午4:45
 * To change this template use File | Settings | File Templates.
 */
class Warning_time_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'warning_time';
        parent::__construct();
    }



    function default_info(){
        return array(
            'id'=>0,
            'value'=>0,
            'time_value'=>-1,
            'end_time_value'=>-1,
        );
    }
}