<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-30
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
class Replay_app_model extends Base_Model {
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'ReplayApp';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'DataFileDir'=>"",
            'IndexFileDir'=>"",
            'AppName'=>"",
            'ModuleName'=>0,
            'Monitor'=>"",
            'LogPath'=>"",
            'GrainSize'=>0,
            'LogFileLevel'=>0,
            'LogTermLevel'=>0,
            'LogTermColorful'=>0,
            'LogHead'=>"",
            'LogLimit'=>0,
            'NTId'=>0,
        );
    }
}