<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-30
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
class Process_blackOrwhite_model extends Base_Model {
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'ProcessBlackOrWhiteList';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'blackOrWhite'=>"",
            'FilePath'=>"",
            'NTId'=>0
        );
    }
}