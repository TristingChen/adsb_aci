<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenjialing
 * Date: 17-2-16
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */
class Xml_basic_config_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'xml_basic_config';
        parent::__construct();
    }

    function default_info(){
        return array(
            'kind_id'=>'',
            'name'=>'',
            'hardware_ids'=>"",
            'is_del'=>0,
            'remark'=>0,
            'basic_xml_name'=>''
        );
    }
}