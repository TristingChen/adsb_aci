<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-4-28
 * Time: 上午11:14
 * To change this template use File | Settings | File Templates.
 */

class Recv_cast_data_model extends Base_Model {
    var $page_size = 5;
    public  function __construct(){
        $this->table_name = 'recv_cast_data';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'Note'=>"",
            'RecvCastIp'=>"",
            'Interface'=>"",
            'RecvCastPort'=>0,
            'cast_type'=>0,
            'NTId'=>0,
        );
    }
}