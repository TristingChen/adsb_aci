<?php if( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: chenyong
 * Date: 17-3-31
 * Time: 上午11:17
 * To change this template use File | Settings | File Templates.
 */
class Rules_model extends Base_Model{
    var $page_size = 10;
    public  function __construct(){
        $this->table_name = 'rules';
        parent::__construct();
    }

    function default_info(){
        return array(
            'id'=>0,
            'rules'=>"",
            'eth_id'=>0,
            'is_enable'=>""
        );
    }
}