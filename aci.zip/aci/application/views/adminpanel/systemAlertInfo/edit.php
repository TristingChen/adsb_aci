<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>系统告警设置
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'systemAlertInfo','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
                <div class="form-group">
                    <label for="cpu_alert_value" class="col-sm-2 control-label">CPU告警值(%):</label>
                    <div class="col-sm-4">
                        <input name="cpu_alert_value"  type="text" id="cpu_alert_value"  cols="45" rows="5" class="form-control  validate[required,custom[cpu_alert_value]]" placeholder="请输入CPU告警值"  value="<?php echo isset($data_list['cpu_alert_value'])?$data_list['cpu_alert_value']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="memory_alert_value" class="col-sm-2 control-label">内存告警值(%):</label>
                    <div class="col-sm-4">
                        <input name="memory_alert_value"  type="text" id="memory_alert_value"  cols="45" rows="5" class="form-control  validate[required,custom[memory_alert_value]]" placeholder="请输入内存告警值"  value="<?php echo isset($data_list['memory_alert_value'])?$data_list['memory_alert_value']:'' ?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <label for="disk_alert_value" class="col-sm-2 control-label">磁盘使用上限(%):</label>
                    <div class="col-sm-4">
                        <input name="disk_alert_value"  type="text" id="disk_alert_value"  cols="45" rows="5" class="form-control  validate[required,custom[disk_alert_value]]" sacholder="请输入磁盘使用上限"  value="<?php echo isset($data_list['disk_alert_value'])?$data_list['disk_alert_value']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="NIC_recv_min_value" class="col-sm-2 control-label">网口接收数据流量下限:</label>
                    <div class="col-sm-4">
                        <input name="NIC_recv_min_value"  type="text" id="NIC_recv_min_value"  cols="45" rows="5" class="form-control" sicholder="请输入网口接收数据流量下限"  value="<?php echo isset($data_list['NIC_recv_min_value'])?$data_list['NIC_recv_min_value']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="NIC_recv_max_value" class="col-sm-2 control-label">网口接收数据流量上限:</label>
                    <div class="col-sm-4">
                        <input name="NIC_recv_max_value"  type="number" step="0.01" id="NIC_recv_max_value"  cols="45" rows="5" class="form-control" latholder="请输入网口接收数据流量上限"  value="<?php echo isset($data_list['NIC_recv_max_value'])?$data_list['NIC_recv_max_value']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="NIC_send_min_value" class="col-sm-2 control-label">网口发送数据流量下限:</label>
                    <div class="col-sm-4">
                        <input name="NIC_send_min_value"  type="number" step="0.01" id="NIC_send_min_value"  cols="45" rows="5" class="form-control" lonholder="请输入网口发送数据流量下限"  value="<?php echo isset($data_list['NIC_send_min_value'])?$data_list['NIC_send_min_value']:'' ?>"/>
                    </div>
                </div>
               <div class="form-group">
                    <label for="NIC_send_max_value" class="col-sm-2 control-label">网口发送数据流量上限:</label>
                    <div class="col-sm-4">
                        <input name="NIC_send_max_value"  type="number" step="0.01" id="NIC_send_max_value"  cols="45" rows="5" class="form-control" heightholder="请输入网口发送数据流量上限"  value="<?php echo isset($data_list['NIC_send_max_value'])?$data_list['NIC_send_max_value']:'' ?>"/>
                    </div>
                </div> 
            </fieldset>
            
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'systemAlertInfo','edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_list['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var id = "<?php echo isset($id)?$id:'';?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>