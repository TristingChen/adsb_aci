<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<div class="panel">
    <div class="panel-body">
        <div class="row placeholders">
            <?php foreach($data_list as $k=>$v): ?>
                <div class="col-md-3">
                    <div class="well">
                        <table class="table">
                            <caption><?php echo $v['hardware_name']?></caption>
                            <threa>
                                <tr>
                                    <th>状态</th>
                                    <th><?php echo $v['status']?'在线':'离线'?></th>
                                </tr>
                                <tr>
                                    <th>服务器IP</th>
                                    <th><?php echo $v['monitor_ip']?></th>
                                </tr>
                                <tr>
                                    <th>网络延时</th>
                                    <th><?php echo $v['ping_time']?></th>
                                </tr>
                                <tr>
                                    <th>开机运行时间</th>
                                    <th><?php echo $v['sys_up_time']?></th>
                                </tr>
                            </threa>

                        </table>
                        <div style="text-align: right;padding-top: 10px">
                            <?php aci_ui_a($folder_name,'hardwareMonitor','lists',$v['hardware_id'].'/'.$v['hardware_name'],'','<span></span>更多...') ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script language="javascript" type="text/javascript">
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/index.js']);
    });
</script>