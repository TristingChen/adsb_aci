<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>设备
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'hardwareMonitor','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label for="hardware_name" class="col-sm-2 control-label">设备名称</label>
                    <div class="col-sm-9">
                        <input name="hardware_name" type="text" id="hardware_name"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入设备名称"  value ="<?php echo isset($data_info['hardware_name'])?$data_info['hardware_name']:'' ?>"/>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="hardware_other_name" class="col-sm-2 control-label">设备别名</label>
                    <div class="col-sm-9">
                        <input name="hardware_other_name" type="text" id="hardware_other_name"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入设备别名"  value ="<?php echo isset($data_info['hardware_other_name'])?$data_info['hardware_other_name']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">设备类型</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="hardware_type_id">
                            <?php echo hardware_type_options($data_info['hardware_type_id'])?>
                        </select>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <label for="eth_num" class="col-sm-2 control-label">网口数量</label>
                    <div class="col-sm-9">
                        <input name="eth_num"  type="text" id="eth_num"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入网口数量"  value="<?php echo isset($data_info['eth_num'])?$data_info['eth_num']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label for="cpu_num" class="col-sm-2 control-label">CPU核数</label>
                    <div class="col-sm-9">
                        <input name="cpu_num"  type="text" id="cpu_num"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入CPU核数"  value="<?php echo isset($data_info['cpu_num'])?$data_info['cpu_num']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="disk_size" class="col-sm-2 control-label">硬盘容量</label>
                    <div class="col-sm-9">
                        <input name="disk_size"  type="text" id="disk_size"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入硬盘容量"  value="<?php echo isset($data_info['disk_size'])?$data_info['disk_size']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="memory_size" class="col-sm-2 control-label">内存</label>
                    <div class="col-sm-9">
                        <input name="memory_size"  type="text" id="memory_size"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入内存大小"  value="<?php echo isset($data_info['memory_size'])?$data_info['memory_size']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="position" class="col-sm-2 control-label">设备位置</label>
                    <div class="col-sm-9">
                        <input name="position"  type="text" id="position"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入设备位置"  value="<?php echo isset($data_info['position'])?$data_info['position']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="factory" class="col-sm-2 control-label">厂家</label>
                    <div class="col-sm-9">
                        <input name="factory"  type="text" id="factory"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入设备厂家"  value="<?php echo isset($data_info['factory'])?$data_info['factory']:'' ?>"/>
                    </div>
                </div>
               <!--  <div style="<?php echo (isset($data_info['hardware_type_id']) && $data_info['hardware_type_id'] !=2 && $is_edit==true) ?'display:none':'' ?>">
                      <div class="form-group" >
                    <label for="factory" class="col-sm-2 control-label">ftp用户名</label>
                    <div class="col-sm-9">
                        <input name="ftp_name"  type="text" id="ftp_name"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入ftp用户名"  value="<?php echo isset($data_info['ftp_name'])?$data_info['ftp_name']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="factory" class="col-sm-2 control-label">ftp密码</label>
                    <div class="col-sm-9">
                        <input name="ftp_code"  type="password" id="ftp_code"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入ftp密码"  value="<?php echo isset($data_info['ftp_code'])?$data_info['ftp_code']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="factory" class="col-sm-2 control-label">请再次输入ftp密码</label>
                    <div class="col-sm-9">
                        <input name="ftp_code2"  type="password" id="ftp_cod2"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请再次输入ftp密码"  value="<?php echo isset($data_info['ftp_code'])?$data_info['ftp_code']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group" style="<?php echo (isset($data_info['hardware_type_id']) && $data_info['hardware_type_id'] !=2 && $is_edit==true) ?'display:none':'' ?>">
                    <label for="factory" class="col-sm-2 control-label">文件存放路径</label>
                    <div class="col-sm-9">
                        <input name="ftp_dir"  type="text" id="ftp_dir"  cols="45" rows="5" class="form-control  validate[required]" placeholder="ftp路径"  value="<?php echo isset($data_info['ftp_dir'])?$data_info['ftp_dir']:'' ?>"/>
                    </div>
                </div>
                
              
                <div class="form-group">
                    <label  class="col-sm-2 control-label">是否进行运行监控</label>
                    <div class="col-sm-4">
                        <label class="radio-inline">
                            <input type="radio" name="is_monitor" id="is_monitor" value="1" <?php echo $data_info['is_monitor']?'checked="checked"':''?> onclick="is_monitor_change()"> 是
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="is_monitor" id="is_monitor" value="0" <?php echo !$data_info['is_monitor']?'checked="checked"':''?> onclick="is_monitor_change()"> 否
                        </label>
                    </div>
                </div>
                <div class="form-group" style="display: none" id="div_monitor_ip">
                    <label for="factory" class="col-sm-2 control-label" >监控IP</label>
                    <div class="col-sm-9">
                        <input name="monitor_ip"  type="text" id="monitor_ip"  cols="45" rows="5" class="form-control   validate[required,custom[monitor_ip  ]]" placeholder="请输入设备监控IP"  value="<?php echo isset($data_info['monitor_ip'])?$data_info['monitor_ip']:'' ?>"/>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'hardwareMonitor','edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
    var id="<?php echo $data_info['hardware_id']?>";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>