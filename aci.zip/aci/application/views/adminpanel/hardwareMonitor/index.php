<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<div id="content">
    <canvas height="100%" width="100%" id="canvas"></canvas>
</div>
<script language="javascript" type="text/javascript">
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/index.js']);
        require(['<?php echo SITE_URL?>scripts/lib/jtopo-0.4.8-min.js']);
        require(['<?php echo SITE_URL?>scripts/lib/jtopo-toolbar.js']);
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/network.js']);
    });
</script>