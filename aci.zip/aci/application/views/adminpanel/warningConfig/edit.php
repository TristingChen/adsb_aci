<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
               <i class='glyphicon glyphicon-th-list'></i><?php echo $is_edit?'编辑':'添加'; ?> 告警参数配置(24小时内)
            <div class='panel-tools'>
                
            </div>
        </div>
        <div class='panel-body'>
                <div class="form-group">
                    <label class="col-sm-2 control-label">参数告警基站选择:</label>
                   <div class="col-sm-4">
                        <select class="form-control validate[required]" name="station_id">
                            <?php if($is_edit):?>
                                    <option value="<?php echo $data_info['station_id'] ?>"  ><?php echo $data_info['station_name'] ?></option>
                            <?php  else:?>
                                 <?php foreach ($rest_stations as $key => $value):?>
                                    <option value="<?php echo $value['station_id'] ?>"  ><?php echo $value['station_name'] ?></option>
                                <?php endforeach;?>
                            <?php  endif;?>
                           
                        </select>
                    </div>
                </div>
                <div class="form-group">
                   <label for="warning_switch"  class="col-sm-2 control-label">监控开启状态</label>
                    <div class="col-sm-5 ">
                    
                        <label class="radio-inline  control-label">开</label>
                            <input type="radio" name="warning_switch" value="1"  <?php echo $data_info['warning_switch']==1?'checked':'' ?>  >
                        <label class="radio-inline  control-label">关</label>
                            <input type="radio" name="warning_switch" value="0" <?php echo $data_info['warning_switch']==0?'checked':'' ?> > 
                    </div>
                </div>
                    <div class="row">
                     <div class=" col-md-6">
                         
                            <label for="to_ip" class="col-sm-4 control-label">时间段一(h):</label>
                            <div class="controls controls-row col-sm-3 ">
                                 <select name="time_value1" id="time_value1" class="form-control">
                                        <?php foreach ($warning_value_time as $key => $value):?>
                                                <option value="<?php echo $key ?>" <?php  echo $data_info['time_value1'] == $key?'selected':'' ?> ><?php echo $value ?></option>
                                        <?php endforeach;?>
                                 </select>
                            </div>
                            <div class="controls controls-row col-sm-3 ">
                                 <!-- <span>之</span> -->
                                  <select name="end_time_value1" id="end_time_value1" class="form-control " onchange="">
                                       <?php foreach ($warning_value_time as $key => $value):?>
                                                <option value="<?php echo $key ?>" <?php  echo $data_info['end_time_value1'] == $key?'selected':'' ?> ><?php echo $value ?></option>
                                        <?php endforeach;?>

                                 </select>
                                 <!-- <input name="end_time" id="end_time"  class="span1 validate[required]" type="text"  value=""  placeholder="结束时间"  /> -->
                            </div>

                     </div>
                     <div class="col-xs-6 col-md-4">
                            <label for="to_ip" class="col-sm-3 control-label">最小航迹数:</label>
                            <div class="col-sm-5 controls controls-row">
                                 <input name="value1"  class="form-control validate[required]" type="text" value="<?php echo  isset($data_info['value1'])?$data_info['value1']:'' ?>"  placeholder="请输入数据限制值"   />
                            </div>
                     </div>
                    </div>
                    <div class="row">
                     <div class="col-md-6">
                            <label for="to_ip" class="col-sm-4 control-label">时间段二(h):</label>
                            <div class="controls controls-row col-sm-3 ">
                                 <select name="time_value2" id="time_value2" class="form-control">
                                        <?php foreach ($warning_value_time as $key => $value):?>
                                                <option value="<?php echo $key ?>" <?php  echo $data_info['time_value2'] == $key?'selected':'' ?> ><?php echo $value ?></option>

                                        <?php endforeach;?>
                                 </select>
                            </div>
                            <div class="controls controls-row col-sm-3 ">
                                 <!-- <span>之</span> -->
                                  <select name="end_time_value2" id="end_time_value2"  class="form-control " onchange="">
                                       <?php foreach ($warning_value_time as $key => $value):?>

                                                <option value="<?php echo $key ?>" <?php  echo $data_info['end_time_value2'] == $key?'selected':'' ?> ><?php echo $value ?></option>

                                        <?php endforeach;?>

                                 </select>
                                 <!-- <input name="end_time" id="end_time"  class="span1 validate[required]" type="text"  value=""  placeholder="结束时间"  /> -->
                            </div>

                     </div>
                     <div class="col-xs-6 col-md-4">
                            <label for="to_ip" class="col-sm-3 control-label">最小航迹数:</label>
                            <div class="col-sm-5 controls controls-row">
                                 <input name="value2"  class="form-control validate[required]" type="text" value="<?php echo   isset($data_info['value2'])?$data_info['value2']:''  ?>"  placeholder="请输入数据限制值"   />
                            </div>
                     </div>
                    </div>
                    <div class="row">
                     <div class="col-md-6">
                           <label for="to_ip" class="col-sm-4 control-label">时间段三(h):</label>
                           <div class="controls controls-row col-sm-3 ">
                                 <select name="time_value3" id="time_value3"  class="form-control">
                                        <?php foreach ($warning_value_time as $key => $value):?>
                                                <option value="<?php echo $key ?>" <?php  echo $data_info['time_value3'] == $key?'selected':'' ?> ><?php echo $value ?></option>
                                        <?php endforeach;?>
                                 </select>
                            </div>
                            <div class="controls controls-row col-sm-3 ">
                                 <!-- <span>之</span> -->
                                  <select name="end_time_value3" id="end_time_value3"   class="form-control " onchange="">
                                       <?php foreach ($warning_value_time as $key => $value):?>
                                                <option value="<?php echo $key ?>" <?php  echo $data_info['end_time_value3'] == $key?'selected':'' ?> ><?php echo $value ?></option>
                                        <?php endforeach;?>

                                 </select>
                                 <!-- <input name="end_time" id="end_time"  class="span1 validate[required]" type="text"  value=""  placeholder="结束时间"  /> -->
                            </div>
                     </div>
                     <div class="col-xs-6 col-md-4">
                            <label for="to_ip" class="col-sm-3 control-label">最小航迹数:</label>
                            <div class="col-sm-5 controls controls-row">
                                 <input name="value3" class="form-control validate[required]" type="text" value="<?php echo  isset($data_info['value3'])?$data_info['value3']:'' ?>"  placeholder="请输入数据限制值"   />
                            </div>
                     </div>
                    </div>
               
            <div class='form-actions '>
                <?php aci_ui_button($folder_name,'warningConfig','edit','type="submit" name="replayer_type" value="1"  class="btn btn-primary dosubmit"','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_list['id']?>//";
    var station_id = <?php echo $is_edit?$station_id:'\'\'' ?>;
    var folder_name = "<?php echo $folder_name?>";
    var controller_name = "<?php echo $controller_name?>";
   
    var is_edit = "<?php echo $is_edit;?>";
    var warning_value_time = '<?php echo json_encode($warning_value_time);?>';
    var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/edit.js');?>;
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js?t='+filemtime]);
    });
</script>