<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>版本
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'VersionsCtrl','versions_manage','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label class="col-sm-2 control-label">最新程序选择</label>
                    <div class="col-sm-9">
                        <select class="form-control validate[required]" name="version_id">
                            <?php echo versions_relation_options($data_info['versions_data'])?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">请选择相应的服务器</label>
                    <div class="col-sm-9">
                        <?php foreach ($data_info['server_data'] as $item): ?>
                            <div  class="col-sm-5" >
                                <label class="col-sm-5 control-label"><?=$item['hardware_name']?></label><input name="hardware_id[]" value="<?=$item['hardware_id']?>"  type="checkbox"   cols="45" rows="5" class="checkbox  validate[required]"  />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">备注</label>
                    <div class="col-sm-9">
                        <textarea name="remark"  type="text" id="remark"  cols="45" rows="5" class="form-control " placeholder="备注" /></textarea>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'VersionsCtrl','edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_info['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";

    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/VersionsCtrl/Version_relation.js']);
    });
</script>