<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid' xmlns="http://www.w3.org/1999/html">
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> ��������Ϣ�б�
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'versionsCtrl','add', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> ��������') ?>
            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">�ؼ���</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="������ؼ���"/></div>
            <button type="submit" name="dosubmit" value="����" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
            <div class="panel panel-body">
                <table class="table table-hover dataTable">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Ӳ����</th>
                        <th>Ӳ������</th>
                        <th>����λ��</th>
                        <th>��ǰ�汾</th>
                        <th>�汾��</th>
                        <th>����</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($data_list as $k => $v): ?>
                        <tr>
                            <td><input type="checkbox" name="pid[]" value="<?php echo $v['hardware_id'] ?>"/></td>
                            <td><?php echo $v['hardware_name'] ?></td>
                            <td><?php echo hardware_type($v['hardware_type_id'])?></td>
                            <td><?php echo $v['position']?></td>
                            <td><?php echo $v['program']?></td>

                            <td><?php echo $v['version_num']?></td>
                            <td>
                                <?php aci_ui_a($folder_name, 'versionsCtrl', 'edit', $v['hardware_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> �汾����') ?>
                                <?php aci_ui_a($folder_name, 'versionsCtrl', 'edit', $v['hardware_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> �汾����') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">
                <div class="pull-left">
                    <div class="btn-group">
                        <button type="button" class="btn btn-default" id="reverseBtn"><span
                                class="glyphicon glyphicon-ok"></span> ��ѡ
                        </button>
                        <?php aci_ui_button($folder_name, 'versionsCtrl', 'delete', ' class="btn btn-default" id="deleteBtn" ', '<span class="glyphicon glyphicon-remove"></span> ɾ����ѡ') ?>
                    </div>
                </div>
                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> ����������ʾ... �����Խ�����������</div>
            </div>
        <?php endif; ?>
    </form>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
