<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid' xmlns="http://www.w3.org/1999/html">
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> 服务器参数文件信息列表
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'publishDataDeploy','goal_file_add', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 添加') ?>
            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
            <div class="panel panel-body">
                <table class="table table-hover dataTable">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>参数文件名</th>
                        <th>参数文件说明</th>
                        <th>编辑时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($data_list as $k => $v): ?>
                        <tr>
                            <td><?php echo $k + 1 ?></td>
                            <td><?php echo $v['basic_xml_name']?></td>
                            <td><?php echo $v['name']?></td>
                            <td><?php echo date('Y-m-d H:i:s',$v['dateline']);?></td>
                            <td>
                                <?php aci_ui_a($folder_name, 'publishDataDeploy', 'goal_file_edit', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 编辑') ?>
                                <?php aci_ui_a($folder_name, 'publishDataDeploy', 'goal_file_delete', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 删除') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">

                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
            </div>
        <?php endif; ?>
    </form>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
    
</script>
