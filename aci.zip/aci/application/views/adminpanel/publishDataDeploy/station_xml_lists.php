<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid' xmlns="http://www.w3.org/1999/html">
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> 版本列表
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'versionsCtrl','versions_relation_add', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 服务器应用添加') ?>
            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
            <div class="panel panel-body">
                <table class="table table-hover dataTable">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>当前程序名</th>
                        <th>版本号</th>
                        <th>服务器名称</th>
                        <th>服务器位置</th>
                        <th>服务器使用程序时间</th>
                         <th>备注</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($data_list as $k => $v): ?>
                        <tr>
                            <td><?php echo $k + 1 ?></td>
                            <td><?php echo $v['program'] ?></td>
                            <td><?php echo $v['version_num']?></td>
                            <td><?php echo $v['hardware_name']?></td>
                            <td><?php echo $v['position']?></td>
                            <td><?php echo date('Y-m-d H:i:s',$v['update_time']);?></td>
                            <td><?php echo $v['remark']?></td>
                            <td>
                                <a href="#"  class="btn btn-default btn-xs btn-up" attr = "<?php echo $v['id'];?>" has_new="<?php echo $v['has_new'];?>"><span class="glyphicon glyphicon-edit"></span> 版本更新</a>
                                <p   class="btn btn-default btn-xs btn-down" attr = "<?php echo $v['id'];?>"><span class="glyphicon glyphicon-edit"></span> 版本回退</p>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">

                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
            </div>
        <?php endif; ?>
    </form>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
