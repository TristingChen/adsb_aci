<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform" action="<?php echo current_url()?>">
    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?'查看':'添加';?>参数文件
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'publishDataDeploy','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label class="col-sm-2 control-label">参数文件选择</label>
                    <div class="col-sm-4">
                       <select class="form-control validate[required]" name="xml_id" id="xml_id">
                            <?php foreach ($all_config_xml as $key => $value):?>
                                <option value="<?php echo $value['id'];?>" <?php echo (isset($data_info['xml_id']) && $data_info['xml_id']==$value['id'] )?'selected':'';?> ><?php echo $value['xml_name'];?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="col-sm-2 control-label">备注</label>
                    <div class="col-sm-9">
                        <textarea name="remark"  type="text" id="remark"  cols="45" rows="5" class="form-control " placeholder="备注" /><?php echo isset($data_info['remark'])? $data_info['remark']:'';?> </textarea>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php if(!$is_edit):?>
                   <?php aci_ui_button($folder_name,'publishDataDeploy','publish_file_add','type="submit" id="dosubmit" class="btn btn-primary "','发布')?>
                <?php endif;?>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <legend>当前配置文件详情</legend>
                <div class="form-group">
                  <pre id="xml_show">
                      <?php if($xml_data == -1):?>
                            <?php  echo '资源已不存在' ?>
                      <?php else:?>
                            <?php echo $xml_data;?>
                      <?php endif;?>  
                  </pre>
                </div>
                
            </fieldset>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_info['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/publish_file.js']);
    });
</script>