<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform" action="<?php echo current_url()?>">
    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?'编辑':'添加';?>参数文件
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'publishDataDeploy','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
              
                <div class="form-group">
                    <label class="col-sm-2 control-label">参数文件名：</label>
                    <div class="col-sm-4">
                        <input type="text" name="basic_xml_name" value="<?php echo $data_info['basic_xml_name'] ?>"
                           class="validate[required] form-control"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">参数文件说明：</label>
                    <div class="col-sm-4">
                        <input type="text" name="name" value="<?php echo $data_info['name'] ?>"
                           class="validate[required] form-control"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">请选择相应的服务器</label>
                    <div class="col-sm-12">
                        <?php foreach ($all_hardware_lists as $item): ?>
                            <div  class="col-sm-6" >
                                <label class="col-sm-6 control-label"><?=$item['hardware_name']?></label><input name="hardware_id[]" value="<?=$item['hardware_id']?>"  type="checkbox"   cols="45" rows="5" class="checkbox  validate[required]" <?php echo (isset($data_info['hardware_id_arr'])&& in_array($item['hardware_id'], $data_info['hardware_id_arr']))?'checked':'';?>  />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">备注</label>
                    <div class="col-sm-9">
                        <textarea name="remark"  type="text" id="remark"  cols="45" rows="5" class="form-control " placeholder="备注" /><?php echo isset($data_info['remark'])? $data_info['remark']:'';?> </textarea>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                   <?php aci_ui_button($folder_name,'publishDataDeploy','publish_file_add','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
        
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_info['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var id = <?php echo $is_edit?$id:0; ?>;
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/goal_basic_edit.js']);
    });
</script>