<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-edit'></i> 管制数据源配置<?php echo $is_edit ? "编辑发送目标" : "新增发送目标"?>
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, $controller_name, 'lists', '', ' class="btn btn-sm pull-right"', '<span class="glyphicon glyphicon-arrow-left"></span> 返回') ?>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <form name="validateform" id="validateform" class="form-horizontal"
              action="<?php echo site_url($folder_name . '/' . $controller_name . '/edit') ?>" method="post">
            <div class="form-group">
                <label class="col-sm-2 control-label">数据发送方式</label>

                <div class="col-sm-5">
                    <label class="radio-inline">
                        <input type="radio" name="cast_type" id="cast_type1"
                               value="1" <?php echo ($data_info['cast_type'] == 1) ? 'checked="checked"' : ''?>> 单播
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="cast_type" id="cast_type2"
                               value="2" <?php echo ($data_info['cast_type'] == 2) ? 'checked="checked"' : ''?>> 组播
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="cast_type" id="cast_type3"
                               value="3" <?php echo ($data_info['cast_type'] == 3) ? 'checked="checked"' : ''?>> 广播
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">用户说明</label>

                <div class="col-sm-5">
                    <input type="text" name="Name" value="<?php echo $data_info['Name'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">发送IP：端口</label>

                <div class="col-sm-5">
                    <input type="text" name="SendAddr" value="<?php echo $data_info['SendAddr'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">发送优先级</label>

                <div class="col-sm-5">
                    <input type="text" name="Pri" value="<?php echo $data_info['Pri'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">发送延时</label>

                <div class="col-sm-5">
                    <input type="text" name="Delay  " value="<?php echo $data_info['Delay'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">发送频率</label>

                <div class="col-sm-5">
                    <input type="text" name="Freq" value="<?php echo $data_info['Freq'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">定制公司三字码</label>

                <div class="col-sm-5">
                    <textarea name="CompanyName" class="form-control" rows="3" placeholder="定制公司三字码，用空格隔开"
                              value="<?php echo $data_info['CompanyName'] ?>"></textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">已选数据源</label>

                <div class="col-sm-5">
                    <textarea class="form-control" rows="3"></textarea>
                </div>
            </div>
            <div class='panel panel-default grid'>
                <div class='panel-heading'>
                    <i class='glyphicon glyphicon-th-list'></i> 数据源列表
                </div>
                <div class='panel-filter '>
                    <div class="form-group form-inline" style="padding-left: 10px">
                        <label for="keyword" class="form-control-static control-label">关键词</label>
                        <input class="form-control" type="text" name="keyword" value="" id="keyword"
                               placeholder="请输入关键词"/>
                        <button type="button" value="搜索" class="btn btn-success" onclick="search()">
                            <i class="glyphicon glyphicon-search"></i></button>
                    </div>
                </div>
                <div id="recv_source">
                    <div class="panel panel-body">
                        <table class="table table-hover dataTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>数据源</th>
                                <th>数据源IP</th>
                                <th>数据源端口</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody id="recv_datas">
                            <?php
                            foreach ($recv_lists as $k => $v) {
                                echo '<tr>';
                                echo '<td><input type="checkbox" name="pid[]" value="' . $v['id'] . '"/></td>';
                                echo '<td>' . $v['Note'] . '</td>';
                                echo '<td>' . $v['RecvCastIp'] . '</td>';
                                echo '<td>' . $v['RecvCastPort'] . '</td>';
                                echo '<td><a href="javascript:void(0);" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-remove"></span> 删除</a></td>';
                                echo '</tr>';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div id="pages_footer">
                        <?php
                        echo '<div class="panel-footer">';
                        echo '<div class="pull-left">';
                        echo '<div class="btn-group">';
                        echo '<button type="button" class="btn btn-default" id="reverseBtn"><span class="glyphicon glyphicon-ok"></span> 反选 </button>';
                        echo '<button class="btn btn-default" id="deleteBtn"><span class="glyphicon glyphicon-edit"></span>选择勾选数据源</button>';
                        echo '</div></div>';
                        echo '<div class="pull-right">';
                        echo ajax_pages($count, 1, $page_size, '', 'get_recv_source');
                        echo '</div></div>';
                        ?>
                    </div>
                </div>
            </div>

            <div class='form-actions'>
                <button type="button" class="btn btn-primary" onclick="">保存</button>
            </div>
        </form>
    </div>
</div>
<script language="javascript" type="text/javascript">
    var edit =<?php echo $is_edit?"true":"false"?>;
    var network_type =<?php echo $network_type?>;
    var folder_name = "<?php echo $folder_name?>";
    var controller_name = "<?php echo $controller_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>