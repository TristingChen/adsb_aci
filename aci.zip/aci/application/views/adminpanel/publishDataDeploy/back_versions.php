<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
           参数文件 <?php echo $is_back?'回退':'更新';?>
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'publishDataDeploy','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label class="col-sm-2 control-label">参数文件选择</label>
                    <div class="col-sm-4">

                       <?php if($is_back):?>
                             <select class="form-control validate[required]" name="xml_id" id="xml_id">
                                <?php foreach ($data_xmls as $key => $value):?>
                                    <option value="<?php echo $value['id'];?>" ><?php echo $value['xml_name'];?></option>
                                <?php endforeach;?>
                            </select>
                       <?php else:?>
                            <input type="hidden" name="xml_id" value="<?php echo isset($data_xmls['id'])?$data_xmls['id']:'' ?>" />
                            <input type="text" name="" readonly value="<?php echo isset($data_xmls['xml_name'])?$data_xmls['xml_name']:''; ?>"
                           class="validate[required] form-control"/>
                       <?php endif;?> 
                      
                    </div>
                </div>
                <!--<div class="form-group">
                    <label class="col-sm-2 control-label">请选择相应的服务器</label>
                    <div class="col-sm-9">
                        <?php /*foreach ($all_hardware_lists as $item): */?>
                            <div  class="col-sm-5" >
                                <label class="col-sm-5 control-label"><?/*=$item['hardware_name']*/?></label><input name="hardware_id[]" value="<?/*=$item['hardware_id']*/?>"  type="checkbox"   cols="45" rows="5" class="checkbox  validate[required]" <?php /*echo (isset($data_info['hardware_id_arr'])&& in_array($item['hardware_id'], $data_info['hardware_id_arr']))?'checked':'';*/?>  />
                            </div>
                        <?php /*endforeach; */?>
                    </div>
                </div>-->
                <?php if($is_back):?>
                <div class="form-group">
                    <label class="col-sm-2 control-label">原有备注</label>
                    <div class="col-sm-9">
                        <textarea name="old_remark"  type="text" id="old_remark"  cols="45" rows="5" class="form-control " placeholder="备注" /><?php echo $remark_info;?> </textarea>
                    </div>
                </div>
                <?php endif;?>
                <div class="form-group">
                    <label class="col-sm-2 control-label">备注</label>
                    <div class="col-sm-9">
                        <textarea name="remark"  type="text" id="remark"  cols="45" rows="5" class="form-control " placeholder="备注" /></textarea>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                   <?php aci_ui_button($folder_name,'publishDataDeploy','publish_file_add','type="submit" id="dosubmit" class="btn btn-primary "','发布')?>
            </div>
            <div class='panel-body'>
                <fieldset>
                    <legend>当前配置文件详情</legend>
                    <div class="form-group">
                  <pre id="xml_show">
                      <?php if($xml_data == -1):?>
                          <?php  echo '资源已不存在' ?>
                      <?php else:?>
                          <?php echo $xml_data;?>
                      <?php endif;?>
                  </pre>
                    </div>

                </fieldset>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_info['id']?>//";
    var is_back= <?php echo $is_back?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var id = "<?php echo $id?>";

    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/back_file.js']);
    });
</script>