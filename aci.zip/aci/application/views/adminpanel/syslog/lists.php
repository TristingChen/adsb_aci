<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> 日志列表
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
    <?php if ($data_list): ?>
    <div class="panel panel-body">
        <form method="post" id="form_list">
            <div class="table-responsive">

                <table class="table table-hover dataTable">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>时间</th>
                        <th>设施</th>
                        <th>日志级别</th>
                        <th>服务器</th>
                        <th>日志标签</th>
                        <th>进程ID</th>
                        <th>消息类型</th>
                        <th>内容</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($data_list as $k => $v): ?>
                        <tr>
                            <td><?php echo $k + 1 ?></td>
                            <td><?php echo $v['ReceivedAt'] ?></td>
                            <td><?php echo $v['Facility']?></td>
                            <td><?php echo $v['Priority']?></td>
                            <td><?php echo $v['FromHost']?></td>
                            <td><?php echo $v['SysLogTag']?></td>
                            <td><?php echo $v['EventID']?></td>
                            <td><?php echo $v['EventLogType']?></td>
                            <td><?php echo $v['Message']?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

    </div>
    <?php if($pages):?>
        <div class=" panel-footer">
            <div class="pull-left">
            </div>
            <div class="pull-right">
                <?php echo $pages; ?>
            </div>
            </form>
        </div>
    <?php endif?>
<?php else: ?>
    <div class="panel panel-body">
        <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
    </div>
<?php endif; ?>
</form>
</div>

<script language="javascript" type="text/javascript">
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/list.js']);
    });
</script>
