<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>参数文件
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'bypassManage','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
                <div class="form-group">
                    <label for="to_name" class="col-sm-2 control-label">用户名</label>
                    <div class="col-sm-4">
                        <input name="to_name"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入用户名"  value="<?php echo isset($data_list['to_name'])?$data_list['to_name']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">数据传输方式</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="cast_type" id="cast_type1"
                                   value="1" <?php echo ($data_list['cast_type'] == 1) ? 'checked="checked"' : ''?>> 单播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="cast_type" id="cast_type2"
                                   value="2" <?php echo ($data_list['cast_type'] == 2) ? 'checked="checked"' : ''?>> 组播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="cast_type" id="cast_type3"
                                   value="3" <?php echo ($data_list['cast_type'] == 3) ? 'checked="checked"' : ''?>> 广播
                        </label>
                    </div>
                </div>

                <div class="form-group">
                        <label for="in_work_option"  class="col-sm-2 control-label">旁路开关</label>
                       
                        <div class="col-sm-5">
                                <label class="radio-inline">
                                    <input type="radio" name="in_work_option" id="in_work_option1"
                                           value="1" <?php echo ($data_list['in_work_option'] == 1) ? 'checked="checked"' : ''?>> 开
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="in_work_option" id="in_work_option2"
                                           value="2" <?php echo ($data_list['in_work_option'] == 0) ? 'checked="checked"' : ''?>> 关
                                </label>
                                
                            </div>
                        </div>
                </div>

                <div class="form-group">
                    <label for="to_ip" class="col-sm-2 control-label">发送IP</label>
                    <div class="col-sm-4">
                        <input name="to_ip"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入发送IP"  value="<?php echo isset($data_list['to_ip'])?$data_list['to_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="to_port" class="col-sm-2 control-label">发送端口</label>
                    <div class="col-sm-4">
                        <input name="to_port"  type="text" id="send_port_A"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入数据发送端口"  value="<?php echo isset($data_list['to_port'])?$data_list['to_port']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="to_port" class="col-sm-2 control-label">接口ip</label>
                    <div class="col-sm-4">
                        <input name="interface_ip"  type="text" id="interface_ip"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入接口ip"  value="<?php echo isset($data_list['interface_ip'])?$data_list['interface_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">请选择基站</label>
                    <div class="col-sm-9">
                        <?php foreach ($station_data as $item): ?>
                            <div  class="col-sm-3" >
                                <label class="col-sm-5 control-label"><?=$item['station_name']?></label><input name="station_ids[]" value="<?=$item['station_id']?>"  type="checkbox"  <?php echo (is_array($data_list['station_ids']) && in_array($item['station_id'],$data_list['station_ids']))?'checked':'';?>  cols="45" rows="5" class="checkbox" style="" />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">备注</label>
                    <div class="col-sm-9">
                        <textarea name="remark"  type="text" id="remark"  cols="45" rows="5" class="form-control " placeholder="备注" /><?php echo isset($data_list['remark'])?$data_list['remark']:'' ?></textarea>
                    </div>
                </div>
            </fieldset>
             
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'bypassManage','add','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_list['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var id = <?php echo isset($id)?$id:0?>;
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>