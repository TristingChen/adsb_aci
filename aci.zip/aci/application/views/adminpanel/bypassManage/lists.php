<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid' xmlns="http://www.w3.org/1999/html">
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> 旁路信息列表
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'bypassManage', 'add', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 添加') ?>
                <?php if(count($data_list)): ?>

                 <?php aci_ui_a($folder_name, 'bypassManage', 'produce_xml', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 生成配置文件') ?>
            <?php endif;?>
            <?php if($fresh_xml_data):?>
                            <?php aci_ui_a($folder_name, 'publishDataDeploy', 'publish_file_add', $fresh_xml_data['id'], ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 发布配置文件') ?>
                    <?php endif;?>
            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <!-- <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form> -->
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
            <div class="panel panel-body">
                <table class="table table-hover dataTable">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>用户名</th>
                        <th>发送ip</th>
                        <th>发送端口</th>
                        <th>传输方式</th>
                        <th>用户开关</th>
                        <th>发送说明</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($data_list as $k => $v): ?>
                        <tr>
                            <td><?php echo $k + 1 ?></td>
                            <td><?php echo $v['to_name'] ?></td>
                            <td><?php echo ($v['to_ip']) ?></td>
                            <td><?php echo $v['to_port']?></td>
                            <td><?php echo $v['cast_type']==1?'单播':(($v['cast_type']==2)?'组播':'广播')?></td>
                            <td><?php echo ($v['in_work_option']==1)?"开":'关' ?></td>
                            <td><?php echo $v['remark']?></td>
                            <td> 
                               <?php aci_ui_a($folder_name, 'bypassManage', 'edit', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 编辑') ?>
                               <?php aci_ui_a($folder_name, 'bypassManage', 'delete', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-del"></span> 删除') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">
                <div class="pull-left">
                    <div class="btn">旁路总开关</div>
                    
                        <button type="button" class="btn <?php echo $main_swtich['main_switch']==1?'btn-primary  main_switch':'btn-default';  ?> " value='0'>开</button>
                        <button type="button"  class="btn <?php echo $main_swtich['main_switch']==0?'btn-primary  main_switch':'btn-default'; ?>" value='1'>关</button>
                      
                    
                </div>
                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
            </div>
        <?php endif; ?>
    </form>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
