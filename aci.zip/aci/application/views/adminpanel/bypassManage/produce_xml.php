
<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="" xmlns="">

    <div class='panel panel-default'>
         <div class='panel-heading'>
            <i class='glyphicon glyphicon-th-list'></i> 检查文件内容
           
        </div>
            <fieldset>
                <div class="row" style="padding: 20px;font-size: 18px">
                    <pre style="font-size: 16px">
                            <?php echo $xml_data;?>
                        
                    </pre>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_a($folder_name,'bypassManage','lists','',' class="btn btn-primary"','<span class="glyphicon glyphicon-arrow-left"></span> 取消并返回上一层')?>
                <?php aci_ui_button($folder_name,'bypassManage','edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>
</form>
<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/produce_xml.js']);
    });
</script>