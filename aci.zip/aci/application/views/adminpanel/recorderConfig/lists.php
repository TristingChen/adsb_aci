<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid' xmlns="http://www.w3.org/1999/html">
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> 录制回放参数列表
        <div class='panel-tools'>
                <div class='btn-group'>
                 <?php if($data_list['id']):?>
                     <?php aci_ui_a($folder_name, 'recorderConfig', 'produce_xml', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 生成配置文件') ?>
                 <?php endif;?>    
                 <?php if($fresh_xml_data):?>
                    <?php aci_ui_a($folder_name, 'publishDataDeploy', 'publish_file_add', $fresh_xml_data['id'], ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 发布配置文件') ?>
                <?php endif;?>
                </div>
        </div>
    </div>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform" action="<?php echo current_url()?>" enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

        <div class='panel-body'>
            <fieldset>
                <legend>通道A接收地址</legend>
                 <div class="form-group">
                    <label for="input_ip_a" class="col-sm-2 control-label">输入ip:</label>
                    <div class="col-sm-4">
                        <input name="input_ip_a"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输入ip"  value="<?php echo isset($data_list['input_ip_a'])?$data_list['input_ip_a']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="input_ip_a_port" class="col-sm-2 control-label">输入端口:</label>
                    <div class="col-sm-4">
                        <input name="input_ip_a_port"  type="number" id="input_ip_a_port"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输入端口"  value="<?php echo isset($data_list['input_ip_a_port'])?$data_list['input_ip_a_port']:'' ?>"/>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="output_ip_a" class="col-sm-2 control-label">输出ip:</label>
                    <div class="col-sm-4">
                        <input name="output_ip_a"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输入ip"  value="<?php echo isset($data_list['output_ip_a'])?$data_list['output_ip_a']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="output_ip_a_port" class="col-sm-2 control-label">输出端口:</label>
                    <div class="col-sm-4">
                        <input name="output_ip_a_port"  type="number" id="output_ip_a_port"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输出端口"  value="<?php echo isset($data_list['output_ip_a_port'])?$data_list['output_ip_a_port']:'' ?>"/>
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend>通道B接收地址</legend>
                 <div class="form-group">
                    <label for="input_ip_b" class="col-sm-2 control-label">输入ip:</label>
                    <div class="col-sm-4">
                        <input name="input_ip_b"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输入ip"  value="<?php echo isset($data_list['input_ip_b'])?$data_list['input_ip_b']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="input_ip_b_port" class="col-sm-2 control-label">输入端口:</label>
                    <div class="col-sm-4">
                        <input name="input_ip_b_port"  type="number" id="input_ip_b_port"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输入端口"  value="<?php echo isset($data_list['input_ip_b_port'])?$data_list['input_ip_b_port']:'' ?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <label for="output_ip_b" class="col-sm-2 control-label">输出ip:</label>
                    <div class="col-sm-4">
                        <input name="output_ip_b"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输出ip"  value="<?php echo isset($data_list['output_ip_b'])?$data_list['output_ip_b']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="output_ip_b_port" class="col-sm-2 control-label">输出端口:</label>
                    <div class="col-sm-4">
                        <input name="output_ip_b_port"  type="number" id="output_ip_b_port"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入输出端口"  value="<?php echo isset($data_list['output_ip_b_port'])?$data_list['output_ip_b_port']:'' ?>"/>
                    </div>
                </div>
            </fieldset>
               <fieldset>
                <legend></legend>
                <!-- <div class="form-group">
                    <label for="log_path" class="col-sm-2 control-label">日志目录:</label>
                    <div class="col-sm-4">
                        <input name="log_path"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入日志目录"  value="<?php echo isset($data_list['log_path'])?$data_list['log_path']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="log_level" class="col-sm-2 control-label">日志等级:</label>
                    <div class="col-sm-4">
                        <input name="log_level"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入日志等级"  value="<?php echo isset($data_list['log_level'])?$data_list['log_level']:'' ?>"/>
                    </div>
                </div>
                
                
                <div class="form-group">
                    <label for="interval" class="col-sm-2 control-label">发送间隔:</label>
                    <div class="col-sm-4">
                        <input name="interval"  type="number" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入发送间隔"  value="<?php echo isset($data_list['interval'])?$data_list['interval']:'' ?>"/>
                    </div>
                </div>
                               <div class="form-group">
                    <label for="miss_count" class="col-sm-2 control-label">消失间隔:</label>
                    <div class="col-sm-4">
                        <input name="miss_count"  type="number" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入消失间隔"  value="<?php echo isset($data_list['miss_count'])?$data_list['miss_count']:'' ?>"/>
                    </div>
                </div>
                               <div class="form-group">
                    <label for="send_ip" class="col-sm-2 control-label">发送状态ip:</label>
                    <div class="col-sm-4">
                        <input name="send_ip"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入发送状态ip"  value="<?php echo isset($data_list['send_ip'])?$data_list['send_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="send_port" class="col-sm-2 control-label">发送状态端口:</label>
                    <div class="col-sm-4">
                        <input name="send_port"  type="number" id="send_port_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="发送状态端口"  value="<?php echo isset($data_list['send_port'])?$data_list['send_port']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="send_heart_ip" class="col-sm-2 control-label">发送心跳包ip:</label>
                    <div class="col-sm-4">
                        <input name="send_heart_ip"  type="text" id="send_heart_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入发送心跳包ip"  value="<?php echo isset($data_list['send_heart_ip'])?$data_list['send_heart_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="send_heart_port" class="col-sm-2 control-label">发送心跳包端口:</label>
                    <div class="col-sm-4">
                        <input name="send_heart_port"  type="number" id="send_heart_port_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入发送心跳包端口"  value="<?php echo isset($data_list['send_heart_port'])?$data_list['send_heart_port']:'' ?>"/>
                    </div>
                </div>
                               <div class="form-group">
                    <label for="recv_cmd_ip" class="col-sm-2 control-label">接受心跳包ip:</label>
                    <div class="col-sm-4">
                        <input name="recv_cmd_ip"  type="text" id="recv_cmd_ip"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入接受心跳包ip"  value="<?php echo isset($data_list['recv_cmd_ip'])?$data_list['recv_cmd_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="recv_cmd_port" class="col-sm-2 control-label">接受心跳包端口:</label>
                    <div class="col-sm-4">
                        <input name="recv_cmd_port"  type="number" id="recv_cmd_port"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入接受心跳包端口"  value="<?php echo isset($data_list['recv_cmd_port'])?$data_list['recv_cmd_port']:'' ?>"/>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="bufsize" class="col-sm-2 control-label">接收缓存大小:</label>
                    <div class="col-sm-4">
                        <input name="bufsize"  type="number" id="bufsize"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入接收缓存大小"  value="<?php echo isset($data_list['bufsize'])?$data_list['bufsize']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label for="recorder_a_dir" class="col-sm-2 control-label">通道A文件目录:</label>
                    <div class="col-sm-4">
                        <input name="recorder_a_dir"  type="text" id="recorder_a_dir"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入通道A文件目录"  value="<?php echo isset($data_list['recorder_a_dir'])?$data_list['recorder_a_dir']:'' ?>"/>
                    </div>
                </div>

               <div class="form-group">
                    <label for="recorder_b_dir" class="col-sm-2 control-label">通道B文件目录:</label>
                    <div class="col-sm-4">
                        <input name="recorder_b_dir"  type="text" id="recorder_b_dir"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入通道B文件目录"  value="<?php echo isset($data_list['recorder_b_dir'])?$data_list['recorder_b_dir']:'' ?>"/>
                    </div>
                </div>
               </fieldset>
               
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'recorderConfig','lists','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
