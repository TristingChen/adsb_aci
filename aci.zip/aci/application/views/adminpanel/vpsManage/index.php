<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            应用参数配置信息列表
            <div class='panel-tools'>

            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label class="col-sm-2 control-label">通道数据熔断后是否自动恢复</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="is_open_channel_by_self" id="is_open_channel_by_self1"
                                   value="1" <?php echo ($data_info['is_open_channel_by_self'] == 1) ? 'checked="checked"' : ''?>> 恢复
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="is_open_channel_by_self" id="is_open_channel_by_self2"
                                   value="2" <?php echo ($data_info['is_open_channel_by_self'] == 2) ? 'checked="checked"' : ''?>> 不恢复
                        </label>
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <div class="form-group">
                    <label for="program_name" class="col-sm-2 control-label">TDOA距离差(m)</label>
                    <div class="col-sm-4">
                        <input name="tdoa"  type="text" id="program_start_dir"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入tdoa数值"  value="<?php echo isset($data_info['tdoa'])?$data_info['tdoa']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="program_log_dir" class="col-sm-2 control-label">延时(s)</label>
                    <div class="col-sm-4">
                        <input name="delay"  type="text" id="delay"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入延时数值"  value="<?php echo isset($data_info['delay'])?$data_info['delay']:'' ?>"/>
                    </div>
                </div>
				<div class="form-group">
                    <label  class="col-sm-2 control-label">NUC门限值</label>
                    <div class="col-sm-4">
                        <input name="nuc"  type="text" id="nuc"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入NUC门限值"  value="<?php echo isset($data_info['nuc'])?$data_info['nuc']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">NAC门限值</label>
                    <div class="col-sm-4">
                        <input name="nac"  type="text" id="nac"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入NAC门限值"  value="<?php echo isset($data_info['nac'])?$data_info['nac']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">NIC门限值</label>
                    <div class="col-sm-4">
                        <input name="nic"  type="text" id="nic"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入NIC门限值"  value="<?php echo isset($data_info['nic'])?$data_info['nic']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">SIL门限值</label>
                    <div class="col-sm-4">
                        <input name="sil"  type="text" id="sil"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入SIL门限值"  value="<?php echo isset($data_info['sil'])?$data_info['sil']:'' ?>"/>
                    </div>
                </div>
				<div class="form-group">
                    <label class="col-sm-2 control-label">重要数据项保持时间(s)</label>
                    <div class="col-sm-4">
                        <input name="item_value_keep_time"  type="text" id="item_value_keep_time"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入重要数据项保持时间"  value="<?php echo isset($data_info['item_value_keep_time'])?$data_info['item_value_keep_time']:'' ?>"/>
                    </div>
                </div>
            </fieldset>
			<fieldset>
                <!-- <div class="form-group">
                    <label for="in_height" class="col-sm-2 control-label">关联雷达最大高度差(FL)</label>
                    <div class="col-sm-4">
                        <input name="in_height"  type="number" id="in_height"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入关联雷达数据两点最大高度差"  value="<?php echo isset($data_info['in_height'])?$data_info['in_height']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_speed" class="col-sm-2 control-label">关联雷达最大速度差(米/秒)</label>
                    <div class="col-sm-4">
                        <input name="in_speed"  type="number" id="in_speed"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入关联雷达最大速度差"  value="<?php echo isset($data_info['in_speed'])?$data_info['in_speed']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_time" class="col-sm-2 control-label">关联雷达最大时间差(秒)</label>
                    <div class="col-sm-4">
                        <input name="in_time"  type="number" id="in_time"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入关联雷达最大时间差"  value="<?php echo isset($data_info['in_time'])?$data_info['in_time']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_pos" class="col-sm-2 control-label">关联雷达最大距离差(米)</label>
                    <div class="col-sm-4">
                        <input name="in_pos"  type="number" id="in_pos"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入关联雷达最大距离差"  value="<?php echo isset($data_info['in_pos'])?$data_info['in_pos']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label for="in_angle" class="col-sm-2 control-label">航向角最大偏差</label>
                    <div class="col-sm-4">
                        <input name="in_angle"  type="number" id="in_angle"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入关联雷达最大角度差"  value="<?php echo isset($data_info['in_angle'])?$data_info['in_angle']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_count" class="col-sm-2 control-label">最大比较点迹个数(个)</label>
                    <div class="col-sm-4">
                        <input name="in_count"  type="number" id="in_count"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入关联雷达最大比较点迹个数"  value="<?php echo isset($data_info['in_count'])?$data_info['in_count']:'' ?>"/>
                    </div>
                </div>
                 <div class="form-group">
                    <label  class="col-sm-2 control-label">最小比较点迹个数(个)</label>
                    <div class="col-sm-4">
                        <input name="min_track_points"  type="number" id="min_track_points"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入最少航迹个数"  value="<?php echo isset($data_info['min_track_points'])?$data_info['min_track_points']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="rate" class="col-sm-2 control-label">雷达与关联ADSB的匹配率</label>
                    <div class="col-sm-4">
                        <input name="rate"  type="text" id="rate"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入雷达与关联ADSB的匹配率"  value="<?php echo isset($data_info['rate'])?$data_info['rate']:'' ?>"/>
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">航空器最大水平速度(米/秒)</label>
                    <div class="col-sm-4">
                        <input name="max_speed"  type="text" id="max_speed"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入航空器最大水平速度"  value="<?php echo isset($data_info['max_speed'])?$data_info['max_speed']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">判断航迹消失时间(秒) </label>
                    <div class="col-sm-4">
                        <input name="disappear_time_sec"  type="number" id="disappear_time_sec"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入判断航迹丢点个数"  value="<?php echo isset($data_info['disappear_time_sec'])?$data_info['disappear_time_sec']:'' ?>"/>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <label  class="col-sm-2 control-label">同个航迹相邻数据帧最大时间差(秒)</label>
                    <div class="col-sm-4">
                        <input name="in_jump_time_sec"  type="text" id="in_jump_time_sec"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入同个航迹相邻数据帧最大时间差"  value="<?php echo isset($data_info['in_jump_time_sec'])?$data_info['in_jump_time_sec']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">判断航迹位置跳变差(米)</label>
                    <div class="col-sm-4">
                        <input name="jump_position_distance"  type="text" id="jump_position_distance"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入航迹两点距离大于以下值判断为位置跳变"  value="<?php echo isset($data_info['jump_position_distance'])?$data_info['jump_position_distance']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">判断航迹高度跳变差(米)</label>
                    <div class="col-sm-4">
                        <input name="jump_height_distance"  type="text" id="jump_height_distance"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入航迹两点高度大于以下值判断为高度跳变"  value="<?php echo isset($data_info['jump_height_distance'])?$data_info['jump_height_distance']:'' ?>"/>
                    </div>
                </div> -->
                 <div class="form-group">
                    <label  class="col-sm-2 control-label">最大垂直速度(FL/s)</label>
                    <div class="col-sm-4">
                        <input name="max_virtual_speed"  type="text" id="max_virtual_speed"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入最大垂直速度"  value="<?php echo isset($data_info['max_virtual_speed'])?$data_info['max_virtual_speed']:'' ?>"/>
                    </div>
                </div> 

                <div class="form-group">
                    <label  class="col-sm-2 control-label">质量统计周期(微妙)</label>
                    <div class="col-sm-4">
                        <input name="chk_duration_microsec"  type="number" id="chk_duration_microsec"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入质量统计周期"  value="<?php echo isset($data_info['chk_duration_microsec'])?$data_info['chk_duration_microsec']:'' ?>"/>
                    </div>
                </div>
               
                <div class="form-group">
                    <label  class="col-sm-2 control-label">可视为同一个点的水平距离(米)</label>
                    <div class="col-sm-4">
                        <input name="fusion_point_distance"  type="number" id="fusion_point_distance"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入可视为同一个点的水平距离"  value="<?php echo isset($data_info['fusion_point_distance'])?$data_info['fusion_point_distance']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">可视为同一个点的垂直距离(FL)</label>
                    <div class="col-sm-4">
                        <input name="fusion_point_height"  type="number" id="fusion_point_height"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入可视为同一个点的垂直距离"  value="<?php echo isset($data_info['fusion_point_height'])?$data_info['fusion_point_height']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">低空高度(FL)</label>
                    <div class="col-sm-4">
                        <input name="low_height"  type="number" step="0.01" id="low_height"   class="form-control  validate[required]" placeholder="请输入可视为同一个点的垂直距离"  value="<?php echo isset($data_info['low_height'])?$data_info['low_height']:'' ?>"/>
                    </div>
                </div>
            </fieldset>

            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'vpsManage','index','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
                <?php if($can_upload):?>
                    <?php aci_ui_a($folder_name, 'publishDataDeploy', 'publish_file_add', $xml_info['id'], ' class="btn btn-primary "', '<span class="glyphicon glyphicon-file"></span> 发布配置文件') ?>
                <?php endif; ?>
            </div>

        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/index.js']);
    });
</script>