<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>

<style>
.div-box{text-align:center;font-size:18px}

</style>


<div class='panel panel-default grid'>
    <div class='panel-heading'>
                
        <i class='glyphicon glyphicon-th-list'></i>基站日志列表
           <i style="font-size: 6px;color: red">(由于数据量大，请选择24小时范围以内的日期)</i>

        <div class='panel-tools'>
         
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" id='search_form' method="get" >
            <div class="form-group">
                <label for="station_id" class="form-control-static control-label">基站名</label>
                <select class="form-control validate[required]" name="station_id" id="station_id">
                    <?php foreach($station_list as $key =>$value): ?>
                        <option value="<?php echo $value['station_id'] ?>" <?php echo isset($_GET['station_id'])&&$_GET['station_id'] == $value['station_id']?'selected':'';?> ><?php echo $value['station_name'];?></option>
                    <?php endforeach;?>
                 </select>

            </div>
            <div class="form-group">
                <label for="station_name" class="form-control-static control-label">通道选择</label>
                 <select class="form-control validate[required]" name="channel_id" id="channel_id">
                    <!-- <option value="1" <?php echo isset($_GET['channel_id'])&&$_GET['channel_id'] == 1?'selected':'';?> >R</option> -->
                    <option value="2" <?php echo isset($_GET['channel_id'])&&$_GET['channel_id'] == 2?'selected':'';?> >A</option>
                    <option value="3" <?php echo isset($_GET['channel_id'])&&$_GET['channel_id'] == 3?'selected':'';?> >B</option>
                 </select>
            </div>
            <div class="form-group">
                <label for="station_name" class="form-control-static control-label">日志类型</label>
                 <select class="form-control validate[required]" name="log_kind" id="log_kind">
                    <option value="0" <?php echo isset($_GET['log_kind'])&&$_GET['log_kind'] == 0?'selected':'';?> >异常日志</option>
                    <option value="1" <?php echo isset($_GET['log_kind'])&&$_GET['log_kind'] == 1?'selected':'';?> >所有日志</option>
                    <option value="2" <?php echo isset($_GET['log_kind'])&&$_GET['log_kind'] == 2?'selected':'';?> >数据超载</option>
                 </select>
            </div>
            <div class="form-group">
                <label for="start_time" class="form-control-static control-label">开始时间(UTC)</label>
                <input class="form-control validate[required]" type="text" onclick='WdatePicker()' name="start_time" placeholder="请输入开始时间" value="<?php echo isset($_GET['start_time'])&&$_GET['start_time']?$_GET['start_time']:'';?>" id="start_time"
                      />

            </div>
            <div class="form-group">
                <label for="end_time" class="form-control-static control-label">结束时间(UTC)</label>
                <input class="form-control validate[required]" type="text" onclick='WdatePicker()'  name="end_time" placeholder="请输入结束时间" value="<?php echo isset($_GET['end_time'])&&$_GET['end_time']?$_GET['end_time']:'';?>" id="end_time"
                       />

            </div>
            <button type="button" id='sum_button' name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
            <div class="form-group">
                <label for="clear" class="form-control-static control-label"></label>
                <button type="button" id='clear_input' name="" value="" class="btn btn btn-default">清空</button>
            </div>
            <div class="form-group pull-right">
                 <button type="button" id='print_table' name="" value="打印" class="btn btn-success"><i
                    class="glyphicon glyphicon-print"></i></button>
            </div>
        </form>
    </div>
    <form method="post" id="form_list">
            <!-- <div class="alert alert-warning" role="alert"> 暂无数据显示...</div> -->
            <!--startprint-->
            <div class="table-responsive">
                    
                        <div class='panel-body '>
                            <table class="table table-hover dataTable ">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>数据包总数</th>
                                    <th>航迹数量</th>
                                    <th>航迹消失数量</th>
                                    <th>信标机消失次数</th>
                                    <th>错包数</th>
                                    <th>位置跳变数</th>
                                    <th>高度跳变数</th>
                                    <th>日期</th>
                                    <th>日志状态</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php if($data_list):?>
                                 <?php foreach ($data_list as $k => $v): ?>
                                    <tr>
                                        <td><?php echo $k + 1 ?></td>
                                        <td><?php echo $v['count']?></td>
                                        <td><?php echo $v['target_cnt']?></td>
                                        <td><?php echo $v['dispear_cnt']?></td>
                                        <td><?php echo $v['test_dispear_cnt']?></td>
                                        <td><?php echo $v['error_cnt']?></td>
                                        <td><?php echo $v['post_jump_cnt']?></td>
                                        <td><?php echo $v['height_jump_cnt']?></td>
                                        <td><?php echo date('Y-m-d H:i:s',$v['dateline']) ?></td>
                                        <td><?php echo $v['station_status']?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                <?php else: ?>
                        <div class="alert alert-warning" role="alert"><?php echo $search_warning?'请先进行筛选条件的选择(所有筛选条件必填)':'暂无数据';?></div>
                <?php endif; ?>
                    </div>
        <?php if($pages):?>
            <div class=" panel-footer">
                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>
        <?php endif;?>
        <!--endprint-->
    </form>

</div>
</div>
<script language="javascript" type="text/javascript">
    
    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>