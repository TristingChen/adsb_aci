<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-edit'></i> 黑名单管理<?php echo $is_edit?"修改黑名单":"新增黑名单"?>
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, $controller_name, 'lists', '', ' class="btn btn-sm pull-right"', '<span class="glyphicon glyphicon-arrow-left"></span> 返回') ?>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <form name="validateform" id="validateform" class="form-horizontal"
              action="<?php echo site_url($folder_name.'/'.$controller_name.'/edit') ?>" method="post">
            <div class="form-group">
                <label class="col-sm-2 control-label">24位地址码</label>
                <div class="col-sm-5">
                    <input type="text" name="target_addr" value="<?php echo $data_info['target_addr'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">原因</label>
                <div class="col-sm-5">
                    <input type="text" name="reason" value="<?php echo $data_info['reason'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">备注</label>
                <div class="col-sm-5">
                    <input type="text" name="remark" value="<?php echo $data_info['remark'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,$controller_name, 'edit', ' type="submit" id="dosubmit" class="btn btn-primary" ', '保存') ?>
            </div>
        </form>
    </div>
</div>
<script language="javascript" type="text/javascript">
    var edit =<?php echo $is_edit?"true":"false"?>;
    var folder_name="<?php echo $folder_name?>";
    var controller_name ="<?php echo $controller_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>