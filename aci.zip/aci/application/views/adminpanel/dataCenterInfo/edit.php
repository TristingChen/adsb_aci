<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>系统信息
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'dataCenterInfo','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
                <div class="form-group">
                    <label for="data_center_name" class="col-sm-2 control-label">数据中心名称:</label>
                    <div class="col-sm-4">
                        <input name="data_center_name"  type="text" id="data_center_name"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入数据中心名称"  value="<?php echo isset($data_list['data_center_name'])?$data_list['data_center_name']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_center_name" class="col-sm-2 control-label">系统级别:</label>
                    <div class="col-sm-4">
                       <select class="form-control validate[required]" name="level">
                            <option value="1"  <?php echo ($data_list['level']==1)?"selected":''; ?>  >一级</option>
                            <option value="2" <?php echo ($data_list['level']==2)?"selected":''; ?> >二级</option>
                            <option value="3" <?php echo ($data_list['level']==3)?"selected":''; ?> >三级</option>

                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="place" class="col-sm-2 control-label">数据中心所在位置:</label>
                    <div class="col-sm-4">
                        <input name="place"  type="text" id="place"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入数据中心所在位置"  value="<?php echo isset($data_list['place'])?$data_list['place']:'' ?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <label for="sac" class="col-sm-2 control-label">sac码:</label>
                    <div class="col-sm-4">
                        <input name="sac"  type="text" id="sac"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" sacholder="请输入sac码"  value="<?php echo isset($data_list['sac'])?$data_list['sac']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="sic" class="col-sm-2 control-label">sic码:</label>
                    <div class="col-sm-4">
                        <input name="sic"  type="text" id="sic"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" sicholder="请输入sic码"  value="<?php echo isset($data_list['sic'])?$data_list['sic']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="lat" class="col-sm-2 control-label">纬度:</label>
                    <div class="col-sm-4">
                        <input name="lat"  type="number" step="0.01" id="lat"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" latholder="请输入lat码"  value="<?php echo isset($data_list['lat'])?$data_list['lat']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="lon" class="col-sm-2 control-label">经度:</label>
                    <div class="col-sm-4">
                        <input name="lon"  type="number" step="0.01" id="lon"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" lonholder="请输入lon码"  value="<?php echo isset($data_list['lon'])?$data_list['lon']:'' ?>"/>
                    </div>
                </div>
               <div class="form-group">
                    <label for="height" class="col-sm-2 control-label">高度:</label>
                    <div class="col-sm-4">
                        <input name="height"  type="number" step="0.01" id="height"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" heightholder="请输入高度"  value="<?php echo isset($data_list['height'])?$data_list['height']:'' ?>"/>
                    </div>
                </div> 
            </fieldset>
            
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'dataCenterInfo','add','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_list['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var id = "<?php echo isset($id)?$id:'';?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>