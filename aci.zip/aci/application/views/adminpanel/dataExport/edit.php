<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>参数文件
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'dataExport','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
                <div class="form-group">
                    <label for="name" class="col-sm-2 control-label">用户名:</label>
                    <div class="col-sm-4">
                        <input name="name"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入用户名"  value="<?php echo isset($data_list['name'])?$data_list['name']:'' ?>"/>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <label for="name" class="col-sm-2 control-label">用户id:</label>
                    <div class="col-sm-4">
                        <input name="user_id"  type="number" id="user_id"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入用户名id"  value="<?php echo isset($data_list['user_id'])?$data_list['user_id']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group" id="data_switch">
                    <label class="col-sm-2 control-label">数据类型:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" class="data_type" name="type" id="type1"
                                   value="0" <?php echo ($data_list['type'] == 0) ? 'checked="checked"' : ''?>> 融合
                        </label>
                        <label class="radio-inline">
                            <input type="radio" class="data_type" name="type" id="type2"
                                   value="1" <?php echo ($data_list['type'] == 1) ? 'checked="checked"' : ''?>> 原始
                        </label>
                       
                    </div>
                </div>
                <?php   if($data_list['type'] == 0):?>
                    
                    
                <?php else:?>
                    <div class="form-group" id="path_switch">
                        <label for="duration_switch" class="col-sm-2 control-label">输出通道数据:</label>
                        <div class="col-sm-5">
                            <label class="radio-inline"><input type="radio" name="from_type" class="from_type" <?php echo $data_list['from_type'] == 1 ? 'checked="checked"' : ''  ?>  value="1">A通道</label>
                            <label class="radio-inline"><input type="radio" name="from_type" class="from_type"  <?php echo $data_list['from_type'] == 2 ? 'checked="checked"' : ''  ?> value="2"> B通道 </label>
                        </div>
                    </div>
                <?php endif;?>
                <div class="form-group" id="faker_switch">
                        <label for="duration_switch" class="col-sm-2 control-label">关闭可疑目标输出:</label>
                        <div class="col-sm-5">
                            <label class="radio-inline"><input type="checkbox" <?php echo $data_list['faker_range'] == 1 ? 'checked="checked"' : ''  ?> name="faker_range" id="faker_range" value="1">范围</label>
                            <label class="radio-inline"><input type="checkbox" <?php echo $data_list['faker_radar'] == 1 ? 'checked="checked"' : ''  ?> name="faker_radar" id="faker_radar" value="1"> 雷达 </label>
                            <label class="radio-inline"><input type="checkbox" <?php echo $data_list['faker_tdoa'] == 1 ? 'checked="checked"' : ''  ?> name="faker_tdoa" id="faker_tdoa" value="1"> TDOA </label>
                            <label class="radio-inline"><input type="checkbox" <?php echo $data_list['faker_plan'] == 1 ? 'checked="checked"' : ''  ?> name="faker_plan" id="faker_plan" value="1"> 飞行计划 </label>
                        </div>
                    </div>
                
                <!-- <div class="form-group">
                    <label for="duration_switch" class="col-sm-2 control-label">输出格式:</label>
                    <div class="col-sm-4">
                        <input name=""  type="" id=""  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="输出格式"  value=""/>
                    </div>
                </div> -->
                <!-- <div class="form-group" id="is_output">
                        <label for="is_output" class="col-sm-2 control-label">输出扩展位:</label>
                        <div class="col-sm-5">
                            <label class="radio-inline"><input type="radio" name="is_output" class="is_output" <?php echo $data_list['is_output'] == 1 ? 'checked="checked"' : '' ?> value="1">是</label> 
                            <label class="radio-inline"><input type="radio" name="is_output" class="is_output"  <?php echo $data_list['is_output'] == 0 ? 'checked="checked"' : '' ?> value="0"> 否 </label>
                        </div> 
                </div> -->
                <div class="form-group" >
                    <label for="duration_switch" class="col-sm-2 control-label">周期输出开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="duration_switch" id="duration_switch1" onclick="change_display(0,'duration_val_group')"
                                   value="0" <?php echo ($data_list['duration_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="duration_switch" id="duration_switch2" onclick="change_display(1,'duration_val_group')"
                                   value="1" <?php echo ($data_list['duration_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>
                       
                    </div>
                </div>
                <div class="form-group duration_val_group" style="display: <?php echo ($data_list['duration_switch'] == 1) ? '' : 'none'?>" >
                    <label for="duration_val" class="col-sm-2 control-label">周期输出时长(秒):</label>
                    <div class="col-sm-4">
                        <input name="duration_val"  type="number" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入时长"  value="<?php echo isset($data_list['duration_val'])?$data_list['duration_val']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="delay_switch" class="col-sm-2 control-label">延迟输出开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="delay_switch" onclick="change_display(0,'delay_val_group')"
                                   value="0" <?php echo ($data_list['delay_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="delay_switch"  onclick="change_display(1,'delay_val_group')"
                                   value="1" <?php echo ($data_list['delay_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>
                       
                    </div>
                </div>
                <div class="form-group delay_val_group" style="display: <?php echo ($data_list['delay_switch'] == 1) ? '' : 'none'?>" >
                    <label for="delay_val" class="col-sm-2 control-label">延迟输出时长(秒):</label>
                    <div class="col-sm-4">
                        <input name="delay_val"  type="number" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入时长"  value="<?php echo isset($data_list['delay_val'])?$data_list['delay_val']:'' ?>"/>
                    </div>
                </div>
            
                <!-- <div class="form-group">
                    <label for="duration_switch" class="col-sm-2 control-label">A通道服务器:</label>
                    <div class="col-sm-4">
                        <input name=""  type="" id=""  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="A通道服务器"  value=""/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label class="col-sm-2 control-label">数据传输方式</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="cast_type" id="cast_type1"
                                   value="1" <?php echo ($data_list['cast_type'] == 1) ? 'checked="checked"' : ''?>> 单播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="cast_type" id="cast_type2"
                                   value="2" <?php echo ($data_list['cast_type'] == 2) ? 'checked="checked"' : ''?>> 组播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="cast_type" id="cast_type3"
                                   value="3" <?php echo ($data_list['cast_type'] == 3) ? 'checked="checked"' : ''?>> 广播
                        </label>
                    </div>
                </div>
                 <div class="form-group cast_type_ip_group" style="display: <?php echo ($data_list['cast_type'] == 2) ? '' : 'none'?>">
                    <label for="cast_type_ip" class="col-sm-2 control-label">组播地址</label>
                    <div class="col-sm-4">
                        <input name="cast_type_ip"  type="text" id="cast_type_ip"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入组播地址"  value="<?php echo isset($data_list['cast_type_ip'])?$data_list['cast_type_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group send_a_ip_group" style="display: <?php echo ($data_list['cast_type'] == 2) ? 'none' : ''?>">
                    <label for="send_a_ip" class="col-sm-2 control-label">发送目标IP</label>
                    <div class="col-sm-4">
                        <input name="send_a_ip"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入发送IP"  value="<?php echo isset($data_list['send_a_ip'])?$data_list['send_a_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group eth_num_group" style="display: <?php echo ($data_list['cast_type'] == 2) ? '' : 'none'?>">
                    <label for="eth_num" class="col-sm-2 control-label">分发服务器发送网口</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="eth_num">
                                <?php echo exchange_eth_options(25,isset($data_list['eth_num'])?$data_list['eth_num']:25)?>
                            </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="send_a_port" class="col-sm-2 control-label">发送端口</label>
                    <div class="col-sm-4">
                        <input name="send_a_port"  type="number" id="send_port_A"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入数据发送端口"  value="<?php echo isset($data_list['send_a_port'])?$data_list['send_a_port']:'' ?>"/>
                    </div>
                </div>
                 
               <!--  <div class="form-group">
                    <label for="duration_switch" class="col-sm-2 control-label">B通道服务器:</label>
                    <div class="col-sm-4">
                        <input name=""  type="" id=""  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="B通道服务器"  value=""/>
                    </div>
                </div> -->
                <!--<div class="form-group">
                    <label for="send_b_ip" class="col-sm-2 control-label">B通道发送IP</label>
                    <div class="col-sm-4">
                        <input name="send_b_ip"  type="text" id="send_b_ip"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入发送IP"  value="<?php /*echo isset($data_list['send_b_ip'])?$data_list['send_b_ip']:'' */?>"/>
                    </div>
                </div>-->
                <!-- <div class="form-group">
                    <label for="" class="col-sm-2 control-label">传输速率</label>
                    <div class="col-sm-4">
                        <input name=""  type="number"   cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入传输速率"  value=""/>
                    </div>
                </div> -->
                <!--<div class="form-group">
                    <label for="send_b_port" class="col-sm-2 control-label">B通道发送端口</label>
                    <div class="col-sm-4">
                        <input name="send_b_port"  type="number" id="send_b_port"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入数据发送端口"  value="<?php /*echo isset($data_list['send_b_port'])?$data_list['send_b_port']:'' */?>"/>
                    </div>
                </div>
                 <div class="form-group">
                    <label class="col-sm-2 control-label">B数据传输方式</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="cast_type_b" id="cast_type_b1"
                                   value="1" <?php /*echo ($data_list['cast_type_b'] == 1) ? 'checked="checked"' : ''*/?>> 单播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="cast_type_b" id="cast_type_b2"
                                   value="2" <?php /*echo ($data_list['cast_type_b'] == 2) ? 'checked="checked"' : ''*/?>> 组播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="cast_type_b" id="cast_type_b3"
                                   value="3" <?php /*echo ($data_list['cast_type_b'] == 3) ? 'checked="checked"' : ''*/?>> 广播
                        </label>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="cast_type_ip_b" class="col-sm-2 control-label">B组播地址</label>
                    <div class="col-sm-4">
                        <input name="cast_type_ip_b"  type="text" id="cast_type_ip_b"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入组播地址"  value="<?php /*echo isset($data_list['cast_type_ip_b'])?$data_list['cast_type_ip_b']:'' */?>"/>
                    </div>
                </div>-->
            </fieldset>
            <fieldset>
                <legend>过滤输出</legend>
                 <div class="form-group">
                    <label for="station_switch" class="col-sm-2 control-label">基站输出开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="station_switch" onclick="change_display(0,'station_list_group','station_flip_group')" id="station_switch1"
                                   value="0" <?php echo ($data_list['station_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="station_switch" onclick="change_display(1,'station_list_group','station_flip_group')" id="station_switch2"
                                   value="1" <?php echo ($data_list['station_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>                       
                    </div>
                </div>
                <div class="form-group station_list_group"  style="display: <?php echo ($data_list['station_switch'] == 0) ? 'none' : ''?>">
                    <label class="col-sm-2 control-label">请选择基站</label>
                    <div class="col-sm-9">
                        <?php foreach ($station_data as $item): ?>
                            <div  class="col-sm-3" >
                                <label class="col-sm-5 control-label"><?=$item['station_name']?></label><input name="station_list[]" value="<?=$item['station_id']?>"  type="checkbox"  <?php echo (is_array($data_list['station_list']) && in_array($item['station_id'],$data_list['station_list']))?'checked':'';?>  cols="45" rows="5" class="checkbox" style="" />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-group station_flip_group" style="display: <?php echo ($data_list['station_switch'] == 0) ? 'none' : ''?>" >
                    <label for="station_flip" class="col-sm-2 control-label">基站取反:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="station_flip" id="station_flip1"
                                   value="1" <?php echo ($data_list['station_flip'] == 1) ? 'checked="checked"' : ''?>> 是
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="station_flip" id="station_flip2"
                                   value="0" <?php echo ($data_list['station_flip'] == 0) ? 'checked="checked"' : ''?>> 否
                        </label>
                       
                    </div>
                </div>
                <!-- <div class="form-group">
                    <label for="select_item_switch" class="col-sm-2 control-label">版本转换开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="select_item_switch" id="select_item_switch1" onclick="change_display(0,'select_item_version_group','reverseBtn_group','select_item_val_group')" 
                                   value="0" <?php echo ($data_list['select_item_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="select_item_switch" id="select_item_switch2" onclick="change_display(1,'select_item_version_group','reverseBtn_group','select_item_val_group')" 
                                   value="1" <?php echo ($data_list['select_item_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>                       
                    </div>
                </div> -->
                <div class="form-group select_item_version_group" >
                    <label for="select_item_version"  class="col-sm-2 control-label">输出数据版本</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="select_item_version" id = "select_item_version">
                            <option value="0.26" <?php echo isset($data_list['select_item_version'])&& $data_list['select_item_version']=='0.26'?'selected':''; ?>>0.26</option>
                            <option value="1.5" <?php echo isset($data_list['select_item_version'])&& $data_list['select_item_version']=='1.5'?'selected':''; ?>>1.5</option>
                            <option value="2.1" <?php echo isset($data_list['select_item_version'])&& $data_list['select_item_version']=='2.1'?'selected':''; ?>>2.1</option>                            
                        </select>
                    </div>
                </div>
                <div class="form-group reverseBtn_group" >
                    
                 
                    <label class="col-sm-2 control-label">版本输出项:</label>
                    <div class="col-sm-5">
                        <div class="pull-left">
                            <button type="button" class="btn btn-default " id="reverseBtn"><span
                                            class="glyphicon glyphicon-ok"></span> 反选
                                    </button>
                        </div>
                    </div>
                </div>
                <div class="form-group select_item_val_group" >
                    <!-- <label for="select_item_val" class="col-sm-2 control-label">版本输出项</label> -->
                   <!--  <div class="col-sm-4">
                       <input name="select_item_val"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[select_item_val]]" placeholder="请输入版本输出项"  value="<?php echo isset($data_list['select_item_val'])?$data_list['select_item_val']:''?>"/>
                   </div> -->
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9" id = 'cat_version_data'>
                        <?php if($is_edit):?>
                                 <?php foreach ($the_chosed_data as $key=> $item): ?>
                                    <div  class="col-sm-6" >
                                        <label class="col-sm-6 control-label"><?=$item?></label><input name="select_item_val[]" value="<?= $key?>"  type="checkbox"  <?php echo $select_item_val_arr[$key] == 1?'checked':''; ?> cols="45" rows="5" class="checkbox" style="" />
                                    </div>
                                <?php endforeach; ?>


                        <?php else:?>
                                <?php foreach ($cat_version_data['0.26'] as $key=> $item): ?>
                                    <div  class="col-sm-6" >
                                        <label class="col-sm-6 control-label"><?=$item?></label><input name="select_item_val[]" checked value="<?= $key?>"  type="checkbox"   cols="45" rows="5" class="checkbox" style="" />
                                    </div>
                                <?php endforeach; ?>
                        <?php  endif;?>
                        
                    </div>
                </div>


                <div class="form-group">
                    <label for="target_add_switch" class="col-sm-2 control-label">24位地址码开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="target_add_switch" id="target_add_switch1" onclick="change_display(0,'target_add_list_group','target_addr_flip_group')"
                                   value="0" <?php echo ($data_list['target_add_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="target_add_switch" id="target_add_switch2" onclick="change_display(1,'target_add_list_group','target_addr_flip_group')"
                                   value="1" <?php echo ($data_list['target_add_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>
                       
                    </div>
                 </div>
                 <div class="form-group target_add_list_group" style="display: <?php echo ($data_list['target_add_switch'] == 0) ? 'none' : ''?>">
                    <label for="target_add_list" class="col-sm-2 control-label">24位地址码</label>
                    <div class="col-sm-4">
                        <input name="target_add_list"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入24位地址码"  value="<?php echo isset($data_list['target_add_list'])?$data_list['target_add_list']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group target_addr_flip_group" style="display: <?php echo ($data_list['target_add_switch'] == 0) ? 'none' : ''?>">
                    <label for="target_addr_flip" class="col-sm-2 control-label">24位地址码取反:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="target_add_flip" id="station_flip1"
                                   value="1" <?php echo ($data_list['target_add_flip'] == 1) ? 'checked="checked"' : ''?>> 是
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="target_add_flip" id="station_flip2"
                                   value="0" <?php echo ($data_list['target_add_flip'] == 0) ? 'checked="checked"' : ''?>> 否
                        </label>
                       
                    </div>
                </div>
               <div class="form-group">
                    <label for="company_switch" class="col-sm-2 control-label">公司三字码开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="company_switch" id="company_switch1" onclick="change_display(0,'company_list_group','company_flip_group')"
                                   value="0" <?php echo ($data_list['company_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="company_switch" id="company_switch2" onclick="change_display(1,'company_list_group','company_flip_group')"
                                   value="1" <?php echo ($data_list['company_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>
                    </div>
                </div>
                 <div class="form-group company_list_group" style="display: <?php echo ($data_list['company_switch'] == 0) ? 'none' : ''?>">
                    <label for="company_list" class="col-sm-2 control-label">公司三字码:</label>
                    <div class="col-sm-4">
                        <input name="company_list"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入公司三字码"  value="<?php echo isset($data_list['company_list'])?$data_list['company_list']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group company_flip_group" style="display: <?php echo ($data_list['company_switch'] == 0) ? 'none' : ''?>">
                    <label for="company_flip" class="col-sm-2 control-label">公司三字码取反:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="company_flip" id="company_flip1"
                                   value="1" <?php echo ($data_list['company_flip'] == 1) ? 'checked="checked"' : ''?>> 是
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="company_flip" id="company_flip2"
                                   value="0" <?php echo ($data_list['company_flip'] == 0) ? 'checked="checked"' : ''?>> 否
                        </label>
                       
                    </div>
                </div>

                <div class="form-group">
                    <label for="range_switch" class="col-sm-2 control-label">区域范围开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="range_switch" id="range_switch1" onclick="change_display(0,'range_list_group')"
                                   value="0" <?php echo ($data_list['range_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="range_switch" id="range_switch2" onclick="change_display(1,'range_list_group')"
                                   value="1" <?php echo ($data_list['range_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>
                       
                    </div>
                </div>
                
                <div class="form-group range_list_group" style="display: <?php echo ($data_list['range_switch'] == 0) ? 'none' : ''?>">
                    <label for="range_list" class="col-sm-2 control-label">区域选择:</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="range_list">
                            <?php foreach ($area_data as $key => $value):?>
                                <option value="<?php echo $value['id'];?>" <?php echo $value['id']==$data_list['range_list']?'selected':'';?> ><?php echo $value['name'];?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <label for="range_flip" class="col-sm-2 control-label">区域屏蔽开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="range_flip" id="range_flip1"
                                   value="1" <?php echo ($data_list['range_flip'] == 1) ? 'checked="checked"' : ''?>> 是
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="range_flip" id="range_flip2"
                                   value="0" <?php echo ($data_list['range_flip'] == 0) ? 'checked="checked"' : ''?>> 否
                        </label>
                       
                    </div>
                </div>
                <div class="form-group">
                    <label for="height_switch" class="col-sm-2 control-label">高度开关:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="height_switch" id="height_switch1"
                                   value="0" <?php echo ($data_list['height_switch'] == 0) ? 'checked="checked"' : ''?>> 关
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="height_switch" id="height_switch2"
                                   value="1" <?php echo ($data_list['height_switch'] == 1) ? 'checked="checked"' : ''?>> 开
                        </label>
                       
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="height_list" class="col-sm-2 control-label">高度范围:</label>
                    <div class="controls controls-row col-xs-2">
                       <input name="min_height" class="form-control " type="number"  placeholder="最小" value="<?php echo isset($data_list['min_height'])?$data_list['min_height']:'';?>">
                       
                    </div>
                    <div class="controls controls-row col-xs-2">
                       <input name="max_height" class="form-control  " type="number"  placeholder="最大" value="<?php echo isset($data_list['max_height'])?$data_list['max_height']:'';?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="height_flip" class="col-sm-2 control-label">高度取反:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="height_flip" id="height_flip1"
                                   value="1" <?php echo ($data_list['height_flip'] == 1) ? 'checked="checked"' : ''?>> 是
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="height_flip" id="height_flip2"
                                   value="0" <?php echo ($data_list['height_flip'] == 0) ? 'checked="checked"' : ''?>> 否
                        </label>
                       
                    </div>
                </div> -->
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'dataExport','add','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_list['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var id = "<?php echo isset($id)?$id:'';?>";
    var cat_version_data = JSON.parse('<?php echo json_encode($cat_version_data);?>');
    var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/edit.js');?>;
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js?t='+filemtime]);
    });
</script>