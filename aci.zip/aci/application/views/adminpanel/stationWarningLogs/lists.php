<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>

<style>
.div-box{text-align:center;font-size:18px}

</style>


<div class='panel panel-default grid'>
    <div class='panel-heading'>
                
        <i class='glyphicon glyphicon-th-list'></i>基站日志列表
           <i style="font-size: 6px;color: red">(由于数据量大，请选择24小时范围以内的日期)</i>

        <div class='panel-tools'>
         
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" id='search_form' method="get" action="/adminpanel/stationWarningLogs/lists">
            <div class="form-group">
                <label for="station_id" class="form-control-static control-label">基站名</label>
                <select class="form-control validate[required]" name="station_id" id="station_id">
                    <option value="">请选择基站</option>
                    <?php foreach($station_list as $key =>$value): ?>
                        <option value="<?php echo $value['station_id'] ?>" <?php echo isset($_GET['station_id'])&&$_GET['station_id'] == $value['station_id']?'selected':'';?> ><?php echo $value['station_name'];?></option>
                    <?php endforeach;?>
                 </select>

            </div>
            <div class="form-group">
                <label for="start_time" class="form-control-static control-label">开始时间(UTC)</label>
                <input class="form-control validate[required]" type="text" onclick='WdatePicker()' name="start_time" placeholder="请输入开始时间" value="<?php echo isset($_GET['start_time'])&&$_GET['start_time']?$_GET['start_time']:'';?>" id="start_time"
                      />

            </div>
            <div class="form-group">
                <label for="end_time" class="form-control-static control-label">结束时间(UTC)</label>
                <input class="form-control validate[required]" type="text" onclick='WdatePicker()'  name="end_time" placeholder="请输入结束时间" value="<?php echo isset($_GET['end_time'])&&$_GET['end_time']?$_GET['end_time']:'';?>" id="end_time"
                       />

            </div>
            <!-- <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/>
            </div> -->
            <button type="submit" id='sum_button' name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
            <div class="form-group">
                <label for="clear" class="form-control-static control-label"></label>
                <button type="button" id='clear_input' name="" value="" class="btn btn btn-default">清空</button>
            </div>
            
        </form>
    </div>
    <form method="post" id="form_list">
            <!-- <div class="alert alert-warning" role="alert"> 暂无数据显示...</div> -->
            <!--startprint-->
            <div class="table-responsive">
                    
                        <div class='panel-body '>
                            <table class="table table-hover dataTable ">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>基站名</th>
                                    <th>告警内容</th>
                                    <th>日期</th>

                                </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($data_list as $k => $v): ?>
                                    <tr>
                                        <td><?php echo $k + 1 ?></td>
                                        <td><?php echo $v['station_name']?></td>
                                        <td><?php echo $v['log_content']?></td>
                                        <td><?php echo date('Y-m-d H:i:s',$v['dateline']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
              
                    </div>
        <?php if($pages):?>
            <div class=" panel-footer">
                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>
        <?php endif;?>
        <!--endprint-->
    </form>

</div>
</div>
<script language="javascript" type="text/javascript">
    
    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>