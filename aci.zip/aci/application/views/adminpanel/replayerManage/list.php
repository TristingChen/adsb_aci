<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    .gray_status{background: gray;}
</style>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
               <i class='glyphicon glyphicon-th-list'></i> 回放参数配置
            <div class='panel-tools'>
                
            </div>
        </div>
        <div class='panel-body'>
                <!-- <div class="form-group">
                    <label class="col-sm-2 control-label">回放方式:</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="replayer_type" id="replayer_type1"
                                   value="1"> 开始
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="replayer_type" id="replayer_type2"
                                   value="2" > 暂停
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="replayer_type" id="replayer_type3"
                                   value="3" > 终止
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="replayer_type" id="replayer_type3"
                                   value="3" > 恢复
                        </label>
                    </div>
                </div> -->


                <div class="form-group">
                    <label class="col-sm-2 control-label">请选择基站</label>
                    <div class="col-sm-9">
                        <?php foreach ($station_data as $item): ?>
                            <div  class="col-sm-3" >
                                <label class="col-sm-5 control-label"><?=$item['station_name']?></label><input name="station_ids[]" value="<?=$item['station_id']?>" <?php echo in_array($item['station_id'], $data_info['choose_datas'])?'checked':''  ?> type="checkbox"  cols="45" rows="5" class="checkbox" style="" />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
				<div class="form-group">
                    <label class="col-sm-2 control-label">请选择回放通道</label>
                    <div class="col-sm-3">
                          <select class="form-control validate[required]" name="replay_channel" id ='replay_channel'>
                            <option value="1" <?php echo $data_info['replay_channel'] == 1?'selected':''; ?>>A</option>
                            <option value="2" <?php echo $data_info['replay_channel'] == 2?'selected':''; ?> >B</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">请选择回放服务器</label>
                    <div class="col-sm-3">
                          <select class="form-control validate[required]" name="hardware_id" id ='hardware_id'>
                            <option value="27" <?php echo $data_info['hardware_id'] == 27?'selected':''; ?>>数据录制回放服务器A</option>
                            <option value="28" <?php echo $data_info['hardware_id'] == 28?'selected':''; ?> >数据录制回放服务器B</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">发送Ip:</label>
                   <div class="col-sm-3">
                        <input name="station_ip" id="station_ip"  class="form-control validate[required]" type="text" value="<?php echo $data_info['send_ip'] ?>" placeholder="发送Ip"  />
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">发送端口:</label>
                    <div class="col-sm-3">
                        <input name="station_port" id="station_port"  class="form-control validate[required]" type="number" value="<?php echo $data_info['send_port'] ?>" placeholder="发送端口"  />
                    </div>
                </div>

                 <div class="form-group">
                    <label for="to_ip" class="col-sm-2 control-label">回放时间:</label>
                        <div class="controls controls-row col-xs-2">
                           
                           <input name="start_time" id="start_time" class="form-control validate[required]" type="text" value="<?php echo $data_info['start_time'] ?>"  placeholder="开始时间" onclick='WdatePicker()'  />
                        </div>
                        <div class="controls controls-row col-xs-2">
                           
                            <input name="end_time" id="end_time"  class="form-control validate[required]" type="text"  value="<?php echo $data_info['end_time'] ?>"  placeholder="结束时间" onclick='WdatePicker()' />
                        </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">回放倍数:</label>
                    <div class="col-sm-3">
                        <input name="rate" id="rate"  class="form-control validate[required]" type="number" value="<?php echo $data_info['replayer_rate'] ?>" placeholder="回放倍数"  />
                    </div>
                </div>
            </fieldset>
              <div class='form-actions '>
                <label class="col-sm-2 control-label">点击回放方式:</label>
               
                <button type="submit" name="replayer_type" value="1" class="btn btn-primary dosubmit ">
                    开始
                </button>
                
                <button type="submit" name="replayer_type" value="3" class="btn btn-primary dosubmit">终止</button>
            </div>
            <div class='form-actions '>
                <label class="col-sm-2 control-label"></label>
                <button type="submit" name="replayer_type" value="2" class="btn btn-primary dosubmit ">暂停</button>
                <button type="submit" name="replayer_type" value="4" class="btn btn-primary dosubmit ">恢复</button>

            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_list['id']?>//";
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>