<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>告警策略
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'appMonitor','app_alert_lists',$app_id,' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label for="app_name" class="col-sm-2 control-label">所属应用</label>
                    <div class="col-sm-4">
                        <input name="app_name"  type="text" id="app_name"  cols="45" rows="5" class="form-control  validate[required]"  value="<?php echo app_name($app_id) ?>" readonly="true"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="min_value" class="col-sm-2 control-label">最小值</label>
                    <div class="col-sm-4">
                        <input name="min_value"  type="text" id="min_value"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入最小值（默认为0）"  value="<?php echo isset($data_info['min_value'])?$data_info['min_value']:'0' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="max_value" class="col-sm-2 control-label">最大值</label>
                    <div class="col-sm-4">
                        <input name="max_value"  type="text" id="max_value"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入最大值（默认为0）"  value="<?php echo isset($data_info['max_value'])?$data_info['max_value']:'0' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="alert_description" class="col-sm-2 control-label">告警说明</label>
                    <div class="col-sm-4">
                        <input name="alert_description"  type="text" id="alert_description"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入告警说明"  value="<?php echo isset($data_info['alert_description'])?$data_info['alert_description']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="program_name" class="col-sm-2 control-label">告警周期（秒）</label>
                    <div class="col-sm-4">
                        <input name="alert_cycle"  type="text" id="alert_cycle"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入告警周期（秒）"  value="<?php echo isset($data_info['alert_cycle'])?$data_info['alert_cycle']:'30' ?>"/>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'appMonitor','alert_edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>
</form>
<script language="javascript" type="text/javascript">
    var app_id = <?php echo $app_id?>;
    var alert_id = <?php echo $data_info['alert_id']?>;
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/app_alert_edit.js']);
    });
</script>