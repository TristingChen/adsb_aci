<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i>  <?php echo $app_name?> 运行信息
        <div class='panel-tools'>

            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'appMonitor', 'data_charts', $app_id.'/'.$app_name, ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-stats"></span> 图表') ?>
            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
            <div class='panel-body '>
                <table class="table table-hover dataTable">
                    <thead>
                    <tr>
                        <th>数据源</th>
                        <th>数据IP/端口</th>
                        <th>数据量</th>
                        <th>报告时间</th>
                        <th>状  态</th>
                        <th>操  作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($data_list as $k => $v): ?>
                        <tr>
                            <td><?php echo $v['data_source'] ?></td>
                            <td><?php echo $v['data_source_ip_port'] ?></td>
                            <td><?php echo $v['count'] ?></td>
                            <td><?php echo $v['report_time'] ?></td>
                            <td><?php echo $v['alert_content'] ?></td>
                            <td>
                                <?php
                                if($v['is_receive'] == 0){
                                    aci_ui_a($folder_name, 'user', 'edit', $v['status_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-stop"></span> 关闭');
                                }else{
                                    aci_ui_a($folder_name, 'user', 'edit', $v['status_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-play"></span> 开启');
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    </tbody>
                </table>

            </div>

            <div class="panel-footer">
                <div class="pull-left">
                    <div class="btn-group">
                        <?php aci_ui_button($folder_name, 'user', 'lock', ' class="btn btn-default" id="closeMonBtn" ', '<span class="glyphicon glyphicon-stop"></span> 取消监控') ?>
                        <?php aci_ui_button($folder_name, 'user', 'lock', ' class="btn btn-default" id="openMonBtn" ', '<span class="glyphicon glyphicon-play"></span> 开启监控') ?>
                        <?php aci_ui_button($folder_name, 'user', 'lock', ' class="btn btn-default" id="updateMonBtn" ', '<span class="glyphicon glyphicon-refresh"></span> 更新监控信息') ?>
                        <?php aci_ui_button($folder_name, 'user', 'lock', ' class="btn btn-default" id="closeAppBtn" ', '<span class="glyphicon glyphicon-stop"></span> 终止应用') ?>
                        <?php aci_ui_button($folder_name, 'user', 'lock', ' class="btn btn-default" id="openAppBtn" ', '<span class="glyphicon glyphicon-play"></span> 启动应用') ?>
                    </div>
                </div>
                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>

        <?php else: ?>
            <div class="alert alert-warning" role="alert"> 暂无数据显示...</div>
        <?php endif; ?>
    </form>
</div>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/index.js']);
    });
</script>
