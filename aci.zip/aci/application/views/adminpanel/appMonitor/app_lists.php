<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> 应用列表
        <div class='panel-tools'>

            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'appMonitor', 'app_add', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 添加') ?>
					<!--
                    <p class="btn  btn-sm pull-right use_server" server_id = '0'><span class="glyphicon glyphicon-arrow-left"></span>重启</p>                            
                    <p class="btn  btn-sm pull-right use_server" server_id = '1'><span class="glyphicon glyphicon-arrow-left"></span>关机</p>
					-->

            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
        <div class="panel panel-body">
            <form method="post" id="form_list">
                <div class="table-responsive">
                    <table class="table table-hover dataTable">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>程序名</th>
                            <th>应用说明</th>
                            <th>所在服务器</th>
                            <th>操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($data_list as $k => $v): ?>
                            <tr>
                                <td><?php echo $k+1;?></td>
                                <td><?php echo $v['program_name']?></td>
                                <td><?php echo $v['app_description']?></td>
                                <td><?php echo $v['hardware_name']?></td>
                                <td>
                                    <?php aci_ui_a($folder_name, 'appMonitor', 'app_info', $v['app_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 详情') ?>
                                    <?php aci_ui_a($folder_name, 'appMonitor', 'app_edit', $v['app_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 编辑') ?>
                                    <?php aci_ui_a($folder_name, 'appMonitor', 'delete_app_one', $v['app_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-remove"></span> 删除') ?>                                  
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <?php if($pages):?>
        <div class=" panel-footer">
            <div class="pull-left">
                   <!--  <div class="btn-group">
                        <button type="button" class="btn btn-default" id="reverseBtn"><span
                                class="glyphicon glyphicon-ok"></span> 反选
                        </button>
                        <!-- <?php aci_ui_button($folder_name, 'app', 'lock', ' class="btn btn-default" id="lockBtn" ', '<span class="glyphicon glyphicon-lock"></span> 反设置禁止登录') ?> -->
                    </div> -->
                
            </div>
            <div class="pull-right">
                <?php echo $pages; ?>
            </div>
    </form>
</div>
<?php endif?>
<?php else: ?>
    <div class="panel panel-body">
        <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
    </div>
<?php endif; ?>
</form>
</div>

<script language="javascript" type="text/javascript">
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/list.js']);
    });
</script>
