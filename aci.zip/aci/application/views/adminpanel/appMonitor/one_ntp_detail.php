<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    /*h3{background: green}*/
    .res_span{background: #e45757 !important}
    .red_span{background: #e45757 !important}
    .normal_span{background: #00ffe7 !important}
    .yellow_span{background: #FFFF00 !important};
    .data-hide{cursor: pointer;};
</style>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'><?php echo $data_list['hardware_name']?> 运行图表</i><span id="main_info">
                    <?php echo $data_list['is_main']==1?'(主用)':'(备用)';  ?>
        </span>
        <!-- <span><b>时间:</b><i class="clock_time"><?php echo date('Y-m-d H:i:s',$data_list['snmp_file_time']) ?></i></span> -->
        <div class='panel-tools'>
            <div class='btn-group' id="sound_switch" style="<?php echo $data_list['error_degree']>0?'':'display: none'; ?>">
                <?php if($data_list['sound_switch'] == 1):?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $hardware_id;?>,0,0)'><span class="glyphicon glyphicon-volume-up"></span>告警铃声关闭</p>
                <?php else:?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $hardware_id;?>,1,0)'><span class="glyphicon glyphicon-volume-up"></span>告警铃声开启</p>
                <?php endif;?>
            </div>
        </div>
    </div>
            <div class="alert alert-warning res_span" role="alert" style="<?php echo $data_list['error_degree'] == 2?'':'display: none'?> ">
                  <?php  echo isset($data_list['error_info'])?$data_list['error_info']:'';?>
            </div>
            <div class="panel-body">
                    <div class="panel-body col-md-6">
                        <h3>ntp时间</h3>
                        <table class="table table-hover dataTable">
                            <thread>
                                <tr>
                                    <th>
                                        <div id = "time_box" class="normal_span" style=" margin: 0 auto; text-align: center;font-weight: bolder;font-size: 50px;vertical-align: center;border-radius: 10%;">
                                            <?php  echo date('Y-m-d H:i:s',$data_list['snmp']['time']);?>
                                        </div>
                                    </th>
                                </tr>
                            </thread>
                        </table>
                    </div>
               
            </div>
           

</div>
<script language="javascript" type="text/javascript">
        var controller_name = "<?php echo $controller_name?>";
        var folder_name = "<?php echo $folder_name?>";
        var data_list = <?php echo json_encode($data_list);?>;
        var hardware_id = <?php echo $hardware_id;?>;
         var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/one_ntp_detail.js');?>;
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
            require(['<?php echo SITE_URL?>scripts/sound_alarm.js']);
            require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/one_ntp_detail.js?t='+filemtime]);
        });
</script>