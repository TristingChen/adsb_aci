<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i>
        <?php echo $app_name ?> 告警策略
        <div class='panel-tools'>

            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'appMonitor', 'app_alert_add',$app_id, ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 添加') ?>
            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
        <div class="panel panel-body">
            <form method="post" id="form_list">
                <div class="table-responsive">
                    <table class="table table-hover dataTable">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>最小值</th>
                            <th>最大值</th>
                            <th>告警说明</th>
                            <th>告警周期（秒）</th>
                            <th>告警颜色</th>
                            <th>操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($data_list as $k => $v): ?>
                            <tr>
                                <td><?php echo $k + 1 ?></td>
                                <td><?php echo $v['min_value'] ?></td>
                                <td><?php echo $v['max_value']?></td>
                                <td><?php echo $v['alert_description']?></td>
                                <td><?php echo $v['alert_cycle']?></td>
                                <td><?php echo $v['alert_color']?></td>
                                <td>
                                    <?php aci_ui_a($folder_name, 'appMonitor', 'app_alert_edit', $v['alert_id']."/".$app_id, ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 编辑') ?>
                                    <?php aci_ui_a($folder_name, 'appMonitor', 'app_alert_delete', $v['alert_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-remove"></span> 删除') ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <?php if($pages):?>
        <div class=" panel-footer">
            <div class="pull-left">
            </div>
            <div class="pull-right">
                <?php echo $pages; ?>
            </div>
    </form>
</div>
<?php endif?>
<?php else: ?>
    <div class="panel panel-body">
        <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
    </div>
<?php endif; ?>
</form>
</div>

<script language="javascript" type="text/javascript">
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/list.js']);
    });
</script>
