<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<style type="text/css">
    .red_status{color: red};
    .green_status{color: green};
</style>
<div class="panel">
    <div class="panel-body">
        <div class="row placeholders">
            <?php foreach($data_list as $k=>$v): ?>
            <div class="col-md-3" id="<?php echo 'app_'.$v['app_id']?>">
                <div class="well" att_appid = "<?php echo $v['app_id']; ?>" style="height: 300px">
                    <table class="table">
                            <caption><?php echo $v['program_name']?></caption>
                            <threa>
                                <tr>
                                    <th>应用说明</th>
                                    <th><?php echo $v['app_description']?></th>
                                </tr>
                                <tr>
                                    <th>所在服务器</th>
                                    <th><?php echo $v['hardware_name']?></th>
                                </tr>
                                <tr>
                                    <th>最新报告时间</th>
                                    <th class="report_time"><?php echo $v['app_report_time']?></th>
                                </tr>
                                <tr>
                                    <th>报告状态</th>
                                    <th class="timing_status"><?php echo ($v['app_status'] == "OK")?'<span>正常</span>':'<span>不正常</span>'?></th>
                                </tr>
                            </threa>
                    </table>
                    <div style="text-align: right;padding-top: 10px">                        
                        <?php aci_ui_button($folder_name, 'user', 'lock', 'att_appid='.$v['app_id'].' class="btn btn-default confirm_msg"  msg_kind = "1"', '<span class="glyphicon glyphicon-stop"></span> 终止应用') ?>
                        <?php aci_ui_button($folder_name, 'user', 'lock', 'att_appid='.$v['app_id'].' class="btn btn-default confirm_msg"  msg_kind = "2"', '<span class="glyphicon glyphicon-play"></span> 启动应用') ?>
                        <?php aci_ui_button($folder_name, 'user', 'lock', 'att_appid='.$v['app_id'].' class="btn btn-default confirm_msg"  msg_kind = "3"', '<span class="glyphicon glyphicon-refresh"></span> 重启应用') ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php if($pages):?>
        <div class=" panel-footer">
            <div class="pull-left">
            </div>
            <div class="pull-right">
                <?php echo $pages; ?>
            </div>
        </div>
    <?php endif?>
</div>

<script language="javascript" type="text/javascript">
        var folder_name = "<?php echo $folder_name;?>";
        // var data_list = <?php echo json_encode($data_list);?>;
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/index.js']);
    });
</script>