<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            应用详情
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'appMonitor','app_lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            fieldset>
                <div class="form-group">
                    <label for="program_name" class="col-sm-2 control-label">程序名</label>
                    <div class="col-sm-4">
                        <input name="program_name"  type="text" id="program_name"  cols="45" rows="5" class="form-control readonly validate[required]" placeholder="请输入应用进程名称"  value="<?php echo isset($data_info['program_name'])?$data_info['program_name']:'' ?>"/>
                    </div>
                </div>
               
                
                <div class="form-group">
                    <label for="app_description" class="col-sm-2 control-label">应用说明</label>
                    <div class="col-sm-4">
                        <input name="app_description"  type="text" id="app_description"  cols="45" rows="5" class="form-control readonly  validate[required]" placeholder="请输入应用说明"  value="<?php echo isset($data_info['app_description'])?$data_info['app_description']:'' ?>"/>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="app_description" class="col-sm-2 control-label">程序目录</label>
                    <div class="col-sm-4">
                        <input name="program_start_dir"  type="text" id="program_start_dir"  cols="45" rows="5" class="form-control  validate[required]" readonly placeholder="请输入程序目录"  value="<?php echo isset($data_info['program_start_dir'])?$data_info['program_start_dir']:'' ?>"/>
                    </div>
                </div>
                 <div class="form-group">
                    <label class="col-sm-2 control-label">请选择相应的服务器</label>
                    <div class="col-sm-9">
                        <?php foreach ($hardware_data as $item): ?>
                            <div  class="col-sm-5" >
                                <label class="col-sm-5 control-label"><?=$item['hardware_name']?></label><input name="hardware_id[]" <?php echo in_array($item['hardware_id'], $data_info['hardware_id'])?'checked':'';  ?>  value="<?=$item['hardware_id']?>" disabled="disabled" type="checkbox"   cols="45" rows="5"  class="checkbox  validate[required]"  />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
              </fieldset>
           
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
    var id = <?php echo $data_info['app_id']?>;
    // var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/app_edit.js']);
    });
</script>