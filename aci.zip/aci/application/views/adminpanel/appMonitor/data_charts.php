<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> <?php echo $app_name?> 运行图表
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, 'appMonitor', 'data_lists',  $app_id.'/'.$app_name, ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-list"></span> 列表') ?>
            </div>
            <div class='badge'><?php echo count($data_list) ?></div>
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
    <form method="post" id="form_list">
        <?php if ($data_list): ?>
            <?php $i = 0;?>
            <?php foreach ($data_list as $k => $v): ?>
                <div class="panel-body col-md-4">
                    <table class="table table-hover dataTable">
                        <thread>
                            <tr>
                                <th>
                                    <div id = "container_<?php echo $i?>"></div>
                                </th>
                            </tr>
                        </thread>
                    </table>
                </div>
                <?php $i++?>
            <?php endforeach; ?>

        <?php else: ?>
            <div class="alert alert-warning" role="alert"> 暂无数据显示...</div>
        <?php endif; ?>
    </form>
</div>
</div>
<script language="javascript" type="text/javascript">
    var app_id = <?php echo $app_id?>;
    var app_name = "<?php echo $app_name?>";
    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    var charts_count = <?php echo count($data_list)?>;
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/charts.js']);
    });
</script>