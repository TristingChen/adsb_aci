<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    /*h3{background: green}*/
    .res_span{background: #e45757 !important}
    .red_span{background: #e45757 !important}
    .normal_span{background: #00ffe7 !important}
    .yellow_span{background: #FFFF00 !important};
    .data-hide{cursor: pointer;};
</style>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'><?php echo $data_list['hardware_name']?> 运行图表</i><span id="main_info">
            <?php if(!empty($is_main_limit) && $data_list['server_type'] ==2):?>
                    <?php echo $is_main_limit['is_main']==1?'(主用)':'(备用)';  ?>
            <?php endif;?>

        </span>
        <!-- <span><b>时间:</b><i class="clock_time"><?php echo date('Y-m-d H:i:s',$data_list['snmp_file_time']) ?></i></span> -->
        <div class='panel-tools'>
            <div class='btn-group' id="sound_switch" style="<?php echo $data_list['error_degree']>0?'':'display: none'; ?>">
                <?php if($data_list['sound_switch'] == 1):?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $hardware_id;?>,0,0)'><span class="glyphicon glyphicon-volume-up"></span>关闭告警铃声</p>
                <?php else:?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $hardware_id;?>,1,0)'><span class="glyphicon glyphicon-volume-up"></span>开启告警铃声</p>
                <?php endif;?>
            </div>
            <div class='btn-group'>
                <?php if(!empty($is_main_limit)): ?>
                    <p class="btn  btn-sm pull-right" id="shift_main" ><span class="glyphicon glyphicon-transfer"></span>主备切换</p>
                <?php endif;?>
            </div>  
            <div class='btn-group'>
                    <p class="btn  btn-sm pull-right use_server" server_id = '0'><span class="glyphicon glyphicon-repeat"></span>重启</p>
            </div>
            <div class='btn-group'>
                    <p class="btn  btn-sm pull-right use_server" server_id = '1'><span class="glyphicon glyphicon-off"></span>关机</p>
            </div>
           
        </div>
    </div>
    <!-- <?php if(isset($data_list['snmp'])):?> -->
            <div class="alert alert-warning res_span" role="alert" style="<?php echo $data_list['error_degree'] == 2?'':'display: none'?> ">
                  <?php  echo isset($data_list['error_info'])?$data_list['error_info']:'';?>
            </div>
    <!-- <?php endif;?> -->

            <div class="panel-body">
                 <div class="panel-body col-md-6" >
                        <h3>cpu信息</h3>
                        <table class="table table-hover table-condensed dataTable">
                            <thread>
                                <tr>
                                    <th>
                                        <div id = "container_cpu" class="<?php echo $data_list['snmp']['cpu']> $data_list['hardware_alert']['cpu_alert_value'] || $data_list['snmp']['cpu'] <0?'red_span':'normal_span' ?>" style="margin: 0 auto; text-align: center;font-size: 50px;font-weight: bolder;vertical-align: center;width: 40%;border-radius: 10%;">
                                                <?php echo $data_list['snmp']['cpu'].'%' ;?>
                                            
                                        </div>
                                    </th>
                                </tr>
                            </thread>
                        </table>
                    </div>
                    <?php if($data_list['server_type'] == 2):?>
                    <div class="panel-body col-md-6">
                                <h3>内存信息</h3>

                        <table class="table table-hover dataTable">
                            <thread>
                                <tr>
                                    <th>
                                        <div id = "container_memory" class="<?php echo $data_list['snmp']['diskArray'][0]['use']/$data_list['snmp']['diskArray'][0]['total'] >($data_list['hardware_alert']['memory_alert_value']/100) || $data_list['snmp']['diskArray'][0]['use'] <0 || $data_list['snmp']['diskArray'][0]['total'] < 0?'red_span':'normal_span' ?>" style=" margin: 0 auto; text-align: center;font-weight: bolder;font-size: 50px;vertical-align: center;border-radius: 10%;">
                                            <?php echo number_format(number_format($data_list['snmp']['diskArray'][0]['use'],2,'.','') / number_format($data_list['snmp']['diskArray'][0]['total'],2,'.',''),3,'.','').'%' ;?>
                                        </div>
                                    </th>
                                </tr>
                            </thread>
                        </table>
                    </div>
                <?php endif;?>
            </div>
            <!-- <div class="alert alert-warning" role="alert"> 暂无数据显示...</div> -->
               
                            <div class="panel-body" >
                   
                                 <?php if ($data_list['server_type'] == 2): ?>
                                    <div class='panel-body col-md-6'>
                                        <legend></legend>
                                        <h3>磁盘信息</h3>
                                        <table class="table table-responsive table-hover table-bordered dataTable ">
                                            <thead>
                                            <tr>
                                                <th>磁盘名</th>
                                                <th>磁盘总大小(G)</th>
                                                <th>磁盘已用大小(G)</th>
                                                <th>磁盘已用占比(%)</th>
                                                <th>磁盘状态</th>
                                            </tr>
                                            </thead>
                                            <tbody class="table1">
                                            <?php foreach($data_list['snmp']['diskArray'] as $key => $value): ?>
                                                <?php if( $key != 0):?>
                                                    <tr>
                                                        <td><?php echo $value['name'] ;?></td>
                                                        <td><?php echo number_format($value['total']/1024,3);?></td>
                                                        <td><?php echo number_format($value['use']/1024,3) ;?></td>
                                                        <td><?php echo number_format($value['use']/$value['total']*100,3) ; ?></td>
                                                        <td class="<?php echo (number_format($value['use']/$value['total'],3) > ($data_list['hardware_alert']['disk_alert_value']/100) || $value['fx'] == 0 || $value['total'] <0 ||$value['use']<0 )?'res_span':'';  ?> ">
                                                            <?php 
                                                                if(number_format($value['use']/$value['total'],2) > ($data_list['hardware_alert']['disk_alert_value']/100) || $value['fx'] == 0 || $value['total'] <0 ||$value['use']<0 ){
                                                                    echo '不正常';
                                                                }else {
                                                                    echo '正常';
                                                                }

                                                             ?>
                                                        </td>
                                                    </tr>
                                                <?php endif;?>
                                            <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                     <?php endif; ?>

                                      <div class='panel-body <?php echo $data_list['server_type'] == 2?'col-md-6':'' ?>'>
                                        <legend></legend>
                                        <h3>网络信息</h3>
                                        <table class="table table-hover table-bordered dataTable ">
                                            <thead>
                                            <tr>
                                                <th>网口名称</th>
                                                <th>网口ip</th>
                                                <th>已接收数据量</th>                                               
                                                <th>已发出数据量</th>                                               
                                                <th>网口状态</th>
                                            </tr>
                                            </thead>
                                            <tbody class="table2">
                                            <?php foreach ($data_list['snmp']['agentArray'] as $key => $value): ?>
                                                <tr>
                                                    <td><?php echo $value['name'] ;?></td>
                                                    <td><?php echo $value['ip'] ;?></td>
                                                    <td><?php echo $value['inNum'];?></td>
                                                    <td><?php echo $value['outNum'] ;?></td>
                                                    <td class="<?php echo ($value['fx']!=0 && $value['switch']== 1)?'':'res_span';  ?>" ><?php echo ($value['fx']!=0 && $value['switch']== 1)?"正常":"不正常" ?></td>
                                                </tr>
                                            <?php endforeach; ?>

                                            </tbody>
                                        </table>
                                    </div>
                             </div>
                             <?php  if ($data_list['server_type'] == 2): ?>
                                     <div class='panel-body col-md-6'>
                                        <legend></legend>
                                        <h3>进程信息</h3>
                                       <?php if($data_list['snmp']['forkSwitch']==1):?>
                                                <?php if(!empty($data_list['snmp']['forkArray'])):?>

                                                    <?php  foreach($data_list['snmp']['forkArray'] as $key => $value): ?>
                                                        <div class="col-md-6" >
                                                            <div class="<?php 
                                                                if($value['count'] <= 1 && $value['fx'] != 0  && $value['application']['appStatus'] =='OK' && $value['application']['hearbeatTimeOut']== true ){
                                                                    echo 'well well_progress';
                                                                }else{
                                                                    if(abs($value['count']) > 1  || $value['application']['hearbeatTimeOut'] == false){
                                                                        echo 'well well_progress red_span';
                                                                    }else{
                                                                        echo 'well well_progress yellow_span';
                                                                    }
                                                                }
                                                            ?>"  style="height: 300px; ">
                                                                <table class="table table-bordered table3">
                                                                        <caption><b><?php echo $value['name']?></b></caption>
                                                                        <threa>
                                                                            <tr>
                                                                                <th>cpu占比(%)</th>
                                                                                <th><?php echo number_format($value['cpu'],3)?></th>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>内存占用(%)</th>
                                                                                <th><?php echo number_format($value['mem'],3)?></th>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>报告状态</th>
                                                                                <th class="timing_status">
                                                                                    <?php if(abs($value['count']) <= 1 && $value['fx'] != 0 && $value['application']['hearbeatTimeOut'] != false && $value['application']['appStatus'] =='OK'  ): ?>
                                                                                           <?php  echo '正常';?>
                                                                                    <?php else: ?>    
                                                                                            <?php if($value['count'] >1 || $value['application']['hearbeatTimeOut'] == false):?>
                                                                                                  <?php echo '进程挂断,以上信息不准确';?>

                                                                                            <?php else:;?>

                                                                                                <?php echo  isset($value['application']['appAlertContent']{20})?'<div class="data-hide"  data-toggle="modal" data-target="#myModal" onclick="data_hide(this)" data-hide="'.$value['application']['appAlertContent'].'" >不正常:'.substr($value['application']['appAlertContent'], 0,20).'...</div>':'<div>不正常:'.$value['application']['appAlertContent'].'</div>';?>
                                                                                            <?php endif;?>    

                                                                                    <?php endif;?>

                                                                                </th>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>报告时间</th>
                                                                                <th><?php echo $value['application']['appReportTime'];?></th>
                                                                            </tr>
                                                                        </threa>
                                                                </table>
                                                                 <div style="text-align: right;padding-top: 10px">                        
                                                                    
                                                                    <button type="button" att_appid="<?php echo $value['app_id'];  ?>" class="btn btn-default confirm_msg" msg_kind="1" style="padding: 6px 8px"><span class="glyphicon glyphicon-stop"></span> 启动应用</button>
                                                                     <button type="button" att_appid="<?php echo $value['app_id'];  ?>" class="btn btn-default confirm_msg" msg_kind="2" style="padding: 6px 8px"><span class="glyphicon glyphicon-stop"></span> 终止应用</button>
                                                                      <button type="button" att_appid="<?php echo $value['app_id'];  ?>" class="btn btn-default confirm_msg" msg_kind="3" style="padding: 6px 8px"><span class="glyphicon glyphicon-stop"></span> 重启应用</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach;?>
                                                <?php else:?>

                                                    <div class="col-md-3" >
                                                         
                                                            <div class="well res_span"  style="height: 300px; ">
                                                                <table class="table table">
                                                                        <caption></caption>
                                                                        <threa>
                                                                            <tr>
                                                                                <th>cpu占比(%)</th>
                                                                                <th></th>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>内存占用(MB)</th>
                                                                                <th></th>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>报告状态</th>
                                                                                <th class="timing_status">
                                                                                    
                                                                                            <?php echo '无进程';?>
                                                                                  
                                                                                </th>
                                                                            </tr>
                                                                        </threa>
                                                                </table>
                                                                 
                                                            </div>
                                                        </div>

                                                <?php endif;?>
                                                
                                        <?php else:?>
                                            
                                                <?php echo '暂未进行监控'?>
                                            
                                        <?php endif;?>
                                        

                                    </div>
                            <?php endif; ?>
                            <?php   if ($data_list['server_type'] == 2):?>
                                <div class="panel-body col-md-6">
                                    <legend></legend>
                                     <h3>ntp时钟校验</h3>
                                     <div class="col-md-6" >
                                                <div class="well <?php echo $ntp_warning?'red_span':'' ?>" id = 'ntp_server_subtime' style="height: 300px; ">
                                                    <table class="table table">
                                                            <caption>时钟校验</caption>
                                                            <threa>
                                                                <tr>
                                                                    <th>ntp时间</th>
                                                                    <th><?php echo date('Y-m-d H:i:s',$ntp_time)?></th>
                                                                </tr>
                                                                <tr>
                                                                    <th>该服务器时间</th>
                                                                    <th><?php echo date('Y-m-d H:i:s',$data_list['snmp']['time']);?></th>
                                                                </tr>
                                                                <tr>
                                                                    <th>相差时间</th>
                                                                    <th>
                                                                        <?php echo $ntp_server_subtime ?>
                                                                    </th>
                                                                </tr>
                                                                <tr>
                                                                    <th>状态</th>
                                                                    <th>
                                                                        <?php echo $ntp_status_info ?>
                                                                    </th>
                                                                </tr>
                                                            </threa>
                                                    </table>
                                                     
                                                </div>
                                    </div>
                                </div>
                            <?php endif;?>
                               
            </div>

</div>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="z-index: 1055">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            &times;
                        </button>
                        <h4 class="modal-title" id="myModalLabel" attd = ''>
                            状态详情 
                        </h4>
                    </div>
                    <div class="modal-body">
                            <div class='panel-body' id="model_content">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">关闭
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal -->
</div>

<script language="javascript" type="text/javascript">
        var controller_name = "<?php echo $controller_name?>";
        var folder_name = "<?php echo $folder_name?>";
        var data_list = <?php echo json_encode($data_list);?>;
        var hardware_id = <?php echo $hardware_id;?>;
        var is_main_limit = <?php echo json_encode($is_main_limit);?>;
         var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/one_hardware_detail.js');?>;
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
            require(['<?php echo SITE_URL?>scripts/sound_alarm.js']);
            require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/one_hardware_detail.js?t='+filemtime]);
        });
</script>