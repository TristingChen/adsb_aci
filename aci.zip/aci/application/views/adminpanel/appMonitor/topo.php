<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<style>
  #pop_div{display:none;background:transparent;color:#000;background-color:rgba(255,255,255,1);position:absolute;border:1px solid #ffcfcf;z-index:1000;width:320px;height:500px;bottom:0px;left:-315px;overflow: auto}
  .wrong_row{padding-left:25px }
  .break-word{word-wrap: break-word;word-break: break-all;font-size: 8px;#c0c0c0}
  .list-group{padding-right: 20px ;}
  h6{color: red};
</style>
<div>
  <audio id="redAudio"><source src="<?php echo AUDIO_PATH;?>red.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>red.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>red.wav" type="audio/ogg"></audio>
  <audio id="yellowAudio"><source src="<?php echo AUDIO_PATH;?>yellow.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>yellow.wav" type="audio/ogg"><source src="<?php echo AUDIO_PATH;?>yellow.wav" type="audio/ogg"></audio>
</div>
<div class="myTabContent" class="tab-content">
  
    <div class="tab-pane fade in active" id="content">
       <input type="radio" name="modeRadio" value="normal" checked id="r1"/>
       <label for="r1"> 默认</label>
       &nbsp;<input type="radio" name="modeRadio" value="select" id="r2"/><label for="r2"> 框选</label>
       &nbsp;&nbsp;<input type="button" id="centerButton" value="居中显示"/>
       <input type="button" id="fullScreenButton"  value="全屏显示"/>
       <input type="button" id="zoomOutButton" value=" 放 大 " />
       <input type="button" id="zoomInButton" value=" 缩 小 " />
       &nbsp;&nbsp;<input type="checkbox" id="zoomCheckbox"/><label for="zoomCheckbox">鼠标缩放</label>
      <!--  &nbsp;&nbsp;<input type="text" id="findText" style="width: 100px;" value="" onkeydown="enterPressHandler(event)">
      <input type="button" id="findButton" value=" 查 询 ">
      &nbsp;&nbsp;<input type="button" id="cloneButton" value="选中克隆">
      &nbsp;&nbsp;<input type="button" id="linkButton" value="加  线" onclick="window.location.href='<?php echo SITE_URL.$folder_name."/".$controller_name."/add_line"?>'">
      &nbsp;&nbsp;<input type="button" id="exportButton" value="导出PNG">
      &nbsp;&nbsp;<input type="button" id="printButton" value="导出PDF"> -->
       <canvas height="500" width="800" id="canvas"></canvas>
    </div>
    
</div>

<div id = 'pop_div'>
           <div style='line-height:32px;background:#f6f0f3;border-bottom:1px solid #e0e0e0;font-size:14px;padding:0 0 0 10px;color:red'>
                <div style='float:left;'>
                  <b>监控实时信息</b>
                </div>
                <div style='float:right;cursor:pointer;'>
                  <!-- <span class='glyphicon glyphicon-remove' onclick='pop_close()'></span> -->
                </div>
                <div style='clear:both'></div>
            </div>
            <div id = 'pop_content' style='overflow:auto'>
                <div class=" wrong_row ">
                    <h6>  设备与进程实时信息简介</h6> 
                    <ul class="break-word list-group  hardware_content">  
                        <li class="list-group-item">  ssdfsadfasdfasdfasdfasfsdfsfasddddfffffffffffffffsdfffffffffffffffffffffffffffffffffffffffffffffffffffffb</li>
                    </ul>
                    
                </div>
                <div class=" wrong_row "> 
                    <h6>  基站实时信息简介</h6> 

                    <ul class="break-word list-group station_content">  

                    </ul>
                </div>
                <div class=" wrong_row">
                    <h6>  雷达实时信息简介</h6> 

                    <ul class=" break-word list-group rader_content">  

                    </ul>
                </div>
            </div>
</div>

<script language="javascript" type="text/javascript">
    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    // var to_end_notes = <?php echo to_end_notes()?>;
    var img_path = "<?php echo IMG_PATH;?>";
    var data_list = <?php echo $data_list;?>;
    var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/network.js');?>;
    
    // var server_data = <?php $server_data;?>;
    // console.log($server_data);
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/lib/jtopo-0.4.8-min.js']);
        require(['<?php echo SITE_URL?>scripts/lib/jtopo-toolbar.js']);
        require(['<?php echo SITE_URL?>scripts/jtopoCommen.js?t='+filemtime]);
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/network.js?t='+filemtime]);
        // require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/monitor.js']);
    });
</script>