<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>连线
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'appMonitor','topo','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">头节点</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="start_node_id" id="start_node_id" onchange="get_node_eths(0)">
                            <?php echo hardware_options($data_info['start_node_id'])?>
                        </select>
                    </div>
                </div>
                <div class="form-group" id="start_eth" style="display: none">
                    <label  class="col-sm-2 control-label">头节点网口</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="start_node_eth_id" id="start_node_eth_id" ></select>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">尾节点</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="end_node_id" id="end_node_id" onchange="get_node_eths(1)">
                            <?php echo hardware_options($data_info['end_node_id'])?>
                        </select>
                    </div>
                </div>
                <div class="form-group" id="end_eth" style="display: none">
                    <label  class="col-sm-2 control-label">尾节点网口</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="end_node_eth_id" id="end_node_eth_id" ></select>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">连线类型</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="line_type_id">
                            <?php echo line_type_options($data_info['line_type_id'])?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">连线颜色</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="line_color_id">
                            <?php echo color_options($data_info['line_color_id'])?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="description" class="col-sm-2 control-label">连线说明</label>
                    <div class="col-sm-4">
                        <input name="description"  type="text" id="description"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入连线说明"  value="<?php echo isset($data_info['description'])?$data_info['description']:'' ?>"/>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'ethManage','edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>
</form>
<script language="javascript" type="text/javascript">
    var id="<?php echo $data_info['line_id']?>";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/link.js']);
    });
</script>