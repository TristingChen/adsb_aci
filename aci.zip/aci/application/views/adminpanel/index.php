<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<?php if (!isset($hidden_menu)): ?>
    <style type="text/css">
        .objbody {
            overflow: hidden
        }
        .list-parents{background: silver;}
        .menu_backround{background: #1abc9c}
        a.list-parents:hover{background-color: #c0c0c0}
        a.list-parents:focus{background-color: #c0c0c0}

    </style>
    <div class="white-bg">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                            aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"><?php echo SITE_NAME?></a>
                    <a href="" class="navbar-brand"><b id="geleral_time">UTC时间:<?php echo date('Y-m-d H:i:s');?>&nbsp </b></a>
                    <p> </p>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right navbar-icon-menu">
                        <?php if ($menu_data) foreach ($menu_data as $k => $v): ?>
                            <li><a href="<?php echo $v['url'] ?>" class="<?php echo in_array($third_menu_id, explode(',', $v['arr_childid'])) ?'menu_backround':''  ?>"> <i
                                        class="fa fa-<?php echo $v['css_icon'] ?>"></i><span><?php echo $v['menu_name'] ?></span></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-3 col-md-2 sidebar">
                     <aside>
                        <?php if ($sub_menu_data) foreach ($sub_menu_data as $k => $v): ?>
                            <div class="list-group">
                                <a href="javascript:void(0)" onclick="show_children(this)" class="list-group-item list-parents"><?php echo $v['menu_name'] ?> </a>
                                <?php
                                $sub_array = $v['sub_array'];
                                if ($sub_array)
                                    foreach ($sub_array as $key => $m) {
                                        ?>
                                        <a href="<?php echo $m['url'] ?>"
                                           class="list-group-item list-children <?php echo $third_menu_id == $m['menu_id']?' current-active':'' ?>"><?php echo $m['menu_name'] ?> <i class="fa fa-chevron-right"></i></a>
                                        <?php
                                    }
                                ?>
                            </div>
                        <?php endforeach; ?>
                    </aside>
                </div>
                <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2" style="padding:0px;padding-top: 80px; ">
                    <div class="text-right pull-right" style="padding-right: 10px;"> <i class="fa fa-user"></i> <?php echo $this->user_name?> [ <?php echo group_name($this->group_id)?>], <a href="<?php echo base_url('adminpanel/manage/logout')?>">注销</a></div>

                    <ul class='breadcrumb' id='breadcrumb'>
                         <?php echo $current_pos?>
                    </ul>

                    <div style="padding: 0px 10px">
                        <?php if(DEMO_STATUS):?>
                        <div class="alert alert-warning alert-dismissible" role="alert">
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          <strong>友情提示! </strong> 当前为演示状态，增删改都不会生效，谢谢, 需要变成正式版，请修改constans.php 中 DEMO_STATUS = FALSE；
                        </div>
                        <?php endif;?>
                        <?php echo $sub_page ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <style type="text/css">
        body {
            overflow: hidden;
        }
    </style>
    <?php echo $sub_page ?>

<?php endif; ?>

<script>
    // var server_time = <?php echo time()-8*60*60;?>;
    var timeDiff = new Date().valueOf()-<?php  echo time()*1000;?>;
    var date_zone = "<?php echo date('H:s:i');?>";
    function serverTime(){
        this.date = new Date();
        date.setTime(new Date().valueOf()-timeDiff);
        this.Y = date.getUTCFullYear() + '-';
        this.M = (date.getUTCMonth()+1 < 10 ? '0'+(date.getUTCMonth()+1):date.getUTCMonth()+1)+'-';
        this.D = date.getUTCDate() <10 ? '0' + date.getUTCDate() + ' ' :date.getUTCDate() + ' ';
        this.h = date.getUTCHours() < 10 ? '0' + date.getUTCHours() + ':':date.getUTCHours() + ':';
        this.m = date.getUTCMinutes() <10 ? '0' + date.getUTCMinutes() + ':':date.getUTCMinutes() + ':';
        this.s = date.getUTCSeconds() <10 ? '0' + date.getUTCSeconds():date.getUTCSeconds();
        var timeString = "UTC时间:" + Y + M + D + h + m + s;
        document.getElementById('geleral_time').innerHTML = timeString;
    }
    window.onload = function(){
            serverTime();

        setInterval(function(){
            serverTime();
        },1000);
    }

    /*function server_clock(timestamp){
        var date = new Date(timestamp * 1000);
        Y = date.getFullYear() + '-';
        M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1):date.getMonth()+1)+'-';
        D = date.getDate() <10 ? '0' + date.getDate() + ' ' :date.getDate() + ' ';
        h = date.getHours() < 10 ? '0' + date.getHours() + ':':date.getHours() + ':';
        m = date.getMinutes() <10 ? '0' + date.getMinutes() + ':':date.getMinutes() + ':';
        s = date.getSeconds() <10 ? '0' + date.getSeconds():date.getSeconds();

        timeString = "UTC时间:" + Y + M + D + h + m + s;
        document.getElementById('geleral_time').innerHTML = timeString;
        timestamp++;
        window.setTimeout("server_clock("+timestamp+");",1000);
    }*/

    //菜单栏功能页
    var listChildren = document.getElementsByClassName('list-children');
    for (var i = 0; i < listChildren.length; i++) {
        listChildren[i].style.display = 'none';
    };

    for (var i = 0; i < listChildren.length; i++) {
        if(js_hasClass(listChildren[i],'current-active')){
            var group_list = listChildren[i].parentNode.children;
            for (var j = 0; j < group_list.length; j++) {
                group_list[j].style.display = 'block';
            };
        }
    };
    var list_parents = document.getElementsByClassName('list-parents');

    function js_hasClass(element,cls){
        return (' '+element.className + ' ').indexOf(' '+cls+' ') > -1;
    }

    //小目录的点击展开与关闭
    function show_children(_this){
        var this_children = _this.nextElementSibling;
        var brother_list = _this.parentNode.children;
        var parent_list = _this.parentNode;
        var all_parent_list = _this.parentNode.parentNode.children;
        if(this_children.offsetParent == null){
            for (var i = 0; i < brother_list.length; i++) {
                if(brother_list[i] == _this){
                    continue;
                }else{
                    brother_list[i].style.display = 'block'

                }
            };
        }else{
            for (var i = 0; i < brother_list.length; i++) {
                if(brother_list[i] == _this){
                    continue;

                }else{
                    brother_list[i].style.display = 'none'
                }
            };
        }

        for (var i = 0; i < all_parent_list.length; i++) {
            if(all_parent_list[i] == parent_list){
                continue;
            }else{
                if(all_parent_list[i].children[1].offsetParent == null){
                    continue;
                }else{
                    for (var j = 1; j < all_parent_list[i].children.length ; j++) {
                        all_parent_list[i].children[j].style.display = 'none';
                    };
                }
            }
        };
    }
    //20分钟一次
setInterval("wake_ajax(5)",1000*20*60);
function wake_ajax(ajax_time){
    var ajax = new XMLHttpRequest();
    ajax.open('get',SITE_URL+folder_name+"/manage/wake_ajax/"+ajax_time);
    ajax.send();
    ajax.onreadystatechange = function(){
        if(ajax.readyState==4 && ajax.status==200){
            console.log(ajax.responseText);
        }
    };
    
}
</script>
