<style type="text/css">
    .comments {
        overflow: auto;
        word-break: break-all;
    }
</style>
<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-edit'></i> 数据帧详细信息
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, $controller_name, 'index', $station_id.'/'.$channel_id,
                    ' class="btn btn-sm pull-right"', '<span class="glyphicon glyphicon-arrow-left"></span> 返回') ?>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <form name="validateform" id="validateform" class="form-horizontal"
              action="<?php echo site_url($folder_name . '/' . $controller_name . '/edit') ?>" method="post">

            <div class="form-group">
                <label class="col-sm-2 control-label">数据帧原文</label>
                <div class="col-sm-5">
                    <textarea id="buff"  cols="45" rows="3" class="form-control">
                        <?php echo $buff ?>
                    </textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">数据帧详情</label>
                <div class="col-sm-5">
                    <textarea id="detail"  cols="45" rows="25" class="form-control comments">

                    </textarea>
                </div>
            </div>
        </form>
    </div>
</div>
<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    var station_id = "<?php echo $station_id?>";
    var channel_id = "<?php echo $channel_id?>";
    var controller_name = "<?php echo $controller_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/detail.js']);
    });
</script>