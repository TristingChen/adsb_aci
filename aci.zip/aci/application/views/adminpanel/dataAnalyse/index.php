<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    .table-thead {
        background: #e0e0e0;
        color: #000;

    }
</style>
<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-list'></i>
        数据质量分析
        <div class='panel-tools'>
            <div class='btn-group' id="add_node">
                <a href="#" class="btn  btn-sm " id="suspend" style="display: block;float: right" onclick="suspend()">
                    <span class="glyphicon glyphicon-pause"></span> 暂停
                </a>
                <a href="#" class="btn  btn-sm " id="resume" style="display: none;float: right;" onclick="resume()">
                    <span class="glyphicon glyphicon-play"></span> 恢复
                </a>

            </div>
        </div>
    </div>
    <div class='panel-filter ' style="padding:10px">
        <div class="row">
            <form class="form-inline" role="form" method="get">
                <div class="form-group" style="padding-left: 35px">
                    <label for="keyword" class="form-control-static control-label">关键词</label>
                    <input class="form-control" type="text" name="keyword" value="" id="keyword"
                           placeholder="请输入地址码、航班号、二次代码"/></div>
                    <button type="button" name="dosubmit" value="搜索" class="btn btn-success" onclick="set_keyword()"><i
                        class="glyphicon glyphicon-search"></i></button>

                <div style="float: right;padding-right: 35px">
                    <label class="control-label" style="margin-top: 7px">基 站：</label>
                    <select class="form-control" style="width: 150px" name="station_id" id="station_id">
                        <?php echo station_options()?>
                    </select>
                    <label class="control-label" style="padding-top: 7px">通 道：</label>
                    <select class="form-control" style="width: 100px" name="channel_id" id="channel_id">
                        <option value="0" selected="selected">A</option>
                        <option value="1">B</option>
                        <option value="2">R</option>
                    </select>
                    <button type="button" class="btn btn-primary" onclick="setDatasource()">确 认</button>
                </div>
            </form>
        </div>
        <div class="row">
            <div class="col-sm-12 col-lg-12">
                <form id="formlist" name="formlist" method="post">
                    <div class="panel-body">
                        <table class="table table-hover table-bordered">
                            <thead class="table-thead">
                            <tr>
                                <th>接收时间</th>
                                <th>24位地址码</th>
                                <th>航班号</th>
                                <th>二次代码</th>
                                <th>sac码</th>
                                <th>sic码</th>
								<th>数据版本</th>													
                                <th>原始报文</th>  
								<th>异常说明</th>									
                                <th>报文分析</th>
                            </tr>
                            </thead>
                            <tbody id="buff_tbody">
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div style="display: none">
    <input type="hidden" name="hidden_keyword" id="hidden_keyword" value="">
</div>
<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    var station_id = "<?php echo $station_id?>";
    var channel_id = "<?php echo $channel_id?>";

    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/index.js']);
    });
</script>