<style type="text/css">
    .table-thead {
        background: #e0e0e0;
        color: #000;
    }
</style>
<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-list'></i>
        数据质量分析
        <div class='panel-tools'>
            <div class='btn-group' id="add_node">
                <a href="#" class="btn  btn-sm " id="suspend" style="display: block;margin-top:2px;float: right"
                   onclick="suspend()">
                    <span class="glyphicon glyphicon-pause"></span> 暂停
                </a>
                <a href="#" class="btn  btn-sm " id="resume" style="display: none;margin-top:2px;float: right"
                   onclick="resume()">
                    <span class="glyphicon glyphicon-play"></span> 恢复
                </a>
                <a href="#" class="btn btn-sm" style="margin-top: 2px"><span>选择数据源：</span></a>
                <select class="form-control" style="width:200px;display:inline;margin:2px" name="station_id"
                        id="station_id" onchange="reload_show_charts()">
                    <?php echo station_options()?>
                </select>
            </div>
        </div>
    </div>
    <div class='panel-body' style="padding:10px">
        <div class="row placeholders">
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="COUNT" class="table"></table>
                </div>

            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="TARGET_CNT" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="DISPEAR_CNT" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="TEST_DISPEAR_CNT" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="ERROR_CNT" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="POS_JUMP_CNT" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="HEIGHT_JUMP_CNT" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="GHOST_TARGET_CNT" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="ERROR_TIMEMARK" class="table"></table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="well" style="height: 450px">
                    <table id="LOW_QUALITY" class="table"></table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="sourceModal" tabindex="-1" role="dialog" aria-lableledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" style="z-index: 1050">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        &times;
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                        数据源选择
                    </h4>
                </div>
                <div class="panel-body">
                    <fieldset>
                        <div class="form-group" style="margin-top:15px">
                            <label class="col-sm-2 control-label" style="margin-top: 7px">基 站</label>

                            <div class="col-sm-4">
                                <select class="form-control validate[required]" name="station_id" id="station_id">
                                    <?php echo station_options()?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label" style="padding-top: 7px">通 道</label>

                            <div class="col-sm-4">
                                <select class="form-control validate[required]" name="channel_id" id="channel_id">
                                    <option value="0" selected="selected">A</option>
                                    <option value="1">B</option>
                                    <option value="2">R</option>
                                </select>
                            </div>
                        </div>
                    </fieldset>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">关 闭</button>
                    <button type="button" class="btn btn-primary" onclick="setDatasource()">确 认</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/statistics.js']);
    });


</script>