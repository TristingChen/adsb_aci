<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-list'></i> 数据质量分析
        <div class='panel-tools'>
            <div class='btn-group' id="add_node">
                <a href="#" class="btn  btn-sm " data-toggle="modal" data-target="#sourceModal">
                    <span class="glyphicon glyphicon-plus"></span> 选择数据源
                </a>
				<a href="#" class="btn  btn-sm " onclick="downloadExcel()">
                    <span class="glyphicon glyphicon-download-alt"></span> 导出数据
                </a>
            </div>
        </div>
    </div>
    <div class='panel-filter ' style="padding:10px">
        <div class="panel panel-body" id="network_A">
            <div class="row placeholders">
                <div class="col-md-6">
                    <div class="well" style="height: 450px">
                        <table id="COUNT" class="table"></table>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="well" style="height: 450px">
                        <table id="ERROR_TIMEMARK" class="table"></table>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="well" style="height: 450px">
                        <table id="LOW_QUALITY" class="table"></table>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="well" style="height: 450px">
                        <table id="GHOST_TARGET_CNT" class="table"></table>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="sourceModal" tabindex="-1" role="dialog" aria-lableledby="myModalLabel"
             aria-hidden="true">
            <div class="modal-dialog" style="z-index: 1050">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            &times;
                        </button>
                        <h4 class="modal-title" id="myModalLabel">
                            离线分析配置
                        </h4>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" role="form" id="sourceform" role="form" name="sourceform"
                              action="<?php echo current_url() ?>">
                            <fieldset>
                                <div class=" form-group">

                                    <label class=" col-sm-2 control-label
                                " style="padding-top: 7px">基 站</label>

                                    <div class="col-sm-4">
                                        <select class="form-control validate[required]" name="station_id"
                                                id="station_id">
                                            <?php echo station_options()?>
                                        </select>
                                    </div>

                                    <label class="col-sm-2 control-label" style="padding-top: 7px">通 道</label>

                                    <div class="col-sm-4">
                                        <select class="form-control validate[required]" name="channel_id"
                                                id="channel_id">
                                            <option value="0" selected="selected">A</option>
                                            <option value="1">B</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label" style="padding-top: 20px">开始时间</label>

                                    <div class="col-sm-4" style="padding-top: 10px">
                                        <input id="starttime" name='starttime' type='text' class="form-control"
                                               onclick='WdatePicker()' value=''><span
                                            style='color: #ff6D74'>&nbsp;*提示：使用UTC时间</span>
                                    </div>
                                    <label class="col-sm-2 control-label" style="padding-top: 20px">结束时间</label>

                                    <div class="col-sm-4" style="padding-top: 10px">
                                        <input id="endtime" name='endtime' type='text' class="form-control"
                                               onclick='WdatePicker()'
                                               value=''><span style='color: #ff6D74'>&nbsp;*提示：使用UTC时间</span>
                                    </div>
                                </div>
                            </fieldset>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">关 闭</button>
								<button type="button" class="btn btn-primary" onclick="setDatasource()">确 认</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <script language="javascript" type="text/javascript">
        var folder_name = "<?php echo $folder_name?>";
    </script>
    <script src= "<?php echo SITE_URL?>scripts/lib/jquery.js"></script>
    <script src= "<?php echo SITE_URL?>scripts/lib/bootstrap.js"></script>
    <script src= "<?php echo SITE_URL?>scripts/lib/sco.message.js"></script>
    <script src= "<?php echo SITE_URL?>scripts/lib/My97DatePicker/WdatePicker.js"></script>
    <script src= "<?php echo SITE_URL?>scripts/lib/highcharts/highcharts.js"></script>
    <script src= "<?php echo SITE_URL?>scripts/lib/highcharts/modules/exporting.js"></script>
    <script src= "<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/offline.js"></script>