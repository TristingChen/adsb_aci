<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-edit'></i> 节点管理<?php echo $is_edit?"修改节点":"新增节点"?>
        <div class='panel-tools'>
            <div class='btn-group'>
                <?php aci_ui_a($folder_name, $controller_name, 'index', $app_id, ' class="btn btn-sm pull-right"', '<span class="glyphicon glyphicon-arrow-left"></span> 返回') ?>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <form name="validateform" id="validateform" class="form-horizontal"
              action="<?php echo site_url($folder_name.'/'.$controller_name.'/edit') ?>" method="post">
            <div class="form-group">
                <label class="col-sm-2 control-label">所属应用</label>
                <div class="col-sm-5">
                    <select name="app_id" id="app_id" class=" form-control">
                        <?php echo app_options($app_id); ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">上级节点</label>
                <div class="col-sm-5">
                    <select name="parent_id" id="parent_id" class=" form-control">
                        <option value="0">作为一级节点</option>
                        <?php echo $select_categorys; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">节点名称</label>
                <div class="col-sm-5">
                    <input type="text" name="node_name" value="<?php echo $data_info['node_name'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">节点说明</label>
                <div class="col-sm-5">
                    <input type="text" name="node_description" value="<?php echo $data_info['node_description'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">对应数据库表</label>
                <div class="col-sm-5">
                    <input type="text" name="table_name" value="<?php echo $data_info['table_name'] ?>"
                           class="validate[required] form-control"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">节点属性</label>
                <div class="col-sm-5">
                    <input type="text" name="node_attribute" value="<?php echo $data_info['node_attribute'] ?>"
                           class="validate[required] form-control"/>
                    <p class="help-block">多个属性请用“;”隔开 </p>
                </div>
            </div>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,$controller_name, 'edit', ' type="submit" id="dosubmit" class="btn btn-primary" ', '保存') ?>
            </div>
        </form>
    </div>
</div>
<script language="javascript" type="text/javascript">
    var node_id =<?php echo $data_info['node_id']?>;
    var edit =<?php echo $is_edit?"true":"false"?>;
    var folder_name="<?php echo $folder_name?>";
    var controller_name ="<?php echo $controller_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>