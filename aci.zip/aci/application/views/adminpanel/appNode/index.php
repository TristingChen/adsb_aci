<div class='panel panel-default'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-list'></i> 节点管理
        <div class='panel-tools'>
            <div class='btn-group' id="add_node">
                <?php aci_ui_a($folder_name,$controller_name,'add','1/'.$app_id,' class="btn btn-sm pull-right"','<span class="glyphicon glyphicon-plus"></span> 添加节点')?>
            </div>
        </div>
    </div>
    <div class='panel-filter ' style="padding:10px">
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">应用模块</label>
                <select name="app_id" id="app_id" class=" form-control" onchange="make_table_html(this)">
                    <?php echo app_options($app_id); ?>
                </select>
            </div>
        </form>
    </div>
    <form id="formlist" name="formlist" method="post">
        <div class="panel-body">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>#</th>
                    <th>节点名称</th>
                    <th>节点说明</th>
                    <th>节点属性</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody id="tbody">
                <?php echo $table_html;?>
                </tbody>
            </table>
        </div>
        <div class="panel-footer">
            <div class="pull-left">
                <div class="btn-group">
                    <button type="button" class="btn btn-default" id="reverseBtn" ><span class="glyphicon glyphicon-ok"></span> 反选</button>
                    <?php aci_ui_button($folder_name,$controller_name,'delete',' type="button" id="deleteBtn"  class="btn btn-default" ','<span class="glyphicon glyphicon-remove"></span> 删除勾选')?>
                    <button type="button" class="btn btn-default" id="xmlBtn" ><span class="glyphicon glyphicon-ok"></span>生成XML</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script language="javascript" type="text/javascript">
    var folder_name="<?php echo $folder_name?>";
    var controller_name ="<?php echo $controller_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/index.js']);
    });
</script>