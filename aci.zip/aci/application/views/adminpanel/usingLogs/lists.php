<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    #tabContent{position: relative;}
    .work_option{display: none;margin: 0 AUTO;position: absolute;top: 20px;left:30%;background: gray;z-index: 1;width: 50%;}
    .work_grop{width: 90%;height: 90%;background: #fff}
    .modal-backdrop {z-index:0}
    .green_a{color: green}
    /*.btn-radio{with:20px;height: 20px;border-radius: 50%;vertical-align: middle;}*/
</style>
<div id="tabContent" class="tab-content">
<!--     <div class="panel-body work_option">
        <div class="form-group work_grop">
                    <label for="in_work_option"  class="col-sm-4 control-label">选择通道</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="in_work_option">
                            <option value="1">AUTO</option>
                            <option value="2">A</option>
                            <option value="3">B</option>
                        </select>
                    </div>
        </div>

    </div> -->
    <div class='panel panel-default grid tab-pane fade in active'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-th-list'></i> 用户操作日志列表
            <div class='panel-tools'>
                
                <div class='badge'><?php echo count($data_list) ?></div>
            </div>
        </div>
        <div class='panel-filter '>
            <form class="form-inline" role="form" method="get">
                <div class="form-group">
                    <label for="keyword" class="form-control-static control-label">关键词</label>
                    <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                           placeholder="请输入关键词"/></div>
                <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                        class="glyphicon glyphicon-search"></i></button>
            </form>
        </div>
        <?php if ($data_list): ?>
            <div class="panel panel-body" id="network_A">
                <form method="post" id="form_list">
                    <div class="table-responsive">
                        <table class="table table-hover dataTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>用户名</th>
                                <th>操作内容</th>
                                <th>操作详情</th>
                                <th>操作状态</th>
                                <th>操作ip地址</th>
                                <th>操作时间</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($data_list as $k => $v): ?>
                                <tr>
                                    <td><?php echo $k + 1 ?></td>
                                    <td><?php echo $v['username'] ?></td>
                                    
                                    <td><?php echo $v['operate_explain'] ?></td>
                                    <?php if($v['operate_info'] && $v['info_url'] ==''): ?>
                                    <td>
                                        <?php foreach ($v['operate_info'] as $key => $value):?>
                                            <dd>字段名称：<?php echo $value['key'];?>;旧值：<?php echo $value['old_val']?>;新值：<?php echo $value['new_val'];?></dd>
                                            
                                        <?php endforeach;?>

                                    </td>
                                    <?php elseif($v['operate_info'] == '' && $v['info_url']):; ?>
                                    <td><?php echo $v['info_url']  ?></td>

                                    <?php elseif($v['operate_info'] == '' && $v['info_url'] == ''):?>
                                    <td></td>
                                    <?php endif;?>   
                                    <td><?php echo $v['status_explain']  ?></td>
                                    <td><?php echo $v['ip_add']  ?></td>

                                    <td>
                                        <?php echo date('Y-m-d H:i:s',$v['dateline'])	?>								
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($pages):?>
                        <div class=" panel-footer">
                            <div class="pull-left">
                            </div>
                            <div class="pull-right">
                                <?php echo $pages; ?>
                            </div>
                        </div>
                    <?php endif?>
                </form>
            </div>

        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
            </div>
        <?php endif; ?>
    </div>
    
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name;?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
