<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    #tabContent{position: relative;}
    .work_option{display: none;margin: 0 AUTO;position: absolute;top: 20px;left:30%;background: gray;z-index: 1;width: 50%;}
    .work_grop{width: 90%;height: 90%;background: #fff}
    .modal-backdrop {z-index:0}
</style>
<div id="tabContent" class="tab-content">

    <div class='panel panel-default grid tab-pane fade in active'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-th-list'></i> 多边形列表
            <div class='panel-tools'>
                <div class='btn-group'>
                    

                    <?php aci_ui_a($folder_name, 'polygonsManage', 'add', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 添加') ?>
                    <!-- <?php aci_ui_a($folder_name, 'polygonsManage', 'rader_base_set', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-cog"></span> 雷达基础参数配置') ?> -->
                    <!-- <?php aci_ui_a($folder_name, 'polygonsManage', 'rader_produce_xml', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 雷达配置文件生成') ?> -->
                   
                </div>
                <div class='badge'><?php echo count($data_list) ?></div>
            </div>
        </div>
       <div class='panel-filter '>
        <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form>
    </div>
        <?php if ($data_list): ?>
            <div class="panel panel-body" id="network_A">
                <form method="post" id="form_list">
                    <div class="table-responsive">
                        <table class="table table-hover dataTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>多边形名称</th>
                                <!-- <th>类型</th> -->
                                <th>高度范围(FL)</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($data_list as $k => $v): ?>
                                <tr>
                                    <td><?php echo $k + 1 ?></td>
                                    <td><?php echo $v['name'] ?></td>
                                    <!-- <td><?php echo ($v['kind']==1)?"输出型":'输入型'; ?></td> -->
                                    <td><?php echo $v['height_list'];?></td>
                                    <td>
                                        <?php aci_ui_a($folder_name, 'polygonsManage', 'edit', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 编辑') ?>
                                        <?php aci_ui_a($folder_name, 'polygonsManage', 'delete', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 删除') ?>
                                    </td>

                                </tr>

                                     
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($pages):?>
                        <div class=" panel-footer">
                            <div class="pull-left">
                            </div>
                            <div class="pull-right">
                                <?php echo $pages; ?>
                            </div>
                        </div>
                    <?php endif?>
                </form>
            </div>
        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
            </div>
        <?php endif; ?>
    </div>
    <div class='panel panel-default grid tab-pane fade' id="network_B">

    </div>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name;?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
