<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" method="post" id="validateform" name="validateform"
      action="<?php echo current_url()?>"
      enctype="multipart/form-data" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
      xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>区域信息
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'areaManage','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
                <div class="form-group">
                    <label for="to_name" class="col-sm-2 control-label">区域名称：</label>
                    <div class="col-sm-4">
                        <input name="name"  type="text" id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入用户名"  value="<?php echo isset($data_info['name'])?$data_info['name']:'' ?>"/>
                    </div>
                </div>
                

                <!-- <div class="form-group">
                    <label for="height" class="col-sm-2 control-label">区域高度：</label>
                    <div class="col-sm-4">
                        <input name="height"  type="number" id="height"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入高度"  value="<?php echo isset($data_info['height'])?$data_info['height']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label class="col-sm-2 control-label">请选择多边形：</label>
                    <div class="col-sm-9">
                        <?php foreach ($polygons_data as $item): ?>
                            <div  class="col-sm-3" >
                                <label class="col-sm-5 control-label"><?=$item['name']?></label><input name="polygons_ids[]" value="<?=$item['id']?>"  type="checkbox"  <?php echo (is_array($data_info['polygons_ids']) && in_array($item['id'],$data_info['polygons_ids']))?'checked':'';?>  cols="20" rows="5" class="checkbox" style="" />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'areaManage','add','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
//    var id="<?php //echo $data_info['id']?>//";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var id = "<?php echo $data_info['id']?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>