<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>质量统计参数配置
            <div class='panel-tools'>

                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'trackAlert','choose','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>

                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
<!--				<div class="form-group">
                    <label for="fuserDataVersion" class="col-sm-2 control-label">融合数据版本</label>
                    <div class="col-sm-9">
                        <select class="form-control validate[required]" name="fuserDataVersion">
                            <option value="0.26"  <?php /*echo ($data_info['fuserDataVersion']==0.26)?"selected":''; */?>  >0.26</option>
                            <option value="2.1" <?php /*echo ($data_info['fuserDataVersion']==2.1)?"selected":''; */?> >2.1</option>
                            <option value="1.5" <?php /*echo ($data_info['fuserDataVersion']==1.5)?"selected":''; */?> >1.5</option>
                        </select>
                    </div>
                </div>-->
				<div class="form-group">
                    <label for="chkDrationMicroSec" class="col-sm-2 control-label">数据质量统计周期(s)</label>
                    <div class="col-sm-9">
                        <input name="chkDrationMicroSec" type="text" id="chkDrationMicroSec"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入数据质量统计周期，单位：秒"  value ="<?php echo isset($data_info['chkDrationMicroSec'])?($data_info['chkDrationMicroSec']/1000000):'' ?>"/>
                    </div>
                </div>
				<div class="form-group">
                    <label for="maxSpeed" class="col-sm-2 control-label">航空器最大速度(m/s)</label>
                    <div class="col-sm-9">
                        <input name="maxSpeed" type="text" id="maxSpeed"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入航空器最大速度值，单位：米/秒"  value ="<?php echo isset($data_info['maxSpeed'])?$data_info['maxSpeed']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="disappearTimeSec" class="col-sm-2 control-label">判断航迹消失时间(s)</label>
                    <div class="col-sm-9">
                        <input name="disappearTimeSec" type="text" id="disappearTimeSec"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入判断航迹消失时间，单位：秒"  value ="<?php echo isset($data_info['disappearTimeSec'])?$data_info['disappearTimeSec']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inJumpTimeSec" class="col-sm-2 control-label">判断位置或高度跳变时间范围(s)</label>
                    <div class="col-sm-9">
                        <input name="inJumpTimeSec" type="text"  id="inJumpTimeSec"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入判断位置或高度跳变时间范围，单位：秒"  value="<?php echo isset($data_info['inJumpTimeSec'])?$data_info['inJumpTimeSec']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="jumpPositionDistance" class="col-sm-2 control-label">判断位置跳变距离(m)</label>
                    <div class="col-sm-9">
                        <input name="jumpPositionDistance"  type="text" id="jumpPositionDistance"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入判断位置跳变距离，单位：米"  value="<?php echo isset($data_info['jumpPositionDistance'])?$data_info['jumpPositionDistance']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="jumpHeightDistance" class="col-sm-2 control-label">判断高度跳变值(FL)</label>
                    <div class="col-sm-9">
                        <input name="jumpHeightDistance"  type="text" id="jumpHeightDistance"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入判断高度跳变值，单位：百英尺"  value="<?php echo isset($data_info['jumpHeightDistance'])?$data_info['jumpHeightDistance']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="timeDelay" class="col-sm-2 control-label">判断数据延时时间(s)</label>
                    <div class="col-sm-9">
                        <select class="form-control validate[required]" name="timeDelay">
                            <option value="0"  <?php echo ($data_info['timeDelay']==0)?"selected":''; ?>  >0.4</option>
                            <option value="1" <?php echo ($data_info['timeDelay']==1)?"selected":''; ?> >0.8</option>
                            <option value="2" <?php echo ($data_info['timeDelay']==2)?"selected":''; ?> >1.2</option>
                            <option value="3" <?php echo ($data_info['timeDelay']==3)?"selected":''; ?> >1.8</option>
                            <option value="4" <?php echo ($data_info['timeDelay']==4)?"selected":''; ?> >10</option>
                            <option value="5" <?php echo ($data_info['timeDelay']==5)?"selected":''; ?> >1800</option>
                            <option value="6" <?php echo ($data_info['timeDelay']==6)?"selected":''; ?> >其他</option>
                        </select>
                    </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'trackAlert','add','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
    var id="<?php echo $data_info['id']?>";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>