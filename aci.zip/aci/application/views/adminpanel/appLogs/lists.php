<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>

<style>
.div-box{text-align:center;font-size:18px}

</style>


<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i>应用日志列表
        <div class='panel-tools'>
         
           
        </div>
    </div>
    <div class='panel-filter '>
        <form class="form-inline" role="form" id='search_form' method="get" >
            <div class="form-group">
                <label for="station_name" class="form-control-static control-label">应用名</label>
                 <select class="form-control validate[required]" name="station_name" id="station_name">
                    <?php foreach ($app_list as $key => $value) :?>
                        <option value="<?php echo $value['app_id'];?>" <?php echo isset($_GET['station_name'])&&trim($_GET['station_name']) ==$value['app_id'] ?'selected':'';?> ><?php echo $value['program_name'];?></option>
                    <?php endforeach;?>
                 </select>
            </div>
            
            <div class="form-group">
                <label for="start_time" class="form-control-static control-label">开始时间</label>
                <input class="form-control validate[required]" type="text" onclick='WdatePicker()' name="start_time" placeholder="请输入开始时间" value="<?php echo isset($_GET['start_time'])&&$_GET['start_time']?$_GET['start_time']:'';?>" id="start_time"
                      />

            </div>
            <div class="form-group">
                <label for="end_time" class="form-control-static control-label">结束时间</label>
                <input class="form-control validate[required]" type="text" onclick='WdatePicker()'  name="end_time" placeholder="请输入结束时间" value="<?php echo isset($_GET['end_time'])&&$_GET['end_time']?$_GET['end_time']:'';?>" id="end_time"
                       />

            </div>
            <button type="button" id='sum_button' name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
            <div class="form-group">
                <label for="clear" class="form-control-static control-label"></label>
                <button type="button" id='clear_input' name="" value="" class="btn btn btn-default">清空</button>
            </div>
            <div class="form-group pull-right">
                 <button type="button" id='print_table' name="" value="打印" class="btn btn-success"><i
                    class="glyphicon glyphicon-print"></i></button>
            </div>
        </form>
    </div>
    <form method="post" id="form_list">
            <!-- <div class="alert alert-warning" role="alert"> 暂无数据显示...</div> -->
            <!--startprint-->
            <div class="table-responsive">
                    
                        <div class='panel-body '>
                            <table class="table table-hover dataTable ">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>日志信息</th>
                                    <th>信息级别</th>
                                    <th>日期</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php if($data_list):?>
                                 <?php foreach ($data_list as $k => $v): ?>
                                    <tr>
                                        <td><?php echo $k + 1 ?></td>
                                        <td><?php echo $v['err_info']?></td>
                                        <td><?php echo $v['err_kind']?></td>
                                        <td><?php echo $v['dateline'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                <?php else: ?>
                        <div class="alert alert-warning" role="alert"><?php echo $search_warning?'请先进行筛选条件的选择(所有筛选条件必填)':'暂无数据';?></div>
                <?php endif; ?>
                    </div>
        <?php if($pages):?>
            <div class=" panel-footer">
                <div class="pull-right">
                    <?php echo $pages; ?>
                </div>
            </div>
        <?php endif;?>
        <!--endprint-->
    </form>

</div>
</div>
<script language="javascript" type="text/javascript">
     <?php 
    $file_path =  FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/lists.js';
    if(file_exists($file_path)){
        $file_time = filectime($file_path);
    }else{
        $file_time = 0;
    }
    ?>

    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>