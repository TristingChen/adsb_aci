
<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
                             基站详情
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'station','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <legend>基本信息</legend>
                <div class="form-group">
                    <label for="station_name"  class="col-sm-2 control-label">基站名称</label>
                    <div class="col-sm-4">
                        <input name="station_name"  type="text" readonly id="station_name"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入基站名称"  value="<?php echo isset($station_info['station_name'])?$station_info['station_name']:'' ?>"/>
                    </div>
                </div>
                
               
                <div class="form-group">
                    <label for="station_height"  class="col-sm-2 control-label">基站高度</label>
                    <div class="col-sm-4">
                        <input name="station_height"  type="text" readonly id="station_height"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入基站高度"  value="<?php echo isset($station_info['station_height'])?$station_info['station_height']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group" style="display:none;">
                    <label for="station_status"  class="col-sm-2 control-label">基站状态</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" disabled="true" name="station_status">
                            <option value="1" <?php echo ($station_info['station_status']==1)?"selected":''; ?> >正常</option>
                            <option value="2" <?php echo ($station_info['station_status']==2)?"selected":''; ?> >旁路</option>
                            <option value="3" <?php echo ($station_info['station_status']==3)?"selected":''; ?> >不正常</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_work_option"  class="col-sm-2 control-label">通道首选项</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" disabled="true" name="in_work_option">                            
                            <option value="3" <?php echo isset($station_info['in_work_option'])&& $station_info['in_work_option'] == 3?'selected':''; ?> >AUTO</option>
                            <option value="1" <?php echo isset($station_info['in_work_option'])&&$station_info['in_work_option'] == 1?'selected':''; ?>  >A</option>
                            <option value="2" <?php echo isset($station_info['in_work_option'])&&$station_info['in_work_option'] == 2?'selected':''; ?>  >B</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="longtitude"  class="col-sm-2 control-label">基站经度</label>
                    <div class="col-sm-4">
                        <input name="longtitude"  type="text" readonly id="station_lng_degree"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['longtitude'])?$station_info['longtitude']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="latitude"  class="col-sm-2 control-label">基站纬度</label>
                    <div class="col-sm-4">
                        <input name="latitude"  type="text" readonly  id="station_lat_degree"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['latitude'])?$station_info['latitude']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="have_beacon"  class="col-sm-2 control-label">是否配备信标机</label>
                    <div class="col-sm-4">
                         <select class="form-control validate[required]" disabled="true" name="have_beacon">
                            <option value="1">是</option>
                            <option value="0">否</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="update_route"  class="col-sm-2 control-label">cat021推送周期(秒)</label>
                    <div class="col-sm-4">
                           <input name="update_route"  type="number" readonly step="0.1" id="update_route"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['update_route'])?$station_info['update_route']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="cat023_route"  class="col-sm-2 control-label">cat023推送周期(秒)</label>
                    <div class="col-sm-4">
                           <input name="cat023_route"  type="number" readonly id="cat023_route"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['cat023_route'])?$station_info['cat023_route']:0 ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="cat247_route"  class="col-sm-2 control-label">cat247推送周期(秒)</label>
                    <div class="col-sm-4">
                           <input name="cat247_route"  type="number" readonly  id="cat247_route"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['cat247_route'])?$station_info['cat247_route']:0 ?>"/>
                    </div>
                </div>
                <!-- <div class="form-group">
                    <label for="original_kind"  class="col-sm-2 control-label">数据源类型</label>
                    <div class="col-sm-4">
                           <input name="original_kind"  type="number" step="0.1"  id="original_kind"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['original_kind'])?$station_info['original_kind']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label for="beacon_send_cycle"  class="col-sm-2 control-label">信标机发送周期（秒）</label>
                    <div class="col-sm-4">
                           <input name="beacon_send_cycle"  type="number" readonly step="0.1" id="station_lng_degree"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['beacon_send_cycle'])?$station_info['beacon_send_cycle']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="receive_range"  class="col-sm-2 control-label">最大覆盖范围(KM)</label>
                    <div class="col-sm-4">
                           <input name="receive_range"  type="number" readonly step="0.1"  id="station_lng_degree"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_info['receive_range'])?$station_info['receive_range']:'' ?>"/>
                    </div>
                </div>


               
                <!-- 
                <div class="form-group">
                    <label for="tdoa_check"  class="col-sm-2 control-label">TDOA验证假目标发送</label>
                    <div class="col-sm-5 ">
                    
                        <label class="radio-inline  control-label">是</label>
                            <input type="radio" class="btn-radio " <?php echo $station_info['tdoa_check']==1?'checked':'' ?> name="tdoa_check" id="tdoa_check2"
                                   value="1" > 
                        <label class="radio-inline  control-label">否</label>
                            <input type="radio" name="tdoa_check" id="tdoa_check3"
                                   value="0" <?php echo $station_info['tdoa_check']==0?'checked':'' ?> > 
                        
                    </div>
                </div>
                <div class="form-group">
                    <label for="rader_check"  class="col-sm-2 control-label">雷达验证假目标发送</label>
                    <div class="col-sm-5 ">
                    
                        <label class="radio-inline  control-label">是</label>
                            <input type="radio" class="btn-radio " <?php echo $station_info['rader_check']==1?'checked':'' ?> name="rader_check" id="rader_check2"
                                   value="1" > 
                        <label class="radio-inline  control-label">否</label>
                            <input type="radio" name="rader_check" id="rader_check3"
                                   value="0" <?php echo $station_info['rader_check']==0?'checked':'' ?> >                         
                    </div>
                </div>
                <div class="form-group">
                    <label for="is_send"  class="col-sm-2 control-label">范围验证假目标发送</label>
                    <div class="col-sm-5 ">
                    
                        <label class="radio-inline  control-label">是</label>
                            <input type="radio" class="btn-radio " <?php echo $station_info['is_send']==1?'checked':'' ?> name="is_send" id="is_send2"
                                   value="1" > 
                        <label class="radio-inline  control-label">否</label>
                            <input type="radio" name="is_send" id="is_send3"
                                   value="0" <?php echo $station_info['is_send']==0?'checked':'' ?> > 
                        
                    </div>
                </div>
                <div class="form-group">
                    <label for="is_channel_open_self"  class="col-sm-2 control-label">熔断自动恢复</label>
                    <div class="col-sm-5 ">                    
                        <label class="radio-inline  control-label">是</label>
                            <input type="radio" class="btn-radio " <?php echo $station_info['is_send']==1?'checked':'' ?> name="is_channel_open_self" 
                                   value="1" > 
                        <label class="radio-inline  control-label">否</label>
                            <input type="radio" name="is_channel_open_self" 
                                   value="0" <?php echo $station_info['is_send']==0?'checked':'' ?> >                      
                    </div>
                </div>
                -->
                <div class="form-group">
                    <label for="rader_ids"  class="col-sm-2 control-label">关联雷达</label>
                        <div class="col-sm-9">
                            <?php foreach ($all_rader_list as $item): ?>
                                <div  class="col-sm-3" >
                                    <label class="col-sm-5 control-label"><?=$item['name']?></label><input name="rader_ids[]" value="<?=$item['id']?>"  <?php echo is_array($station_info['rader_ids']) && in_array($item['id'], $station_info['rader_ids'])?'checked':''  ?>  type="checkbox" disabled="true"  cols="45" rows="5" class="checkbox" style="" />
                                </div>
                            <?php endforeach; ?>
                        </div>
                </div>
                <div class="form-group">
                    <label for="is_station"  class="col-sm-2 control-label">是否数据站</label>
                    <div class="col-sm-5 ">
                    
                        <label class="radio-inline  control-label">是</label>
                            <input type="radio" disabled="true" class="btn-radio " <?php echo $station_info['is_station']==1?'checked':'' ?> name="is_station" id="is_station2"
                                   value="1" > 
                        <label class="radio-inline  control-label">否</label>
                            <input type="radio" disabled="true" name="is_station" id="is_station3"
                                   value="0" <?php echo $station_info['is_station']==0?'checked':'' ?> > 
                        
                    </div>
                </div>
                 <div class="form-group">
                    <label for="is_station"  class="col-sm-2 control-label">是否监控</label>
                    <div class="col-sm-5 ">
                    
                        <label class="radio-inline  control-label">是</label>
                            <input type="radio" disabled="true" class="btn-radio " <?php echo $station_info['is_monitor']==1?'checked':'' ?> name="is_monitor" id="is_monitor2"
                                   value="1" > 
                        <label class="radio-inline  control-label">否</label>
                            <input type="radio" disabled="true" name="is_monitor" id="is_monitor3"
                                   value="0" <?php echo $station_info['is_monitor']==0?'checked':'' ?> > 
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend>配置信息</legend>
                <label style="text-align: center;margin-bottom: 8px">A路数据配置</label>
                <div class="form-group">
                    <label for="sac_code_A"  class="col-sm-2 control-label">通道A-SAC码</label>
                    <div class="col-sm-4">
                        <input name="sac_code_A"  type="text" readonly id="sac_code_A"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入基站SAC码"  value="<?php echo isset($station_config_info['sac_code_A'])?$station_config_info['sac_code_A']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="sic_code_A"  class="col-sm-2 control-label">通道A-SIC码</label>
                    <div class="col-sm-4">
                        <input name="sic_code_A"  type="text" readonly id="sic_code_A"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入基站SIC码"  value="<?php echo isset($station_config_info['sic_code_A'])?$station_config_info['sic_code_A']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_version_A"  class="col-sm-2 control-label">数据版本</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" disabled="true" name="data_version_A">
                            <option value="0.26"  <?php echo ($station_config_info['data_version_A']==0.26)?"selected":''; ?>  >0.26</option>
                            <option value="2.1" <?php echo ($station_config_info['data_version_A']==2.1)?"selected":''; ?> >2.1</option>
                            <option value="1.5" <?php echo ($station_config_info['data_version_A']==1.5)?"selected":''; ?> >1.5</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="cast_type_A" class="col-sm-2 control-label">传输类型</label>
                    <div class="col-sm-4">
                        <select id="cast_type_A" class="form-control validate[required]" disabled="true" name="cast_type_A">
                            <?php echo  cast_type_options(isset($station_config_info['cast_type_A'])?$station_config_info['cast_type_A']:1)?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="channel_status_A" class="col-sm-2 control-label">通道状态</label>
                    <div class="col-sm-4">
                        <select id="enable_A" class="form-control" disabled="true" name="enable_A">
                            <?php echo enable_status_options(isset($station_config_info['enable_A'])?$station_config_info['enable_A']:1)?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="send_ip_A" class="col-sm-2 control-label">发送数据IP</label>
                    <div class="col-sm-4">
                        <input name="send_ip_A"  type="text" readonly id="send_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入A网数据接收IP"  value="<?php echo isset($station_config_info['send_ip_A'])?$station_config_info['send_ip_A']:'' ?>"/>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="channel_ip_A" class="col-sm-2 control-label">通道IP</label>
                    <div class="col-sm-4">
                        <input name="channel_ip_A"  type="text" readonly id="channel_ip_A"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入A网数据接收IP"  value="<?php echo isset($station_config_info['channel_ip_A'])?$station_config_info['channel_ip_A']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="send_port_A" class="col-sm-2 control-label">发送数据端口</label>
                    <div class="col-sm-4">
                        <input name="send_port_A"  type="text" readonly id="send_port_A"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入A网数据接收端口"  value="<?php echo isset($station_config_info['send_port_A'])?$station_config_info['send_port_A']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="exchange_eth_num_A" class="col-sm-2 control-label">ADS-B收集解析服务器A数据接收网口</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" disabled="true" name="exchange_eth_num_A">
                            <?php echo exchange_eth_options(1,isset($station_config_info['exchange_eth_num_A'])?$station_config_info['exchange_eth_num_A']:1)?>
                        </select>
                    </div>
                </div>
               <!--  <div class="form-group">
                    <label for="channel_status_A" class="col-sm-2 control-label">主备状态</label>
                    <div class="col-sm-4">
                        <select id="channel_status_A" class="form-control" name="channel_status_A">
                            <?php echo channel_status_options(isset($station_config_info['channel_status_A'])?$station_config_info['channel_status_A']:1)?>
                        </select>
                    </div>
                </div> -->
                <div class="form-group">
                    <label for="channel_status_A" class="col-sm-2 control-label">最大航迹数</label>
                    <div class="col-sm-4">
                          <input name="track_upper_limit_A"  type="number" readonly  id="track_upper_limit_A"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_config_info['track_upper_limit_A'])?$station_config_info['track_upper_limit_A']:0 ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="data_upper_limit_A" class="col-sm-2 control-label">最大接收数据帧数量（个/秒）</label>
                    <div class="col-sm-4">
                        <input name="data_upper_limit_A"  type="number" readonly  id="data_upper_limit_A"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_config_info['data_upper_limit_A'])?$station_config_info['data_upper_limit_A']:0 ?>"/>
                    </div>
                </div>
                    <label style="text-align: center;margin-bottom: 8px">B路数据配置</label>
                    <div class="form-group">
                        <label for="sac_code_B"  class="col-sm-2 control-label">通道B-SAC码</label>
                        <div class="col-sm-4">
                            <input name="sac_code_B"  type="text" readonly id="sac_code_B"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入基站SAC码"  value="<?php echo isset($station_config_info['sac_code_B'])?$station_config_info['sac_code_B']:'' ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="sic_code_B"  class="col-sm-2 control-label">通道B-SIC码</label>
                        <div class="col-sm-4">
                            <input name="sic_code_B"  type="text" readonly id="sic_code_B"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入基站SIC码"  value="<?php echo isset($station_config_info['sic_code_B'])?$station_config_info['sic_code_B']:'' ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="data_version_B"  class="col-sm-2 control-label">数据版本</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="data_version_B" disabled="true">
                            <option value="0.26"  <?php echo ($station_config_info['data_version_B']==0.26)?"selected":''; ?>  >0.26</option>
                            <option value="2.1" <?php echo ($station_config_info['data_version_B']==2.1)?"selected":''; ?> >2.1</option>
                            <option value="1.5" <?php echo ($station_config_info['data_version_B']==1.5)?"selected":''; ?> >1.5</option>
                        </select>
                    </div>
                </div>
                    <div class="form-group">
                        <label for="cast_type_B" class="col-sm-2 control-label">传输类型</label>
                        <div class="col-sm-4">
                            <select id="cast_type_B" class="form-control" name="cast_type_B" disabled="true">
                                <?php echo  cast_type_options(isset($station_config_info['cast_type_B'])?$station_config_info['cast_type_B']:1)?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="channel_status_A" class="col-sm-2 control-label">通道状态</label>
                    <div class="col-sm-4">
                        <select id="enable_B" class="form-control" name="enable_B" disabled="true">
                            <?php echo enable_status_options(isset($station_config_info['enable_B'])?$station_config_info['enable_B']:1)?>
                        </select>
                    </div>
                    </div>
                    <div class="form-group">
                        <label for="recv_ip_B" class="col-sm-2 control-label">发送数据IP</label>
                        <div class="col-sm-4">
                            <input name="send_ip_B"  type="text" readonly id="send_ip_B"  cols="45" rows="5" class="form-control  validate[required,custom[send_ip_B]]" placeholder="请输入B网数据接收IP"  value="<?php echo isset($station_config_info['send_ip_B'])?$station_config_info['send_ip_B']:'' ?>"/>
                        </div>
                    </div>

                    <div class="form-group">
                    <label for="channel_ip_B" class="col-sm-2 control-label">通道IP</label>
                    <div class="col-sm-4">
                        <input name="channel_ip_B"  type="text" readonly id="channel_ip_B"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入A网数据接收IP"  value="<?php echo isset($station_config_info['channel_ip_B'])?$station_config_info['channel_ip_B']:'' ?>"/>
                    </div>
                </div>
                    <div class="form-group">
                        <label for="recv_port_B" class="col-sm-2 control-label">发送数据端口</label>
                        <div class="col-sm-4">
                            <input name="send_port_B"  type="text" readonly id="send_port_B"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入B网数据接收端口"  value="<?php echo isset($station_config_info['send_port_B'])?$station_config_info['send_port_B']:'' ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="exchange_eth_num_B" class="col-sm-2 control-label">ADS-B收集解析服务器B数据接收网口</label>
                        <div class="col-sm-4">
                            <select class="form-control validate[required]" disabled="true" name="exchange_eth_num_B">
                                <?php echo exchange_eth_options(1,isset($station_config_info['exchange_eth_num_B'])?$station_config_info['exchange_eth_num_B']:1)?>
                            </select>
                        </div>
                    </div>
                   <!--  <div class="form-group">
                        <label for="channel_status_B" class="col-sm-2 control-label">主备状态</label>
                        <div class="col-sm-4">
                            <select id="channel_status_B" class="form-control" name="channel_status_B">
                                <?php echo channel_status_options(isset($station_config_info['channel_status_B'])?$station_config_info['channel_status_B']:1)?>;
                            </select>
                        </div>
                    </div> -->
                    <div class="form-group">
                    <label for="channel_status_A" class="col-sm-2 control-label">最大航迹数</label>
                    <div class="col-sm-4">
                          <input name="track_upper_limit_B"  type="number" readonly  id="track_upper_limit_B"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_config_info['track_upper_limit_B'])?$station_config_info['track_upper_limit_B']:0 ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="channel_status_A" class="col-sm-2 control-label">最大接收数据帧数量（个/秒）</label>
                    <div class="col-sm-4">
                        <input name="data_upper_limit_B"  type="number" readonly  id="data_upper_limit_B"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($station_config_info['data_upper_limit_B'])?$station_config_info['data_upper_limit_B']:0 ?>"/>
                    </div>
                </div>
            </fieldset>
            
           
        </div>
    </div>
</form>
<script language="javascript" type="text/javascript">
    var id="<?php echo $station_info['station_id']?>";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>