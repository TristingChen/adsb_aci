<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    #tabContent{position: relative;}
    .work_option{display: none;margin: 0 AUTO;position: absolute;top: 20px;left:30%;background: gray;z-index: 1;width: 50%;}
    .work_grop{width: 90%;height: 90%;background: #fff}
    .modal-backdrop {z-index:0}
    /*.btn-radio{with:20px;height: 20px;border-radius: 50%;vertical-align: middle;}*/
</style>
<div id="tabContent" class="tab-content">
<!--     <div class="panel-body work_option">
        <div class="form-group work_grop">
                    <label for="in_work_option"  class="col-sm-4 control-label">选择通道</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="in_work_option">
                            <option value="1">AUTO</option>
                            <option value="2">A</option>
                            <option value="3">B</option>
                        </select>
                    </div>
        </div>

    </div> -->
    <div class='panel panel-default grid tab-pane fade in active'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-th-list'></i> 基站列表
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name, 'station', 'add', $network, ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 添加') ?>
                    <?php aci_ui_a($folder_name, 'station', 'produce_xml', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 生成配置文件') ?>
                    <?php if($fresh_xml_data):?>
                            <?php aci_ui_a($folder_name, 'publishDataDeploy', 'publish_file_add', $fresh_xml_data['id'], ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 发布配置文件') ?>
                    <?php endif;?>
                </div>
                <div class='badge'><?php echo count($data_list) ?></div>
            </div>
        </div>
       
        <?php if ($data_list): ?>
            <div class="panel panel-body" id="network_A">
                <form method="post" id="form_list">
                    <div class="table-responsive">
                        <table class="table table-hover dataTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>基站名称</th>
                                <!-- <th>基站状态</th> -->
                               <!--  <th>SAC</th>
                                <th>SIC</th> -->
                                <th>A通道CAT021版本</th>
                                <th>B通道CAT021版本</th>
                                <th>经度</th>
                                <th>纬度</th>
                                <th>高度</th>
                                <th>通道首选项</th>
                                <!--<th>当前主用通道</th>-->
                                <th>是否数据站</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($data_list as $k => $v): ?>
                                <tr>
                                    <td><?php echo $k + 1 ?></td>
                                    <td><?php echo $v['station_name'] ?></td>
                                    <!-- <td><?php echo ($v['station_status']==1)?"NORMAL":(($v['station_status']==2)?'STANDBY':'FAILED') ?></td> -->
                                    <!-- <td><?php echo $v['sac_code']?></td>
                                    <td><?php echo $v['sic_code']?></td> -->
                                    <td><?php echo $v['data_version_A']?></td>
                                    <td><?php echo $v['data_version_B']?></td>
                                    <td><?php echo $v['longtitude']?></td>
                                    <td><?php echo $v['latitude']?></td>
                                    <td><?php echo $v['station_height']?></td>
                                    <td><?php echo ($v['in_work_option']==1)?"A":(($v['in_work_option']==2)?'B':'ATUO') ?></td>
                                    <!-- <td class="current_td"><?php echo $v['current_work_pass']==1?'A':'B'; ?></td> -->
                                    <td><?php echo $v['is_station']==0?'否':'是'; ?></td>
                                    <td>
                                        <?php aci_ui_a($folder_name, 'station', 'info', $v['station_id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 详情') ?>
                                        <?php aci_ui_a($folder_name, 'station', 'edit', $v['station_id'].'/'.$network, ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 修改') ?>
                                        <?php aci_ui_a($folder_name, 'station', 'delete', $v['station_id'].'/'.$network, ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 删除') ?>
                                       
                                        										
                                    </td>

                                </tr>

                                     
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($pages):?>
                        <div class=" panel-footer">
                            <div class="pull-left">
                            </div>
                            <div class="pull-right">
                                <?php echo $pages; ?>
                            </div>
                        </div>
                    <?php endif?>
                </form>
            </div>
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                    &times;
                                </button>
                                <h4 class="modal-title" id="myModalLabel" attd = ''>
                                    基站管理 
                                </h4>
                            </div>
                            <div class="modal-body">
                                <form class="form-horizontal">
                                    <div class='panel-body'>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">通知服务器选择:</label>
                                            <div class="col-sm-9">
                                                <label>
                                                    <input type="checkbox" class="btn-checkbox " checked disabled="disabled" name="hardware_id[]" id="hardware_id2"
                                                           value="1" >ADS-B数据收集解析服务器A
                                                           <input type="hidden" name="hardware_id[]" value="1">
                                                </label>
                                                <label>
                                                    <input type="checkbox" class="btn-checkbox " checked disabled="disabled" name="hardware_id[]" id="hardware_id3"
                                                           value="2" >ADS-B数据收集解析服务器B
                                                           <input type="hidden" name="hardware_id[]" value="2">

                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">当前通道切换:</label>
                                            <div class="col-sm-5">
                                                <label class="radio-inline">
                                                    <input type="radio" name="current_work_pass"  id="current_work_pass2"
                                                           value="1" class="btn-radio change_current_path" onchange="change_current_path($(this))"> A
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="current_work_pass"  id="current_work_pass3"
                                                           value="2" class="btn-radio change_current_path" onchange="change_current_path($(this))"> B
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" id = 'station_name_again'>:</label>
                                            <div class="col-sm-5">
                                                <label class="radio-inline">
                                                    <input type="radio" class="btn-radio "  name="path_switch" id="path_switch2"
                                                           value="1"  class=" change_current_path btn-radio " onchange ="change_current_path($(this))"> 开
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="path_switch"  id="path_switch3"
                                                           value="0"  class="btn-radio change_current_path" onchange ="change_current_path($(this))"> 关
                                                </label>
                                            </div>
                                        </div>
                                        <div class="path_detail">
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label">通道A:</label>
                                                    <div class="col-sm-5">
                                                        <label class="radio-inline">
                                                            <input type="radio" class="btn-radio "  name="enable_a" id="enable_a2"
                                                                   value="1"  class="btn-radio change_current_path" onchange="change_current_path($(this))"> 开
                                                        </label>
                                                        <label class="radio-inline">
                                                            <input type="radio" name="enable_a"  id="enable_a3"
                                                                   value="0" class="btn-radio change_current_path" onchange="change_current_path($(this))"> 关
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label">通道B:</label>
                                                    <div class="col-sm-5">
                                                        <label class="radio-inline">
                                                            <input type="radio" class="btn-radio change_current_path"  name="enable_b" id="enable_b2"
                                                                   value="1" onchange="change_current_path($(this))"> 开
                                                        </label>
                                                        <label class="radio-inline">
                                                            <input type="radio" name="enable_b" class="btn-radio change_current_path"  id="enable_b3"
                                                                   value="0" onchange="change_current_path($(this))"> 关
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">关闭
                                </button>
                                <!-- <button type="button" class="btn btn-primary" id="change_current_path" >
                                    提交更改
                                </button> -->
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal -->
            </div>




        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
            </div>
        <?php endif; ?>
    </div>
    <div class='panel panel-default grid tab-pane fade' id="network_B">

    </div>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name;?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
