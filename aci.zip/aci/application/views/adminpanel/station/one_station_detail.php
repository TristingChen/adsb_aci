<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>

<style>
.div-box{text-align:center;font-size:18px}
.red_status{background: #e45757};
.yellow_status{background: #ffff00};
.caption{text-align: center !important;font-weight: bold;}
.table th{text-align: center}
</style>


<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> <?php echo $one_data_list[0]['station_name']?> 基站详情
        <div class='panel-tools'>
            <div class='btn-group' id="sound_switch" style="<?php echo $one_data_list[0]['alarm_status']>0?'':'display: none'; ?>">
                <?php if($one_data_list[0]['sound_switch'] == 1):?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $one_data_list[0]['station_id'];?>,0,1)'><span class="glyphicon glyphicon-volume-down"></span>告警铃声关闭</p>
                <?php else:?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $one_data_list[0]['station_id'];?>,1,1)'><span class="glyphicon glyphicon-volume-up"></span>告警铃声开启</p>
                <?php endif;?>
            </div>
			<div class="btn-group" id="cat023">
                  <?php if($one_data_list[0]['cat023_switch'] == 1):?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='cat_switch(<?php echo $one_data_list[0]['station_id'];?>,0,1)'><span class="glyphicon glyphicon-pause"></span>关闭cat023监控</p>
                <?php else:?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='cat_switch(<?php echo $one_data_list[0]['station_id'];?>,1,1)'><span class="glyphicon glyphicon-play"></span>开启cat023监控</p>
                <?php endif;?>      
            </div>
            <div class="btn-group" id="cat247">
                  <?php if($one_data_list[0]['cat247_switch'] == 1):?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch"  onclick='cat_switch(<?php echo $one_data_list[0]['station_id'];?>,0,2)'><span class="glyphicon glyphicon-pause"></span>关闭cat247监控</p>
                <?php else:?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" title="点我啊" onclick='cat_switch(<?php echo $one_data_list[0]['station_id'];?>,1,2)'><span class="glyphicon glyphicon-play"></span>开启cat247监控</p>
                <?php endif;?>      
            </div>
            <!-- <?php if($change_current_path_check):?>
                <div class="btn-group" id="change_curent_path">
                    <p class="btn  btn-sm pull-right"  title="点击切换主备通道" onclick='change_current_path(<?php echo $one_data_list[0]['current_work_pass'];?>,0)'><span class="glyphicon glyphicon-info-sign"></span><?php echo $one_data_list[0]['current_work_pass'] == 'A'?'切换B通道为主用':'切换A通道为主用';?></p>
                </div>
            <?php endif;?> -->
            <!-- <div class='btn-group'>
                <?php if($one_data_list[0]['sound_switch'] == 1):?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm(<?php echo $one_data_list[0]['station_id'];?>,0,1)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声关闭</p>
                <?php else:?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $hardware_id;?>,1,1)'><span class="glyphicon glyphicon-volume-up"></span>告警铃声开启</p>
                <?php endif;?>
            </div> -->
           
        </div>
    </div>
    <div class='panel-filter '>
        <!-- <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form> -->
    </div>
    <form method="post" id="form_list">
            <!-- <div class="alert alert-warning" role="alert"> 暂无数据显示...</div> -->
            <div class="table-responsive">
                    <?php if($one_data_list):?>
                        <div class='panel-body'>
                            <?php foreach($one_data_list as $key => $value):?>
                                 <div class="col-md-6 " >
                                    <div class="path_box_<?php echo $key ;?>  style="height: 370px; ">
                                        <table class="table table-responsive table-bordered table-hover table3">
                                                <caption style="text-align: center;font-size: 18px;font-weight: bold;"><?php echo $key == 0?'A通道':'B通道'  ?></caption>
                                                <tbody class="tbody_<?php echo $key?>">
                                                    <tr>
                                                        <th>通道状态</th>
                                                        <th class="current_td"><button type="button" class="btn btn-default" title="点击进行改变状态操作" onclick="change_current_path(<?php echo $value['current_work_pass'] ;?>,0,<?php echo $key == 0?'A':'B'  ?>)" ><?php if($key == 0){echo($value['current_work_pass'] == 'A')?'主用':'备用';}else{echo($value['current_work_pass'] == 'B')?'主用':'备用';} ?></button></th>
                                                    </tr>
                                                    <tr>
                                                        <th>通道开启状态</th>
                                                        <th ><button type="button" class="btn btn-default" title="点击进行改变状态操作" onclick="change_current_path(<?php echo $value['enable'] ;?>,1，<?php echo $key == 0?'A':'B'  ?>)"><?php echo $value['enable']?></button></th>
                                                    </tr>
                                                    <tr>
                                                        <th>通道发送ip</th>
                                                        <th><?php echo $value['send_ip']?></th>
                                                    </tr>
                                                    <tr>
                                                        <th>通道发送端口</th>
                                                        <th><?php echo $value['send_port']?></th>
                                                    </tr>
                                                    <tr>
                                                        <th>最小航迹数</th>
                                                        <th><?php echo $value['data_upper_limit']?></th>
                                                    </tr>
                                                    <tr>
                                                        <th>当前航迹量</th>
                                                        <?php  if(strpos($value['enable'], '开启') !== false):?>
                                                        	<th class="<?php echo $value['channel_data']>0&&$value['data_upper_limit']<$value['channel_data']?'':'red_status' ?>"><?php echo $value['channel_data'];?></th>
                                                        <?php else:?>
                                                        	<th>通道关闭未监控</th>
                                                        <?php endif;?>
                                                    </tr>
                                                    <tr>
                                                        <th>当前流量(Byte)</th>
                                                        <th><?php echo $value['channel_bite'];?></th>
                                                    </tr>
                                                    <tr>
                                                        <th>实时版本</th>
                                                        <th><?php echo $value['channel_version'];?></th>
                                                    </tr>
                                                    <tr>
                                                    	<th>版本匹配状态</th>
                                                    	<?php if(strpos($value['enable'], '开启') !== false):?>
	                                                        <?php if($value['cat247_switch']):?>
	                                                            <th><?php echo $value['version_alarm'] == 0 ?'<dd>匹配</dd>':($value['version_alarm'] == -1 ?'<dd class="red_status"> 数据流失</dd>':'<dd class="red_status"> 不匹配</dd>');?></th>
	                                                        <?php else:?>
	                                                            <th>cat247监控关闭</th>
	                                                        <?php endif;?>
                                                         <?php else:?>
                                                            <th>通道关闭未监控</th>
                                                        <?php  endif;?>
                                                    </tr>
                                                     <tr>
                                                        <th>通道告警状态</th>
                                                        <?php if(strpos($value['enable'], '开启') !== false):?>
                                                            <th><?php echo $value['channel_status']=='1'?'正常':'<dd class="red_status"> 不正常</dd>';?></th>
                                                        <?php else:?>
                                                            <th>通道关闭未监控</th>
                                                        <?php  endif;?>
                                                    </tr>
                                                     <tr>
                                                        <th>状态报告时间</th>
                                                        <th><?php echo $value['channel_time'];?></th>
                                                    </tr>
                                                     <tr>
                                                        <th>cat023详情</th>
                                                        <?php if(strpos($value['enable'], '开启') !== false):?>
	                                                        <?php if($value['cat023_switch'] == 1):?>
	                                                        	<?php if($value['cat023_status'] == 1):?>
		                                                        	<th><button type="button" class="btn btn-primary  cat_<?php echo $key;?>" onclick="show_html(<?php echo $key ;?>)">正常</button></th>
			                                                    <?php else:?>
			                                                    	<th><button type="button" class="btn btn-danger  cat_<?php echo $key;?>" onclick="show_html(<?php echo $key ;?>)">不正常</button></th>
			                                                    <?php  endif;?>
	                                                       	<?PHP else:?>
	                                                       		<th><button type="button" class="btn btn-default disabled cat_<?php echo $key;?>" onclick="show_html(<?php echo $key ;?>)">cat023未监控</button></th>
	                                                       <?php endif;?>
	                                                    <?php else:;?>
	                                                    	   <th><button type="button" class="btn btn-default disabled cat_<?php echo $key;?>" onclick="show_html(<?php echo $key ;?>)">通道关闭</button></th>
	                                                    <?php endif;?>
	                                                        
                                                    </tr>
                                                   
                                                </tbody>
                                        </table>
                                        
                                    </div>
                                </div>
                            <?php endforeach;?>
                           
                        </div>
                        
                <?php else: ?>
                    <div class="alert alert-warning" role="alert"> 暂无数据显示...</div>
                <?php endif; ?>
                    </div>
    </form>
    <?php if($one_data_list):?>
        <div class="row" style="margin: 20px auto;">
            <div class="col-md-6 cat_0_info" style="background: ;padding: 5px;display: none;"> 
                <div class="div-box">A通道</div>
                <div class="a_data_file"><?php echo $one_data_list[0]['a_data_file'];?></div>
            </div>
            <div class="col-md-6 cat_1_info" style="background: ;padding: 5px;display: none;" > 
                <div class="div-box">B通道</div>
                <div class="b_data_file"> <?php echo $one_data_list[1]['a_data_file'];?></div>
            </div>
        </div>
    <?php endif;?>
</div>
</div>
<script language="javascript" type="text/javascript">
    
    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    var station_id = <?php echo $one_data_list[0]['station_id'];?>;
    var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/one_station_detail.js');?>;

    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/sound_alarm.js']);
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/one_station_detail.js?t='+filemtime]);
    });
</script>