
<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            雷达基本参数配置
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'station','rader_lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <legend>基本信息</legend>
                <div class="form-group">
                    <label for="recv_adsb_ip"  class="col-sm-2 control-label">A网ADS-B数据接收ip</label>
                    <div class="col-sm-4">
                        <input name="recv_adsb_ip"  type="text" id="recv_adsb_ip"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入接收A网ADS-B数据ip"  value="<?php echo isset($data_info['recv_adsb_ip'])?$data_info['recv_adsb_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="recv_adsb_port"  class="col-sm-2 control-label">A网ADS-B数据接收端口</label>
                    <div class="col-sm-4">
                        <input name="recv_adsb_port"  type="number" placeholder="A网ADS-B数据接收端口" step="0.0001" id=""  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($data_info['recv_adsb_port'])?$data_info['recv_adsb_port']:'' ?>"/>
                    </div>
                </div>
				
				<div class="form-group">
                    <label for="recv_adsb_ip_2"  class="col-sm-2 control-label">B网ADS-B数据接收ip</label>
                    <div class="col-sm-4">
                        <input name="recv_adsb_ip_2"  type="text" id="recv_adsb_ip"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入接收B网ADS-B数据ip"  value="<?php echo isset($data_info['recv_adsb_ip_2'])?$data_info['recv_adsb_ip_2']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="recv_adsb_port_2"  class="col-sm-2 control-label">B网ADS-B数据接收端口</label>
                    <div class="col-sm-4">
                        <input name="recv_adsb_port_2"  type="number" placeholder="B网ADS-B数据接收端口" step="0.0001" id=""  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($data_info['recv_adsb_port_2'])?$data_info['recv_adsb_port_2']:'' ?>"/>
                    </div>
                </div>
				
                <div class="form-group">
                    <label for="category_path"  class="col-sm-2 control-label">cat配置文件目录</label>
                    <div class="col-sm-4">
                        <input name="category_path"  type="text"  id="category_path"  cols="45" rows="5" class="form-control validate[required]" placeholder=""  value="<?php echo isset($data_info['category_path'])?$data_info['category_path']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="log_path"  class="col-sm-2 control-label">日志目录</label>
                    <div class="col-sm-4">
                        <input name="log_path"  type="text"  id="log_path"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入日志目录"  value="<?php echo isset($data_info['log_path'])?$data_info['log_path']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="log_devel"  class="col-sm-2 control-label">日志级别</label>
                    <div class="col-sm-4">
                        <input name="log_devel"  type="number"  id="log_devel"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入纬度"  value="<?php echo isset($data_info['log_devel'])?$data_info['log_devel']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="interval"  class="col-sm-2 control-label">监控信息发送间隔</label>
                    <div class="col-sm-4">
                         <input name="interval"  type="number" id="interval"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入发送间隔"  value="<?php echo isset($data_info['interval'])?$data_info['interval']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="missCnt"  class="col-sm-2 control-label">心跳包丢失数</label>
                    <div class="col-sm-4">
                        <input name="missCnt"  type="number" id="missCnt"  cols="45" rows="5" class="form-control  validate[required]" placeholder="心跳包丢失数"  value="<?php echo isset($data_info['missCnt'])?$data_info['missCnt']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="watch_ip"  class="col-sm-2 control-label">监控信息发送ip</label>
                    <div class="col-sm-4">
                       <input name="watch_ip"  type="text" id="watch_ip"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入雷达发送ip"  value="<?php echo isset($data_info['watch_ip'])?$data_info['watch_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="watch_ip_port"  class="col-sm-2 control-label">监控信息发送端口</label>
                    <div class="col-sm-4">
                        <input name="watch_ip_port"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入雷达发送端口"  value="<?php echo isset($data_info['watch_ip_port'])?$data_info['watch_ip_port']:'' ?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <label for="send_result_ip"  class="col-sm-2 control-label">雷达验证结果发送ip</label>
                    <div class="col-sm-4">
                        <input name="send_result_ip"  type="text"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入雷达验证结果发送ip"  value="<?php echo isset($data_info['send_result_ip'])?$data_info['send_result_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="send_result_port"  class="col-sm-2 control-label">雷达验证结果发送端口</label>
                    <div class="col-sm-4">
                        <input name="send_result_port"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="雷达验证结果发送端口"  value="<?php echo isset($data_info['send_result_port'])?$data_info['send_result_port']:'' ?>"/>
                    </div>
                </div>
				<div class="form-group">
                    <label for="send_result_type"  class="col-sm-2 control-label">验证结果UDP发送类型</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="rader_kind">
                            <option value="1"  <?php echo ($data_info['send_result_type']==1)?"selected":''; ?>  >单播</option>
                            <option value="2" <?php echo ($data_info['send_result_type']==2)?"selected":''; ?> >组播</option>
                            <option value="3" <?php echo ($data_info['send_result_type']==3)?"selected":''; ?> >广播</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="recieve_program_ip"  class="col-sm-2 control-label">接收程序ip</label>
                    <div class="col-sm-4">
                        <input name="recieve_program_ip"  type="text" id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入雷达接收端口"  value="<?php echo isset($data_info['recieve_program_ip'])?$data_info['recieve_program_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="recieve_program_port"  class="col-sm-2 control-label">接收程序端口</label>
                    <div class="col-sm-4">
                        <input name="recieve_program_port"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入接收程序端口"  value="<?php echo isset($data_info['recieve_program_port'])?$data_info['recieve_program_port']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_height"  class="col-sm-2 control-label">匹配高度</label>
                    <div class="col-sm-4">
                        <input name="in_height"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配高度"  value="<?php echo isset($data_info['in_height'])?$data_info['in_height']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_speed"  class="col-sm-2 control-label">匹配速度</label>
                    <div class="col-sm-4">
                        <input name="in_speed"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配速度"  value="<?php echo isset($data_info['in_speed'])?$data_info['in_speed']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_time"  class="col-sm-2 control-label">匹配时间差</label>
                    <div class="col-sm-4">
                        <input name="in_time"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配速度"  value="<?php echo isset($data_info['in_time'])?$data_info['in_time']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_pos"  class="col-sm-2 control-label">匹配位置差</label>
                    <div class="col-sm-4">
                        <input name="in_pos"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配位置差"  value="<?php echo isset($data_info['in_pos'])?$data_info['in_pos']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_angle"  class="col-sm-2 control-label">匹配角度</label>
                    <div class="col-sm-4">
                        <input name="in_angle"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配角度"  value="<?php echo isset($data_info['in_angle'])?$data_info['in_angle']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_count"  class="col-sm-2 control-label">匹配轨迹最大点数</label>
                    <div class="col-sm-4">
                        <input name="in_count"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配角度"  value="<?php echo isset($data_info['in_count'])?$data_info['in_count']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="min_count"  class="col-sm-2 control-label">两轨最小点数</label>
                    <div class="col-sm-4">
                        <input name="min_count"  type="number"  id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配角度"  value="<?php echo isset($data_info['min_count'])?$data_info['min_count']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="rate"  class="col-sm-2 control-label">匹配度</label>
                    <div class="col-sm-4">
                        <input name="rate"  type="number"  step="0.1" id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入匹配角度"  value="<?php echo isset($data_info['rate'])?$data_info['rate']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="check_duration"  class="col-sm-2 control-label">验证周期</label>
                    <div class="col-sm-4">
                        <input name="check_duration"  type="number"   id=""  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入验证周期"  value="<?php echo isset($data_info['check_duration'])?$data_info['check_duration']:'' ?>"/>
                    </div>
                </div>
                </fieldset>
                 
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'station','rader_edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>
</form>
<script language="javascript" type="text/javascript">
    var id="<?php echo $data_info['id']?>";
    var folder_name = "<?php echo $folder_name?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/rader_base_set.js']);
    });
</script>