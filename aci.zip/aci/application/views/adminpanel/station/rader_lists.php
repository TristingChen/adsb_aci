<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    #tabContent{position: relative;}
    .work_option{display: none;margin: 0 AUTO;position: absolute;top: 20px;left:30%;background: gray;z-index: 1;width: 50%;}
    .work_grop{width: 90%;height: 90%;background: #fff}
    .modal-backdrop {z-index:0}
</style>
<div id="tabContent" class="tab-content">

    <div class='panel panel-default grid tab-pane fade in active'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-th-list'></i> 基站列表
            <div class='panel-tools'>
                <div class='btn-group'>
                    

                    <?php aci_ui_a($folder_name, 'station', 'rader_add', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-plus"></span> 添加') ?>
                    <!-- <?php aci_ui_a($folder_name, 'station', 'rader_base_set', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-cog"></span> 雷达基础参数配置') ?> -->
                    <?php aci_ui_a($folder_name, 'station', 'rader_produce_xml', '', ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 雷达配置文件生成') ?>
                    <?php if($fresh_xml_data):?>
                            <?php aci_ui_a($folder_name, 'publishDataDeploy', 'publish_file_add', $fresh_xml_data['id'], ' class="btn  btn-sm "', '<span class="glyphicon glyphicon-file"></span> 发布配置文件') ?>
                    <?php endif;?>
                </div>
                <div class='badge'><?php echo count($data_list) ?></div>
            </div>
        </div>
       <div class='panel-filter '>
        <!-- <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form> -->
    </div>
        <?php if ($data_list): ?>
            <div class="panel panel-body" id="network_A">
                <form method="post" id="form_list">
                    <div class="table-responsive">
                        <table class="table table-hover dataTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>雷达名</th>
                                <th>接收数据状态</th>
                                <th>经度</th>
                                <th>纬度</th>
                                <th>覆盖范围</th>
                                <th>建设高度</th>
                                <th>雷达接收ip</th>
                                <th>雷达接收端口</th>
                                <th>操作</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($data_list as $k => $v): ?>
                                <tr>
                                    <td><?php echo $k + 1 ?></td>
                                    <td><?php echo $v['name'] ?></td>
                                    <td><?php echo ($v['switch']==1)?"是":'否'; ?></td>
                                    <td><?php echo $v['longtitude']?></td>
                                    <td><?php echo $v['latitude']?></td>
                                    <td><?php echo $v['range']?></td>
                                    <td><?php echo $v['height']?></td>
                                    <td><?php echo $v['receive_ip'];?></td>
                                    <td><?php echo $v['receive_port'];?></td>
                                    <td>
                                        <?php aci_ui_a($folder_name, 'station', 'rader_info', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 详情') ?>
                                        <?php aci_ui_a($folder_name, 'station', 'rader_edit', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 修改') ?>
                                        <?php aci_ui_a($folder_name, 'station', 'rader_delete', $v['id'], ' class="btn btn-default btn-xs"', '<span class="glyphicon glyphicon-edit"></span> 删除') ?>
                                    </td>

                                </tr>

                                     
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($pages):?>
                        <div class=" panel-footer">
                            <div class="pull-left">
                            </div>
                            <div class="pull-right">
                                <?php echo $pages; ?>
                            </div>
                        </div>
                    <?php endif?>
                </form>
            </div>
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                    &times;
                                </button>
                                <h4 class="modal-title" id="myModalLabel">
                                    主备切换
                                </h4>
                            </div>
                            <div class="modal-body">
                               <select class="form-control validate[required]" name="modal_current_path" id="modal_current_path" >
                                    <option value="2">A</option>
                                    <option value="3">B</option>
                                </select>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">关闭
                                </button>
                                <button type="button" class="btn btn-primary" id="change_current_path">
                                    提交更改
                                </button>
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal -->
            </div>




        <?php else: ?>
            <div class="panel panel-body">
                <div class="alert alert-warning" role="alert"> 暂无数据显示... 您可以进行新增操作</div>
            </div>
        <?php endif; ?>
    </div>
    <div class='panel panel-default grid tab-pane fade' id="network_B">

    </div>
</div>

<script language="javascript" type="text/javascript">
    var folder_name = "<?php echo $folder_name;?>";
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/lists.js']);
    });
</script>
