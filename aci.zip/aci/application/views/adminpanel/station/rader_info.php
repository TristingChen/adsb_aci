
<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<style type="text/css">
    .dots_remove{cursor: pointer;top:6px;left:-20px;font-size: 20px }
</style>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
                雷达详情
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'station','rader_lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <legend>基本信息</legend>
                <div class="form-group">
                    <label for="name"  class="col-sm-2 control-label">雷达名称</label>
                    <div class="col-sm-4">
                        <input name="name"  type="text" id="name"  cols="45" rows="5" class="form-control  validate[required]" readonly placeholder="请输入雷达名称"  value="<?php echo isset($data_info['name'])?$data_info['name']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">    
                    <label for="rader_kind"  class="col-sm-2 control-label">雷达类型</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="rader_kind" id="rader_kind" disabled="disabled">
                            <?php foreach ($raders_kind_info as $key => $value):?>
                                <option value="<?php echo $value['id'] ?>" tmp_version = "<?php echo $value['versions'] ;?>"  <?php echo ($data_info['rader_kind']==$value['id'])?"selected":''; ?>  ><?php echo $value['rader_name_kind'] ?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="version"  class="col-sm-2 control-label">雷达数据版本</label>
                    <div class="col-sm-4">
                        <!-- <input name="version"  type="number" step="0.01" id="version"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入雷达数据版本"  value="<?php echo isset($data_info['version'])?$data_info['version']:'' ?>"/> -->

                        <select class="form-control validate[required]" name="version" id="version" disabled="disabled">
                            <?php if(isset($versions_data_arr)):?>
                                <?php foreach($versions_data_arr as $key => $value):?>
                                    <option value="<?php echo $value;?>" <?php echo $value==$data_info['version']?'selected':'';?> ><?php echo $value;?></option>
                                <?php endforeach;?>
                            <?php endif;?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="switch"  class="col-sm-2 control-label">接收数据状态</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="switch" disabled="disabled">
                            <option value="1" <?php echo $data_info['switch']==1?'selected':'';?> >是</option>
                            <option value="0" <?php echo $data_info['switch']==0?'selected':'';?>  >否</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="longtitude"  class="col-sm-2 control-label">经度</label>
                    <div class="col-sm-4">
                        <input name="longtitude"  type="number" step="0.01" id="longtitude" readonly  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入经度"  value="<?php echo isset($data_info['longtitude'])?$data_info['longtitude']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="latitude"  class="col-sm-2 control-label">纬度</label>
                    <div class="col-sm-4">
                        <input name="latitude"  type="number" step="0.01" id="latitude" readonly  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入纬度"  value="<?php echo isset($data_info['latitude'])?$data_info['latitude']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="range"  class="col-sm-2 control-label">覆盖范围</label>
                    <div class="col-sm-4">
                        <input name="range"  type="number" id="range"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入雷达覆盖范围"  readonly value="<?php echo isset($data_info['range'])?$data_info['range']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="height"  class="col-sm-2 control-label">建设高度</label>
                    <div class="col-sm-4">
                        <input name="height"  type="number" id="height"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入雷达高度" readonly  value="<?php echo isset($data_info['height'])?$data_info['height']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="in_work_option"  class="col-sm-2 control-label">通道首选项</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="in_work_option" disabled="disabled">
                            <option value="3" <?php echo isset($data_info['in_work_option'])&& $data_info['in_work_option'] == 3?'selected':''; ?> >AUTO</option>
                            <option value="1" <?php echo isset($data_info['in_work_option'])&&$data_info['in_work_option'] == 1?'selected':''; ?>  >A</option>
                            <option value="2" <?php echo isset($data_info['in_work_option'])&&$data_info['in_work_option'] == 2?'selected':''; ?>  >B</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="is_station"  class="col-sm-2 control-label">是否监控</label>
                    <div class="col-sm-5 ">

                        <label class="radio-inline  control-label">是</label>
                        <input type="radio" class="btn-radio " disabled="disabled" <?php echo $data_info['is_monitor']==1?'checked':'' ?> name="is_monitor" id="is_monitor2"
                               value="1"  >
                        <label class="radio-inline  control-label">否</label>
                        <input type="radio" name="is_monitor" id="is_monitor3" disabled="disabled"
                               value="0" <?php echo $data_info['is_monitor']==0?'checked':'' ?> >
                    </div>
                </div>
                <fieldset id="route_a">
                    <legend>雷达通道A</legend>
                <!-- <div class="form-group">
                    <label for="receive_ip"  class="col-sm-2 control-label">雷达通道A接收ip</label>
                    <div class="col-sm-4">
                        <input name="receive_ip"  type="text" id="receive_ip"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入雷达接收ip"  value="<?php echo isset($data_info['receive_ip'])?$data_info['receive_ip']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label class="col-sm-2 control-label">通道A数据传输方式</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="data_cast_type" id="data_cast_type1" disabled="disabled"
                                   value="1" <?php echo ($data_info['data_cast_type'] == 1) ? 'checked="checked"' : ''?>> 单播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="data_cast_type" id="data_cast_type2" disabled="disabled"
                                   value="2" <?php echo ($data_info['data_cast_type'] == 2) ? 'checked="checked"' : ''?>> 组播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="data_cast_type" id="data_cast_type3" disabled="disabled"
                                   value="3" <?php echo ($data_info['data_cast_type'] == 3) ? 'checked="checked"' : ''?>> 广播
                        </label>
                    </div>
                </div>
                <div class="form-group cast_type_ip_group" style="display: <?php echo ($data_info['data_cast_type'] == 2) ? '' : 'none'?>">
                    <label for="cast_type_ip_a" class="col-sm-2 control-label">雷达通道A组播地址</label>
                    <div class="col-sm-4">
                        <input name="cast_type_ip_a"  type="text" readonly id="cast_type_ip_a"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入组播地址"  value="<?php echo isset($data_info['cast_type_ip_a'])?$data_info['cast_type_ip_a']:'' ?>"/>
                    </div>
                </div>

                    <div class="form-group receive_ip_group" style="display: <?php echo $data_info['data_cast_type'] !=3?'':'none'; ?>">
                        <label for="receive_ip"  class="col-sm-2 control-label">雷达通道A接收ip</label>
                        <div class="col-sm-4">
                            <select class="form-control validate[required]" name="receive_ip" disabled="disabled">
                                    <?php echo exchange_eth_options(3,isset($data_info['receive_ip'])?$data_info['receive_ip']:1)?>
                                </select>
                        </div>
                    </div>
                    <div class="form-group broad_ip_a_group"  style="display: <?php echo $data_info['data_cast_type'] ==3?'':'none'; ?>">
                        <label for="receive_ip"  class="col-sm-2 control-label">雷达通道A广播地址</label>
                            <div class="col-sm-4">
                                    <input name="broad_ip_a"  type="text" readonly id="broad_ip_a"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入广播地址"  value="<?php echo isset($data_info['broad_ip_a'])?$data_info['broad_ip_a']:'' ?>"/>
                            </div>

                        </div>

                <div class="form-group">
                    <label for="receive_port"  class="col-sm-2 control-label">雷达通道A接收端口</label>
                    <div class="col-sm-4">
                        <input name="receive_port"  type="number" readonly step="0.0001" id="receive_port"  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入雷达接收端口"  value="<?php echo isset($data_info['receive_port'])?$data_info['receive_port']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="receive_port"  class="col-sm-2 control-label">雷达通道A屏蔽数据包前字节数(0-10)</label>
                    <div class="col-sm-4">
                        <input name="pre_abandon_bype_a"  type="number" readonly min=0 max=10 id="pre_abandon_bype_a"  cols="45" rows="5" class="form-control validate[required]"  placeholder="请输入屏蔽数据包前字节数"  value="<?php echo isset($data_info['pre_abandon_bype_a'])?$data_info['pre_abandon_bype_a']:0 ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="is_station"  class="col-sm-2 control-label">通道监控A开关</label>
                    <div class="col-sm-5 ">

                        <label class="radio-inline  control-label">是</label>
                        <input type="radio" class="btn-radio " disabled="disabled" <?php echo $data_info['path_switch_a']==1?'checked':'' ?> name="path_switch_a"
                               value="1" >
                        <label class="radio-inline  control-label">否</label>
                        <input type="radio" name="path_switch_a" disabled="disabled"
                               value="0" <?php echo $data_info['path_switch_a']==0?'checked':'' ?> >
                    </div>
                </div>
                <div class="form-group">
                    <label for="longtitude"  class="col-sm-2 control-label">通道A雷达转发地址:</label>
                    <div class="col-sm-4">
                        <p class="btn btn-primary" >添加地址</p>
                    </div>
                </div>
                <?php if(!empty($raders_arr)):?>
                    <?php foreach ($raders_arr as $key => $value):?>
                        <div class="form-group" dot_num = "<?php echo $key+1;?>">
                            <label for="longtitude"  class="col-sm-2 control-label dots" >转发地址<?php echo $key+1;?>:</label>

                            <div class="controls controls-row col-xs-2">
                                <input name="resend_ip[]"  class="form-control validate[required]" type="text" readonly  placeholder="转发地址ip"  value="<?php echo isset($value['resend_ip'])?$value['resend_ip']:'' ?>"/>
                            </div>
                            <div class="controls controls-row col-xs-2">

                                <input name="resend_port[]"  class="form-control validate[required]" type="number" readonly id="resend_port"   placeholder="转发地址端口"  value="<?php echo isset($value['resend_port'])?$value['resend_port']:'' ?>"/>
                            </div>
                            <div class="controls controls-row col-xs-2">

                                <select  class="form-control cast_type_select" onchange="show_next(this,'<?php echo $value['resend_group_ip'];?>',0)" name="cast_type[]" disabled="disabled">
                                    <?php echo  cast_type_options(isset($value['cast_type'])?$value['cast_type']:1)?>
                                </select>
                            </div>
                            <?php  if($value['cast_type'] == 2):?>
                                 <div class="controls controls-row col-xs-2 resend_group_ip_a_input">
                                        <input name="resend_group_ip_a[]"  class="form-control validate[required]" type="text" readonly  placeholder="转发组播地址"  value="<?php echo isset($value['resend_group_ip'])?$value['resend_group_ip']:'' ?>"/>
                                  </div>
                            <?php endif;?>
                            <div class="controls controls-row col-xs-2">
                                <!-- <span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span> -->
                            </div>

                        </div>
                    <?php endforeach;?>
                <?php endif; ?>
                </fieldset>
                <fieldset id="route_b">
                    <legend>雷达通道B</legend>
                <!-- <div class="form-group">
                    <label for="receive_ip"  class="col-sm-2 control-label">雷达通道B接收ip</label>
                    <div class="col-sm-4">
                        <input name="receive_ip_b"  type="text" id="receive_ip_b"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入雷达接收ip"  value="<?php echo isset($data_info['receive_ip_b'])?$data_info['receive_ip_b']:'' ?>"/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label class="col-sm-2 control-label">通道B数据传输方式</label>
                    <div class="col-sm-5">
                        <label class="radio-inline">
                            <input type="radio" name="data_cast_type_b" id="data_cast_type_b1" disabled="disabled"
                                   value="1" <?php echo ($data_info['data_cast_type_b'] == 1) ? 'checked="checked"' : ''?>> 单播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="data_cast_type_b" id="data_cast_type_b2" disabled="disabled"
                                   value="2" <?php echo ($data_info['data_cast_type_b'] == 2) ? 'checked="checked"' : ''?>> 组播
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="data_cast_type_b" id="data_cast_type_b3" disabled="disabled"
                                   value="3" <?php echo ($data_info['data_cast_type_b'] == 3) ? 'checked="checked"' : ''?>> 广播
                        </label>
                    </div>
                </div>

                <div class="form-group cast_type_ip_b_group" style="display: <?php echo ($data_info['data_cast_type_b'] == 2) ? '' : 'none'?>">
                    <label for=" cast_type_ip_b" class="col-sm-2 control-label">雷达通道B组播地址</label>
                    <div class="col-sm-4">
                        <input name=" cast_type_ip_b"  type="text" readonly id=" cast_type_ip_b"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入组播地址"  value="<?php echo isset($data_info[' cast_type_ip_b'])?$data_info[' cast_type_ip_b']:'' ?>"/>
                    </div>
                </div>

                
                    <div class="form-group receive_ip_b_group" style="display: <?php echo $data_info['data_cast_type_b'] !=3?'':'none'; ?>">
                        <label for="receive_ip_b"  class="col-sm-2 control-label">雷达通道B接收ip</label>
                        <div class="col-sm-4">
                            <select class="form-control validate[required]"  name="receive_ip_b" disabled="disabled">
                                    <?php echo exchange_eth_options(3,isset($data_info['receive_ip_b'])?$data_info['receive_ip_b']:1)?>
                                </select>

                        </div>
                    </div>
              
                    <div class="form-group broad_ip_b_group" style="display: <?php echo $data_info['data_cast_type_b'] ==3?'':'none'; ?>">
                        <label for="broad_ip_b"  class="col-sm-2 control-label">雷达通道B广播地址</label>
                            <div class="col-sm-4">
                                    <input name="broad_ip_b"  type="text" readonly id="broad_ip_b"  cols="45" rows="5" class="form-control  validate[required,custom[recv_ip_A]]" placeholder="请输入广播地址"  value="<?php echo isset($data_info['broad_ip_b'])?$data_info['broad_ip_b']:'' ?>"/>
                            </div>

                    </div>

                
                <div class="form-group">
                    <label for="receive_port"  class="col-sm-2 control-label">雷达通道B接收端口</label>
                    <div class="col-sm-4">
                        <input name="receive_port_b"  type="number" readonly step="0.0001" id="receive_port_b"  cols="45" rows="5" class="form-control validate[required]" placeholder="" placeholder="请输入雷达接收端口"  value="<?php echo isset($data_info['receive_port_b'])?$data_info['receive_port_b']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="receive_port"  class="col-sm-2 control-label">雷达通道B屏蔽数据包前字节数(0-10)</label>
                    <div class="col-sm-4">
                        <input name="pre_abandon_bype_b"  type="number" readonly min=0 max=10 id="pre_abandon_bype_b"  cols="45" rows="5" class="form-control validate[required]"  placeholder="请输入屏蔽数据包前字节数"  value="<?php echo isset($data_info['pre_abandon_bype_b'])?$data_info['pre_abandon_bype_b']:0 ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="is_station"  class="col-sm-2 control-label">通道B监控开关</label>
                    <div class="col-sm-5 ">

                        <label class="radio-inline  control-label">是</label>
                        <input type="radio" class="btn-radio " <?php echo $data_info['path_switch_b']==1?'checked':'' ?> name="path_switch_b"
                               value="1" disabled="disabled" >
                        <label class="radio-inline  control-label">否</label>
                        <input type="radio" name="path_switch_b"
                               value="0" disabled="disabled" <?php echo $data_info['path_switch_b']==0?'checked':'' ?> >
                    </div>
                </div>
                <div class="form-group">
                    <label for="longtitude"  class="col-sm-2 control-label">通道B雷达转发地址:</label>
                    <div class="col-sm-4">
                        <p class="btn btn-primary" id="">添加地址</p>
                    </div>
                </div>
                <?php if(!empty($raders_arr_b)):?>
                    <?php foreach ($raders_arr_b as $key => $value):?>
                        <div class="form-group " dot_num = "<?php echo $key+1;?>">
                            <label for="longtitude"  class="col-sm-2 control-label dots" >转发地址<?php echo $key+1;?>:</label>

                            <div class="controls controls-row col-xs-2">
                                <input name="resend_ip_b[]"  class="form-control validate[required]" type="text" readonly  placeholder="转发地址ip"  value="<?php echo isset($value['resend_ip'])?$value['resend_ip']:'' ?>"/>
                            </div>
                            <div class="controls controls-row col-xs-2">

                                <input name="resend_port_b[]"  class="form-control validate[required]" type="number" readonly id="resend_port_b"   placeholder="转发地址端口"  value="<?php echo isset($value['resend_port'])?$value['resend_port']:'' ?>"/>
                            </div>
                            <div class="controls controls-row col-xs-2">

                                <select  class="form-control cast_type_b_select" onchange="show_next(this,'<?php echo $value['resend_group_ip'];?>',1)"  name="cast_type_b[]" disabled="disabled">
                                    <?php echo  cast_type_options(isset($value['cast_type'])?$value['cast_type']:1)?>
                                </select>
                            </div>
                            <?php  if($value['cast_type'] == 2):?>
                                 <div class="controls controls-row col-xs-2">
                                        <input name="resend_group_ip_b[]"  class="form-control validate[required]" type="text" readonly  placeholder="转发组播地址"  value="<?php echo isset($value['resend_group_ip'])?$value['resend_group_ip']:'' ?>"/>
                                  </div>
                            <?php endif;?>
                            <div class="controls controls-row col-xs-2">
                                <!-- <span class="glyphicon glyphicon-remove dots_remove" onclick="remove_self($(this))"></span> -->
                            </div>

                        </div>
                    <?php endforeach;?>
                <?php endif; ?>
                </fieldset>


            </fieldset>

           
        </div>
    </div>
</form>
<script language="javascript" type="text/javascript">
    var id="<?php echo $data_info['id']?>";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
    var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/rader_edit.js');?>;
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/rader_edit.js?t='+filemtime]);
    });
</script>