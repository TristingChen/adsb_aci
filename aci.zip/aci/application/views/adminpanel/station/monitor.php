<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<div id="content">
   <input type="radio" name="modeRadio" value="normal" checked id="r1"/>
   <label for="r1"> 默认</label>
   &nbsp;<input type="radio" name="modeRadio" value="select" id="r2"/><label for="r2"> 框选</label>
   &nbsp;&nbsp;<input type="button" id="centerButton" value="居中显示"/>
   <input type="button" id="fullScreenButton"  value="全屏显示"/>
   <input type="button" id="zoomOutButton" value=" 放 大 " />
   <input type="button" id="zoomInButton" value=" 缩 小 " />
   &nbsp;&nbsp;<input type="checkbox" id="zoomCheckbox"/><label for="zoomCheckbox">鼠标缩放</label>
   &nbsp;&nbsp;<input type="text" id="findText" style="width: 100px;" value="" onkeydown="enterPressHandler(event)">
   <input type="button" id="findButton" value=" 查 询 ">
   &nbsp;&nbsp;<input type="button" id="cloneButton" value="选中克隆">
   &nbsp;&nbsp;<input type="button" id="linkButton" value="加  线" onclick="window.location.href='<?php echo SITE_URL.$folder_name."/".$controller_name."/add_line"?>'">
   &nbsp;&nbsp;<input type="button" id="exportButton" value="导出PNG">
   &nbsp;&nbsp;<input type="button" id="printButton" value="导出PDF">
   <canvas height="500" width="800" id="canvas"></canvas>
</div>
<script language="javascript" type="text/javascript">
    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    // var to_end_notes = <?php echo to_end_notes()?>;
    var img_path = <?php echo IMG_PATH;?>;
    var data_list = <?php echo $data_list;?>
    // var server_data = <?php $server_data;?>;
    // console.log($server_data);
    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/lib/jtopo-0.4.8-min.js']);
        require(['<?php echo SITE_URL?>scripts/lib/jtopo-toolbar.js']);
        // require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/jtopoCommen.js']);
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/monitor.js']);
    });
</script>