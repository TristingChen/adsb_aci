<?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<style type="text/css">
    .red-color{color: red};
</style>
<div class="panel">
    <div class="panel-body">
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-th-list'></i> <?php echo $table_data['station_name']?> 数据站详情
            <div class='panel-tools'>
                <i class='glyphicon glyphicon-th-list'></i>  <?php echo date('Y-m-d H:i:s',strtotime($data_info[0])) ;?>
             </div>
        </div>

            <div class="col-md-3" >
                <div class="well ">
                    <table class="table">
                            <caption></caption>
                            <threa>
                                <tr>
                                    <th>输入子网</th>
                                </tr>
                                <tr>
                                    <th>A通道状态</th>
                                    <th><?php echo $data_info[4];?></th>
                                </tr>
                                 <tr>
                                    <th>A通道流量</th>
                                    <th><?php echo $data_info[5];?></th>
                                </tr>
                                <tr>
                                    <th>B通道状态</th>
                                    <th><?php echo $data_info[6];?></th>
                                </tr>
                                <tr>
                                    <th>B通道流量</th>
                                    <th><?php echo $data_info[7];?></th>
                                </tr>
                            </threa>
                    </table>
                </div>
            </div>
            <div class="col-md-3" >    
                <div class="well">
                    <table class="table">
                            <caption></caption>
                            <threa>
                                <tr>
                                    <th>输出子网</th>
                                </tr>
                                <tr>
                                    <th>A通道状态</th>
                                    <th class="<?php echo $data_info[8]!='OK'?'red-color':'';?>"><?php echo $data_info[8];?></th>
                                </tr>
                                 <tr>
                                    <th>A通道流量</th>
                                    <th><?php echo $data_info[9];?></th>
                                </tr>
                                <tr>
                                    <th>B通道状态</th>
                                    <th class="<?php echo $data_info[10]!='OK'?'red-color':'';?>"><?php echo $data_info[10];?></th>
                                </tr>
                                <tr>
                                    <th>B通道流量</th>
                                    <th><?php echo $data_info[11];?></th>
                                </tr>
                            </threa>
                    </table>
                </div>
            </div>
            <div class="col-md-3" >
                <div class="well">
                    <table class="table">
                            <caption></caption>
                            <threa>
                                <tr>
                                    <th>运行子网</th>
                                </tr>
                                <tr>
                                    <th>A通道状态</th>
                                    <th class="<?php echo $data_info[12]!='OK'?'red-color':'';?>"><?php echo $data_info[12];?></th>
                                </tr>
                                 <tr>
                                    <th>A通道流量</th>
                                    <th><?php echo $data_info[13];?></th>
                                </tr>
                                <tr>
                                    <th>B通道状态</th>
                                    <th class="<?php echo $data_info[14]!='OK'?'red-color':'';?>"><?php echo $data_info[14];?></th>
                                </tr>
                                <tr>
                                    <th>B通道流量</th>
                                    <th><?php echo $data_info[15];?></th>
                                </tr>
                            </threa>
                    </table>
                </div>
            </div>

            <div class="col-md-3" >
                <div class="well">
                    <table class="table">
                            <caption></caption>
                            <threa>
                                <tr>
                                    <th>旁路</th>
                                </tr>
                                <tr>
                                    <th>旁路状态</th>
                                    <th class="<?php echo $data_info[26]!='OK'?'red-color':'';?>"><?php echo $data_info[26];?></th>
                                </tr>
                                 <tr>
                                    <th>旁路主备状态</th>
                                    <th><?php echo $data_info[27];?></th>
                                </tr>
                                <tr>
                                    <th>旁路cpu</th>
                                    <th ><?php echo $data_info[28];?></th>
                                </tr>
                                <tr>
                                    <th>旁路内存</th>
                                    <th ><?php echo $data_info[29];?></th>
                                </tr>
                                <tr>
                                    <th>旁路磁盘</th>
                                    <th ><?php echo $data_info[30];?></th>
                                </tr>
                            </threa>
                    </table>
                </div>
            </div>

            <div class="col-md-3" >
                <div class="well">
                    <table class="table">
                            <caption></caption>
                            <threa>
                                <tr>
                                    <th>融合处理</th>
                                </tr>
                                 <tr>
                                    <th>A通道状态</th>
                                    <th class="<?php echo $data_info[16]!='OK'?'red-color':'';?>"><?php echo $data_info[16];?></th>
                                </tr>
                                 <tr>
                                    <th>A通道主备状态</th>
                                    <th><?php echo $data_info[17];?></th>
                                </tr>
                                <tr>
                                    <th>A通道cpu</th>
                                    <th ><?php echo $data_info[18];?></th>
                                </tr>
                                <tr>
                                    <th>A通道内存</th>
                                    <th ><?php echo $data_info[19];?></th>
                                </tr>
                                <tr>
                                    <th>A通道磁盘</th>
                                    <th ><?php echo $data_info[20];?></th>
                                </tr>
                                <tr>
                                    <th>B通道状态</th>
                                    <th class="<?php echo $data_info[21]!='OK'?'red-color':'';?>"><?php echo $data_info[21];?></th>
                                </tr>
                                 <tr>
                                    <th>B通道主备状态</th>
                                    <th><?php echo $data_info[22];?></th>
                                </tr>
                                <tr>
                                    <th>B通道cpu</th>
                                    <th ><?php echo $data_info[23];?></th>
                                </tr>
                                <tr>
                                    <th>B通道内存</th>
                                    <th ><?php echo $data_info[24];?></th>
                                </tr>
                                <tr>
                                    <th>B通道磁盘</th>
                                    <th ><?php echo $data_info[25];?></th>
                                </tr>


                                <tr>
                                    <th>tdoa验证</th>
                                    <th class="<?php echo $data_info[31]=='bad'?'red-color':'';?>"><?php echo $data_info[31];?></th>
                                </tr>
                                <tr>
                                    <th>雷达验证</th>
                                    <th class="<?php echo $data_info[32]=='bad'?'red-color':'';?>" ><?php echo $data_info[32];?></th>
                                </tr>
                                <tr>
                                    <th>过载状态</th>
                                    <th><?php echo $data_info[33];?></th>
                                </tr>
                            </threa>
                    </table>
                </div>
            </div>
            
            </div>
        </div>
    </div>
   


<script language="javascript" type="text/javascript">
        var folder_name = "<?php echo $folder_name;?>";
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/one_station_num_detail.js']);
    });
</script>