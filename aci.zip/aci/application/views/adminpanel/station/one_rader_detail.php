<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>

<style>
.div-box{text-align:center;font-size:18px}
.red_status{background: red};
</style>


<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='glyphicon glyphicon-th-list'></i> <?php echo $one_data_list['name']?> 雷达详情
        <div class='panel-tools'>
             <div class='btn-group' id="sound_switch" style="<?php echo $one_data_list['rader_alarm']>0?'':'display: none'; ?>">
                <?php if($one_data_list['sound_switch'] == 1):?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick="sound_alarm(<?php echo $one_data_list['id'];?>,0,2)"><span class="glyphicon glyphicon-volume-up"></span>告警铃声关闭</p>
                <?php else:?>
                    <p class="btn  btn-sm pull-right sound_alarm_switch" onclick='sound_alarm(<?php echo $hardware_id;?>,1,2)'><span class="glyphicon glyphicon-volume-up"></span>告警铃声开启</p>
                <?php endif;?>
            </div>
           
        </div>
    </div>
    <div class='panel-filter '>
        <!-- <form class="form-inline" role="form" method="get">
            <div class="form-group">
                <label for="keyword" class="form-control-static control-label">关键词</label>
                <input class="form-control" type="text" name="keyword" value="<?php echo $keyword; ?>" id="keyword"
                       placeholder="请输入关键词"/></div>
            <button type="submit" name="dosubmit" value="搜索" class="btn btn-success"><i
                    class="glyphicon glyphicon-search"></i></button>
        </form> -->
    </div>
    <form method="post" id="form_list">
            <!-- <div class="alert alert-warning" role="alert"> 暂无数据显示...</div> -->
            <div class="table-responsive">
                    <?php if($one_data_list):?>
                        <div class='panel-body '>
                            <table class="table table-hover table-bordered dataTable ">
                                <thead>
                                <tr>
                                    <th class="text-center">雷达名</th>
                                    <th  class="text-center">A通道开启状态</th>
                                    <th  class="text-center">A通道数据量</th>
                                    <th  class="text-center">A通道状态</th>
                                    <th  class="text-center">B通道开启状态</th>
                                    <th  class="text-center">B通道数据量</th>
                                    <th  class="text-center">B通道状态</th>
                                    <th  class="text-center">数据推送时间</th>
                                    <th  class="text-center">总状态</th>
                                </tr>
                                </thead>
                                <tbody>
                                 
                                    <tr class="text-center"  id="rader_body">
                                        <td><?php echo $one_data_list['name'];?></td>
                                        <td><?php echo $one_data_list['path_switch_a']?'开启':'关闭' ?></td>
                                        <td><?php echo $one_data_list['rader_a_bag']?></td>
                                        <?php  if($one_data_list['path_switch_a'] == 0):?>
                                        <td>A通道未监控</td>
                                        <?php else:?>
                                            <?php  if($one_data_list['path_a_alarm']):?>
                                                <td class="red_status">不正常:A通道数据量为0</td>
                                            <?php else:?>
                                                <td>正常</td>
                                            <?php endif;?>
                                        <?php  endif;?>    
                                        <td><?php echo $one_data_list['path_switch_b']?'开启':'关闭' ?></td>
                                        <td><?php echo $one_data_list['rader_b_bag'];?></td>
                                        <?php  if($one_data_list['path_switch_b'] == 0):?>
                                        <td>B通道未监控</td>
                                        <?php else:?>
                                            <?php  if($one_data_list['path_b_alarm']):?>
                                                <td class="red_status">不正常:B通道数据量为0</td>
                                            <?php else:?>
                                                <td>正常</td>
                                            <?php endif;?>
                                        <?php  endif;?> 
                                        <td><?php echo  date('Y-m-d H:i:s',$one_data_list['report_time'])== '1970-01-01 00:00:00'?'数据未能成功推送':date('Y-m-d H:i:s',$one_data_list['report_time']);?></td>
                                        <td class="<?php echo $one_data_list['rader_alarm']?'red_status':'';  ?>"><?php echo $one_data_list['rader_alarm']?'不正常':'正常';   ?></td>
                                    </tr>
                               
                                </tbody>
                            </table>
                        </div>
                        
                <?php else: ?>
                    <div class="alert alert-warning" role="alert"> 暂无数据显示...</div>
                <?php endif; ?>
                    </div>
    </form>

</div>
</div>
<script language="javascript" type="text/javascript">
    
    var controller_name = "<?php echo $controller_name?>";
    var folder_name = "<?php echo $folder_name?>";
    var rader_id = <?php echo $one_data_list['id'];?>;
    var filemtime = <?php echo filemtime(FCPATH.'scripts/'.$folder_name.'/'.$controller_name.'/one_rader_detail.js');?>;

    require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/sound_alarm.js']);
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/one_rader_detail.js?t='+filemtime]);
    });
</script>