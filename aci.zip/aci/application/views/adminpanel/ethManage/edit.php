<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo current_url()?>"
      xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

    <div class='panel panel-default'>
        <div class='panel-heading'>
            <i class='glyphicon glyphicon-edit'></i>
            <?php echo $is_edit?"修改":"新增"?>设备网口配置
            <div class='panel-tools'>
                <div class='btn-group'>
                    <?php aci_ui_a($folder_name,'ethManage','lists','',' class="btn  btn-sm pull-right"','<span class="glyphicon glyphicon-arrow-left"></span> 返回')?>
                </div>
            </div>
        </div>
        <div class='panel-body'>
            <fieldset>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">设备名称</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="hardware_id">
                            <?php echo hardware_options($data_info['hardware_id'])?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="eth_num" class="col-sm-2 control-label">网口编号</label>
                    <div class="col-sm-9">
                        <input name="eth_num"  type="text" id="eth_num"  cols="45" rows="5" class="form-control  validate[required]" placeholder="请输入网口编号"  value="<?php echo isset($data_info['eth_num'])?$data_info['eth_num']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="eth_ip" class="col-sm-2 control-label">网口IP</label>
                    <div class="col-sm-9">
                        <input name="eth_ip"  type="text" id="eth_ip"  cols="45" rows="5" class="form-control  validate[required,custom[eth_ip]]" placeholder="请输入网口IP"  value="<?php echo isset($data_info['eth_ip'])?$data_info['eth_ip']:'' ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="eth_ip" class="col-sm-2 control-label">网口类型</label>
                    <div class="col-sm-4">
                        <select class="form-control validate[required]" name="eth_type">
                            <option value="0" <?php echo isset($data_info['eth_type'])?'selected':''; ?> >运行子网</option>
                            <option value="1" <?php echo isset($data_info['eth_type'])?'selected':''; ?> >输入子网</option>
                            <option value="2" <?php echo isset($data_info['eth_type'])?'selected':''; ?> >输出子网</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="net_type" class="col-sm-2 control-label">网络类型</label>
                    <div class="col-sm-5">
                    <label class="radio-inline">
                        <input type="radio" name="net_type" id="net_type1"
                               value="0" <?php echo (isset($data_info['net_type'])&&$data_info['net_type'] == 0) ? 'checked="checked"' : ''?>> S网
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="net_type" id="net_type2"
                               value="1" <?php echo (isset($data_info['net_type'])&&$data_info['net_type'] == 1) ? 'checked="checked"' : ''?>> A网
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="net_type" id="net_type3"
                               value="2" <?php echo (isset($data_info['net_type'])&&$data_info['net_type'] == 2) ? 'checked="checked"' : ''?>> B网
                    </label>
                </div>
                </div>
            </fieldset>
            <div class='form-actions'>
                <?php aci_ui_button($folder_name,'ethManage','edit','type="submit" id="dosubmit" class="btn btn-primary "','保存')?>
            </div>
        </div>
    </div>

</form>
<script language="javascript" type="text/javascript">
    var id="<?php echo $data_info['eth_id']?>";
    var edit= <?php echo $is_edit?"true":"false"?>;
    var folder_name = "<?php echo $folder_name?>";
        require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
        require(['<?php echo SITE_URL?>scripts/<?php echo $folder_name?>/<?php echo $controller_name?>/edit.js']);
    });
</script>